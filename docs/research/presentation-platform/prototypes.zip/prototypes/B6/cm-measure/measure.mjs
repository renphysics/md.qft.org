// Measures minified / gzip / brotli sizes for CodeMirror 6 feature sets, relative to the site's current baseline.
import { build } from 'esbuild';
import { gzipSync, brotliCompressSync, constants } from 'node:zlib';
import { mkdirSync, writeFileSync } from 'node:fs';

const BASE = `
import { basicSetup } from 'codemirror';
import { Compartment, EditorState } from '@codemirror/state';
import { EditorView, keymap } from '@codemirror/view';
import { markdown } from '@codemirror/lang-markdown';
import { HighlightStyle, syntaxHighlighting } from '@codemirror/language';
import { openSearchPanel } from '@codemirror/search';
import { isolateHistory, undo } from '@codemirror/commands';
import { tags } from '@lezer/highlight';
export const base = [basicSetup, Compartment, EditorState, EditorView, keymap, markdown(), HighlightStyle, syntaxHighlighting, openSearchPanel, isolateHistory, undo, tags];
`;
const scenarios = {
  '00-baseline (site today: basicSetup+markdown)': '',
  '01-+html()': `import { html } from '@codemirror/lang-html'; export const x = [html()];`,
  '02-+css()': `import { css } from '@codemirror/lang-css'; export const x = [css()];`,
  '03-+javascript({ts,jsx})': `import { javascript } from '@codemirror/lang-javascript'; export const x = [javascript({typescript:true,jsx:true})];`,
  '04-+json()+jsonParseLinter': `import { json, jsonParseLinter } from '@codemirror/lang-json'; import { linter } from '@codemirror/lint'; export const x = [json(), linter(jsonParseLinter())];`,
  '05-+yaml()': `import { yaml } from '@codemirror/lang-yaml'; export const x = [yaml()];`,
  '06-+vue()': `import { vue } from '@codemirror/lang-vue'; export const x = [vue()];`,
  '07-+xml() (svg)': `import { xml } from '@codemirror/lang-xml'; export const x = [xml()];`,
  '08-+lint (linter,lintGutter,diagnostics)': `import { linter, lintGutter, setDiagnostics, forceLinting, lintKeymap } from '@codemirror/lint'; export const x = [linter, lintGutter, setDiagnostics, forceLinting, lintKeymap];`,
  '09-+merge (MergeView+unifiedMergeView)': `import { MergeView, unifiedMergeView, acceptChunk, rejectChunk, getChunks, presentableDiff } from '@codemirror/merge'; export const x = [MergeView, unifiedMergeView, acceptChunk, rejectChunk, getChunks, presentableDiff];`,
  '10-+merge unifiedMergeView only': `import { unifiedMergeView, acceptChunk, rejectChunk } from '@codemirror/merge'; export const x = [unifiedMergeView, acceptChunk, rejectChunk];`,
  '11-+autocomplete extras (snippets, completeFromList)': `import { autocompletion, snippetCompletion, completeFromList, startCompletion } from '@codemirror/autocomplete'; export const x = [autocompletion, snippetCompletion, completeFromList, startCompletion];`,
  '12-+html+css+js+json+yaml+vue+xml': `import { html } from '@codemirror/lang-html'; import { css } from '@codemirror/lang-css'; import { javascript } from '@codemirror/lang-javascript'; import { json, jsonParseLinter } from '@codemirror/lang-json'; import { yaml } from '@codemirror/lang-yaml'; import { vue } from '@codemirror/lang-vue'; import { xml } from '@codemirror/lang-xml'; import { linter, lintGutter } from '@codemirror/lint';
     export const x = [html(), css(), javascript({typescript:true,jsx:true}), json(), linter(jsonParseLinter()), lintGutter(), yaml(), vue(), xml()];`,
  '13-all langs + lint + merge (recommended editor set)': `import { html } from '@codemirror/lang-html'; import { css } from '@codemirror/lang-css'; import { javascript } from '@codemirror/lang-javascript'; import { json, jsonParseLinter } from '@codemirror/lang-json'; import { yaml } from '@codemirror/lang-yaml'; import { vue } from '@codemirror/lang-vue'; import { xml } from '@codemirror/lang-xml'; import { linter, lintGutter, setDiagnostics } from '@codemirror/lint'; import { MergeView, unifiedMergeView, acceptChunk, rejectChunk } from '@codemirror/merge';
     export const x = [html(), css(), javascript({typescript:true,jsx:true}), json(), linter(jsonParseLinter()), lintGutter(), setDiagnostics, yaml(), vue(), xml(), MergeView, unifiedMergeView, acceptChunk, rejectChunk];`,
  '14-+markdown codeLanguages via language-data (all chunks)': `import { languages } from '@codemirror/language-data'; import { markdown as md2 } from '@codemirror/lang-markdown'; export const x = [md2({codeLanguages: languages})];`,
  '15-+jsdiff (diff@9: structuredPatch/applyPatch/parsePatch)': `import { applyPatch, parsePatch, structuredPatch, createTwoFilesPatch, diffLines } from 'diff'; export const x = [applyPatch, parsePatch, structuredPatch, createTwoFilesPatch, diffLines];`,
  '16-+diff-match-patch': `import DMP from 'diff-match-patch'; export const x = [DMP];`,
};
mkdirSync('entries', { recursive: true });
mkdirSync('out', { recursive: true });
const rows = [];
let baseline;
for (const [name, extra] of Object.entries(scenarios)) {
  const id = name.slice(0, 2);
  const entry = `entries/${id}.js`;
  writeFileSync(entry, BASE + extra);
  const result = await build({ entryPoints: [entry], bundle: true, minify: true, format: 'esm', target: 'es2022', splitting: true, outdir: `out/${id}`, metafile: true, logLevel: 'silent', legalComments: 'none' });
  let raw = 0, gz = 0, br = 0, files = 0, entryRaw = 0, entryGz = 0;
  for (const [file, info] of Object.entries(result.metafile.outputs)) {
    const bytes = (await import('node:fs')).readFileSync(file);
    raw += bytes.length; gz += gzipSync(bytes, { level: 9 }).length;
    br += brotliCompressSync(bytes, { params: { [constants.BROTLI_PARAM_QUALITY]: 11 } }).length; files += 1;
    if (info.entryPoint) { entryRaw = bytes.length; entryGz = gzipSync(bytes, { level: 9 }).length; }
  }
  const row = { name, files, raw, gz, br, entryRaw, entryGz };
  if (!baseline) baseline = row;
  rows.push(row);
}
const kb = (n) => (n / 1024).toFixed(1).padStart(8);
console.log('scenario'.padEnd(62), 'files', '  min KB', '  gz KB', '   br KB', ' +min KB', ' +gz KB', ' +br KB', ' entry-only +gz');
for (const r of rows) console.log(r.name.padEnd(62), String(r.files).padStart(5), kb(r.raw), kb(r.gz), kb(r.br), kb(r.raw - baseline.raw), kb(r.gz - baseline.gz), kb(r.br - baseline.br), kb(r.entryGz - baseline.entryGz));
writeFileSync('results.json', JSON.stringify(rows, null, 2));
