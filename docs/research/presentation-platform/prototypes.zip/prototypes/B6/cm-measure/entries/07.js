
import { basicSetup } from 'codemirror';
import { Compartment, EditorState } from '@codemirror/state';
import { EditorView, keymap } from '@codemirror/view';
import { markdown } from '@codemirror/lang-markdown';
import { HighlightStyle, syntaxHighlighting } from '@codemirror/language';
import { openSearchPanel } from '@codemirror/search';
import { isolateHistory, undo } from '@codemirror/commands';
import { tags } from '@lezer/highlight';
export const base = [basicSetup, Compartment, EditorState, EditorView, keymap, markdown(), HighlightStyle, syntaxHighlighting, openSearchPanel, isolateHistory, undo, tags];
import { xml } from '@codemirror/lang-xml'; export const x = [xml()];