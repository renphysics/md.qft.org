
import { basicSetup } from 'codemirror';
import { Compartment, EditorState } from '@codemirror/state';
import { EditorView, keymap } from '@codemirror/view';
import { markdown } from '@codemirror/lang-markdown';
import { HighlightStyle, syntaxHighlighting } from '@codemirror/language';
import { openSearchPanel } from '@codemirror/search';
import { isolateHistory, undo } from '@codemirror/commands';
import { tags } from '@lezer/highlight';
export const base = [basicSetup, Compartment, EditorState, EditorView, keymap, markdown(), HighlightStyle, syntaxHighlighting, openSearchPanel, isolateHistory, undo, tags];
import { html } from '@codemirror/lang-html'; import { css } from '@codemirror/lang-css'; import { javascript } from '@codemirror/lang-javascript'; import { json, jsonParseLinter } from '@codemirror/lang-json'; import { yaml } from '@codemirror/lang-yaml'; import { vue } from '@codemirror/lang-vue'; import { xml } from '@codemirror/lang-xml'; import { linter, lintGutter } from '@codemirror/lint';
     export const x = [html(), css(), javascript({typescript:true,jsx:true}), json(), linter(jsonParseLinter()), lintGutter(), yaml(), vue(), xml()];