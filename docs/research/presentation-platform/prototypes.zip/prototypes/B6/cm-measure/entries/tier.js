
import { basicSetup } from 'codemirror';
import { Compartment, EditorState } from '@codemirror/state';
import { EditorView, keymap } from '@codemirror/view';
import { markdown } from '@codemirror/lang-markdown';
import { HighlightStyle, syntaxHighlighting } from '@codemirror/language';
import { openSearchPanel } from '@codemirror/search';
import { isolateHistory, undo } from '@codemirror/commands';
import { tags } from '@lezer/highlight';
export const base = [basicSetup, Compartment, EditorState, EditorView, keymap, markdown(), HighlightStyle, syntaxHighlighting, openSearchPanel, isolateHistory, undo, tags];
import { html } from '@codemirror/lang-html'; import { css } from '@codemirror/lang-css'; import { javascript } from '@codemirror/lang-javascript'; import { json, jsonParseLinter } from '@codemirror/lang-json'; import { yaml, yamlFrontmatter } from '@codemirror/lang-yaml'; import { vue } from '@codemirror/lang-vue'; import { linter, lintGutter, setDiagnostics } from '@codemirror/lint';
export const langs = [html(), css(), javascript({ typescript: true, jsx: true }), json(), linter(jsonParseLinter()), lintGutter(), setDiagnostics, yaml(), yamlFrontmatter, vue()];import { MergeView, unifiedMergeView, acceptChunk, rejectChunk, getChunks, getOriginalDoc, presentableDiff } from '@codemirror/merge'; export const merge = [MergeView, unifiedMergeView, acceptChunk, rejectChunk, getChunks, getOriginalDoc, presentableDiff];import { mapRevealDeck, mapSlidevMarkdownExact, slideAtOffset, slidifyRanges } from '../slide-map.mjs'; export const map = [mapRevealDeck, mapSlidevMarkdownExact, slideAtOffset, slidifyRanges];import { parseAnswer, applyAnswer, failureReport } from '../patch-apply.mjs'; export const patch = [parseAnswer, applyAnswer, failureReport];