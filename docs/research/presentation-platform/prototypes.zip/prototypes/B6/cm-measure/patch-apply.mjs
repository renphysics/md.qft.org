// Prototype: apply an AI chat answer to an in-browser project without calling any AI service (task B6).
// Accepts, in one pasted text: SEARCH/REPLACE blocks, unified diffs (line numbers ignored), OpenAI
// "*** Begin Patch" (V4A) blocks, and whole files in fenced code blocks that are labelled with a path.
// Nothing is written: the result is a candidate revision plus a report, to be reviewed as a diff.

const normEol = (text) => text.replace(/\r\n?/g, '\n');
const PATH = String.raw`[\w@.+\-/ ]+\.[\w]+`;

/** Find `needle` lines inside `hay` lines with progressively looser matching. Returns {index, level} or null. */
export function locate(hayLines, needleLines, hint = 0) {
  if (!needleLines.length) return null;
  const levels = [
    (s) => s,                                  // exact
    (s) => s.replace(/[ \t]+$/, ''),           // ignore trailing whitespace
    (s) => s.trim(),                           // ignore indentation
    (s) => s.trim().replace(/\s+/g, ' '),      // collapse inner whitespace
    (s) => s.trim().replace(/\s+/g, ' ').replace(/[“”]/g, '"').replace(/[‘’]/g, "'").replace(/[–—]/g, '-').replace(/ /g, ' '), // typographic drift
  ];
  for (let level = 0; level < levels.length; level += 1) {
    const f = levels[level];
    const hay = hayLines.map(f);
    const needle = needleLines.map(f);
    const hits = [];
    outer: for (let i = 0; i + needle.length <= hay.length; i += 1) {
      for (let j = 0; j < needle.length; j += 1) if (hay[i + j] !== needle[j]) continue outer;
      hits.push(i);
    }
    if (hits.length === 1) return { index: hits[0], level, ambiguous: false };
    if (hits.length > 1) {
      // Prefer the hit nearest to the hint (for example the line number in a hunk header or the current slide).
      hits.sort((a, b) => Math.abs(a - hint) - Math.abs(b - hint));
      return { index: hits[0], level, ambiguous: true, candidates: hits.length };
    }
  }
  return null;
}

function resolvePath(files, raw) {
  let path = raw.trim().replace(/^["'`*]+|["'`*:]+$/g, '').replace(/^(?:a|b)\//, '').replace(/^\.\//, '');
  if (files.has(path)) return path;
  // Unique basename match ("slides.md" for "source/slides.md").
  const matches = [...files.keys()].filter((key) => key === path || key.endsWith('/' + path) || path.endsWith('/' + key));
  return matches.length === 1 ? matches[0] : path;
}

/** Parse a pasted chat answer into edit operations. */
export function parseAnswer(text, files, { defaultPath } = {}) {
  const source = normEol(text);
  const lines = source.split('\n');
  const ops = [];
  const used = new Array(lines.length).fill(false);
  const mark = (from, to) => { for (let i = from; i < to; i += 1) used[i] = true; };
  const pathBefore = (index) => {
    // Look up to three non-empty lines above for something that names a file.
    for (let i = index - 1, seen = 0; i >= 0 && seen < 3; i -= 1) {
      const line = lines[i].trim();
      if (!line) continue;
      seen += 1;
      if (/^(```|~~~)/.test(line)) continue;
      const match = line.match(new RegExp(String.raw`(?:^|[\s:*#\x60(])(${PATH})[\x60*:)]*\s*$`));
      if (match && !/\s/.test(match[1].trim())) return match[1].trim();
    }
    return null;
  };

  // 1. OpenAI V4A patches.
  for (let i = 0; i < lines.length; i += 1) {
    if (!/^\*\*\* Begin Patch/.test(lines[i])) continue;
    let j = i + 1; let current = null;
    for (; j < lines.length && !/^\*\*\* End Patch/.test(lines[j]); j += 1) {
      const header = lines[j].match(/^\*\*\* (Update|Add|Delete) File: (.+)$/);
      if (header) {
        current = { kind: header[1] === 'Add' ? 'create' : header[1] === 'Delete' ? 'delete' : 'hunks', path: resolvePath(files, header[2]), hunks: [], content: [], format: 'v4a' };
        ops.push(current); continue;
      }
      if (!current) continue;
      if (current.kind === 'create') { if (lines[j].startsWith('+')) current.content.push(lines[j].slice(1)); continue; }
      if (/^@@/.test(lines[j])) { current.hunks.push({ lines: [], anchor: lines[j].replace(/^@@\s*/, '').trim() }); continue; }
      if (/^\*\*\* End of File/.test(lines[j])) continue;
      if (!current.hunks.length) current.hunks.push({ lines: [] });
      if (/^[ +-]/.test(lines[j]) || lines[j] === '') current.hunks[current.hunks.length - 1].lines.push(lines[j] === '' ? ' ' : lines[j]);
    }
    mark(i, j + 1); i = j;
  }

  // 2. SEARCH/REPLACE blocks (Aider style), with or without a surrounding code fence.
  for (let i = 0; i < lines.length; i += 1) {
    if (used[i] || !/^<{5,9} ?SEARCH\s*$/.test(lines[i])) continue;
    let mid = -1, end = -1;
    for (let j = i + 1; j < lines.length; j += 1) {
      if (mid < 0 && /^={5,9}\s*$/.test(lines[j])) mid = j;
      else if (mid >= 0 && /^>{5,9} ?REPLACE\s*$/.test(lines[j])) { end = j; break; }
    }
    if (mid < 0 || end < 0) { ops.push({ kind: 'error', message: `An unfinished SEARCH/REPLACE block starts at line ${i + 1} of the answer.` }); continue; }
    const path = pathBefore(i) ?? defaultPath;
    ops.push({ kind: 'search-replace', path: path ? resolvePath(files, path) : undefined, search: lines.slice(i + 1, mid), replace: lines.slice(mid + 1, end), format: 'search-replace' });
    mark(i, end + 1); i = end;
  }

  // 3. Unified diffs. Hunk line numbers and counts are treated as hints only.
  for (let i = 0; i < lines.length; i += 1) {
    if (used[i]) continue;
    const isHeader = /^--- /.test(lines[i]) && /^\+\+\+ /.test(lines[i + 1] ?? '');
    const bareHunk = /^@@ .*@@/.test(lines[i]) || /^@@\s*$/.test(lines[i]);
    if (!isHeader && !bareHunk) continue;
    let path; let j = i;
    if (isHeader) {
      const from = lines[i].slice(4).trim().split('\t')[0]; const to = lines[i + 1].slice(4).trim().split('\t')[0];
      path = to === '/dev/null' ? from : to; j = i + 2;
      if (from === '/dev/null') {
        const content = []; for (; j < lines.length && /^(@@|\+)/.test(lines[j]); j += 1) if (lines[j].startsWith('+')) content.push(lines[j].slice(1));
        ops.push({ kind: 'create', path: resolvePath(files, path), content, format: 'unified' }); mark(i, j); i = j - 1; continue;
      }
      if (to === '/dev/null') { for (; j < lines.length && /^(@@|-)/.test(lines[j]); j += 1); ops.push({ kind: 'delete', path: resolvePath(files, path), format: 'unified' }); mark(i, j); i = j - 1; continue; }
    } else path = pathBefore(i) ?? defaultPath;
    const op = { kind: 'hunks', path: path ? resolvePath(files, path) : undefined, hunks: [], format: 'unified' };
    for (; j < lines.length; j += 1) {
      const header = lines[j].match(/^@@(?: -(\d+)(?:,\d+)? \+\d+(?:,\d+)?)?(?: ?@@)?(.*)$/);
      if (header) { op.hunks.push({ lines: [], hint: header[1] ? Number(header[1]) - 1 : 0 }); continue; }
      if (!op.hunks.length) break;
      if (/^[ +-]/.test(lines[j])) op.hunks[op.hunks.length - 1].lines.push(lines[j]);
      else if (lines[j] === '' && /^[ +-]/.test(lines[j + 1] ?? '')) op.hunks[op.hunks.length - 1].lines.push(' '); // chat UIs strip the lone space of an empty context line
      else if (/^\\ No newline/.test(lines[j])) continue;
      else break;
    }
    if (op.hunks.length) { ops.push(op); mark(i, j); i = j - 1; }
  }

  // 4. Whole files: a fenced block labelled with a known or plausible path.
  for (let i = 0; i < lines.length; i += 1) {
    if (used[i]) continue;
    const open = lines[i].match(/^(\s*)(`{3,}|~{3,})\s*([\w+-]*)\s*(.*)$/);
    if (!open) continue;
    let j = i + 1;
    for (; j < lines.length; j += 1) if (lines[j].trim() === open[2] || (lines[j].trim().startsWith(open[2]) && /^[`~]+$/.test(lines[j].trim()))) break;
    // A fence that only wraps a patch already consumed above is not a whole file.
    if (used.slice(i + 1, j).some(Boolean)) { mark(i, j + 1); i = j; continue; }
    const info = open[4].match(new RegExp(String.raw`(?:title=|file=|filename=)?["']?(${PATH})["']?`));
    let path = info ? info[1] : pathBefore(i);
    const body = lines.slice(i + 1, j);
    if (!path) { const first = (body[0] ?? '').match(new RegExp(String.raw`^\s*(?:<!--|//|#|/\*)\s*(?:file(?:name)?:\s*)?(${PATH})\s*(?:-->|\*/)?\s*$`, 'i')); if (first && files.has(resolvePath(files, first[1]))) { path = first[1]; body.shift(); } }
    if (path) {
      const resolved = resolvePath(files, path);
      ops.push({ kind: files.has(resolved) ? 'replace-file' : 'create', path: resolved, content: body, format: 'whole-file' });
      mark(i, j + 1);
    }
    i = j;
  }
  return ops;
}

/** Apply operations to a Map<path,string>. Returns { files: Map, report: [...] } and never throws. */
export function applyAnswer(files, ops, { hintLine = () => 0 } = {}) {
  const next = new Map(files);
  const report = [];
  const eolOf = (text) => (/\r\n/.test(text) ? '\r\n' : '\n');
  for (const op of ops) {
    const entry = { path: op.path, kind: op.kind, format: op.format, status: 'applied', detail: '' };
    report.push(entry);
    if (op.kind === 'error') { entry.status = 'failed'; entry.detail = op.message; continue; }
    if (!op.path) { entry.status = 'failed'; entry.detail = 'The answer does not say which file this change belongs to.'; continue; }
    if (op.kind === 'create' || op.kind === 'replace-file') {
      const previous = next.get(op.path);
      const eol = previous === undefined ? '\n' : eolOf(previous);
      let content = op.content.join(eol);
      if (previous === undefined || /\n$/.test(previous)) content = content.replace(/(\r?\n)*$/, '') + eol;
      // Guard against "lazy" answers that elide code: "... rest of the file unchanged ...".
      const lazy = op.content.find((line) => /^\s*(?:<!--|\/\/|#|\/\*)?\s*\.{3}\s*(?:rest|remaining|existing|unchanged|other|same|previous)\b/i.test(line) || /\b(?:rest of (?:the )?(?:file|code|slides)|unchanged|remains the same|same as before)\b.*\.{3}/i.test(line));
      if (lazy && op.kind === 'replace-file') { entry.status = 'failed'; entry.detail = `The replacement for ${op.path} contains a placeholder instead of real content: "${lazy.trim().slice(0, 80)}". Ask for the complete file or for SEARCH/REPLACE blocks.`; continue; }
      if (previous !== undefined && previous.length > 400 && content.length < previous.length * 0.4) entry.detail = `Warning: the new file is ${Math.round((content.length / previous.length) * 100)}% of the old size.`;
      next.set(op.path, content);
      continue;
    }
    if (op.kind === 'delete') { if (!next.has(op.path)) { entry.status = 'failed'; entry.detail = 'File not found.'; } else next.delete(op.path); continue; }
    const current = next.get(op.path);
    if (current === undefined) { entry.status = 'failed'; entry.detail = `File not found: ${op.path}. Files: ${[...next.keys()].slice(0, 8).join(', ')}`; continue; }
    const eol = eolOf(current);
    let lines = normEol(current).split('\n');
    const blocks = op.kind === 'search-replace' ? [{ search: op.search, replace: op.replace, hint: hintLine(op.path) }]
      : op.hunks.map((hunk) => ({ search: hunk.lines.filter((l) => l[0] !== '+').map((l) => l.slice(1)), replace: hunk.lines.filter((l) => l[0] !== '-').map((l) => l.slice(1)), hint: hunk.hint ?? hintLine(op.path), anchor: hunk.anchor }));
    const notes = [];
    for (const block of blocks) {
      // Trim empty lines that chat rendering tends to add or drop at block edges.
      let search = block.search.slice(); let replace = block.replace.slice();
      if (!search.some((l) => l.trim())) {
        if (op.kind === 'search-replace' && !lines.join('').trim()) { lines = replace; continue; }
        entry.status = 'failed'; notes.push('A change has no "before" text to locate.'); continue;
      }
      let found = locate(lines, search, block.hint);
      if (!found) {
        while (search.length && !search[0].trim()) { search.shift(); if (replace.length && !replace[0].trim()) replace.shift(); }
        while (search.length && !search[search.length - 1].trim()) { search.pop(); if (replace.length && !replace[replace.length - 1].trim()) replace.pop(); }
        found = locate(lines, search, block.hint);
      }
      if (!found) { entry.status = 'failed'; notes.push(`Could not find this text in ${op.path}:\n${search.slice(0, 6).join('\n')}`); continue; }
      if (found.ambiguous) notes.push(`The "before" text occurs ${found.candidates} times; the occurrence nearest to line ${block.hint + 1} was used.`);
      if (found.level >= 2) {
        // Re-indent the replacement to the indentation actually present in the file.
        const fileIndent = (lines[found.index].match(/^\s*/) ?? [''])[0];
        const patchIndent = (search.find((l) => l.trim())?.match(/^\s*/) ?? [''])[0];
        if (fileIndent !== patchIndent) replace = replace.map((l) => (l.trim() ? (l.startsWith(patchIndent) ? fileIndent + l.slice(patchIndent.length) : fileIndent + l.trimStart()) : l));
        notes.push(`Matched after ignoring ${['', 'trailing spaces', 'indentation', 'spacing', 'punctuation style'][found.level]}.`);
      }
      lines.splice(found.index, search.length, ...replace);
    }
    entry.detail = notes.join(' ');
    if (entry.status === 'applied') next.set(op.path, lines.join(eol));
    else if (blocks.length > 1 && notes.length < blocks.length) entry.detail = 'Some parts could not be placed; nothing in this file was changed. ' + entry.detail;
  }
  return { files: next, report };
}

/** A report the teacher can paste back to the AI when something did not apply. */
export function failureReport(report) {
  const failed = report.filter((entry) => entry.status === 'failed');
  if (!failed.length) return '';
  return ['Some of your changes could not be applied. Please resend only these, as SEARCH/REPLACE blocks whose SEARCH part is copied exactly from the current file:', ...failed.map((entry) => `- ${entry.path ?? '(no file named)'}: ${entry.detail}`)].join('\n');
}
