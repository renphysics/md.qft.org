import { build } from 'esbuild';
const entry = process.argv[2];
const r = await build({ entryPoints: [entry], bundle: true, minify: true, format: 'esm', target: 'es2022', write: false, metafile: true, logLevel: 'silent', legalComments: 'none' });
const out = Object.values(r.metafile.outputs)[0];
const per = {};
for (const [file, info] of Object.entries(out.inputs)) {
  const m = file.match(/node_modules\/((?:@[^/]+\/)?[^/]+)/);
  const k = m ? m[1] : file;
  per[k] = (per[k] || 0) + info.bytesInOutput;
}
const total = Object.values(per).reduce((a, b) => a + b, 0);
for (const [k, v] of Object.entries(per).sort((a, b) => b[1] - a[1])) console.log(k.padEnd(34), (v / 1024).toFixed(1).padStart(8), 'KB min', ((v / total) * 100).toFixed(1).padStart(6) + '%');
console.log('TOTAL'.padEnd(34), (total / 1024).toFixed(1).padStart(8), 'KB min');
