// Slide <-> source mapping prototype (research task B6).
// Pure functions, no DOM. Depends only on @lezer/html, which the site already ships
// (it is pulled in by @codemirror/lang-markdown -> @codemirror/lang-html).
import { parser as htmlParser } from '@lezer/html';

/* ----------------------------- Reveal.js: HTML ----------------------------- */

const lower = (text) => text.toLowerCase();

function openTag(element) {
  const first = element.firstChild;
  return first && (first.name === 'OpenTag' || first.name === 'SelfClosingTag') ? first : null;
}

function tagName(source, element) {
  const tag = openTag(element);
  const name = tag?.getChild('TagName');
  return name ? lower(source.slice(name.from, name.to)) : '';
}

function attributes(source, element) {
  const out = new Map();
  const tag = openTag(element);
  if (!tag) return out;
  for (let node = tag.firstChild; node; node = node.nextSibling) {
    if (node.name !== 'Attribute') continue;
    const name = node.getChild('AttributeName');
    if (!name) continue;
    const value = node.getChild('AttributeValue') ?? node.getChild('UnquotedAttributeValue');
    let text = value ? source.slice(value.from, value.to) : '';
    if (/^["']/.test(text)) text = text.slice(1, -1);
    out.set(lower(source.slice(name.from, name.to)), text);
  }
  return out;
}

function childElements(element) {
  const out = [];
  for (let node = element.firstChild; node; node = node.nextSibling) if (node.name === 'Element') out.push(node);
  return out;
}

function findSlidesRoot(source, top) {
  // Depth-first search for <div class="slides">; prefer one inside class="reveal".
  let fallback = null;
  const visit = (node, insideReveal) => {
    for (const element of childElements(node)) {
      const classes = (attributes(source, element).get('class') ?? '').split(/\s+/);
      if (classes.includes('slides')) { if (insideReveal) return element; fallback ??= element; }
      const found = visit(element, insideReveal || classes.includes('reveal'));
      if (found) return found;
    }
    return null;
  };
  return visit(top, false) ?? fallback;
}

/** Reveal's markdown plugin de-indents inline templates before splitting. Keep an offset map. */
export function deindentWithMap(text) {
  const leadingWs = text.match(/^\n?(\s*)/)[1].length;
  const leadingTabs = text.match(/^\n?(\t*)/)[1].length;
  let pattern = null;
  if (leadingTabs > 0) pattern = new RegExp('\\n?\\t{' + leadingTabs + '}(.*)', 'g');
  else if (leadingWs > 1) pattern = new RegExp('\\n? {' + leadingWs + '}(.*)', 'g');
  if (!pattern) return { text, toOriginal: (offset) => offset };
  let out = '';
  let last = 0;
  const segments = []; // [outStart, originalStart, length] for copied runs
  const copy = (from, to) => { if (to > from) { segments.push([out.length, from, to - from]); out += text.slice(from, to); } };
  for (let match; (match = pattern.exec(text));) {
    copy(last, match.index);
    out += '\n'; // synthetic newline: maps to the start of the match
    segments.push([out.length - 1, match.index, 0]);
    const groupStart = match.index + match[0].length - match[1].length;
    copy(groupStart, groupStart + match[1].length);
    last = match.index + match[0].length;
    if (match[0].length === 0) pattern.lastIndex += 1;
  }
  copy(last, text.length);
  const toOriginal = (offset) => {
    let lo = 0, hi = segments.length - 1, best = segments[0] ?? [0, 0, 0];
    while (lo <= hi) { const mid = (lo + hi) >> 1; if (segments[mid][0] <= offset) { best = segments[mid]; lo = mid + 1; } else hi = mid - 1; }
    return best[1] + Math.min(offset - best[0], best[2]);
  };
  return { text: out, toOriginal };
}

/** Port of reveal.js 6.0.2 plugin/markdown/plugin.js slidify(), returning ranges instead of HTML. */
export function slidifyRanges(markdown, options = {}) {
  const separator = options.separator || '\r?\n---\r?\n';
  const verticalSeparator = options.verticalSeparator || null;
  const separatorRegex = new RegExp(separator + (verticalSeparator ? '|' + verticalSeparator : ''), 'mg');
  const horizontalSeparatorRegex = new RegExp(separator);
  const stack = [];
  let lastIndex = 0, wasHorizontal = true, matches;
  while ((matches = separatorRegex.exec(markdown))) {
    const isHorizontal = horizontalSeparatorRegex.test(matches[0]);
    if (!isHorizontal && wasHorizontal) stack.push([]);
    const range = { from: lastIndex, to: matches.index };
    if (isHorizontal && wasHorizontal) stack.push(range);
    else stack[stack.length - 1].push(range);
    lastIndex = separatorRegex.lastIndex;
    wasHorizontal = isHorizontal;
    if (matches[0].length === 0) separatorRegex.lastIndex += 1;
  }
  (wasHorizontal ? stack : stack[stack.length - 1]).push({ from: lastIndex, to: markdown.length });
  return stack; // array of range | range[] (vertical stack)
}

/**
 * Map every runtime slide (h, v) of a Reveal.js HTML deck to a source range.
 * readFile(path) supplies external Markdown referenced by data-markdown="file.md".
 */
export function mapRevealDeck(html, readFile = () => undefined, htmlPath = 'index.html', options = {}) {
  const tree = htmlParser.parse(html);
  const root = findSlidesRoot(html, tree.topNode);
  const slides = [];
  const problems = [];
  const hidden = [];
  if (!root) return { slides, problems: ['No <div class="slides"> element was found.'] };
  let h = 0;
  const pushHtml = (element, hIndex, vIndex, stackElement) => {
    const open = openTag(element);
    const close = element.lastChild?.name === 'CloseTag' ? element.lastChild : null;
    slides.push({ h: hIndex, v: vIndex, kind: 'html', file: htmlPath, from: element.from, to: element.to,
      innerFrom: open ? open.to : element.from, innerTo: close ? close.from : element.to,
      stackFrom: stackElement?.from, stackTo: stackElement?.to });
  };
  const markdownSection = (element, attrs, emit) => {
    const options = { separator: attrs.get('data-separator'), verticalSeparator: attrs.get('data-separator-vertical') };
    const external = attrs.get('data-markdown');
    if (external) {
      const text = readFile(external);
      if (text === undefined) { problems.push(`External Markdown is missing: ${external}`); emit([{ from: element.from, to: element.to }], htmlPath, 'html-missing-markdown', (o) => o); return; }
      emit(slidifyRanges(text, options), external, 'markdown', (offset) => offset);
      return;
    }
    // Inline: <textarea data-template> or the first <script> inside the section; otherwise the section text.
    let template = null;
    const search = (node) => { for (const child of childElements(node)) { if (template) return; const a = attributes(html, child); const name = tagName(html, child); if (a.has('data-template') || name === 'script') { template = child; return; } search(child); } };
    search(element);
    const host = template ?? element;
    const open = openTag(host);
    const close = host.lastChild?.name === 'CloseTag' ? host.lastChild : null;
    const innerFrom = open ? open.to : host.from;
    const innerTo = close ? close.from : host.to;
    const { text, toOriginal } = deindentWithMap(html.slice(innerFrom, innerTo));
    emit(slidifyRanges(text, options), htmlPath, 'markdown-inline', (offset) => innerFrom + toOriginal(offset));
  };
  for (const section of childElements(root)) {
    if (tagName(html, section) !== 'section') continue;
    const attrs = attributes(html, section);
    // Reveal removes data-visibility="hidden" slides from the DOM during initialization
    // (js/reveal.js removeHiddenSlides, unless config.showHiddenSlides is set).
    if (attrs.get('data-visibility') === 'hidden' && !options.showHiddenSlides) { hidden.push({ file: htmlPath, from: section.from, to: section.to }); continue; }
    if (attrs.has('data-markdown')) {
      markdownSection(section, attrs, (stack, file, kind, map) => {
        for (const entry of stack) {
          const list = Array.isArray(entry) ? entry : [entry];
          list.forEach((range, v) => slides.push({ h, v, kind, file, from: map(range.from), to: map(range.to), vertical: Array.isArray(entry) }));
          h += 1;
        }
      });
      continue;
    }
    const nested = childElements(section).filter((child) => tagName(html, child) === 'section')
      .filter((child) => { const hide = attributes(html, child).get('data-visibility') === 'hidden' && !options.showHiddenSlides; if (hide) hidden.push({ file: htmlPath, from: child.from, to: child.to }); return !hide; });
    if (!nested.length) { pushHtml(section, h, 0); h += 1; continue; }
    let v = 0;
    for (const child of nested) {
      const childAttrs = attributes(html, child);
      if (childAttrs.has('data-markdown')) {
        // A vertical Markdown child can itself expand; Reveal flattens horizontal separators into siblings.
        markdownSection(child, childAttrs, (stack, file, kind, map) => {
          for (const entry of stack) for (const range of (Array.isArray(entry) ? entry : [entry])) { slides.push({ h, v, kind, file, from: map(range.from), to: map(range.to) }); v += 1; }
        });
      } else { pushHtml(child, h, v, section); v += 1; }
    }
    h += 1;
  }
  return { slides, problems, hidden };
}

/** Which slide contains a given source offset (editor cursor -> slide)? */
export function slideAtOffset(map, file, offset) {
  let best = null;
  for (const slide of map.slides) if (slide.file === file && offset >= slide.from && offset <= slide.to && (!best || slide.to - slide.from < best.to - best.from)) best = slide;
  if (best) return best;
  // Between slides (for example on a separator line): choose the next slide in that file.
  return map.slides.filter((slide) => slide.file === file && slide.from >= offset).sort((a, b) => a.from - b.from)[0] ?? null;
}

/* --------------------------------- Slidev --------------------------------- */

/**
 * Minimal Slidev slides.md splitter that reproduces @slidev/parser's slide boundaries
 * (start line, frontmatter range, content range, notes comment) without the YAML dependency.
 * Rules (parser/src/core.ts in @slidev/parser 53.x): a line that is exactly `---` (trailing
 * whitespace allowed) separates slides unless it is inside a fenced code block; a separator that
 * is followed by a frontmatter block (closed by another `---` line) keeps that block with the slide.
 */
export function mapSlidevMarkdown(markdown, file = 'slides.md') {
  const lines = markdown.split(/\r?\n/);
  const offsets = []; // start offset of every line
  { let at = 0; const re = /\r?\n/g; offsets.push(0); for (let m; (m = re.exec(markdown));) offsets.push(m.index + m[0].length); }
  const slides = [];
  let start = 0;
  let contentStart = 0;
  let frontmatter = null;
  const push = (end) => {
    if (start === end && !slides.length && !frontmatter) { /* empty leading chunk */ }
    slides.push({ no: slides.length + 1, file, startLine: start, endLine: end, contentStartLine: contentStart,
      frontmatterLines: frontmatter, from: offsets[start] ?? markdown.length, to: end < offsets.length ? offsets[end] : markdown.length });
  };
  const isSeparator = (line) => /^---+\s*$/.test(line) && line.trimEnd() === '---';
  const fence = (line) => { const m = line.match(/^\s{0,3}(`{3,}|~{3,})/); return m ? m[1] : null; };
  let i = 0;
  const takeFrontmatter = (at) => {
    // at = index of an opening `---`; a frontmatter block needs a closing `---` and YAML-looking lines.
    for (let j = at + 1; j < lines.length; j += 1) {
      if (isSeparator(lines[j])) return j;
      if (fence(lines[j])) return -1;
    }
    return -1;
  };
  // Headmatter
  if (isSeparator(lines[0] ?? '')) {
    const close = takeFrontmatter(0);
    if (close > 0) { frontmatter = [0, close]; contentStart = close + 1; i = close + 1; }
  }
  let open = null;
  for (; i < lines.length; i += 1) {
    const line = lines[i];
    const marker = fence(line);
    if (open) { if (marker && marker[0] === open[0] && marker.length >= open.length && line.trim() === marker) open = null; continue; }
    if (marker) { open = marker; continue; }
    if (!isSeparator(line)) continue;
    push(i);
    const close = takeFrontmatter(i);
    const looksLikeYaml = close > i && lines.slice(i + 1, close).every((l) => l.trim() === '' || /^\s*(#|[\w-]+\s*:|-\s)/.test(l) || /^\s+\S/.test(l));
    if (close > i && looksLikeYaml) { start = i; frontmatter = [i, close]; contentStart = close + 1; i = close; }
    else { start = i + 1; frontmatter = null; contentStart = i + 1; }
  }
  push(lines.length);
  return { slides };
}

/**
 * Exact port of the slide-boundary rules in @slidev/parser 53.1.0 parseSync() (dist/core.mjs:420-469):
 * - a line whose trimEnd() starts with `---` ends the current slide;
 * - if that line is exactly three dashes and the next line is non-blank, a frontmatter block runs to the
 *   next line equal to `---`;
 * - only backtick fences are skipped (a `~~~` fence does NOT protect a `---` line);
 * - `---` inside an HTML comment is ignored.
 * Line numbers are 0-based and identical to the `start` value embedded in a built Slidev client.
 */
export function mapSlidevMarkdownExact(markdown, file = 'slides.md') {
  const text = markdown.replace(/^﻿/, '');
  const bom = markdown.length - text.length;
  const lines = text.split(/\r?\n/g);
  const offsets = [0];
  for (const match of text.matchAll(/\r?\n/g)) offsets.push(match.index + match[0].length);
  const lineOffset = (line) => bom + (line < offsets.length ? offsets[line] : text.length);
  const slides = [];
  let start = 0, contentStart = 0, inComment = false;
  const comment = (line, inside) => {
    let cursor = 0;
    while (cursor < line.length) {
      if (inside) { const end = line.indexOf('-->', cursor); if (end < 0) return true; inside = false; cursor = end + 3; }
      else { const open = line.indexOf('<!--', cursor); if (open < 0) return false; const end = line.indexOf('-->', open + 4); if (end < 0) return true; cursor = end + 3; }
    }
    return inside;
  };
  const slice = (end) => {
    if (start === end) return;
    slides.push({ no: slides.length + 1, file, startLine: start, contentStartLine: contentStart, endLine: end,
      from: lineOffset(start), contentFrom: lineOffset(contentStart), to: lineOffset(end) });
    start = end + 1; contentStart = end + 1;
  };
  for (let i = 0; i < lines.length; i += 1) {
    const raw = lines[i];
    const line = raw.trimEnd();
    if (inComment) { inComment = comment(raw, true); continue; }
    if (line.startsWith('---')) {
      slice(i);
      const next = lines[i + 1];
      if (line[3] !== '-' && next?.trim()) {
        start = i;
        for (i += 1; i < lines.length; i += 1) if (lines[i].trimEnd() === '---') break;
        contentStart = i + 1;
      }
    } else if (line.trimStart().startsWith('```')) {
      const level = line.match(/^\s*`+/)[0];
      let j = i + 1;
      for (; j < lines.length; j += 1) if (lines[j].startsWith(level)) break;
      if (j !== lines.length) i = j;
    } else inComment = comment(raw, false);
  }
  if (start <= lines.length - 1) slice(lines.length);
  return { slides };
}
