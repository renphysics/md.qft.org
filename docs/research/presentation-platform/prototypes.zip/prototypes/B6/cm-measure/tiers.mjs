import { build } from 'esbuild';
import { gzipSync } from 'node:zlib';
import { writeFileSync } from 'node:fs';
const BASE = `
import { basicSetup } from 'codemirror';
import { Compartment, EditorState } from '@codemirror/state';
import { EditorView, keymap } from '@codemirror/view';
import { markdown } from '@codemirror/lang-markdown';
import { HighlightStyle, syntaxHighlighting } from '@codemirror/language';
import { openSearchPanel } from '@codemirror/search';
import { isolateHistory, undo } from '@codemirror/commands';
import { tags } from '@lezer/highlight';
export const base = [basicSetup, Compartment, EditorState, EditorView, keymap, markdown(), HighlightStyle, syntaxHighlighting, openSearchPanel, isolateHistory, undo, tags];
`;
const LANGS = `import { html } from '@codemirror/lang-html'; import { css } from '@codemirror/lang-css'; import { javascript } from '@codemirror/lang-javascript'; import { json, jsonParseLinter } from '@codemirror/lang-json'; import { yaml, yamlFrontmatter } from '@codemirror/lang-yaml'; import { vue } from '@codemirror/lang-vue'; import { linter, lintGutter, setDiagnostics } from '@codemirror/lint';
export const langs = [html(), css(), javascript({ typescript: true, jsx: true }), json(), linter(jsonParseLinter()), lintGutter(), setDiagnostics, yaml(), yamlFrontmatter, vue()];`;
const MERGE = `import { MergeView, unifiedMergeView, acceptChunk, rejectChunk, getChunks, getOriginalDoc, presentableDiff } from '@codemirror/merge'; export const merge = [MergeView, unifiedMergeView, acceptChunk, rejectChunk, getChunks, getOriginalDoc, presentableDiff];`;
const MAP = `import { mapRevealDeck, mapSlidevMarkdownExact, slideAtOffset, slidifyRanges } from '../slide-map.mjs'; export const map = [mapRevealDeck, mapSlidevMarkdownExact, slideAtOffset, slidifyRanges];`;
const PATCH = `import { parseAnswer, applyAnswer, failureReport } from '../patch-apply.mjs'; export const patch = [parseAnswer, applyAnswer, failureReport];`;
const tiers = { 'baseline (today)': BASE, 'MVP: + HTML/CSS/JS/TS/JSON/YAML/Vue + lint': BASE + LANGS, 'Solid: + merge review + slide map + AI patch import': BASE + LANGS + MERGE + MAP + PATCH };
let first;
for (const [name, src] of Object.entries(tiers)) {
  writeFileSync('entries/tier.js', src);
  const r = await build({ entryPoints: ['entries/tier.js'], bundle: true, minify: true, format: 'esm', target: 'es2022', write: false, logLevel: 'silent', legalComments: 'none' });
  const bytes = r.outputFiles[0].contents; const gz = gzipSync(bytes, { level: 9 }).length;
  first ??= { raw: bytes.length, gz };
  console.log(name.padEnd(56), `${(bytes.length / 1024).toFixed(1)} KB min, ${(gz / 1024).toFixed(1)} KB gz  (+${((bytes.length - first.raw) / 1024).toFixed(1)} KB min, +${((gz - first.gz) / 1024).toFixed(1)} KB gz)`);
}
