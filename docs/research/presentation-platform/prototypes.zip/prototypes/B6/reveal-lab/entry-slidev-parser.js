import { parseSync } from '@slidev/parser/core';
export { parseSync };
