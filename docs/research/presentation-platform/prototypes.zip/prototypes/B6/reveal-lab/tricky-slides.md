---
theme: default
title: Tricky deck
---

# Cover

<!-- speaker note for cover -->

---

# Plain separator slide

Some text

```md
---
this is not: a separator
---
```

---
layout: two-cols
class: text-center
---

# Frontmatter slide

::right::

Right column

---

# Slide with table

| a | b |
|---|---|
| 1 | 2 |

~~~yaml
---
fenced: yaml
---
~~~

---
src: ./pages/other.md
---

---

# Last slide

<!--
Multi-line
note
-->
