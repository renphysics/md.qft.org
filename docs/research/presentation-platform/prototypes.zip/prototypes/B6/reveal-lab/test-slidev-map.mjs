import { readFileSync } from 'node:fs';
import { parseSync } from '@slidev/parser/core';
import { mapSlidevMarkdownExact as mapSlidevMarkdown } from './slide-map.mjs';
const files = process.argv.slice(2);
let bad = 0;
for (const file of files) {
  const text = readFileSync(file, 'utf8');
  const t0 = performance.now(); const official = parseSync(text, file); const t1 = performance.now();
  const mine = mapSlidevMarkdown(text, file); const t2 = performance.now();
  console.log(`\n== ${file} (${text.length} chars): @slidev/parser ${official.slides.length} slides in ${(t1 - t0).toFixed(1)} ms; minimal splitter ${mine.slides.length} slides in ${(t2 - t1).toFixed(2)} ms`);
  const n = Math.max(official.slides.length, mine.slides.length);
  for (let i = 0; i < n; i += 1) {
    const a = official.slides[i]; const b = mine.slides[i];
    const same = a && b && a.start === b.startLine && a.end === b.endLine && a.contentStart === b.contentStartLine;
    if (!same) bad += 1;
    console.log(`  #${i + 1} official start=${a?.start} contentStart=${a?.contentStart} end=${a?.end} title=${JSON.stringify(a?.title)} | mine start=${b?.startLine} contentStart=${b?.contentStartLine} end=${b?.endLine} ${same ? 'OK' : 'DIFF'}`);
  }
}
console.log(bad ? `\nDIFFERENCES: ${bad}` : '\nALL SLIDE BOUNDARIES MATCH @slidev/parser');
