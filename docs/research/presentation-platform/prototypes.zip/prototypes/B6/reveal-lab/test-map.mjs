import { createRequire } from 'node:module';
import { readFileSync } from 'node:fs';
import { mapRevealDeck, slideAtOffset } from './slide-map.mjs';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const norm = (s) => s.replace(/\s+/g, ' ').trim();
const browser = await chromium.launch();
let failures = 0;
for (const name of ['demo.html', 'md-deck.html']) {
  const html = readFileSync(`deck/${name}`, 'utf8');
  const t0 = performance.now();
  const map = mapRevealDeck(html, (path) => { try { return readFileSync(`deck/${path}`, 'utf8'); } catch { return undefined; } }, name);
  const ms = performance.now() - t0;
  const page = await browser.newPage();
  await page.route(/^https?:\/\/(?!127\.0\.0\.1)/, (route) => route.abort());
  await page.goto(`http://127.0.0.1:4571/${name}`);
  await page.waitForFunction(() => window.Reveal && Reveal.isReady());
  const real = await page.evaluate(() => Reveal.getSlides().map((slide) => { const i = Reveal.getIndices(slide); const heading = slide.querySelector('h1,h2,h3,h4'); return { h: i.h, v: i.v || 0, heading: heading ? heading.textContent : '', text: slide.textContent.slice(0, 4000) }; }));
  await page.close();
  console.log(`\n== ${name}: mapper ${map.slides.length} slides in ${ms.toFixed(1)} ms (${(html.length / 1024).toFixed(1)} KB); Reveal reports ${real.length} slides; problems: ${JSON.stringify(map.problems)}`);
  const key = (s) => `${s.h}.${s.v}`;
  const byKey = new Map(map.slides.map((s) => [key(s), s]));
  let ok = 0;
  for (const slide of real) {
    const mapped = byKey.get(key(slide));
    if (!mapped) { console.log('  MISSING in map', key(slide), JSON.stringify(norm(slide.heading))); failures += 1; continue; }
    const source = mapped.file === name ? html.slice(mapped.from, mapped.to) : readFileSync(`deck/${mapped.file}`, 'utf8').slice(mapped.from, mapped.to);
    // The heading words must be present in the mapped source range (tags and Markdown syntax removed).
    const plain = norm(source.replace(/<[^>]+>/g, ' ').replace(/&[a-z]+;/g, ' ').replace(/[#*_`]/g, ''));
    const want = norm(slide.heading.replace(/[^\p{L}\p{N} ]/gu, ' ')).slice(0, 24);
    const have = norm(plain.replace(/[^\p{L}\p{N} ]/gu, ' '));
    const good = want === '' ? true : have.includes(want);
    if (good) ok += 1; else { failures += 1; console.log('  MISMATCH', key(slide), JSON.stringify(want), '<->', JSON.stringify(have.slice(0, 80))); }
  }
  if (map.slides.length !== real.length) { failures += 1; console.log('  COUNT MISMATCH'); }
  console.log(`  ${ok}/${real.length} slides: the runtime heading is inside the mapped source range`);
  for (const s of map.slides.slice(0, 60)) if (name === 'md-deck.html') console.log(`   ${key(s).padEnd(5)} ${s.kind.padEnd(16)} ${s.file}:${s.from}-${s.to}  ${JSON.stringify(norm((s.file === name ? html : readFileSync(`deck/${s.file}`, 'utf8')).slice(s.from, s.to)).slice(0, 46))}`);
  // Reverse direction: cursor offset -> slide
  if (name === 'demo.html') { const at = html.indexOf('Touch Optimized'); const s = slideAtOffset(map, name, at); console.log('  cursor on "Touch Optimized" ->', s && key(s), ' real:', key(real.find((r) => r.heading.includes('Touch Optimized')))); }
}
await browser.close();
console.log(failures ? `\nFAILURES: ${failures}` : '\nALL MAPPINGS VERIFIED');
