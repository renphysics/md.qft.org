const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage();
  const violations = [];
  page.on('console', (m) => { if (/Refused|blocked|Not allowed/i.test(m.text())) violations.push(m.text().slice(0, 160)); });
  await page.goto('http://127.0.0.1:4578/');
  console.log(JSON.stringify(await page.evaluate(() => window.run()), null, 1));
  console.log('console:', JSON.stringify(violations.slice(0, 3)));
  await browser.close();
})();
