const { chromium } = require('playwright');
(async () => {
  for (const args of [[], ['--enable-blink-features=WebMCP,DeclarativeWebMCP'], ['--enable-features=WebMCP,DeclarativeWebMCP', '--enable-blink-features=WebMCP,DeclarativeWebMCP'], ['--enable-experimental-web-platform-features', '--enable-blink-features=WebMCP'], ['--enable-blink-test-features']]) {
    const browser = await chromium.launch({ args });
    const page = await browser.newPage();
    await page.goto('http://127.0.0.1:4570/');
    const out = await page.evaluate(async () => {
      const r = { nav: 'modelContext' in navigator, doc: 'modelContext' in document, win: 'modelContext' in window, ModelContext: typeof window.ModelContext, formTool: 'toolName' in HTMLFormElement.prototype };
      const mc = navigator.modelContext || document.modelContext || window.modelContext;
      if (mc) {
        r.methods = Object.getOwnPropertyNames(Object.getPrototypeOf(mc));
        try {
          const res = mc.registerTool({ name: 'qft_get_current_slide', description: 'Return the current slide number', inputSchema: { type: 'object', properties: {} }, async execute() { return { content: [{ type: 'text', text: '3' }] }; } });
          r.registerTool = 'ok ' + typeof res;
        } catch (e) { r.registerTool = 'error ' + e; }
      }
      return r;
    });
    console.log(JSON.stringify(args), JSON.stringify(out));
    await browser.close();
  }
})();
