const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch();
  console.log('browser version', browser.version());
  const page = await browser.newPage();
  await page.goto('http://127.0.0.1:4570/');
  const out = await page.evaluate(() => window.probe());
  console.log(JSON.stringify(out, null, 1));
  await browser.close();
})();
