const { chromium } = require('playwright');
(async () => {
  for (const args of [['--enable-experimental-web-platform-features'], ['--enable-features=WebMCP'], ['--enable-features=WebMCPTesting,WebMCP,ModelContext'], ['--enable-blink-features=WebMCP'], ['--enable-blink-features=ModelContext']]) {
    const browser = await chromium.launch({ args });
    const page = await browser.newPage();
    await page.goto('http://127.0.0.1:4570/');
    const out = await page.evaluate(() => ({
      modelContext: typeof navigator.modelContext,
      modelContextKeys: navigator.modelContext ? Object.getOwnPropertyNames(Object.getPrototypeOf(navigator.modelContext)) : null,
      modelContextTesting: typeof navigator.modelContextTesting,
      Writer: typeof window.Writer, Rewriter: typeof window.Rewriter, Proofreader: typeof window.Proofreader,
      FileSystemSyncAccessHandle: typeof window.FileSystemSyncAccessHandle,
      toolAttrs: 'toolName' in HTMLFormElement.prototype || 'toolname' in HTMLFormElement.prototype,
    }));
    console.log(JSON.stringify(args), JSON.stringify(out));
    await browser.close();
  }
})();
