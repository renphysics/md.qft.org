const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ args: ['--enable-blink-features=WebMCP'] });
  const page = await browser.newPage();
  await page.goto('http://127.0.0.1:4570/');
  const out = await page.evaluate(async () => {
    const project = new Map([['slides.md', '# One\n\n---\n\n# Two\n']]);
    let current = 2;
    const mc = document.modelContext;
    await mc.registerTool({ name: 'qft_get_current_slide', description: 'Return the number, title and Markdown source of the slide the teacher is looking at.', inputSchema: { type: 'object', properties: {} }, annotations: { readOnlyHint: true }, async execute() { return JSON.stringify({ no: current, file: 'slides.md', source: project.get('slides.md').split(/\n---\n/)[current - 1].trim() }); } });
    await mc.registerTool({ name: 'qft_read_file', description: 'Read one text file of the open presentation project.', inputSchema: { type: 'object', properties: { path: { type: 'string' } }, required: ['path'] }, annotations: { readOnlyHint: true }, async execute({ path }) { return project.get(path) ?? `No such file: ${path}`; } });
    await mc.registerTool({ name: 'qft_propose_edit', description: 'Propose a replacement of exact text in one file. The teacher reviews the change as a diff before it is applied.', inputSchema: { type: 'object', properties: { path: { type: 'string' }, search: { type: 'string' }, replace: { type: 'string' } }, required: ['path', 'search', 'replace'] }, async execute({ path, search, replace }) { const text = project.get(path); if (!text || !text.includes(search)) return 'Not applied: the search text was not found.'; window.pending = { path, next: text.replace(search, replace) }; return 'Proposed. Waiting for the teacher to accept the change.'; } });
    const tools = await mc.getTools();
    const res = {};
    res.tools = tools.map((t) => ({ name: t.name, origin: t.origin, annotations: t.annotations }));
    res.current = await mc.executeTool(tools.find((t) => t.name === 'qft_get_current_slide'), {});
    res.edit = await mc.executeTool(tools.find((t) => t.name === 'qft_propose_edit'), { path: 'slides.md', search: '# Two', replace: '# Two (revised)' });
    res.pending = window.pending;
    return res;
  });
  console.log(JSON.stringify(out, null, 1));
  // CDP domain check
  const client = await page.context().newCDPSession(page);
  try { const r = await client.send('WebMCP.enable'); console.log('CDP WebMCP.enable ->', JSON.stringify(r)); } catch (e) { console.log('CDP WebMCP.enable failed:', e.message.slice(0, 120)); }
  await browser.close();
})();
