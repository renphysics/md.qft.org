// Initial (statically reachable) JS vs lazily loaded JS for each Monaco entry, plus entry CSS.
import { build } from 'esbuild';
import { gzipSync } from 'node:zlib';
for (const name of ['full-main', 'slim-main', 'core-main']) {
  const r = await build({ entryPoints: [`entries/${name}.js`], bundle: true, minify: true, format: 'esm', target: 'es2022', splitting: true, outdir: `out2/${name}`, metafile: true, write: false, logLevel: 'silent', legalComments: 'none', loader: { '.ttf': 'file', '.css': 'css' } });
  const outs = r.metafile.outputs;
  const bytes = Object.fromEntries(r.outputFiles.map((f) => [f.path.replace(process.cwd() + '/', ''), f.contents]));
  const entry = Object.keys(outs).find((k) => outs[k].entryPoint);
  const seen = new Set(); const stack = [entry];
  while (stack.length) { const k = stack.pop(); if (seen.has(k)) continue; seen.add(k); for (const i of outs[k].imports) if (i.kind === 'import-statement' && outs[i.path]) stack.push(i.path); }
  let init = 0, initGz = 0, lazy = 0, lazyGz = 0;
  for (const k of Object.keys(outs)) { if (!k.endsWith('.js')) continue; const b = bytes[k]; const g = gzipSync(b, { level: 9 }).length; if (seen.has(k)) { init += b.length; initGz += g; } else { lazy += b.length; lazyGz += g; } }
  const css = bytes[entry.replace(/\.js$/, '.css')];
  const kb = (n) => (n / 1024).toFixed(0);
  console.log(name.padEnd(10), `initial JS ${kb(init)} KB min / ${kb(initGz)} KB gz; lazy JS ${kb(lazy)} KB min / ${kb(lazyGz)} KB gz; entry CSS ${css ? kb(css.length) + ' KB min / ' + kb(gzipSync(css, { level: 9 }).length) + ' KB gz' : 'n/a'}`);
}
