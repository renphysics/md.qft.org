import { build } from 'esbuild';
import { gzipSync, brotliCompressSync, constants } from 'node:zlib';
import { mkdirSync, writeFileSync, readFileSync } from 'node:fs';
mkdirSync('entries', { recursive: true });
const M = 'monaco-editor';
const entries = {
  // Everything (what `import * as monaco from "monaco-editor"` gives you)
  'full-main': `import * as monaco from 'monaco-editor'; export default monaco;`,
  // Minimal: all editor contribs (editor.main without language registration is not exposed; use edcore-like set): API + six languages' Monarch grammars + the four language services
  'slim-main': `
    import * as monaco from '${M}/editor/editor.api.js';
    import '${M}/editor/browser/widget/codeEditor/codeEditorWidget.js';
    import '${M}/editor/browser/widget/diffEditor/diffEditor.contribution.js';
    import '${M}/editor/contrib/bracketMatching/browser/bracketMatching.js';
    import '${M}/editor/contrib/clipboard/browser/clipboard.js';
    import '${M}/editor/contrib/comment/browser/comment.js';
    import '${M}/editor/contrib/contextmenu/browser/contextmenu.js';
    import '${M}/editor/contrib/cursorUndo/browser/cursorUndo.js';
    import '${M}/features/find/register.js';
    import '${M}/editor/contrib/folding/browser/folding.js';
    import '${M}/editor/contrib/hover/browser/hoverContribution.js';
    import '${M}/editor/contrib/indentation/browser/indentation.js';
    import '${M}/editor/contrib/linesOperations/browser/linesOperations.js';
    import '${M}/editor/contrib/multicursor/browser/multicursor.js';
    import '${M}/editor/contrib/suggest/browser/suggestController.js';
    import '${M}/editor/contrib/wordHighlighter/browser/wordHighlighter.js';
    import '${M}/languages/definitions/html/register.js';
    import '${M}/languages/definitions/css/register.js';
    import '${M}/languages/definitions/javascript/register.js';
    import '${M}/languages/definitions/typescript/register.js';
    import '${M}/languages/definitions/markdown/register.js';
    import '${M}/languages/definitions/yaml/register.js';
    import '${M}/languages/features/css/register.js';
    import '${M}/languages/features/html/register.js';
    import '${M}/languages/features/json/register.js';
    import '${M}/languages/features/typescript/register.js';
    export default monaco;`,
  // Smallest plausible: API + editor widget + diff + find + Monarch grammars, no language services (no workers except editor.worker)
  'core-main': `
    import * as monaco from '${M}/editor/editor.api.js';
    import '${M}/editor/browser/widget/codeEditor/codeEditorWidget.js';
    import '${M}/editor/browser/widget/diffEditor/diffEditor.contribution.js';
    import '${M}/features/find/register.js';
    import '${M}/languages/definitions/html/register.js';
    import '${M}/languages/definitions/css/register.js';
    import '${M}/languages/definitions/javascript/register.js';
    import '${M}/languages/definitions/markdown/register.js';
    import '${M}/languages/definitions/yaml/register.js';
    export default monaco;`,
  'worker-editor': `import '${M}/editor/editor.worker.js';`,
  'worker-json': `import '${M}/languages/features/json/json.worker.js';`,
  'worker-css': `import '${M}/languages/features/css/css.worker.js';`,
  'worker-html': `import '${M}/languages/features/html/html.worker.js';`,
  'worker-ts': `import '${M}/languages/features/typescript/ts.worker.js';`,
};
const rows = [];
for (const [name, source] of Object.entries(entries)) {
  writeFileSync(`entries/${name}.js`, source);
  const t0 = Date.now();
  let result;
  try {
    result = await build({ entryPoints: [`entries/${name}.js`], bundle: true, minify: true, format: 'esm', target: 'es2022', splitting: true, outdir: `out/${name}`, metafile: true, logLevel: 'silent', legalComments: 'none',
      loader: { '.ttf': 'file', '.css': 'css', '.svg': 'file', '.png': 'file' } });
  } catch (e) { console.log(name, 'FAILED', String(e.message).slice(0, 600)); continue; }
  const acc = { js: [0, 0, 0, 0], css: [0, 0, 0, 0], other: [0, 0, 0, 0] };
  for (const file of Object.keys(result.metafile.outputs)) {
    const b = readFileSync(file);
    const k = file.endsWith('.js') ? 'js' : file.endsWith('.css') ? 'css' : 'other';
    acc[k][0] += b.length; acc[k][1] += gzipSync(b, { level: 9 }).length; acc[k][2] += brotliCompressSync(b, { params: { [constants.BROTLI_PARAM_QUALITY]: 9 } }).length; acc[k][3] += 1;
  }
  rows.push({ name, ...acc, ms: Date.now() - t0 });
}
const kb = (n) => (n / 1024).toFixed(0).padStart(7);
console.log('entry'.padEnd(16), 'js-files', ' js min', '  js gz', '  js br', '| css min', ' css gz', '| other(font) raw');
for (const r of rows) console.log(r.name.padEnd(16), String(r.js[3]).padStart(8), kb(r.js[0]), kb(r.js[1]), kb(r.js[2]), '|', kb(r.css[0]), kb(r.css[1]), '|', kb(r.other[0]), `(${r.ms} ms)`);
writeFileSync('results.json', JSON.stringify(rows, null, 2));
