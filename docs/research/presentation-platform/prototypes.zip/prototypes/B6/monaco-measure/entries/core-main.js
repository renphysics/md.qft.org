
    import * as monaco from 'monaco-editor/editor/editor.api.js';
    import 'monaco-editor/editor/browser/widget/codeEditor/codeEditorWidget.js';
    import 'monaco-editor/editor/browser/widget/diffEditor/diffEditor.contribution.js';
    import 'monaco-editor/features/find/register.js';
    import 'monaco-editor/languages/definitions/html/register.js';
    import 'monaco-editor/languages/definitions/css/register.js';
    import 'monaco-editor/languages/definitions/javascript/register.js';
    import 'monaco-editor/languages/definitions/markdown/register.js';
    import 'monaco-editor/languages/definitions/yaml/register.js';
    export default monaco;