// What does the site's REAL player (production build in /home/user/md.qft.org/dist, served read-only) do with a
// self-contained Reveal.js deck that uses `hash: true`? The package is labelled engine "slidev" only because the
// current manifest validator accepts nothing else; the player itself does not care what the HTML is.
import { createRequire } from 'node:module';
import { readFileSync, readdirSync, statSync, writeFileSync } from 'node:fs';
import { join, relative } from 'node:path';
import { inlineRevealProject } from '../live-lab/inline.mjs';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const { zipSync, strToU8 } = createRequire(new URL('../cm-measure/', import.meta.url))('fflate');
const deckDir = new URL('../reveal-lab/deck/', import.meta.url).pathname;
const files = new Map();
const walk = (dir) => { for (const name of readdirSync(dir)) { const path = join(dir, name); if (statSync(path).isDirectory()) walk(path); else if (/\.(html|js|css)$/.test(name) && !/\.d\.ts$/.test(name)) files.set(relative(deckDir, path), readFileSync(path, 'utf8')); } };
walk(deckDir);
const deck = (config) => `<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Waves</title>
<link rel="stylesheet" href="dist/reset.css"><link rel="stylesheet" href="dist/reveal.css"><link rel="stylesheet" href="dist/theme/white.css"></head>
<body><div class="reveal"><div class="slides">
<section><h2>Waves</h2><p>First slide</p></section>
<section><h2>Amplitudes add</h2><p class="fragment">In phase</p></section>
<section><h2>Summary</h2></section>
</div></div>
<script src="dist/reveal.js"></script>
<script>Reveal.initialize(${config});</script></body></html>`;
const SHIM = "<script>for (const name of ['replaceState','pushState']) { const original = history[name].bind(history); history[name] = (...args) => { try { return original(...args); } catch (error) {} }; }</script>";
const variants = { 'hash: true + six-line history shim placed in the deck head': '{ hash: true }' };
const browser = await chromium.launch();
for (const [label, config] of Object.entries(variants)) {
  files.set('index.html', deck(config));
  const built = inlineRevealProject(files, 'index.html', {});
  built.html = built.html.replace('<head>', '<head>' + SHIM);
  const zip = zipSync({
    'qft-presentation.json': strToU8(JSON.stringify({ format: 'qft-presentation', version: 1, engine: 'slidev', title: 'Reveal test ' + label.replace(/[^a-z ]/gi, ''), entry: 'presentation.html' })),
    'presentation.html': strToU8(built.html),
  });
  const zipPath = new URL('./reveal-test.zip', import.meta.url).pathname;
  writeFileSync(zipPath, zip);
  const context = await browser.newContext({ viewport: { width: 1400, height: 900 } });
  const page = await context.newPage();
  const consoleErrors = [];
  page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(m.text().slice(0, 170)); });
  await page.route(/^https?:\/\/(?!127\.0\.0\.1)/, (route) => route.abort());
  await page.goto('http://127.0.0.1:4579/', { waitUntil: 'networkidle' });
  await page.locator('.cm-editor').waitFor();
  await page.locator('[data-open-presentations]').click();
  await page.locator('[data-pres-library]').waitFor({ state: 'visible' });
  await page.locator('[data-pres-input]').setInputFiles(zipPath);
  await page.locator('[data-pres-start-button]').waitFor({ state: 'visible', timeout: 30000 });
  await page.locator('[data-pres-start-button]').click();
  const status = () => page.locator('[data-pres-player-status]').textContent();
  const log = [];
  const snapshot = async (when) => { log.push(`${when}: status=${JSON.stringify(await status())}, frames in host=${await page.locator('[data-pres-host] iframe').count()}, notice=${JSON.stringify((await page.locator('[data-pres-notice]').textContent().catch(() => '')).slice(0, 140))}`); };
  await page.waitForTimeout(2500); await snapshot('2.5 s after Start');
  // Find the deck frame and navigate forward and back to the first slide.
  let deckFrame = null;
  for (const frame of page.frames()) { if (frame !== page.mainFrame() && await frame.locator('.reveal .slides').count().catch(() => 0)) deckFrame = frame; }
  if (deckFrame) {
    await deckFrame.locator('body').press('ArrowRight'); await page.waitForTimeout(900); await snapshot('after ArrowRight');
    await deckFrame.locator('body').press('ArrowLeft').catch(() => {}); await page.waitForTimeout(1200); await snapshot('after returning to slide 1');
  } else log.push('deck frame not found (player already removed it)');
  console.log(`\n=== ${label} ===`); for (const line of log) console.log('  ' + line);
  console.log('  console errors:', JSON.stringify([...new Set(consoleErrors)].slice(0, 3)));
  await context.close();
}
await browser.close();
