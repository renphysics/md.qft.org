const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
  page.on('pageerror', (e) => {});
  await page.route(/^https?:\/\/(?!127\.0\.0\.1)/, (route) => route.abort());
  for (const [label, url] of [['ordinary dist (history router)', 'http://127.0.0.1:4572/'], ['portable presentation.html (memory router)', 'http://127.0.0.1:4573/presentation.html']]) {
    await page.goto(url);
    await page.waitForFunction(() => document.querySelector('[data-slidev-no]'), null, { timeout: 30000 });
    await page.waitForTimeout(800);
    const out = await page.evaluate(async () => {
      const wait = (ms) => new Promise((r) => setTimeout(r, ms));
      const app = document.querySelector('#app').__vue_app__;
      const res = {};
      const describe = (v) => v === null ? 'null' : typeof v !== 'object' && typeof v !== 'function' ? typeof v + ':' + String(v).slice(0, 30) : (v.constructor && v.constructor.name) + '{' + Object.keys(v).slice(0, 14).join(',') + '}';
      const walk = (provides) => Object.getOwnPropertySymbols(provides).map((s) => { let v = provides[s]; let inner = v && v.value !== undefined ? ' value=' + describe(v.value) : ''; return describe(v) + inner; });
      res.appProvides = walk(app._context.provides);
      const root = app._instance;
      res.rootProvidesOwn = root ? walk(root.provides) : null;
      // Look through the root instance's provides chain for an object with nav
      let ctx = null;
      const scan = (provides) => { for (let p = provides; p && p !== Object.prototype; p = Object.getPrototypeOf(p)) for (const s of Object.getOwnPropertySymbols(p)) { const v = p[s]; if (v && typeof v === 'object' && 'nav' in v) ctx = v; } };
      if (root) scan(root.provides);
      // descend into subTree component instances
      const seen = new Set();
      const visit = (vnode, depth) => { if (!vnode || depth > 12 || ctx) return; const c = vnode.component; if (c && !seen.has(c)) { seen.add(c); scan(c.provides); visit(c.subTree, depth + 1); } if (Array.isArray(vnode.children)) for (const ch of vnode.children) visit(ch, depth + 1); if (vnode.suspense) visit(vnode.suspense.activeBranch, depth + 1); };
      if (root && !ctx) visit(root.subTree, 0);
      res.hasCtx = !!ctx;
      if (ctx) {
        const nav = ctx.nav;
        res.navKeys = Object.keys(nav).join(',');
        res.state = { no: nav.currentSlideNo, clicks: nav.clicks, total: nav.total, clicksTotal: nav.clicksTotal };
        res.meta = nav.currentSlideRoute && nav.currentSlideRoute.meta && nav.currentSlideRoute.meta.slide && { start: nav.currentSlideRoute.meta.slide.start, title: nav.currentSlideRoute.meta.slide.title, filepath: nav.currentSlideRoute.meta.slide.filepath };
        res.starts = (nav.slides || []).map((r) => r.meta.slide.start);
        res.routerMode = ctx.configs.routerMode;
      }
      // Public-ish route based approach
      const router = app.config.globalProperties.$router;
      const state = () => ({ path: router.currentRoute.value.path, no: router.currentRoute.value.params.no, clicks: router.currentRoute.value.query.clicks, hash: location.hash, pathname: location.pathname, visible: [...document.querySelectorAll('[data-slidev-no]')].filter((n) => getComputedStyle(n).display !== 'none').map((n) => n.getAttribute('data-slidev-no')) });
      res.s0 = state();
      const events = []; router.afterEach((to) => events.push(to.fullPath));
      await router.push('/3'); await wait(900); res.afterPush3 = state();
      await router.push({ path: '/2', query: { clicks: 1 } }); await wait(900); res.afterPush2c1 = state();
      window.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowRight', code: 'ArrowRight', keyCode: 39, bubbles: true })); await wait(900); res.afterArrowRight = state();
      res.afterEachEvents = events;
      return res;
    });
    console.log(`\n===== ${label} =====\n` + JSON.stringify(out, null, 1));
  }
  await browser.close();
})();
