const { chromium } = require('playwright');
const probe = async () => {
  const out = {};
  const el = document.querySelector('#app');
  const app = el && el.__vue_app__;
  out.hasVueApp = !!app;
  out.vueVersion = app && app.version;
  out.window__slidev__ = typeof window.__slidev__;
  if (!app) return out;
  const gp = app.config.globalProperties;
  out.globalProps = Object.keys(gp);
  const router = gp.$router;
  out.hasRouter = !!router;
  if (router) {
    const r = router.currentRoute.value;
    out.route = { path: r.path, fullPath: r.fullPath, name: String(r.name), query: r.query, metaKeys: Object.keys(r.meta || {}) };
    out.routes = router.getRoutes().map((x) => x.path).slice(0, 12);
  }
  const provides = app._context.provides;
  const syms = Object.getOwnPropertySymbols(provides);
  out.provideSymbols = syms.map((s) => String(s));
  let ctx = null;
  for (const s of syms) { const v = provides[s]; if (v && typeof v === 'object' && v.nav && v.configs) ctx = v; }
  out.hasSlidevContext = !!ctx;
  if (ctx) {
    const nav = ctx.nav;
    out.navKeys = Object.keys(nav).slice(0, 80);
    out.current = { no: nav.currentSlideNo, clicks: nav.clicks, total: nav.total, clicksTotal: nav.clicksTotal, hasNext: nav.hasNext };
    const slide = nav.currentSlideRoute && nav.currentSlideRoute.meta && nav.currentSlideRoute.meta.slide;
    out.currentSlideMeta = slide ? { start: slide.start, title: slide.title, filepath: slide.filepath, index: slide.index, no: slide.no, keys: Object.keys(slide) } : null;
    out.allStarts = (nav.slides || []).map((r) => r.meta && r.meta.slide && r.meta.slide.start);
    out.routerMode = ctx.configs.routerMode;
  }
  out.domSlideNos = [...document.querySelectorAll('[data-slidev-no]')].map((n) => ({ no: n.getAttribute('data-slidev-no'), visible: getComputedStyle(n).display !== 'none', cls: n.className.slice(0, 60) }));
  out.location = { href: location.href.slice(0, 80), hash: location.hash };
  return out;
};
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
  page.on('pageerror', (e) => console.log('pageerror', String(e).slice(0, 200)));
  await page.route(/^https?:\/\/(?!127\.0\.0\.1)/, (route) => route.abort());
  for (const [label, url] of [['ordinary dist (history router)', 'http://127.0.0.1:4572/'], ['portable presentation.html (memory router)', 'http://127.0.0.1:4573/presentation.html']]) {
    await page.goto(url);
    await page.waitForFunction(() => document.querySelector('[data-slidev-no]'), null, { timeout: 30000 });
    await page.waitForTimeout(600);
    const before = await page.evaluate(probe);
    console.log(`\n===== ${label} =====`);
    console.log(JSON.stringify(before, null, 1).slice(0, 4200));
    // Navigate three ways and read state back
    const nav = await page.evaluate(async () => {
      const app = document.querySelector('#app').__vue_app__;
      const provides = app._context.provides; let ctx;
      for (const s of Object.getOwnPropertySymbols(provides)) { const v = provides[s]; if (v && typeof v === 'object' && v.nav && v.configs) ctx = v; }
      const wait = (ms) => new Promise((r) => setTimeout(r, ms));
      const res = {};
      await ctx.nav.go(3); await wait(700); res.afterNavGo3 = { no: ctx.nav.currentSlideNo, path: app.config.globalProperties.$router.currentRoute.value.fullPath, start: ctx.nav.currentSlideRoute.meta.slide.start, hash: location.hash, pathname: location.pathname };
      await app.config.globalProperties.$router.push('/2?clicks=1'); await wait(700); res.afterRouterPush2 = { no: ctx.nav.currentSlideNo, clicks: ctx.nav.clicks, path: app.config.globalProperties.$router.currentRoute.value.fullPath };
      window.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowRight', code: 'ArrowRight', bubbles: true })); await wait(700); res.afterArrowRight = { no: ctx.nav.currentSlideNo, clicks: ctx.nav.clicks };
      res.visibleDom = [...document.querySelectorAll('[data-slidev-no]')].filter((n) => getComputedStyle(n).display !== 'none').map((n) => n.getAttribute('data-slidev-no'));
      return res;
    });
    console.log('navigation:', JSON.stringify(nav));
  }
  await browser.close();
})();
