// Can the editor follow and drive an UNMODIFIED Reveal deck with Reveal's own postMessage API (no injected bridge)?
import { createRequire } from 'node:module';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join, relative } from 'node:path';
import { inlineRevealProject } from './inline.mjs';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const deckDir = new URL('../reveal-lab/deck/', import.meta.url).pathname;
const files = new Map();
const walk = (dir) => { for (const name of readdirSync(dir)) { const path = join(dir, name); if (statSync(path).isDirectory()) walk(path); else if (/\.(html|js|mjs|css|md)$/.test(name) && !/\.d\.ts$/.test(name)) files.set(relative(deckDir, path), readFileSync(path, 'utf8')); } };
walk(deckDir);
// Variant 2: an ES-module deck with no global `Reveal` (how many AI-written decks import reveal.js).
files.set('esm.html', `<!doctype html><html><head><meta charset="utf-8"><link rel="stylesheet" href="dist/reveal.css"><link rel="stylesheet" href="dist/theme/white.css"></head><body>
<div class="reveal"><div class="slides"><section><h2>One</h2></section><section><section><h2>Two</h2><p class="fragment">step</p></section><section><h2>Two-b</h2></section></section><section><h2>Three</h2></section></div></div>
<script type="module">
  import Reveal from './dist/reveal.mjs';
  const deck = new Reveal({ hash: true });
  deck.initialize();
</script></body></html>`);
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1300, height: 760 } });
await page.route(/^https?:\/\/(?!127\.0\.0\.1)/, (route) => route.abort());
await page.goto('http://127.0.0.1:4574/');
for (const entry of ['demo.html', 'esm.html']) {
  let html;
  if (entry === 'esm.html') {
    // Inline the ES module by hand for this test: replace the import with the module source as a data: URL is blocked by CSP in production, so bundle-style inlining is what a real implementation needs.
    const built = inlineRevealProject(files, entry, {});
    const mjs = files.get('dist/reveal.mjs');
    const blobBootstrap = `<script type="module">const url = URL.createObjectURL(new Blob([${JSON.stringify(mjs)}], { type: 'text/javascript' })); const { default: Reveal } = await import(url); const deck = new Reveal({ hash: true }); deck.initialize();</script>`;
    html = built.html.replace(/<script type="module">[\s\S]*?<\/script>/, blobBootstrap);
  } else html = inlineRevealProject(files, entry, {}).html;
  const result = await page.evaluate(async (html) => {
    const stage = document.getElementById('stage'); stage.replaceChildren();
    const frame = document.createElement('iframe'); frame.setAttribute('sandbox', 'allow-scripts');
    const url = URL.createObjectURL(new Blob([html], { type: 'text/html' })); frame.src = url;
    const events = [];
    const onMessage = (e) => { if (e.source !== frame.contentWindow || typeof e.data !== 'string') return; try { const m = JSON.parse(e.data); if (m.namespace === 'reveal') events.push({ event: m.eventName, h: m.state?.indexh, v: m.state?.indexv, f: m.state?.indexf, method: m.method, result: m.result }); } catch {} };
    addEventListener('message', onMessage);
    await new Promise((resolve) => { frame.addEventListener('load', resolve, { once: true }); stage.append(frame); });
    const post = (method, ...args) => frame.contentWindow.postMessage(JSON.stringify({ method, args }), '*');
    const wait = (ms) => new Promise((r) => setTimeout(r, ms));
    // The deck may still be initializing; retry "configure" until a callback arrives.
    let ready = false; const t0 = performance.now();
    for (let i = 0; i < 100 && !ready; i += 1) { post('configure', { postMessageEvents: true }); post('isReady'); await wait(30); ready = events.some((e) => e.event === 'callback' && e.method === 'isReady' && e.result === true); }
    const readyMs = Math.round(performance.now() - t0);
    events.length = 0;
    post('slide', 1, 1); await wait(250);
    post('getTotalSlides'); post('next'); await wait(250);
    removeEventListener('message', onMessage); URL.revokeObjectURL(url);
    return { ready, readyMs, events: events.filter((e) => e.event !== 'callback' || e.method === 'getTotalSlides').slice(0, 8) };
  }, html);
  console.log(`\n${entry}: handshake ok=${result.ready} after ${result.readyMs} ms`);
  for (const e of result.events) console.log('   ', JSON.stringify(e));
}
await browser.close();
