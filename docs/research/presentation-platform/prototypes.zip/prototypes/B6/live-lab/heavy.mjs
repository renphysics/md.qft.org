// Scaling check: reload latency for a large lecture deck (120 slides, KaTeX auto-render, highlighted code, fragments).
import { createRequire } from 'node:module';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join, relative } from 'node:path';
import { inlineRevealProject } from './inline.mjs';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const deckDir = new URL('../reveal-lab/deck/', import.meta.url).pathname;
const files = new Map();
const walk = (dir) => { for (const name of readdirSync(dir)) { const path = join(dir, name); if (statSync(path).isDirectory()) walk(path); else if (/\.(html|js|css|md)$/.test(name) && !/\.d\.ts$/.test(name)) files.set(relative(deckDir, path), readFileSync(path, 'utf8')); } };
walk(deckDir);
const katexDir = '/home/user/md.qft.org/node_modules/katex/dist/';
files.set('vendor/katex.min.js', readFileSync(katexDir + 'katex.min.js', 'utf8'));
files.set('vendor/auto-render.min.js', readFileSync(katexDir + 'contrib/auto-render.min.js', 'utf8'));
// KaTeX CSS references font files; for the timing test the fonts are simply not embedded (system fallback).
files.set('vendor/katex.min.css', readFileSync(katexDir + 'katex.min.css', 'utf8').replace(/src:[^;}]+;?/g, ''));
const slide = (i) => `<section>
  <h2>Lecture slide ${i}: perturbation theory</h2>
  <p>The amplitude at order \\(g^{${i % 5 + 1}}\\) is</p>
  <p>$$\\mathcal{M}_{${i}} = \\int \\frac{d^4 k}{(2\\pi)^4}\\, \\frac{i}{k^2 - m^2 + i\\epsilon}\\, \\frac{i}{(p-k)^2 - m^2 + i\\epsilon}$$</p>
  <p class="fragment">$$\\sigma = \\frac{1}{2s} \\int d\\Pi_2\\, |\\mathcal{M}_{${i}}|^2$$</p>
  <p class="fragment">$$Z = \\int \\mathcal{D}\\phi\\, e^{iS[\\phi]}$$</p>
  <pre><code class="language-python" data-trim>
import numpy as np
def amplitude(s, m=${i}.0):
    return np.sqrt(np.maximum(s - 4 * m**2, 0)) / (16 * np.pi * s)
  </code></pre>
</section>`;
const html = `<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Heavy</title>
<link rel="stylesheet" href="dist/reset.css"><link rel="stylesheet" href="dist/reveal.css"><link rel="stylesheet" href="dist/theme/white.css"><link rel="stylesheet" href="dist/plugin/highlight/monokai.css"><link rel="stylesheet" href="vendor/katex.min.css"></head>
<body><div class="reveal"><div class="slides">
${Array.from({ length: 120 }, (_, i) => slide(i + 1)).join('\n')}
</div></div>
<script src="dist/reveal.js"></script><script src="dist/plugin/highlight.js"></script><script src="dist/plugin/notes.js"></script>
<script src="vendor/katex.min.js"></script><script src="vendor/auto-render.min.js"></script>
<script>
  renderMathInElement(document.querySelector('.slides'), { delimiters: [{ left: '$$', right: '$$', display: true }, { left: '\\\\(', right: '\\\\)', display: false }] });
  Reveal.initialize({ hash: true, plugins: [RevealHighlight, RevealNotes] });
</script></body></html>`;
files.set('heavy.html', html);
const bridge = readFileSync(new URL('./bridge-reveal.js', import.meta.url), 'utf8');
const built = inlineRevealProject(files, 'heavy.html', { bridge });
console.log(`heavy deck: source ${(html.length / 1024).toFixed(0)} KB, inlined ${(built.html.length / 1024).toFixed(0)} KB, missing: ${built.missing.join(',') || 'none'}`);
const stats = (v) => { v = v.slice().sort((a, b) => a - b); return `median ${v[Math.floor(v.length / 2)].toFixed(0)} ms (min ${v[0].toFixed(0)}, max ${v[v.length - 1].toFixed(0)}, n=${v.length})`; };
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1300, height: 760 } });
await page.route(/^https?:\/\/(?!127\.0\.0\.1)/, (route) => route.abort());
await page.goto('http://127.0.0.1:4574/');
const ready = [], restored = [];
for (let i = 0; i < 7; i += 1) { const r = await page.evaluate(([h, buffered]) => window.lab.load(h, { mode: 'blob', buffered, restore: { h: 60, v: 0, f: 0 } }), [built.html, i > 0]); ready.push(r.ready); restored.push(r.restored); if (i === 0) console.log('  slides:', r.total); }
console.log('  full reload (blob, double-buffered) -> Reveal ready:            ', stats(ready));
console.log('  full reload -> ready + slide 60 restored + painted:             ', stats(restored));
const math = await page.evaluate(() => new Promise((res) => { res(document.querySelectorAll('#stage iframe').length); }));
const patch = [];
for (let i = 0; i < 7; i += 1) { const r = await page.evaluate((i) => window.lab.timed({ cmd: 'patch-slide', h: 60, v: 0, inner: `<h2>Patched ${i}</h2><p>plain text only</p>` }), i); patch.push(r.ms); }
console.log('  in-place slide patch -> painted:                                ', stats(patch));
console.log('  errors:', JSON.stringify(await page.evaluate(() => [...new Set(window.lab.errors)].slice(0, 3))));
await browser.close();
