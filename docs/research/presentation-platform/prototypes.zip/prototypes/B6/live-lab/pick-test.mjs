// Preview -> source element picking: DOM child-index path resolved on the Lezer HTML tree, with a text-search fallback.
import { createRequire } from 'node:module';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join, relative } from 'node:path';
import { inlineRevealProject } from './inline.mjs';
import { mapRevealDeck } from '../reveal-lab/slide-map.mjs';
import { parser as htmlParser } from '@lezer/html';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const deckDir = new URL('../reveal-lab/deck/', import.meta.url).pathname;
const files = new Map();
const walk = (dir) => { for (const name of readdirSync(dir)) { const path = join(dir, name); if (statSync(path).isDirectory()) walk(path); else if (/\.(html|js|css|md)$/.test(name) && !/\.d\.ts$/.test(name)) files.set(relative(deckDir, path), readFileSync(path, 'utf8')); } };
walk(deckDir);
files.set('quirks.html', `<!doctype html><html><head><meta charset="utf-8"><link rel="stylesheet" href="dist/reveal.css"><link rel="stylesheet" href="dist/theme/white.css"></head><body>
<div class="reveal"><div class="slides">
<section>
  <h2>Implied tags</h2>
  <table><tr><th>Quantity<th>Value</tr><tr><td>mass<td>125 GeV</tr></table>
  <ul><li>first item<li>second <em>emphasised</em> item<li>third item</ul>
  <p>Unclosed paragraph one
  <p>Unclosed paragraph two
</section>
<section>
  <h2>Second slide</h2>
  <p>Energy <strong>E = mc<sup>2</sup></strong> is conserved.</p>
</section>
</div></div>
<script src="dist/reveal.js"></script><script>Reveal.initialize({ hash: true });</script></body></html>`);
const bridge = readFileSync(new URL('./bridge-reveal.js', import.meta.url), 'utf8');
const norm = (s) => s.replace(/<[^>]+>/g, '').replace(/&amp;/g, '&').replace(/\s+/g, ' ').trim();
const resolvePath = (source, slide, path) => {
  const tree = htmlParser.parse(source);
  let node = tree.resolveInner(slide.from + 1, 1);
  while (node && !(node.name === 'Element' && node.from === slide.from)) node = node.parent;
  for (const index of path) { const kids = []; for (let c = node.firstChild; c; c = c.nextSibling) if (c.name === 'Element') kids.push(c); node = kids[index]; if (!node) return null; }
  return node;
};
// Fallback: smallest element inside the slide whose text equals the picked text and whose tag name matches.
const resolveByText = (source, slide, tag, text) => {
  const tree = htmlParser.parse(source);
  let best = null;
  tree.iterate({ from: slide.from, to: slide.to, enter(ref) {
    if (ref.name !== 'Element' || ref.from < slide.from || ref.to > slide.to) return;
    const node = ref.node; const open = node.firstChild; const name = open?.getChild('TagName');
    if (!name || source.slice(name.from, name.to).toLowerCase() !== tag) return;
    if (norm(source.slice(node.from, node.to)) === norm(text) && (!best || node.to - node.from < best.to - best.from)) best = node;
  } });
  return best;
};
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1300, height: 760 } });
await page.route(/^https?:\/\/(?!127\.0\.0\.1)/, (route) => route.abort());
await page.goto('http://127.0.0.1:4574/');
let exact = 0, fallback = 0, failed = 0, total = 0;
for (const [entry, checks] of [
  ['demo.html', [[10, 0, 'h2'], [21, 0, 'li:nth-child(2)'], [23, 0, 'tbody tr:nth-child(2) td:nth-child(2)'], [14, 1, '.fragment.grow'], [0, 0, 'h3'], [24, 0, 'blockquote'], [3, 0, 'h2'], [31, 0, 'li:nth-child(4)']]],
  ['quirks.html', [[0, 0, 'h2'], [0, 0, 'tr:nth-child(2) td:nth-child(2)'], [0, 0, 'li:nth-child(2)'], [0, 0, 'li:nth-child(2) em'], [0, 0, 'p:nth-of-type(2)'], [1, 0, 'strong'], [1, 0, 'sup']]],
]) {
  const source = files.get(entry);
  const built = inlineRevealProject(files, entry, { bridge });
  const map = mapRevealDeck(source, (p) => files.get(p), entry);
  await page.evaluate((html) => window.lab.load(html, { mode: 'blob' }), built.html);
  console.log(`\n${entry}`);
  for (const [h, v, selector] of checks) {
    total += 1;
    await page.evaluate((g) => window.lab.command({ cmd: 'goto', h: g[0], v: g[1], f: 99 }), [h, v]);
    const pick = await page.evaluate((selector) => window.lab.command({ cmd: 'pick-at', selector }), selector);
    if (!pick.path) { failed += 1; console.log(`  ${selector}: element not found in the live slide`); continue; }
    const slide = map.slides.find((s) => s.h === pick.h && s.v === pick.v);
    let node = resolvePath(source, slide, pick.path);
    let how = 'path';
    const matches = (n) => n && norm(source.slice(n.from, n.to)) === norm(pick.text);
    if (!matches(node)) { node = resolveByText(source, slide, pick.tag, pick.text); how = 'text-fallback'; }
    if (matches(node)) { if (how === 'path') exact += 1; else fallback += 1; } else failed += 1;
    console.log(`  ${`${h}.${v} ${selector}`.padEnd(46)} path=${JSON.stringify(pick.path).padEnd(10)} ${matches(node) ? how.padEnd(14) : 'UNRESOLVED    '} ${node ? JSON.stringify(source.slice(node.from, node.to).replace(/\s+/g, ' ').slice(0, 60)) : ''}`);
  }
}
console.log(`\npicked ${total}: ${exact} by element path, ${fallback} by text fallback, ${failed} unresolved`);
await browser.close();
