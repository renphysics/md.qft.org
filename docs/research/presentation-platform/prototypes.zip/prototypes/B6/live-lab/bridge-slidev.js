// Injected into a built Slidev client (research prototype, task B6). Uses only vue-router through
// the app handle that Vue leaves on the mount element; window.__slidev__ does not exist in builds.
(() => {
  const t0 = performance.now();
  const send = (message) => parent.postMessage(Object.assign({ qftBridge: 1 }, message), '*');
  const painted = (fn) => requestAnimationFrame(() => requestAnimationFrame(fn));
  let router = null;
  for (const name of ['replaceState', 'pushState']) {
    const original = history[name].bind(history);
    history[name] = (...args) => { try { return original(...args); } catch (error) { /* opaque-origin document: URL rewriting is not allowed */ } };
  }
  const state = (kind, extra) => {
    const route = router.currentRoute.value;
    send(Object.assign({ kind, no: Number(route.params.no) || 1, clicks: Number(route.query.clicks) || 0, total: document.querySelectorAll('[data-slidev-no]').length, ms: performance.now() - t0 }, extra));
  };
  document.addEventListener('DOMContentLoaded', () => send({ kind: 'dom', ms: performance.now() - t0 }));
  window.addEventListener('error', (event) => send({ kind: 'error', message: String(event.message || 'resource error').slice(0, 300) }), true);
  const timer = setInterval(() => {
    const host = document.querySelector('#app');
    const app = host && host.__vue_app__;
    const found = app && app.config.globalProperties.$router;
    if (!found || !document.querySelector('[data-slidev-no]')) return;
    clearInterval(timer);
    router = found;
    router.isReady().then(() => { state('ready'); router.afterEach(() => state('state')); });
  }, 15);
  window.addEventListener('message', (event) => {
    if (event.source !== parent) return;
    const m = event.data;
    if (!m || m.qftBridge !== 1 || !router) return;
    if (m.cmd === 'goto') router.push({ path: '/' + m.no, query: m.clicks ? { clicks: String(m.clicks) } : {} }).then(() => painted(() => state('painted', { id: m.id })));
  });
})();
