// Measures preview-refresh strategies in headless Chromium (task B6).
// Usage: node measure.mjs   (expects server.mjs www 4574 to be running)
import { createRequire } from 'node:module';
import { readFileSync, readdirSync, statSync, writeFileSync } from 'node:fs';
import { join, relative } from 'node:path';
import { inlineRevealProject } from './inline.mjs';
import { mapRevealDeck } from '../reveal-lab/slide-map.mjs';
import { parser as htmlParser } from '@lezer/html';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');

const deckDir = new URL('../reveal-lab/deck/', import.meta.url).pathname;
const files = new Map();
const walk = (dir) => { for (const name of readdirSync(dir)) { const path = join(dir, name); if (statSync(path).isDirectory()) walk(path); else if (/\.(html|js|css|md)$/.test(name) && !/\.d\.ts$/.test(name)) files.set(relative(deckDir, path), readFileSync(path, 'utf8')); } };
walk(deckDir);
const bridgeReveal = readFileSync(new URL('./bridge-reveal.js', import.meta.url), 'utf8');
const bridgeSlidev = readFileSync(new URL('./bridge-slidev.js', import.meta.url), 'utf8');

const stats = (values) => { const v = values.filter((x) => x != null).sort((a, b) => a - b); if (!v.length) return 'n/a'; const med = v[Math.floor(v.length / 2)]; return `median ${med.toFixed(0)} ms (min ${v[0].toFixed(0)}, max ${v[v.length - 1].toFixed(0)}, n=${v.length})`; };
const results = {};
const record = (name, values) => { results[name] = values; console.log(`  ${name.padEnd(64)} ${stats(values)}`); };

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1300, height: 760 } });
page.on('pageerror', (error) => console.log('host pageerror:', String(error).slice(0, 200)));
await page.route(/^https?:\/\/(?!127\.0\.0\.1)/, (route) => route.abort());
await page.goto('http://127.0.0.1:4574/');
const RUNS = 9;

/* ------------------------------ Reveal.js demo deck ------------------------------ */
{
  const entry = 'demo.html';
  const source = files.get(entry);
  const t0 = performance.now();
  const built = inlineRevealProject(files, entry, { bridge: bridgeReveal });
  const inlineMs = performance.now() - t0;
  console.log(`\nReveal.js 6.0.2 demo deck: source ${(source.length / 1024).toFixed(1)} KB, inlined document ${(built.html.length / 1024).toFixed(0)} KB, inlining ${inlineMs.toFixed(1)} ms, inlined files: ${built.inlined.join(', ')}; missing: ${built.missing.join(', ') || 'none'}`);
  const map = mapRevealDeck(source, (path) => files.get(path), entry);
  console.log(`  slide map: ${map.slides.length} slides`);

  for (const mode of ['srcdoc', 'blob']) {
    const ready = [], restored = [], dom = [];
    for (let i = 0; i < RUNS; i += 1) {
      const r = await page.evaluate(([html, mode]) => window.lab.load(html, { mode, restore: { h: 10, v: 0, f: -1 } }), [built.html, mode]);
      ready.push(r.ready); restored.push(r.restored); dom.push(r.dom);
      if (i === 0) console.log(`  first ${mode} load: total slides reported by Reveal = ${r.total}`);
    }
    record(`full reload (${mode}) -> DOMContentLoaded`, dom);
    record(`full reload (${mode}) -> Reveal 'ready'`, ready);
    record(`full reload (${mode}) -> ready + slide restored + painted`, restored);
  }
  {
    const swapped = [];
    for (let i = 0; i < RUNS; i += 1) { const r = await page.evaluate((html) => window.lab.load(html, { mode: 'srcdoc', buffered: true, restore: { h: 10, v: 0, f: -1 } }), built.html); swapped.push(r.swapped); }
    record('double-buffered reload -> new frame swapped in (no blank flash)', swapped);
    console.log('  frames left in stage after buffered swaps:', await page.evaluate(() => window.lab.frameCount()));
  }
  {
    // CSS-only soft refresh: edit the theme stylesheet.
    const file = 'dist/theme/black.css';
    const css = files.get(file);
    const times = [];
    for (let i = 0; i < RUNS; i += 1) {
      const text = css + `\n.reveal h2{color:hsl(${i * 40},80%,60%)}`;
      const r = await page.evaluate(([file, text]) => window.lab.timed({ cmd: 'css', file, text }), [file, text]);
      if (r.reply.kind !== 'painted') throw new Error('css patch missed');
      times.push(r.ms);
    }
    record(`CSS soft refresh (${(css.length / 1024).toFixed(0)} KB theme stylesheet swapped) -> painted`, times);
    const small = '.reveal h2{letter-spacing:.02em}';
    const t2 = [];
    for (let i = 0; i < RUNS; i += 1) { const r = await page.evaluate(([file, text]) => window.lab.timed({ cmd: 'css', file, text }), ['dist/reset.css', files.get('dist/reset.css') + small + `/*${i}*/`]); t2.push(r.ms); }
    record('CSS soft refresh (1 KB stylesheet) -> painted', t2);
  }
  {
    // In-place patch of one slide's markup (slide 10,0 = "Touch Optimized").
    const slide = map.slides.find((s) => s.h === 10 && s.v === 0);
    const inner = source.slice(slide.innerFrom, slide.innerTo);
    const times = [];
    let last;
    for (let i = 0; i < RUNS; i += 1) {
      const next = inner.replace('Touch Optimized', `Touch Optimized v${i}`);
      const r = await page.evaluate(([inner]) => window.lab.timed({ cmd: 'patch-slide', h: 10, v: 0, inner }), [next]);
      times.push(r.ms); last = r.reply;
    }
    record('in-place slide patch (innerHTML + Reveal.sync) -> painted', times);
    console.log('  state after patch:', JSON.stringify({ h: last.h, v: last.v, total: last.total }));
  }
  {
    // Navigation only (editor cursor moved to another slide).
    const times = [];
    for (let i = 0; i < RUNS; i += 1) { const r = await page.evaluate((h) => window.lab.timed({ cmd: 'goto', h, v: 0, f: -1 }), 5 + (i % 9)); times.push(r.ms); }
    record('follow cursor: goto another slide -> painted', times);
  }
  {
    // Preview -> source: element path picking verified against the source text.
    const checks = [
      { goto: { h: 10, v: 0 }, selector: 'h2', expect: 'Touch Optimized' },
      { goto: { h: 21, v: 0 }, selector: 'li:nth-child(2)', expect: 'Or here' },
      { goto: { h: 23, v: 0 }, selector: 'tbody tr:nth-child(2) td:nth-child(2)', expect: '$2' },
      { goto: { h: 14, v: 1 }, selector: '.fragment.grow', expect: 'grow' },
    ];
    const resolvePath = (slide, path) => {
      // Walk the Lezer tree of the slide's source along child-element indices.
      const tree = htmlParser.parse(source);
      let node = tree.resolveInner(slide.from + 1, 1);
      while (node && !(node.name === 'Element' && node.from === slide.from)) node = node.parent;
      for (const index of path) {
        const children = []; for (let c = node.firstChild; c; c = c.nextSibling) if (c.name === 'Element') children.push(c);
        node = children[index]; if (!node) return null;
      }
      return node;
    };
    let ok = 0;
    for (const check of checks) {
      await page.evaluate((g) => window.lab.command({ cmd: 'goto', h: g.h, v: g.v, f: 99 }), check.goto);
      const pick = await page.evaluate((selector) => window.lab.command({ cmd: 'pick-at', selector }), check.selector);
      const slide = map.slides.find((s) => s.h === pick.h && s.v === pick.v);
      const node = pick.path && slide ? resolvePath(slide, pick.path) : null;
      const text = node ? source.slice(node.from, node.to) : null;
      const good = !!text && text.includes(check.expect) && text.replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim() === pick.text.replace(/\s+/g, ' ').trim();
      if (good) ok += 1;
      console.log(`  pick ${check.selector} on slide ${pick.h}.${pick.v} path=${JSON.stringify(pick.path)} -> source ${node ? `${node.from}-${node.to}` : 'UNRESOLVED'} ${JSON.stringify((text || '').slice(0, 70))} ${good ? 'OK' : 'MISMATCH'}`);
    }
    console.log(`  preview->source element picking: ${ok}/${checks.length} exact`);
    // Direct text edit written back to the source.
    await page.evaluate(() => window.lab.command({ cmd: 'goto', h: 10, v: 0, f: -1 }));
    const pick = await page.evaluate(() => window.lab.command({ cmd: 'pick-at', selector: 'h2' }));
    const edit = await new Promise(async (resolve) => {
      const reply = await page.evaluate((p) => new Promise((res) => { const onMessage = (e) => { if (e.data && e.data.kind === 'text-edit') { removeEventListener('message', onMessage); res(e.data); } }; addEventListener('message', onMessage); window.lab.command({ cmd: 'set-text', h: p.h, v: p.v, path: p.path, text: 'Touch & Pen <Optimized>' }); }), pick);
      resolve(reply);
    });
    const slide = map.slides.find((s) => s.h === edit.h && s.v === edit.v);
    const node = resolvePath(slide, edit.path);
    const open = node.firstChild, close = node.lastChild;
    const escaped = edit.text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    const updated = source.slice(0, open.to) + escaped + source.slice(close.from);
    const changedOnlyThere = updated.slice(0, open.to) === source.slice(0, open.to) && updated.slice(open.to + escaped.length) === source.slice(close.from);
    console.log(`  direct text edit written back: ${JSON.stringify(source.slice(node.from, node.to))} -> ${JSON.stringify(updated.slice(node.from, node.from + (node.to - node.from) + escaped.length - (close.from - open.to)))}; rest of file byte-identical: ${changedOnlyThere}`);
  }
  console.log('  errors reported by the deck:', JSON.stringify(await page.evaluate(() => [...new Set(window.lab.errors)].slice(0, 5))));
}

/* --------------------------- Slidev portable build --------------------------- */
{
  await page.evaluate(() => { window.lab.errors.length = 0; });
  const html = readFileSync(new URL('../slidev-lab/portable/presentation.html', import.meta.url), 'utf8');
  const withBridge = html.replace(/<head[^>]*>/i, (m) => `${m}<script data-qft-bridge>${bridgeSlidev.replace(/<\/script/gi, '<\\/script')}</script>`);
  console.log(`\nSlidev 53.1.0 portable build (4 slides, one Vue demo): document ${(html.length / 1024 / 1024).toFixed(2)} MB`);
  for (const mode of ['srcdoc', 'blob']) {
    const ready = [], restored = [], dom = [];
    for (let i = 0; i < RUNS; i += 1) {
      const r = await page.evaluate(([html, mode]) => window.lab.load(html, { mode, restore: { no: 3, clicks: 0 } }), [withBridge, mode]);
      ready.push(r.ready); restored.push(r.restored); dom.push(r.dom);
    }
    record(`full reload (${mode}) -> DOMContentLoaded`, dom);
    record(`full reload (${mode}) -> router ready + first slide mounted`, ready);
    record(`full reload (${mode}) -> slide 3 restored + painted`, restored);
  }
  {
    const swapped = [];
    for (let i = 0; i < RUNS; i += 1) { const r = await page.evaluate((html) => window.lab.load(html, { mode: 'blob', buffered: true, restore: { no: 3, clicks: 0 } }), withBridge); swapped.push(r.swapped); }
    record('double-buffered reload (blob) -> swapped in', swapped);
  }
  {
    const times = [];
    for (let i = 0; i < RUNS; i += 1) { const r = await page.evaluate((no) => window.lab.timed({ cmd: 'goto', no, clicks: 0 }), 1 + (i % 4)); times.push(r.ms); }
    record('follow cursor: goto another slide -> painted', times);
  }
  console.log('  errors reported by the deck:', JSON.stringify(await page.evaluate(() => [...new Set(window.lab.errors)].slice(0, 5))));
}
await browser.close();
writeFileSync(new URL('./latency-results.json', import.meta.url), JSON.stringify(results, null, 1));
