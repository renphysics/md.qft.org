import { createRequire } from 'node:module';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join, relative } from 'node:path';
import { inlineRevealProject } from './inline.mjs';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const deckDir = new URL('../reveal-lab/deck/', import.meta.url).pathname;
const files = new Map();
const walk = (dir) => { for (const name of readdirSync(dir)) { const path = join(dir, name); if (statSync(path).isDirectory()) walk(path); else if (/\.(html|js|css|md)$/.test(name) && !/\.d\.ts$/.test(name)) files.set(relative(deckDir, path), readFileSync(path, 'utf8')); } };
walk(deckDir);
const bridge = readFileSync(new URL('./bridge-reveal.js', import.meta.url), 'utf8');
const noShim = bridge.replace(/for \(const name of \['replaceState', 'pushState'\]\) \{[\s\S]*?\n  \}/, '');
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1300, height: 760 } });
const errors = [];
page.on('pageerror', (e) => errors.push(String(e).slice(0, 150)));
await page.route(/^https?:\/\/(?!127\.0\.0\.1)/, (route) => route.abort());
await page.goto('http://127.0.0.1:4574/');
await page.evaluate(() => { window.notes = []; addEventListener('message', (e) => { if (e.data && e.data.qftBridge && (e.data.kind === 'note' || (e.data.kind === 'error' && e.data.message !== 'resource error'))) window.notes.push(e.data.kind + ': ' + e.data.message); }); });
const withTimeout = (p, ms, label) => Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(new Error('TIMEOUT ' + label)), ms))]);
for (const [label, b, mode, buffered] of [['srcdoc, no history shim', noShim, 'srcdoc', false], ['blob, no history shim', noShim, 'blob', false], ['srcdoc + history shim', bridge, 'srcdoc', false], ['blob + shim, buffered (visibility:hidden)', bridge, 'blob', true]]) {
  const built = inlineRevealProject(files, 'demo.html', { bridge: b });
  errors.length = 0; await page.evaluate(() => { window.notes.length = 0; });
  try {
    const r = await withTimeout(page.evaluate(([html, mode, buffered]) => window.lab.load(html, { mode, buffered, restore: { h: 10, v: 0, f: -1 } }), [built.html, mode, buffered]), 15000, 'load');
    console.log(label.padEnd(44), 'OK', JSON.stringify(r));
  } catch (e) { console.log(label.padEnd(44), 'FAILED:', e.message); }
  console.log('   page errors:', JSON.stringify([...new Set(errors)].slice(0, 2)), ' bridge notes:', JSON.stringify(await page.evaluate(() => [...new Set(window.notes)].slice(0, 3))));
  // reset stage between runs
  await page.evaluate(() => { document.getElementById('stage').replaceChildren(); });
  await page.reload(); await page.evaluate(() => { window.notes = []; addEventListener('message', (e) => { if (e.data && e.data.qftBridge && (e.data.kind === 'note' || (e.data.kind === 'error' && e.data.message !== 'resource error'))) window.notes.push(e.data.kind + ': ' + e.data.message); }); });
}
await browser.close();
