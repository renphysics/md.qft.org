// Injected into the previewed Reveal.js deck (research prototype, task B6).
// Runs inside the opaque-origin sandbox; talks to the editor only through postMessage.
(() => {
  const t0 = performance.now();
  const send = (message) => parent.postMessage(Object.assign({ qftBridge: 1 }, message), '*');
  const painted = (fn) => requestAnimationFrame(() => requestAnimationFrame(fn));
  let deck = null;
  let inspect = false;
  // A sandboxed about:srcdoc document may not rewrite its URL: Reveal's `hash: true` calls
  // history.replaceState('#/2') and throws a SecurityError on every slide change. Swallow it.
  let historyBlocked = 0;
  for (const name of ['replaceState', 'pushState']) {
    const original = history[name].bind(history);
    history[name] = (...args) => { try { return original(...args); } catch (error) { if (historyBlocked++ === 0) send({ kind: 'note', message: 'history.' + name + ' blocked: ' + String(error.message).slice(0, 120) }); } };
  }
  const state = (kind, extra) => {
    const i = deck.getIndices();
    send(Object.assign({ kind, h: i.h, v: i.v || 0, f: i.f === undefined ? -1 : i.f, total: deck.getTotalSlides(), ms: performance.now() - t0 }, extra));
  };
  const hook = () => {
    deck = window.Reveal;
    if (!deck || typeof deck.on !== 'function') return false;
    const ready = () => {
      state('ready');
      for (const name of ['slidechanged', 'fragmentshown', 'fragmenthidden']) deck.on(name, () => state('state'));
    };
    if (deck.isReady()) ready(); else deck.on('ready', ready);
    return true;
  };
  document.addEventListener('DOMContentLoaded', () => {
    send({ kind: 'dom', ms: performance.now() - t0 });
    if (!hook()) { const timer = setInterval(() => { if (hook()) clearInterval(timer); }, 15); }
  });
  window.addEventListener('error', (event) => send({ kind: 'error', message: String(event.message || 'resource error').slice(0, 300), line: event.lineno, file: event.filename }), true);
  window.addEventListener('unhandledrejection', (event) => send({ kind: 'error', message: String(event.reason && event.reason.message || event.reason).slice(0, 300) }));

  const slideAt = (h, v) => deck.getSlide(h, v);
  const elementPath = (root, element) => {
    const path = [];
    for (let node = element; node && node !== root; node = node.parentElement) path.unshift(Array.prototype.indexOf.call(node.parentElement.children, node));
    return path;
  };
  const byPath = (root, path) => path.reduce((node, index) => node && node.children[index], root);

  window.addEventListener('message', (event) => {
    if (event.source !== parent) return;
    const m = event.data;
    if (!m || m.qftBridge !== 1) return;
    if (m.cmd === 'goto') { deck.slide(m.h, m.v, m.f); painted(() => state('painted', { id: m.id })); }
    else if (m.cmd === 'css') {
      // Soft refresh: swap the text of one inlined stylesheet, no reload, state untouched.
      const style = document.querySelector(`style[data-qft-file="${m.file}"]`);
      if (!style) { send({ kind: 'miss', id: m.id }); return; }
      style.textContent = m.text;
      deck.layout();
      painted(() => state('painted', { id: m.id }));
    } else if (m.cmd === 'patch-slide') {
      // Replace one slide's markup in place and let Reveal re-read the DOM.
      const slide = slideAt(m.h, m.v);
      if (!slide) { send({ kind: 'miss', id: m.id }); return; }
      slide.innerHTML = m.inner;
      deck.sync();
      const highlight = deck.getPlugin && deck.getPlugin('highlight');
      if (highlight) for (const block of slide.querySelectorAll('pre code')) highlight.highlightBlock(block);
      deck.layout();
      painted(() => state('painted', { id: m.id }));
    } else if (m.cmd === 'inspect') { inspect = !!m.on; document.documentElement.style.cursor = inspect ? 'crosshair' : ''; }
    else if (m.cmd === 'pick-at') {
      // Test hook: behave as if the user alt-clicked the element found by a selector in the current slide.
      const slide = deck.getCurrentSlide();
      const target = slide.querySelector(m.selector);
      const i = deck.getIndices(slide);
      send({ kind: 'pick', id: m.id, h: i.h, v: i.v || 0, path: target ? elementPath(slide, target) : null, tag: target && target.localName, text: target && target.textContent.slice(0, 200) });
    } else if (m.cmd === 'set-text') {
      // Test hook for direct text editing: what a contenteditable commit would report.
      const slide = slideAt(m.h, m.v);
      const target = byPath(slide, m.path);
      target.textContent = m.text;
      const i = deck.getIndices(slide);
      send({ kind: 'text-edit', id: m.id, h: i.h, v: i.v || 0, path: m.path, text: target.textContent });
    }
  });

  // Alt+click (or inspect mode): report which element of which slide was chosen; never follow links.
  document.addEventListener('click', (event) => {
    if (!deck || !(inspect || event.altKey)) return;
    const slide = event.target.closest && event.target.closest('.slides section');
    if (!slide) return;
    event.preventDefault(); event.stopPropagation();
    const i = deck.getIndices(slide);
    send({ kind: 'pick', h: i.h, v: i.v || 0, path: elementPath(slide, event.target), tag: event.target.localName, text: event.target.textContent.slice(0, 200) });
  }, true);

  // Double-click a simple text element to edit it in place; commit on blur or Enter.
  document.addEventListener('dblclick', (event) => {
    if (!deck || !inspect) return;
    const target = event.target;
    const slide = target.closest && target.closest('.slides section');
    if (!slide || target.children.length) return; // only leaf text elements in this prototype
    event.preventDefault();
    const before = target.textContent;
    target.contentEditable = 'plaintext-only';
    target.focus();
    const commit = () => {
      target.removeAttribute('contenteditable');
      target.removeEventListener('blur', commit);
      if (target.textContent === before) return;
      const i = deck.getIndices(slide);
      send({ kind: 'text-edit', h: i.h, v: i.v || 0, path: elementPath(slide, target), text: target.textContent });
    };
    target.addEventListener('blur', commit);
    target.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); target.blur(); } e.stopPropagation(); });
  }, true);
})();
