// Lab-only inliner: turn a multi-file Reveal.js project (path -> text map) into one HTML document that
// runs in an opaque-origin sandbox with no network. A production version would live in the browser;
// this one is just enough to measure preview-refresh latency for task B6.
import { parser } from '@lezer/html';

const escapeScript = (text) => text.replace(/<\/script/gi, '<\\/script');
const escapeStyle = (text) => text.replace(/<\/style/gi, '<\\/style');
const escapeTextarea = (text) => text.replace(/<\/textarea/gi, '&lt;/textarea');

function attrs(source, tag) {
  const out = new Map();
  for (let node = tag.firstChild; node; node = node.nextSibling) {
    if (node.name !== 'Attribute') continue;
    const name = node.getChild('AttributeName');
    const value = node.getChild('AttributeValue') ?? node.getChild('UnquotedAttributeValue');
    let text = value ? source.slice(value.from, value.to) : '';
    if (/^["']/.test(text)) text = text.slice(1, -1);
    if (name) out.set(source.slice(name.from, name.to).toLowerCase(), text);
  }
  return out;
}

/** files: Map<string,string>. Returns { html, inlined: string[], missing: string[] }. */
export function inlineRevealProject(files, entry, { bridge = '' } = {}) {
  const html = files.get(entry);
  const tree = parser.parse(html);
  const edits = []; // {from,to,insert}
  const inlined = [];
  const missing = [];
  const local = (url) => url && !/^(?:[a-z][a-z0-9+.-]*:|\/\/|#)/i.test(url);
  tree.iterate({
    enter(ref) {
      if (ref.name !== 'Element') return;
      const node = ref.node;
      const open = node.firstChild;
      if (!open || (open.name !== 'OpenTag' && open.name !== 'SelfClosingTag')) return;
      const nameNode = open.getChild('TagName');
      const name = nameNode ? html.slice(nameNode.from, nameNode.to).toLowerCase() : '';
      const a = attrs(html, open);
      if (name === 'link' && /\bstylesheet\b/i.test(a.get('rel') ?? '') && local(a.get('href'))) {
        const css = files.get(a.get('href'));
        if (css === undefined) { missing.push(a.get('href')); return; }
        edits.push({ from: node.from, to: node.to, insert: `<style data-qft-file="${a.get('href')}">${escapeStyle(css)}</style>` });
        inlined.push(a.get('href'));
      } else if (name === 'script' && local(a.get('src'))) {
        const js = files.get(a.get('src'));
        if (js === undefined) { missing.push(a.get('src')); return; }
        const type = a.get('type') ? ` type="${a.get('type')}"` : '';
        edits.push({ from: node.from, to: node.to, insert: `<script${type} data-qft-file="${a.get('src')}">${escapeScript(js)}</script>` });
        inlined.push(a.get('src'));
      } else if (name === 'section' && local(a.get('data-markdown'))) {
        const md = files.get(a.get('data-markdown'));
        if (md === undefined) { missing.push(a.get('data-markdown')); return; }
        // Keep every other attribute, blank the file reference and supply the text inline.
        const openText = html.slice(open.from, open.to).replace(/data-markdown\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/i, `data-markdown data-qft-file="${a.get('data-markdown')}"`);
        edits.push({ from: node.from, to: node.to, insert: `${openText}<textarea data-template>${escapeTextarea(md)}</textarea></section>` });
        inlined.push(a.get('data-markdown'));
      }
    },
  });
  edits.sort((x, y) => x.from - y.from);
  let out = '';
  let at = 0;
  for (const edit of edits) { if (edit.from < at) continue; out += html.slice(at, edit.from) + edit.insert; at = edit.to; }
  out += html.slice(at);
  if (bridge) out = out.replace(/<head[^>]*>/i, (m) => `${m}<script data-qft-bridge>${escapeScript(bridge)}</script>`);
  return { html: out, inlined, missing };
}
