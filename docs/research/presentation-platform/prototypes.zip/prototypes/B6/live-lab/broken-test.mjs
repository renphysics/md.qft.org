// What happens when a teacher breaks the HTML? Compare (a) Lezer error nodes, (b) the static slide map, (c) what Reveal actually builds.
import { createRequire } from 'node:module';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join, relative } from 'node:path';
import { inlineRevealProject } from './inline.mjs';
import { mapRevealDeck } from '../reveal-lab/slide-map.mjs';
import { parser } from '@lezer/html';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const deckDir = new URL('../reveal-lab/deck/', import.meta.url).pathname;
const files = new Map();
const walk = (dir) => { for (const name of readdirSync(dir)) { const path = join(dir, name); if (statSync(path).isDirectory()) walk(path); else if (/\.(html|js|css|md)$/.test(name) && !/\.d\.ts$/.test(name)) files.set(relative(deckDir, path), readFileSync(path, 'utf8')); } };
walk(deckDir);
const bridge = readFileSync(new URL('./bridge-reveal.js', import.meta.url), 'utf8');
const original = files.get('demo.html');
const at = original.indexOf('<h2>Touch Optimized</h2>');
const sectionClose = original.indexOf('</section>', at);
const variants = {
  'intact': original,
  'deleted one </section>': original.slice(0, sectionClose) + original.slice(sectionClose + '</section>'.length),
  'unclosed <div in a slide': original.slice(0, at) + '<div class="box"\n' + original.slice(at),
  'unterminated attribute quote': original.replace('<h2>Touch Optimized</h2>', '<h2 class="big>Touch Optimized</h2>'),
  'deleted the Reveal.initialize( call': original.replace('Reveal.initialize({', 'Reveal.initialise({'),
  'JS syntax error in the init script': original.replace('hash: true,', 'hash: true,,'),
};
const lezerErrors = (html) => { const out = []; parser.parse(html).iterate({ enter(ref) { if (ref.type.isError || ref.name === 'MismatchedCloseTag' || ref.name === 'MissingCloseTag' || ref.name === 'IncompleteCloseTag' || ref.name === 'IncompleteTag') out.push({ name: ref.type.isError ? 'error' : ref.name, line: html.slice(0, ref.from).split('\n').length }); } }); return out; };
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1300, height: 760 } });
await page.route(/^https?:\/\/(?!127\.0\.0\.1)/, (route) => route.abort());
await page.goto('http://127.0.0.1:4574/');
for (const [name, html] of Object.entries(variants)) {
  files.set('demo.html', html);
  const errors = lezerErrors(html);
  const map = mapRevealDeck(html, (p) => files.get(p), 'demo.html');
  const built = inlineRevealProject(files, 'demo.html', { bridge });
  await page.evaluate(() => { window.lab.errors.length = 0; document.getElementById('stage').replaceChildren(); });
  let runtime;
  try {
    const r = await Promise.race([page.evaluate((h) => window.lab.load(h, { mode: 'blob' }), built.html), new Promise((_, rej) => setTimeout(() => rej(new Error('not ready after 4 s')), 4000))]);
    runtime = `ready in ${r.ready.toFixed(0)} ms, ${r.total} slides`;
    const shape = await page.evaluate(() => new Promise((res) => { const f = document.querySelector('#stage iframe'); res(null); }));
  } catch (e) { runtime = 'NEVER READY (' + e.message + ')'; }
  const deckErrors = await page.evaluate(() => [...new Set(window.lab.errors)].filter((m) => m !== 'resource error').slice(0, 2));
  console.log(`\n${name}\n   static: ${map.slides.length} slides mapped (${map.slides.filter((s) => s.v > 0).length} vertical children); Lezer problems: ${errors.length ? errors.slice(0, 3).map((e) => `${e.name}@line${e.line}`).join(', ') : 'none'}\n   runtime: ${runtime}; script errors: ${JSON.stringify(deckErrors)}`);
}
await browser.close();
