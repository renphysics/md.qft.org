import { basicSetup } from 'codemirror';
import { EditorState } from '@codemirror/state';
import { EditorView } from '@codemirror/view';
import { markdown } from '@codemirror/lang-markdown';
import { html } from '@codemirror/lang-html';
import { MergeView, unifiedMergeView, acceptChunk, rejectChunk, getChunks, getOriginalDoc, goToNextChunk } from '@codemirror/merge';
import { SearchCursor, RegExpCursor } from '@codemirror/search';
import { Text } from '@codemirror/state';
window.review = {
  unified(original, proposed) {
    document.getElementById('unified').replaceChildren();
    const view = new EditorView({ parent: document.getElementById('unified'), state: EditorState.create({ doc: proposed, extensions: [basicSetup, markdown(), EditorView.lineWrapping, unifiedMergeView({ original, mergeControls: true, highlightChanges: true, gutter: true, collapseUnchanged: { margin: 2, minSize: 4 } })] }) });
    window.unifiedView = view;
    return { chunks: getChunks(view.state)?.chunks.length };
  },
  // Accept = keep the proposed text (updates the stored original); reject = restore the original text.
  act(kind, index) {
    const view = window.unifiedView;
    const chunk = getChunks(view.state).chunks[index];
    const ok = (kind === 'accept' ? acceptChunk : rejectChunk)(view, chunk.fromB);
    return { ok, remaining: getChunks(view.state).chunks.length, doc: view.state.doc.toString(), original: getOriginalDoc(view.state).toString() };
  },
  side(original, proposed) {
    document.getElementById('side').replaceChildren();
    const mv = new MergeView({ parent: document.getElementById('side'), a: { doc: original, extensions: [basicSetup, html(), EditorState.readOnly.of(true)] }, b: { doc: proposed, extensions: [basicSetup, html()] }, revertControls: 'a-to-b', collapseUnchanged: { margin: 2, minSize: 4 } });
    window.mergeView = mv;
    return { chunks: mv.chunks.length };
  },
  // Search across files: plain string and regex over an in-memory Map, reporting line/column.
  searchAll(files, needle, regex) {
    const t0 = performance.now(); let hits = 0; let filesHit = 0;
    for (const [path, text] of files) {
      const doc = Text.of(text.split('\n'));
      const cursor = regex ? new RegExpCursor(doc, needle, { ignoreCase: true }) : new SearchCursor(doc, needle, 0, doc.length, (s) => s.toLowerCase());
      let n = 0; while (!cursor.next().done) n += 1;
      if (n) filesHit += 1; hits += n;
    }
    const cm = performance.now() - t0;
    const t1 = performance.now(); let hits2 = 0; const lower = needle.toLowerCase();
    if (!regex) for (const [, text] of files) { const hay = text.toLowerCase(); let i = -1; while ((i = hay.indexOf(lower, i + 1)) >= 0) hits2 += 1; }
    else for (const [, text] of files) { const re = new RegExp(needle, 'gi'); while (re.exec(text)) hits2 += 1; }
    return { cmCursorMs: cm, nativeMs: performance.now() - t1, hits, hits2, filesHit };
  },
};
