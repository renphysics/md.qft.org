import { createRequire } from 'node:module';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join, relative } from 'node:path';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const original = `---\ntheme: default\ntitle: Waves\n---\n\n# Waves\n\nTwo waves, one relative phase\n\n---\n\n# Amplitudes add\n\n- In phase: reinforce\n- Out of phase: cancel\n\n---\n\n# Try it\n\n<Interference />\n\n---\n\n# Summary\n\n- In phase: reinforce\n- Out of phase: cancel\n`;
const proposed = original.replace('# Waves\n', '# Waves and phases\n').replace('- Out of phase: cancel\n\n---\n\n# Try it', '- Quadrature: half intensity\n- Out of phase: cancel\n\n---\n\n# Try it').replace('<Interference />', '<Interference :phase="0.5" />');
const demo = readFileSync(new URL('../reveal-lab/deck/demo.html', import.meta.url), 'utf8');
const demo2 = demo.replace('Touch Optimized', 'Touch and pen optimised').replace('<h2>Marvelous List</h2>', '<h2>A Marvelous List</h2>\n\t\t\t\t\t<p class="fragment">Now with a subtitle</p>');
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1220, height: 820 } });
page.on('pageerror', (e) => console.log('pageerror', String(e).slice(0, 200)));
await page.goto('http://127.0.0.1:4576/');
await page.waitForFunction(() => !!window.review);
console.log('unified:', await page.evaluate(([a, b]) => window.review.unified(a, b), [original, proposed]));
console.log('side-by-side:', await page.evaluate(([a, b]) => window.review.side(a, b), [demo, demo2]));
await page.waitForTimeout(300);
await page.screenshot({ path: new URL('../../../shots/B6-review-merge.png', import.meta.url).pathname, fullPage: false });
const r1 = await page.evaluate(() => window.review.act('reject', 0));
console.log('reject chunk 0 -> ok', r1.ok, 'remaining', r1.remaining, '| doc has original heading:', r1.doc.includes('# Waves\n'), '| doc still has other proposed changes:', r1.doc.includes('Quadrature'));
const r2 = await page.evaluate(() => window.review.act('accept', 0));
console.log('accept chunk 0 -> ok', r2.ok, 'remaining', r2.remaining, '| baseline now includes accepted text:', r2.original.includes('Quadrature'));
// Search across files: the whole reveal deck folder (dist included) as a stand-in project.
const deckDir = new URL('../reveal-lab/deck/', import.meta.url).pathname; const files = [];
const walk = (dir) => { for (const name of readdirSync(dir)) { const path = join(dir, name); if (statSync(path).isDirectory()) walk(path); else if (/\.(html|js|mjs|css|md|ts)$/.test(name)) files.push([relative(deckDir, path), readFileSync(path, 'utf8')]); } };
walk(deckDir);
const bytes = files.reduce((n, [, t]) => n + t.length, 0);
for (const [needle, regex] of [['fragment', false], ['data-background', false], ['<section[^>]*data-markdown', true]]) {
  const r = await page.evaluate(([files, needle, regex]) => window.review.searchAll(new Map(files), needle, regex), [files, needle, regex]);
  console.log(`search ${JSON.stringify(needle)}${regex ? ' (regex)' : ''} over ${files.length} files / ${(bytes / 1048576).toFixed(1)} MB: CodeMirror cursors ${r.cmCursorMs.toFixed(0)} ms (${r.hits} hits in ${r.filesHit} files); native string/RegExp ${r.nativeMs.toFixed(0)} ms (${r.hits2} hits)`);
}
await browser.close();
