export { parseAnswer, applyAnswer, failureReport, locate } from './patch-apply.mjs';
