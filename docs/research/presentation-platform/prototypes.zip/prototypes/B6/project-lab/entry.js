import { basicSetup } from 'codemirror';
import { EditorState } from '@codemirror/state';
import { EditorView } from '@codemirror/view';
import { undo, redo, undoDepth, isolateHistory } from '@codemirror/commands';
import { html } from '@codemirror/lang-html';
import { css } from '@codemirror/lang-css';
import { javascript } from '@codemirror/lang-javascript';
import { markdown } from '@codemirror/lang-markdown';
import { zipSync, unzipSync, strToU8, strFromU8 } from 'fflate';
const languageFor = (path) => /\.html?$/.test(path) ? html() : /\.css$/.test(path) ? css() : /\.[cm]?[jt]sx?$/.test(path) ? javascript({ typescript: /\.tsx?$/.test(path) }) : /\.(md|markdown)$/.test(path) ? markdown() : [];
window.project = {
  // One EditorView, one EditorState per open file: switching tabs swaps the state, so every file keeps its own undo history.
  multiState(files) {
    const states = new Map();
    const stateFor = (path) => { if (!states.has(path)) states.set(path, EditorState.create({ doc: files[path], extensions: [basicSetup, languageFor(path)] })); return states.get(path); };
    const paths = Object.keys(files);
    const view = new EditorView({ state: stateFor(paths[0]), parent: document.getElementById('host') });
    let current = paths[0];
    const open = (path) => { states.set(current, view.state); current = path; view.setState(stateFor(path)); };
    const out = {};
    view.dispatch({ changes: { from: 0, insert: 'EDIT-A ' } });
    open(paths[1]);
    view.dispatch({ changes: { from: 0, insert: 'EDIT-B ' } });
    view.dispatch({ changes: { from: 0, insert: 'AI-PATCH ' }, annotations: isolateHistory.of('full') });
    open(paths[0]);
    out.firstStillEdited = view.state.doc.sliceString(0, 7);
    out.firstUndoDepth = undoDepth(view.state);
    undo(view); out.firstAfterUndo = view.state.doc.sliceString(0, 7) !== 'EDIT-A ';
    open(paths[1]);
    out.secondUndoDepth = undoDepth(view.state);
    undo(view); out.secondAfterOneUndo = view.state.doc.sliceString(0, 7);
    // Cost of keeping many files open at once.
    const t0 = performance.now(); const heap0 = performance.memory?.usedJSHeapSize ?? 0;
    for (const path of paths) stateFor(path);
    out.createAllStatesMs = Math.round(performance.now() - t0); out.files = paths.length;
    out.heapDeltaMB = performance.memory ? Math.round((performance.memory.usedJSHeapSize - heap0) / 1048576) : null;
    const t1 = performance.now(); for (let i = 0; i < 50; i += 1) open(paths[i % paths.length]); out.switchTabMsAvg = +((performance.now() - t1) / 50).toFixed(2);
    return out;
  },
  zipRoundTrip(entries) {
    const input = {}; let bytes = 0;
    for (const [path, text] of entries) { input[path] = strToU8(text); bytes += input[path].length; }
    const t0 = performance.now(); const zipped = zipSync(input, { level: 6 }); const t1 = performance.now();
    const back = unzipSync(zipped); const t2 = performance.now();
    const same = Object.keys(back).length === entries.length && entries.every(([path, text]) => strFromU8(back[path]) === text);
    return { files: entries.length, rawMB: +(bytes / 1048576).toFixed(2), zipMB: +(zipped.length / 1048576).toFixed(2), zipMs: Math.round(t1 - t0), unzipMs: Math.round(t2 - t1), identical: same };
  },
  folderInput(input) { return [...input.files].map((file) => ({ path: file.webkitRelativePath, size: file.size })); },
};
