---
theme: default
title: Wave packets
routerMode: memory
fonts:
  provider: none
---

# Wave packets

and the uncertainty principle

---
layout: two-cols
---

# A Gaussian packet

$$
\psi(x)=\frac{1}{(2\pi\sigma^2)^{1/4}}e^{-x^2/4\sigma^2}e^{ik_0x}
$$

<v-click>

Width in position: $\Delta x=\sigma$

</v-click>

::right::

![Public picture](/dot.png)

![Relative picture](./images/dot2.png)

---

# Predict, then explore

<PacketDemo />

---
layout: center
---

# Recap

$\Delta x\,\Delta k \ge \tfrac12$

---

# Diagram

```mermaid
graph LR
  A[Source] --> B[Slits] --> C[Screen]
```
