// Is an ORDINARY `slidev build` output location-independent and offline-capable?
// Serve dist (base "/") and dist-relative (--base ./) from a sub-folder of a fake origin, block all other network.
import { createRequire } from 'node:module';
import { readFileSync, existsSync, statSync } from 'node:fs';
import { join, extname } from 'node:path';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const SHARED = process.env.SHARED; const P = new URL('..', import.meta.url).pathname;
const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.svg': 'image/svg+xml', '.woff2': 'font/woff2', '.woff': 'font/woff', '.ttf': 'font/ttf', '.json': 'application/json', '.ico': 'image/x-icon' };
const browser = await chromium.launch();
for (const [label, dir, mount] of [['default base "/" served from /decks/talk/', 'dist', '/decks/talk/'], ['--base ./ served from /decks/talk/', 'dist-relative', '/decks/talk/'], ['--base ./ served from site root /', 'dist-relative', '/']]) {
  const root = join(SHARED, 'slidev-ordinary', dir);
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 720 } }); const page = await ctx.newPage();
  const blocked = [], notFound = [], errors = [];
  page.on('pageerror', (e) => errors.push(String(e.message).slice(0, 160)));
  page.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text().slice(0, 160)); });
  await ctx.route('**/*', (route) => {
    const u = new URL(route.request().url());
    if (u.host !== 'b7.test') { blocked.push(u.href.slice(0, 110)); return route.abort(); }
    if (!u.pathname.startsWith(mount)) { notFound.push(u.pathname); return route.fulfill({ status: 404, body: 'not found' }); }
    let f = join(root, decodeURIComponent(u.pathname.slice(mount.length)) || 'index.html');
    if (existsSync(f) && statSync(f).isDirectory()) f = join(f, 'index.html');
    if (!existsSync(f)) { notFound.push(u.pathname); return route.fulfill({ status: 404, body: 'not found' }); }
    route.fulfill({ status: 200, contentType: mime[extname(f)] || 'application/octet-stream', body: readFileSync(f) });
  });
  await page.goto('http://b7.test' + mount + 'index.html', { waitUntil: 'load' }).catch((e) => errors.push('goto: ' + e.message.slice(0, 120)));
  await page.waitForTimeout(2500);
  const info = await page.evaluate(() => ({ url: location.href, slideEls: document.querySelectorAll('.slidev-page').length, text: (document.querySelector('#app')?.innerText || '').replace(/\s+/g, ' ').slice(0, 90), katex: document.querySelectorAll('.katex').length, canvas: document.querySelectorAll('canvas').length, svg: document.querySelectorAll('#app svg').length }));
  await page.keyboard.press('ArrowRight'); await page.waitForTimeout(800);
  const after = await page.evaluate(() => location.href);
  await page.screenshot({ path: P + 'shots/slidev-' + dir + (mount === '/' ? '-root' : '-sub') + '.png' });
  console.log('\n## ' + label + '\n', JSON.stringify(info), '\n after ArrowRight:', after, '\n blocked external:', [...new Set(blocked)], '\n 404:', [...new Set(notFound)].slice(0, 5), '\n errors:', errors.slice(0, 3));
  await ctx.close();
}
await browser.close();
