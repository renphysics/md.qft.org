import { createRequire } from 'node:module';
const require = createRequire(import.meta.url); const { chromium } = require('playwright');
const b = await chromium.launch(); const p = await b.newPage();
await p.goto('https://agentskills.io/clients', { waitUntil: 'domcontentloaded' }); await p.waitForLoadState('networkidle', { timeout: 8000 }).catch(() => {});
const names = await p.evaluate(() => { const out = new Set(); for (const a of document.querySelectorAll('a')) { if (/Setup instructions/.test(a.textContent)) { let card = a.parentElement; for (let i = 0; i < 6 && card; i++) { const h = card.querySelector('h2,h3,h4,[class*=title],strong'); if (h && h.textContent.trim() && !/Setup/.test(h.textContent)) { out.add(h.textContent.trim()); break; } card = card.parentElement; } } } return [...out]; });
console.log(names.length, names.sort().join('; '));
await b.close();
