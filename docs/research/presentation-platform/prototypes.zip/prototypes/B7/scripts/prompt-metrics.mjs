import { generateLessonPrompt, createStarterLesson } from '../bundles/ai-lesson.mjs';
import { generateSlidevPrompt } from '../bundles/slidev-prompt.mjs';
import { writeFileSync, readFileSync } from 'node:fs';
const input = { topic: 'Wave packets and the uncertainty principle, based on chapter 3 of my course notes.', audience: 'Undergraduate students', language: 'English', duration: 45, mathLevel: 'Match the audience', demos: '' };
const words = (s) => s.split(/\s+/).filter(Boolean).length;
// crude token estimate: ~4 chars/token for English prose
const metrics = (name, s) => ({ name, chars: s.length, words: words(s), lines: s.split('\n').length, approxTokens: Math.round(s.length / 4),
  imperatives: (s.match(/\b(?:Do not|No |must|Keep|Use|Include|Return|Give|Put|Check|Deliver|Preserve|Avoid)\b/g) || []).length,
  numbersToRemember: (s.match(/\b\d[\d,.]*\b/g) || []).length });
const qft = generateLessonPrompt(input), slidev = generateSlidevPrompt(input);
writeFileSync(new URL('../out-qft-prompt.txt', import.meta.url), qft);
writeFileSync(new URL('../out-slidev-prompt.txt', import.meta.url), slidev);
const fmt = readFileSync('/home/user/md.qft.org/public/lesson-format-v2.md', 'utf8');
const readme = readFileSync('/home/user/md.qft.org/tools/slidev/README.md', 'utf8');
console.table([metrics('QFT Markdown prompt (generateLessonPrompt)', qft), metrics('Slidev prompt (generateSlidevPrompt)', slidev), metrics('public/lesson-format-v2.md', fmt), metrics('tools/slidev/README.md', readme)]);
const starter = createStarterLesson(input);
console.log('starter files:', starter.project.files.map(f => f.path + ' ' + f.content.length));
// What does the Slidev prompt require that needs a terminal / network?
for (const kw of ['npm ci', 'npm run build', 'node pack.mjs', 'github.com', 'attached', 'Open the packaged presentation in md.qft.org', 'network access disabled']) console.log(kw.padEnd(48), slidev.includes(kw));
