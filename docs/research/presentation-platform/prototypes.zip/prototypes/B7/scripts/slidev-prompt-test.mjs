// Play the deck built by the exact command sequence of the proposed Slidev prompt, from a sub-folder, with network blocked.
import { createRequire } from 'node:module';
import { readFileSync, existsSync, statSync } from 'node:fs';
import { join, extname } from 'node:path';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const P = new URL('..', import.meta.url).pathname; const root = P + 'slidev-prompt-test/dist'; const mount = '/u/decks/wave/';
const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.svg': 'image/svg+xml', '.woff2': 'font/woff2', '.woff': 'font/woff', '.ttf': 'font/ttf' };
const browser = await chromium.launch(); const ctx = await browser.newContext({ viewport: { width: 1280, height: 720 } }); const page = await ctx.newPage();
const blocked = [], notFound = [], errors = [];
page.on('pageerror', (e) => errors.push(String(e.message).slice(0, 160)));
await ctx.route('**/*', (route) => { const u = new URL(route.request().url());
  if (u.host !== 'b7.test') { blocked.push(u.href.slice(0, 100)); return route.abort(); }
  let f = join(root, decodeURIComponent(u.pathname.slice(mount.length)) || 'index.html');
  if (!u.pathname.startsWith(mount) || !existsSync(f) || statSync(f).isDirectory()) { notFound.push(u.pathname); return route.fulfill({ status: 404, body: '' }); }
  route.fulfill({ status: 200, contentType: mime[extname(f)] || 'application/octet-stream', body: readFileSync(f) }); });
await page.goto('http://b7.test' + mount + 'index.html'); await page.waitForTimeout(2000);
const out = { start: await page.evaluate(() => location.hash) };
await page.keyboard.press('ArrowRight'); await page.waitForTimeout(700);           // slide 2
out.slide2 = await page.evaluate(() => ({ hash: location.hash, katex: document.querySelectorAll('.slidev-page-2 .katex-display, .slidev-page-2 .katex').length, imgs: [...document.querySelectorAll('.slidev-page-2 img')].map((i) => ({ src: i.getAttribute('src'), ok: i.complete && i.naturalWidth > 0 })) }));
await page.keyboard.press('ArrowRight'); await page.keyboard.press('ArrowRight'); await page.waitForTimeout(900);  // click + slide 3
out.slide3 = await page.evaluate(() => ({ hash: location.hash, ranges: document.querySelectorAll('.slidev-page-3 input[type=range]').length, d: document.querySelector('.slidev-page-3 svg path')?.getAttribute('d')?.slice(0, 40) }));
out.interaction = await page.evaluate(async () => { const input = document.querySelector('.slidev-page-3 input[type=range]'); const path = document.querySelector('.slidev-page-3 svg path'); const a = path.getAttribute('d'); input.value = '2.5'; input.dispatchEvent(new Event('input', { bubbles: true })); await new Promise((r) => setTimeout(r, 300)); return a === path.getAttribute('d') ? 'UNCHANGED' : 'SVG path updated by slider (OK)'; });
await page.screenshot({ path: P + 'shots/slidev-prompt-test.png' });
console.log(JSON.stringify({ ...out, blockedExternal: [...new Set(blocked)], notFound: [...new Set(notFound)], errors }, null, 1));
await browser.close();
