// Plays decks in md.qft.org's REAL player (src/lib/presentation-runtime.ts bundled unmodified + the shipped
// dist/presentation-sandbox.html runner), with ALL network blocked. No TCP server: files are route-fulfilled.
import { createRequire } from 'node:module';
import { readFileSync, writeFileSync, readdirSync, statSync, mkdirSync } from 'node:fs';
import { join, relative } from 'node:path';
import { inlineDeck } from './inline-deck.mjs';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const P = new URL('..', import.meta.url).pathname;
const runtime = readFileSync(P + 'bundles/presentation-runtime.iife.js', 'utf8');
const runner = readFileSync('/home/user/md.qft.org/dist/presentation-sandbox.html', 'utf8');
const walk = (dir, base = dir, out = new Map()) => { for (const n of readdirSync(dir)) { const f = join(dir, n); if (statSync(f).isDirectory()) walk(f, base, out); else out.set(relative(base, f), readFileSync(f)); } return out; };
mkdirSync(P + 'shots', { recursive: true }); mkdirSync(P + 'inlined', { recursive: true });

const uchicago = walk(P + 'real-decks/uchicago/lecture-07');
uchicago.set('../assets/css/uchicago-theme.css', readFileSync(P + 'real-decks/uchicago/assets/css/uchicago-theme.css'));
const cases = [
  { id: 'claude-lecture-1-RAW', html: readFileSync(P + 'real-decks/hoyle-part1.html', 'utf8'), raw: true },
  { id: 'claude-lecture-1-NO-HISTORY-SHIM', html: readFileSync(P + 'real-decks/hoyle-part1.html', 'utf8'), noShim: true },
  { id: 'claude-lecture-1', html: readFileSync(P + 'real-decks/hoyle-part1.html', 'utf8') },
  { id: 'claude-lecture-2', html: readFileSync(P + 'real-decks/hoyle-part2.html', 'utf8') },
  { id: 'uchicago-lecture-07', html: uchicago.get('index.html').toString('utf8'), files: uchicago },
  { id: 'skill-example-ryanbbrown', html: readFileSync(P + 'real-decks/ryanbbrown-example.html', 'utf8'), files: new Map([['styles.css', readFileSync(P + 'real-decks/ryanbbrown-styles.css')]]) },
  { id: 'profile-reference', html: readFileSync(P + 'contract/reveal-profile-reference.html', 'utf8') },
];

const browser = await chromium.launch();
const results = [];
for (const c of cases) {
  const { html, report } = c.raw ? { html: c.html, report: null } : inlineDeck(c.html, c.files, { historyShim: !c.noShim });
  if (!c.raw) writeFileSync(P + 'inlined/' + c.id + '.html', html);
  const context = await browser.newContext({ viewport: { width: 1280, height: 760 } });
  const page = await context.newPage();
  const blocked = [];
  await context.route('**/*', (route) => {
    const url = route.request().url();
    if (url === 'http://b7.test/harness.html') return route.fulfill({ contentType: 'text/html', body: `<!doctype html><meta charset="utf-8"><body style="margin:0"><div id="host" style="width:1280px;height:720px"></div><script src="/runtime.js"></script>` });
    if (url === 'http://b7.test/runtime.js') return route.fulfill({ contentType: 'text/javascript', body: runtime });
    if (url === 'http://b7.test/presentation-sandbox.html') return route.fulfill({ contentType: 'text/html', body: runner });
    if (url.startsWith('blob:') || url.startsWith('data:')) return route.continue();
    blocked.push(url.slice(0, 140)); return route.abort();
  });
  await page.goto('http://b7.test/harness.html');
  const t0 = Date.now();
  const outcome = await page.evaluate(({ html, id }) => new Promise((resolve) => {
    const states = []; let error = null;
    const player = QFT.createPresentationPlayer(document.getElementById('host'), html, { title: id, sandboxUrl: '/presentation-sandbox.html',
      onState(s) { states.push(s); if (s === 'ready') setTimeout(() => resolve({ states, error }), 600); if (s === 'error') setTimeout(() => resolve({ states, error }), 50); },
      onError(m) { error = m; } });
    window.__player = player; player.start();
    setTimeout(() => resolve({ states, error: error || 'timeout (25 s)' }), 25000);
  }), { html, id: c.id });
  const row = { id: c.id, inputBytes: Buffer.byteLength(c.html), playedBytes: Buffer.byteLength(html), states: outcome.states.join('>'), error: outcome.error, ms: Date.now() - t0 };
  if (outcome.states.at(-1) === 'ready') {
    const deck = page.frames().find((f) => f.url().startsWith('blob:'));
    row.origin = await deck.evaluate(() => window.origin);
    row.inside = await deck.evaluate(() => {
      const R = window.Reveal; const out = { reveal: typeof R, version: R?.VERSION, ready: R?.isReady?.(), slides: R?.getTotalSlides?.(), katex: document.querySelectorAll('.katex').length, rawDollar: (document.querySelector('.slides')?.innerText.match(/\$[^$\n]{2,60}\$/g) || []).length, canvases: document.querySelectorAll('canvas').length, ranges: document.querySelectorAll('input[type=range]').length, hljs: document.querySelectorAll('.hljs').length, mdSections: document.querySelectorAll('section[data-markdown-parsed]').length, imgsBroken: [...document.images].filter((i) => !i.complete || !i.naturalWidth).length, imgs: document.images.length, fontFamily: getComputedStyle(document.querySelector('.reveal') || document.body).fontFamily.slice(0, 60) };
      return out;
    });
    // keyboard navigation through the real focus path
    const before = await deck.evaluate(() => JSON.stringify(Reveal.getIndices()));
    await page.evaluate(() => window.__player.focus());
    await deck.evaluate(() => document.body.focus());
    await page.keyboard.press('ArrowRight'); await page.keyboard.press('ArrowRight'); await page.waitForTimeout(700);
    row.navigation = before + ' -> ' + await deck.evaluate(() => JSON.stringify(Reveal.getIndices()));
    // interaction: move the first range input on a slide that has a canvas, compare canvas pixels
    row.interaction = await deck.evaluate(async () => {
      const slide = [...document.querySelectorAll('.slides section')].find((s) => s.querySelector('canvas') && s.querySelector('input[type=range]'));
      if (!slide) return 'no slider+canvas slide';
      const idx = Reveal.getIndices(slide); Reveal.slide(idx.h, idx.v || 0, 99);
      await new Promise((r) => setTimeout(r, 900));
      const canvas = slide.querySelector('canvas'), input = slide.querySelector('input[type=range]');
      const snap = () => { try { return canvas.toDataURL().length + ':' + canvas.toDataURL().slice(-64); } catch (e) { return 'ERR ' + e.message; } };
      const a = snap(); input.value = String((Number(input.min) + Number(input.max)) / 2 + Number(input.step || 1)); input.dispatchEvent(new Event('input', { bubbles: true })); input.dispatchEvent(new Event('change', { bubbles: true }));
      await new Promise((r) => setTimeout(r, 500));
      return a === snap() ? 'canvas UNCHANGED after slider input' : 'canvas redrawn after slider input (OK)';
    });
    await page.screenshot({ path: P + 'shots/' + c.id + '.png' });
  }
  row.blockedRequests = blocked.length; row.blockedSample = [...new Set(blocked)].slice(0, 4);
  if (report) row.report = { inlined: report.inlined.length, coerced: [...new Set(report.coerced.map((x) => `${x.lib} ${x.requested}->${x.served}`))], dropped: report.dropped.map((d) => d.kind + ' ' + String(d.url).slice(0, 60)), unresolved: report.unresolved.map((u) => u.kind + ' ' + String(u.url).slice(0, 80)), hazards: report.hazards };
  results.push(row);
  await context.close();
}
await browser.close();
writeFileSync(P + 'play-test-results.json', JSON.stringify(results, null, 1));
for (const r of results) console.log(JSON.stringify(r, null, 1));
