// B7 prototype of the proposed "Check deck" report (qft-deck-check/1). Static analysis only (runtime block is merged
// from the real-player run when available). Input: a .html file, or a .zip. Output: the paste-back block.
import { createRequire } from 'node:module';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { resolveCdn } from './inline-deck.mjs';
const require = createRequire('/home/user/md.qft.org/package.json');
const { unzipSync, strFromU8 } = require('fflate');
const RULES = { reveal: 'https://md.qft.org/ai/reveal.md', slidev: 'https://md.qft.org/ai/slidev.md' };
const lineOf = (text, index) => text.slice(0, index).split('\n').length;
const snip = (s) => s.replace(/\s+/g, ' ').trim().slice(0, 110);

export function checkDeck(name, bytes, runtime) {
  const files = new Map();
  if (/\.zip$/i.test(name)) { for (const [k, v] of Object.entries(unzipSync(bytes))) if (!k.endsWith('/') && !k.startsWith('__MACOSX/')) files.set(k, v); }
  else files.set(name.split('/').pop(), bytes);
  // strip one enclosing folder
  const keys = [...files.keys()]; const top = keys[0]?.split('/')[0];
  if (keys.length > 1 && keys.every((k) => k.startsWith(top + '/'))) { for (const k of keys) { files.set(k.slice(top.length + 1), files.get(k)); files.delete(k); } }
  const paths = [...files.keys()];
  const text = (p) => strFromU8(files.get(p));
  const mustFix = [], shouldFix = [], handled = [];
  const deck = { files: paths.length, bytes: [...files.values()].reduce((a, b) => a + b.length, 0) };
  const pkgPath = paths.find((p) => /^package\.json$/.test(p));
  const pkg = pkgPath ? (() => { try { return JSON.parse(text(pkgPath)); } catch { return null; } })() : null;
  const isSlidevSrc = !!(pkg && ({ ...pkg.dependencies, ...pkg.devDependencies })['@slidev/cli']) || (paths.includes('slides.md') && /^---\n[\s\S]*?\n---/.test(text('slides.md')) && /\b(?:theme|layout|transition|mdc|routerMode|class):/.test(text('slides.md').slice(0, 600)));
  const htmlEntries = paths.filter((p) => /(^|\/)index\.html?$/i.test(p)).sort((a, b) => a.length - b.length);
  const entry = htmlEntries[0] || paths.find((p) => /\.html?$/i.test(p));
  const entryHtml = entry ? text(entry) : '';
  const isSlidevDist = /<meta property="slidev:version"/.test(entryHtml);
  let rules = RULES.reveal;

  if (isSlidevDist) {
    rules = RULES.slidev; deck.kind = 'slidev-dist'; deck.entry = entry; deck.engine = 'slidev ' + (entryHtml.match(/slidev:version" content="([^"]+)/) || [])[1];
    const abs = [...entryHtml.matchAll(/(?:src|href)="(\/assets\/[^"]+)"/g)];
    if (abs.length) mustFix.push({ code: 'slidev-absolute-base', where: `${entry}:${lineOf(entryHtml, abs[0].index)}`, found: abs[0][1], fix: 'Rebuild with a relative base: `slidev build --base ./`.' });
    const js = paths.filter((p) => /\.js$/.test(p)).map(text).join('\n');
    // The resolved Slidev config is embedded in the bundle, e.g. routerMode:`history` (verified on @slidev/cli 53.1.0 builds).
    const mode = (js.match(/routerMode:[`"'](history|hash|memory)[`"']/) || [])[1] || 'history';
    deck.routerMode = mode;
    if (mode === 'history') mustFix.push({ code: 'slidev-history-router', where: 'slides.md headmatter', found: 'routerMode: history (default)', fix: 'Add `routerMode: hash` to the first frontmatter block of slides.md, then rebuild.' });
    const font = entryHtml.match(/<link[^>]+href="(https:\/\/fonts\.googleapis\.com[^"]+)"/);
    if (font) shouldFix.push({ code: 'remote-font', where: `${entry}:${lineOf(entryHtml, font.index)}`, found: snip(font[1]), fix: 'Add `fonts: { provider: none }` to the headmatter (system or bundled fonts), then rebuild.' });
    if (!paths.some((p) => /(^|\/)slides\.md$/.test(p))) shouldFix.push({ code: 'no-source', where: 'ZIP root', found: 'compiled files only', fix: 'Include the source next to the build (slides.md, components/, package.json, package-lock.json) so it can be edited and rebuilt later.' });
  } else if (isSlidevSrc && !entry) {
    rules = RULES.slidev; deck.kind = 'slidev-source'; deck.entry = 'slides.md';
    mustFix.push({ code: 'slidev-not-built', where: 'ZIP root', found: 'slides.md + package.json, no dist/', fix: 'Build it and include the output: add `routerMode: hash` and `fonts: { provider: none }` to the headmatter, run `npm install && npx slidev build --base ./`, then zip the project INCLUDING dist/ (exclude node_modules). If you cannot run commands, say so; the user can build with the GitHub template at ' + RULES.slidev + '#no-node.' });
    const md = text('slides.md'); const vue = [...md.matchAll(/<([A-Z][A-Za-z0-9]+)\b/g)].map((m) => m[1]).filter((n) => !['Transform', 'Arrow', 'Toc', 'Tweet', 'Youtube', 'SlidevVideo', 'AutoFitText', 'LightOrDark', 'Link', 'RenderWhen', 'SlideCurrentNo', 'SlidesTotal', 'TitleRenderer', 'VDragArrow', 'VSwitch', 'PoweredBySlidev'].includes(n));
    const missing = [...new Set(vue)].filter((n) => !paths.some((p) => new RegExp(`components/${n}\\.vue$`).test(p)));
    if (missing.length) mustFix.push({ code: 'slidev-missing-component', where: 'slides.md', found: missing.map((n) => `<${n}>`).join(' '), fix: 'Add components/' + missing[0] + '.vue (and the others) or remove the tags.' });
  } else if (entry) {
    deck.kind = paths.length === 1 ? 'reveal-html' : 'reveal-project'; deck.entry = entry;
    const html = entryHtml;
    if (!/class\s*=\s*["'][^"']*\breveal\b/.test(html) || !/Reveal\.initialize|new\s+Reveal\s*\(/.test(html)) mustFix.push({ code: 'not-reveal', where: entry, found: 'no <div class="reveal"> / Reveal.initialize()', fix: 'Deliver a reveal.js deck: <div class="reveal"><div class="slides"><section>…</section></div></div> and one Reveal.initialize({...}) call.' });
    deck.slides = (html.match(/<section\b/gi) || []).length;
    const engines = new Set();
    for (const m of html.matchAll(/<(script|link)\b[^>]*\b(?:src|href)\s*=\s*["']([^"']+)["'][^>]*>/gi)) {
      const [tag, el, url] = m; const where = `${entry}:${lineOf(html, m.index)}`;
      const rel = (tag.match(/\brel\s*=\s*["']([^"']+)/i) || [])[1] || '';
      if (el === 'link' && rel && !/stylesheet/i.test(rel)) { if (/^https?:/.test(url)) handled.push(`${rel} link removed (${new URL(url).host})`); continue; }
      if (/^https?:\/\/fonts\.(googleapis|gstatic)\.com/.test(url)) { handled.push('Google Fonts stylesheet dropped; fallback fonts are used'); continue; }
      if (/^https?:/.test(url)) {
        const r = resolveCdn(url);
        if (r) { engines.add(`${r.lib} ${r.requested}`); if (r.requested !== r.served) handled.push(`${r.lib} ${r.requested} from ${new URL(url).host} replaced by bundled ${r.lib} ${r.served}`); else handled.push(`${r.lib} ${r.served} served from the site bundle (no network)`); continue; }
        mustFix.push({ code: 'lib-not-bundled', where, found: snip(url), fix: `md.qft.org plays offline and bundles only reveal.js and KaTeX. Remove this ${el === 'script' ? 'script' : 'stylesheet'} or paste its code inline; do not load it from a URL.` });
      } else if (!files.has(url.split(/[?#]/)[0].replace(/^\.\//, ''))) {
        mustFix.push({ code: 'missing-file', where, found: url, fix: paths.length === 1 ? 'Inline this file into index.html, or deliver a ZIP that contains it at this relative path.' : 'Add this file to the ZIP at exactly this relative path, or inline it.' });
      }
    }
    deck.engine = [...engines].join(', ') || 'unknown';
    const authored = html.replace(/<script\b[^>]*\bsrc\s*=[^>]*>\s*<\/script>/gi, (s) => s.replace(/[^\n]/g, ' '));
    const scan = (re, code, sev, fix) => { const m = re.exec(authored); if (m) (sev === 'must' ? mustFix : shouldFix).push({ code, where: `${entry}:${lineOf(authored, m.index)}`, found: snip(authored.slice(m.index, m.index + 110)), fix }); };
    scan(/<[a-z][^>]*\s+on[a-z]+\s*=\s*["']/i, 'inline-event-attribute', 'must', 'Inline handlers (onclick=…) are removed by the player. Attach every handler with addEventListener in a <script>.');
    scan(/\bfetch\s*\(|new\s+XMLHttpRequest|new\s+WebSocket\s*\(|new\s+EventSource\s*\(/, 'network-call', 'must', 'The deck runs with no network. Embed the data in the HTML (a JS object or <script type="application/json">).');
    scan(/<iframe\b|<object\b|<embed\b/i, 'embedded-frame', 'must', 'Embedded pages are blocked. Build the demonstration directly in the slide (canvas/SVG + script).');
    scan(/\bimport\s+[\w*{][^;\n]*\bfrom\s*["']https?:|import\s*\(\s*["']https?:/, 'remote-module', 'must', 'Remote ES-module imports cannot load. Use a classic inline <script>.');
    scan(/\beval\s*\(|new\s+Function\s*\(/, 'eval', 'must', 'eval/new Function are blocked. Write the function directly.');
    scan(/new\s+(?:Shared)?Worker\s*\(/, 'worker', 'must', 'Workers are blocked. Compute on the main thread in small bounded steps.');
    scan(/data-markdown\s*=\s*["'][^"']+\.md/i, 'external-markdown', 'must', 'External Markdown files need fetch. Put the Markdown inside <textarea data-template> in the section.');
    scan(/<img\b[^>]*\bsrc\s*=\s*["']https?:/i, 'remote-image', 'must', 'Remote images cannot load. Embed the image as a data: URI or include the file in the ZIP.');
    scan(/\b(?:localStorage|sessionStorage)\b/, 'storage', 'should', 'Storage is temporary inside the player (cleared on restart). Keep state in variables; define starting values in the source.');
    scan(/\bindexedDB\b|document\.cookie/, 'persistent-storage', 'must', 'IndexedDB and cookies are unavailable. Keep state in memory.');
    if (/\bhash\s*:\s*true|\bhistory\s*:\s*true/.test(authored)) handled.push('Reveal hash/history option neutralised (URL updates are not available in the player)');
    if (/\$[^$\n]*[\\^_][^$\n]*\$|\\\(|\\\[/.test(authored.replace(/<script[\s\S]*?<\/script>/gi, '')) && !/RevealMath|renderMathInElement|katex\.render|MathJax/.test(html)) shouldFix.push({ code: 'math-not-rendered', where: entry, found: 'TeX delimiters but no math renderer', fix: 'Load the reveal.js math plugin and add plugins: [RevealMath.KaTeX] to Reveal.initialize.' });
    if (/RevealMath\.MathJax|MathJax\s*=|mathjax/i.test(html)) handled.push('MathJax request rendered with bundled KaTeX instead (check unusual macros)');
    if (!/<meta\s+name\s*=\s*["']qft-deck["']/i.test(html)) handled.push('Deck id assigned on import (meta name="qft-deck")');
  } else {
    deck.kind = 'unknown';
    mustFix.push({ code: 'no-entry', where: 'ZIP root', found: paths.slice(0, 6).join(', ') || '(empty)', fix: 'Deliver index.html (a reveal.js deck) at the top level of the ZIP, or a built Slidev project (dist/index.html + slides.md).' });
  }
  const id = (entryHtml.match(/<meta\s+name\s*=\s*["']qft-deck["']\s+content\s*=\s*["']id=([\w-]+)/i) || [])[1] || 'unassigned';
  deck.id = id; deck.rev = 'sha256-' + createHash('sha256').update(entry ? files.get(entry) : bytes).digest('hex').slice(0, 12);
  if (runtime) { if (runtime.state === 'error' && !mustFix.length) mustFix.push({ code: 'runtime-error', where: 'while starting the deck', found: snip(runtime.message || ''), fix: 'Fix this JavaScript error. Do not reference libraries that are not included.' }); }
  const verdict = mustFix.length ? 'blocked' : (shouldFix.length || handled.length) ? 'plays-with-notes' : 'plays';
  const report = { report: 'qft-deck-check/1', verdict, deck, mustFix, shouldFix, handledForYou: [...new Set(handled)], ...(runtime ? { runtime } : {}), rules,
    reply: mustFix.length ? `Fix every mustFix item and return the complete corrected ${deck.kind === 'reveal-html' ? 'index.html in one code block' : 'ZIP'}. Keep the qft-deck id. Do not change slide content that is not mentioned.` : 'No changes required.' };
  return `md.qft.org deck check — paste this whole block to your AI assistant.\n\`\`\`json\n${JSON.stringify(report, null, 1)}\n\`\`\`\n`;
}

if (process.argv[1] === new URL(import.meta.url).pathname) {
  const P = new URL('..', import.meta.url).pathname;
  const rt = existsSync(P + 'play-test-results.json') ? JSON.parse(readFileSync(P + 'play-test-results.json', 'utf8')) : [];
  const runtimeFor = (id) => { const r = rt.find((x) => x.id === id); return r ? { state: r.states.split('>').pop(), ...(r.error ? { message: r.error } : {}), ...(r.inside ? { slides: r.inside.slides, mathRendered: r.inside.katex, networkRequests: r.blockedRequests } : {}) } : undefined; };
  const inputs = [['real-decks/hoyle-part1.html', 'claude-lecture-1'], ['real-decks/ryanbbrown-example.html', 'skill-example-ryanbbrown'], ['contract/reveal-profile-reference.html', 'profile-reference'], ['corpus/F-slidev-source.zip'], ['corpus/H-slidev-dist-default-base.zip'], ['corpus/C-reveal6-project.zip'], ['corpus/B-html-cdn+README.zip']];
  let all = '';
  for (const [rel, rid] of inputs) { const out = checkDeck(rel, new Uint8Array(readFileSync(P + rel)), rid && runtimeFor(rid)); all += `\n===== ${rel} (${out.length} chars) =====\n${out}`; }
  writeFileSync(P + 'check-report-examples.txt', all); process.stdout.write(all);
}
