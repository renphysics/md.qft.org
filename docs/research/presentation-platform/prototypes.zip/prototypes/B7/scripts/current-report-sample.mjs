import { checkLesson, formatLessonReport } from '../bundles/lesson-check.mjs';
const src = `# Wave packets

![](images/missing.png)

![remote](https://upload.wikimedia.org/x.png)

---

## Demo

\`\`\`interactive title="Explore"
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<button onclick="go()">Go</button>
<script>function go(){ fetch('/data.json') }</script>
\`\`\`

---

$$\\frac{1}{2$$
`;
const r = checkLesson(src, {});
const out = formatLessonReport(r);
console.log(out); console.log('chars:', out.length);
