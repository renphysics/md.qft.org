// Baseline: what does the CURRENT md.qft.org importer say about the shapes AIs naturally deliver?
// Uses esbuild bundles of the repo's own src/lib (unmodified) and runs them in Node 22 (global File/Blob).
import { createRequire } from 'node:module';
import { readFileSync, writeFileSync, readdirSync, statSync } from 'node:fs';
import { join, relative } from 'node:path';
const require = createRequire('/home/user/md.qft.org/package.json');
const { zipSync, strToU8 } = require('fflate');
const { inspectPresentationArchive } = await import('../bundles/presentation-package.mjs');
const { importWorkspaceBundle } = await import('../bundles/document-bundle.mjs');
const P = new URL('..', import.meta.url).pathname;
const RJ = '/home/user/md.qft.org/node_modules/reveal.js';
const read = (p) => new Uint8Array(readFileSync(p));
const walk = (dir, base = dir, out = {}) => { for (const n of readdirSync(dir)) { const f = join(dir, n); if (statSync(f).isDirectory()) walk(f, base, out); else out[relative(base, f)] = read(f); } return out; };
const hoyle = read(P + 'real-decks/hoyle-part1.html');
const readme = strToU8('# My deck\n\nOpen index.html in a browser. Press S for speaker notes.\n');
const cdnDeck = strToU8(`<!doctype html><html><head><meta charset="utf-8"><title>Deck</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/reveal.js@5.1.0/dist/reveal.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/reveal.js@5.1.0/dist/theme/black.css"></head>
<body><div class="reveal"><div class="slides"><section><h1>Hello</h1></section><section><h2>Two</h2></section></div></div>
<script src="https://cdn.jsdelivr.net/npm/reveal.js@5.1.0/dist/reveal.js"></script>
<script>Reveal.initialize({hash:true});</script></body></html>`);
const localDeck6 = strToU8(`<!doctype html><html><head><meta charset="utf-8"><title>Deck</title>
<link rel="stylesheet" href="dist/reveal.css"><link rel="stylesheet" href="dist/theme/black.css"></head>
<body><div class="reveal"><div class="slides"><section><h1>Hello</h1></section></div></div>
<script src="dist/reveal.js"></script><script src="dist/plugin/markdown.js"></script>
<script>Reveal.initialize({hash:true,plugins:[RevealMarkdown]});</script></body></html>`);
const reveal6 = Object.fromEntries(['dist/reveal.js', 'dist/reveal.css', 'dist/reset.css', 'dist/theme/black.css', 'dist/plugin/markdown.js', 'dist/plugin/notes.js', 'dist/plugin/math.js', 'dist/plugin/highlight.js', 'dist/plugin/highlight/monokai.css'].map(p => [p, read(join(RJ, p))]));
const slidesMd = read('SHARED/slidev-ordinary/slides.md'.replace('SHARED', process.env.SHARED));
const slidevPkg = read(process.env.SHARED + '/slidev-ordinary/package.json');
const vue = Object.fromEntries(Object.entries(walk(process.env.SHARED + '/slidev-ordinary/components')).map(([k, v]) => ['components/' + k, v]));
const dist = walk(process.env.SHARED + '/slidev-ordinary/dist');
const distRel = walk(process.env.SHARED + '/slidev-ordinary/dist-relative');
const prefix = (o, p) => Object.fromEntries(Object.entries(o).map(([k, v]) => [p + k, v]));
const corpus = {
  'A-single-html-cdn.zip': { 'index.html': cdnDeck },
  'A2-real-claude-lecture-single-html.zip': { 'part1-beta-binomial.html': hoyle },
  'B-html-cdn+README.zip': { 'index.html': cdnDeck, 'README.md': readme },
  'C-reveal6-project.zip': { 'index.html': localDeck6, ...reveal6 },
  'D-reveal6-project+README.zip': { 'index.html': localDeck6, 'README.md': readme, ...reveal6 },
  'E-reveal6-project-in-folder.zip': prefix({ 'index.html': localDeck6, ...reveal6 }, 'my-deck/'),
  'F-slidev-source.zip': { 'slides.md': slidesMd, 'package.json': slidevPkg, ...vue },
  'G-slidev-slides-md-only.zip': { 'slides.md': slidesMd },
  'H-slidev-dist-default-base.zip': dist,
  'I-slidev-dist-relative-base.zip': distRel,
  'J-slidev-dist+source.zip': { ...prefix(distRel, 'dist/'), 'slides.md': slidesMd, 'package.json': slidevPkg, ...vue },
  'K-slidev-source-in-folder+README.zip': prefix({ 'slides.md': slidesMd, 'package.json': slidevPkg, 'README.md': readme, ...vue }, 'my-talk/'),
};
const rows = [];
for (const [name, files] of Object.entries(corpus)) {
  const bytes = zipSync(files, { level: 6 });
  writeFileSync(P + 'corpus/' + name, bytes);
  const file = new File([bytes], name, { type: 'application/zip' });
  let stage = 'presentation-package', outcome;
  try {
    const pkg = await inspectPresentationArchive(file);
    if (pkg) outcome = 'ACCEPTED as presentation: ' + pkg.manifest.title;
    else {
      stage = 'document-bundle (fallback)';
      try { const doc = await importWorkspaceBundle(file); outcome = `IMPORTED AS MARKDOWN DOCUMENT "${doc.title}" (document=${doc.project?.document}, mode=${doc.mode ?? 'default'}, ${doc.source.length} chars, extra files kept=${doc.project?.files.length})`; }
      catch (e) { outcome = 'REJECTED: ' + e.message; }
    }
  } catch (e) { outcome = 'REJECTED: ' + e.message; }
  rows.push({ zip: name, entries: Object.keys(files).length, kB: Math.round(bytes.length / 1024), stage, outcome });
}
for (const r of rows) console.log(`${r.zip}  [${r.entries} files, ${r.kB} kB]\n   ${r.stage}: ${r.outcome}\n`);
writeFileSync(P + 'baseline-import-results.json', JSON.stringify(rows, null, 1));
