// Static analysis of a single HTML deck: external resources, inline handlers, reveal init, features. No execution.
import { readFileSync } from 'node:fs';
for (const file of process.argv.slice(2)) {
  const html = readFileSync(file, 'utf8');
  const out = { file: file.split('/').pop(), bytes: Buffer.byteLength(html) };
  const attr = (re) => [...html.matchAll(re)].map(m => m[1]);
  out.scriptSrc = attr(/<script\b[^>]*\bsrc\s*=\s*["']([^"']+)["']/gi);
  out.linkHref = attr(/<link\b[^>]*\bhref\s*=\s*["']([^"']+)["']/gi);
  out.imgSrc = attr(/<(?:img|video|audio|source|iframe)\b[^>]*\bsrc\s*=\s*["']([^"']+)["']/gi).map(s => s.slice(0, 80));
  out.inlineScripts = [...html.matchAll(/<script\b(?![^>]*\bsrc\s*=)[^>]*>([\s\S]*?)<\/script>/gi)].map(m => m[1].length);
  out.moduleScripts = (html.match(/<script\b[^>]*type\s*=\s*["']module["']/gi) || []).length;
  out.inlineHandlers = (html.match(/<[a-z][^>]*\s+on[a-z]+\s*=\s*["']/gi) || []).length;
  out.sections = (html.match(/<section\b/gi) || []).length;
  out.revealInit = (html.match(/Reveal\.initialize\s*\(|new\s+Reveal\s*\(/g) || []).length;
  out.plugins = [...new Set(html.match(/Reveal(?:Markdown|Highlight|Notes|Math(?:\.\w+)?|Zoom|Search)/g) || [])];
  out.dataMarkdown = (html.match(/data-markdown/g) || []).length;
  out.fragments = (html.match(/class\s*=\s*["'][^"']*\bfragment\b/g) || []).length;
  out.canvas = (html.match(/<canvas\b/gi) || []).length;
  out.svg = (html.match(/<svg\b/gi) || []).length;
  out.inputs = (html.match(/<input\b/gi) || []).length;
  out.fetchCalls = (html.match(/\bfetch\s*\(/g) || []).length;
  out.evalLike = (html.match(/\beval\s*\(|new\s+Function\s*\(/g) || []).length;
  out.storage = (html.match(/\b(?:localStorage|sessionStorage|indexedDB)\b/g) || []).length;
  out.importStmts = (html.match(/\bimport\s+[\w*{][^;\n]*\bfrom\s*["'][^"']+["']/g) || []).map(s => s.slice(0, 120));
  out.cssImports = (html.match(/@import\s+(?:url\()?["']?[^;"')]+/g) || []).map(s => s.slice(0, 120));
  out.hosts = [...new Set([...out.scriptSrc, ...out.linkHref, ...out.cssImports, ...out.importStmts].map(u => (u.match(/https?:\/\/([^/"')\s]+)/) || [])[1]).filter(Boolean))];
  console.log(JSON.stringify(out, null, 1));
}
