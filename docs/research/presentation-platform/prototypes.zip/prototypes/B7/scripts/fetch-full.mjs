// Usage: node fetch-full.mjs <url> [max]  -- prints textContent (incl. collapsed accordions) of main/article
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const url = process.argv[2]; const max = Number(process.argv[3] || 60000);
const browser = await chromium.launch();
try {
  const ctx = await browser.newContext({ userAgent: 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36' });
  const page = await ctx.newPage();
  const res = await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 45000 });
  await page.waitForLoadState('networkidle', { timeout: 8000 }).catch(() => {});
  const text = await page.evaluate(() => {
    const root = document.querySelector('main, article, [role=main]') || document.body;
    const clone = root.cloneNode(true);
    clone.querySelectorAll('script,style,noscript,svg').forEach(n => n.remove());
    // insert newlines around block elements
    clone.querySelectorAll('p,li,h1,h2,h3,h4,h5,div,tr,br,summary,details').forEach(n => n.append('\n'));
    return clone.textContent.replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n');
  });
  console.log(`URL: ${page.url()}\nSTATUS: ${res?.status()}\nTITLE: ${await page.title()}\n`);
  console.log(text.slice(0, max));
} catch (e) { console.error('FETCH FAILED', e.message); process.exitCode = 1; }
finally { await browser.close(); }
