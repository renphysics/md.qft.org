import { createRequire } from 'node:module';
import { readFileSync, existsSync, statSync } from 'node:fs';
import { join, extname } from 'node:path';
const require = createRequire(import.meta.url); const { chromium } = require('playwright');
const P = new URL('..', import.meta.url).pathname; const root = P + 'slidev-prompt-test/dist-memory'; const mount = '/u/decks/wave/';
const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.svg': 'image/svg+xml', '.woff2': 'font/woff2', '.woff': 'font/woff', '.ttf': 'font/ttf' };
const browser = await chromium.launch(); const ctx = await browser.newContext({ viewport: { width: 1280, height: 720 } }); const page = await ctx.newPage();
const blocked = [], notFound = [], errors = []; let served = 0, servedBytes = 0;
page.on('pageerror', (e) => errors.push(String(e.message).slice(0, 160)));
await ctx.route('**/*', (route) => { const u = new URL(route.request().url());
  if (u.host !== 'b7.test') { blocked.push(u.href.slice(0, 100)); return route.abort(); }
  let f = join(root, decodeURIComponent(u.pathname.slice(mount.length)) || 'index.html');
  if (!u.pathname.startsWith(mount) || !existsSync(f) || statSync(f).isDirectory()) { notFound.push(u.pathname); return route.fulfill({ status: 404, body: '' }); }
  const body = readFileSync(f); served++; servedBytes += body.length; route.fulfill({ status: 200, contentType: mime[extname(f)] || 'application/octet-stream', body }); });
await page.goto('http://b7.test' + mount + 'index.html'); await page.waitForTimeout(2000);
const visible = () => page.evaluate(() => { const el = [...document.querySelectorAll('.slidev-page')].find((p) => p.offsetParent !== null && getComputedStyle(p).display !== 'none'); return { url: location.href.replace('http://b7.test', ''), page: [...(el?.classList || [])].find((c) => /^slidev-page-\d+$/.test(c)), h1: el?.querySelector('h1')?.innerText }; });
const out = { initial: await visible(), afterFirstLoad: { served, kB: Math.round(servedBytes / 1024) } };
for (let i = 0; i < 6; i++) { await page.keyboard.press('ArrowRight'); await page.waitForTimeout(500); }
await page.waitForTimeout(2500);
out.afterSixRights = await visible();
out.mermaidSvg = await page.evaluate(() => document.querySelectorAll('.mermaid svg, svg[id^="mermaid"], .slidev-page-5 svg').length);
out.total = { served, kB: Math.round(servedBytes / 1024) };
await page.screenshot({ path: P + 'shots/slidev-memory-mermaid.png' });
console.log(JSON.stringify({ ...out, blockedExternal: [...new Set(blocked)], notFound: [...new Set(notFound)], errors }, null, 1));
await browser.close();
