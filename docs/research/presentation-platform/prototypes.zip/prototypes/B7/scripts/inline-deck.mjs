// B7 prototype: turn "what an AI naturally produces" (single HTML with CDN links, or index.html + relative files)
// into ONE self-contained HTML that satisfies md.qft.org's existing player CSP
// (script-src 'unsafe-inline'; style-src 'unsafe-inline'; font-src data:; img-src data: blob:; connect-src 'none').
// Pure string processing; runs the same in Node and in a browser. Nothing is executed.
import { readFileSync, existsSync } from 'node:fs';
import { join } from 'node:path';

const NM = '/home/user/md.qft.org/node_modules';
const REVEAL = join(NM, 'reveal.js/dist');      // 6.0.2 (the version the site ships)
const KATEX = join(NM, 'katex/dist');           // 0.19.1
const txt = (p) => readFileSync(p, 'utf8');
const b64 = (p) => readFileSync(p).toString('base64');

/** Map a URL from a well-known CDN to a vendored file. Version in the URL is recorded, then coerced. */
export function resolveCdn(url) {
  let m;
  // --- reveal.js on jsDelivr / unpkg (npm layout) --------------------------------------------------
  if ((m = url.match(/^https?:\/\/(?:cdn\.jsdelivr\.net\/npm|unpkg\.com)\/reveal\.js(?:@([^/]+))?\/(.+?)(?:[?#].*)?$/))) {
    return revealPath(m[2], m[1] || 'unversioned');
  }
  // --- reveal.js on cdnjs (flattened layout: /reveal.min.js, /theme/x.min.css, /plugin/x/x.min.js) -
  if ((m = url.match(/^https?:\/\/cdnjs\.cloudflare\.com\/ajax\/libs\/reveal\.js\/([^/]+)\/(.+?)(?:[?#].*)?$/))) {
    const rest = /^(?:reveal|reset)(?:\.min)?\.(?:js|css)$/.test(m[2]) || m[2].startsWith('theme/') ? 'dist/' + m[2] : m[2];
    return revealPath(rest, m[1]);
  }
  // --- KaTeX ----------------------------------------------------------------------------------------
  if ((m = url.match(/^https?:\/\/(?:cdn\.jsdelivr\.net\/npm|unpkg\.com)\/katex(?:@([^/]+))?\/dist\/(.+?)(?:[?#].*)?$/))
    || (m = url.match(/^https?:\/\/cdnjs\.cloudflare\.com\/ajax\/libs\/KaTeX\/([^/]+)\/(.+?)(?:[?#].*)?$/i))) {
    const f = m[2].replace(/\.min\./, '.').replace(/^katex\.(js|css)$/, 'katex.min.$1').replace(/^contrib\/([\w-]+)\.js$/, 'contrib/$1.min.js');
    const p = join(KATEX, f);
    return existsSync(p) ? { lib: 'katex', requested: m[1] || 'unversioned', served: '0.19.1', path: p } : null;
  }
  return null;
}
function revealPath(rest, requested) {
  let f = rest.replace(/\.min\.(js|css)$/, '.$1');
  f = f.replace(/^plugin\/(\w+)\/\1\.(?:esm\.)?js$/, 'dist/plugin/$1.js')            // v3-5: plugin/math/math.js -> v6: dist/plugin/math.js
       .replace(/^plugin\/highlight\/(monokai|zenburn)\.css$/, 'dist/plugin/highlight/$1.css')
       .replace(/^dist\/reveal\.esm\.js$/, 'dist/reveal.mjs')
       .replace(/^(?:css|js)\/reveal\.(js|css)$/, 'dist/reveal.$1')                    // v3 layout
       .replace(/^css\/theme\/(\w[\w-]*)\.css$/, 'dist/theme/$1.css');
  if (/^dist\/theme\/fonts\//.test(f)) return { lib: 'reveal.js', requested, served: '6.0.2', path: null, empty: true }; // v6 themes embed their fonts
  const p = join(REVEAL, f.replace(/^dist\//, ''));
  return existsSync(p) ? { lib: 'reveal.js', requested, served: '6.0.2', path: p } : null;
}

/** Inline url(...) font references of a vendored stylesheet as data: URIs (woff2 only) and drop remote @imports. */
function inlineCss(css, baseDir, report) {
  css = css.replace(/@import\s+(?:url\()?["']?(https?:[^"');]+)["']?\)?[^;]*;/g, (_, u) => { report.dropped.push({ kind: 'css-import', url: u }); return ''; });
  // keep only the woff2 source of each @font-face src list
  css = css.replace(/src:([^;}]+)[;}]/g, (whole, list) => {
    const w2 = list.split(',').find((s) => /\.woff2\b/.test(s));
    if (!w2) return whole;
    const u = w2.match(/url\(["']?([^"')]+)["']?\)/)[1];
    const p = join(baseDir, u.split(/[?#]/)[0]);
    if (!existsSync(p)) return whole;
    return `src:url(data:font/woff2;base64,${b64(p)}) format("woff2")${whole.endsWith('}') ? '}' : ';'}`;
  });
  return css;
}

const SHIM_MATH = `/* md.qft.org shim: RevealMath without runtime CDN loading. KaTeX is already inlined above. */
(function(){function make(id){return function(){return {id:id,init:function(deck){var c=(deck.getConfig()||{}).katex||{};var o={delimiters:c.delimiters||[{left:"$$",right:"$$",display:true},{left:"$",right:"$",display:false},{left:"\\\\(",right:"\\\\)",display:false},{left:"\\\\[",right:"\\\\]",display:true}],ignoredTags:["script","noscript","style","textarea","pre","code"],throwOnError:false};var run=function(){renderMathInElement(deck.getSlidesElement(),o);deck.layout();};deck.isReady()?run():deck.on("ready",run);}}}}
var P=make("katex")();window.RevealMath=Object.assign(P,{KaTeX:make("katex"),MathJax2:make("mathjax2"),MathJax3:make("mathjax3"),MathJax4:make("mathjax4")});})();`;

/**
 * @param html   entry HTML text
 * @param files  Map<relativePath, Buffer> of sibling files from the ZIP (may be empty)
 */
export const HISTORY_SHIM = `<script>/* md.qft.org shim: an opaque-origin blob: document cannot call history.replaceState/pushState (Reveal hash:true, Slidev router). */(function(){for(const n of ["replaceState","pushState"]){const f=history[n].bind(history);history[n]=function(){try{return f.apply(null,arguments)}catch(e){}}}})();</script>`;
export function inlineDeck(html, files = new Map(), options = {}) {
  const report = { inlined: [], coerced: [], dropped: [], unresolved: [], notes: [] };
  const authored = html.replace(/<script\b[^>]*\bsrc\s*=[^>]*>\s*<\/script>/gi, '');
  const katexNeeded = { css: false, js: false };
  const usesRevealMath = /\bRevealMath\b/.test(html);
  const esc = (s) => s.replace(/<\/script/gi, '<\\/script');
  const local = (ref) => { const k = ref.split(/[?#]/)[0].replace(/^\.\//, ''); return files.get(k); };

  // <link rel="stylesheet" href>
  html = html.replace(/<link\b([^>]*)>/gi, (tag, attrs) => {
    const href = (attrs.match(/\bhref\s*=\s*["']([^"']+)["']/i) || [])[1];
    const rel = ((attrs.match(/\brel\s*=\s*["']([^"']+)["']/i) || [])[1] || '').toLowerCase();
    if (!href) return tag;
    if (/^(?:preconnect|dns-prefetch|preload|modulepreload|icon|shortcut icon|apple-touch-icon|manifest)$/.test(rel)) { report.dropped.push({ kind: 'link-' + rel, url: href }); return ''; }
    if (rel && rel !== 'stylesheet') return tag;
    if (/^https?:\/\/fonts\.(?:googleapis|gstatic)\.com\//.test(href) || href === 'https://fonts.googleapis.com' ) { report.dropped.push({ kind: 'web-font', url: href.slice(0, 120) }); return ''; }
    if (/^https?:/.test(href)) {
      const r = resolveCdn(href);
      if (!r) { report.unresolved.push({ kind: 'stylesheet', url: href }); return ''; }
      if (r.empty) { report.dropped.push({ kind: 'redundant-font-css', url: href }); return ''; }
      if (r.requested !== r.served) report.coerced.push({ lib: r.lib, requested: r.requested, served: r.served, url: href });
      report.inlined.push({ kind: 'stylesheet', from: href, lib: r.lib });
      const base = r.path.slice(0, r.path.lastIndexOf('/'));
      return `<style data-qft-from="${href}">${inlineCss(txt(r.path), base, report)}</style>`;
    }
    const f = local(href);
    if (!f) { report.unresolved.push({ kind: 'stylesheet', url: href }); return ''; }
    report.inlined.push({ kind: 'stylesheet', from: href });
    return `<style data-qft-from="${href}">${f.toString('utf8')}</style>`;
  });

  // <script src>
  html = html.replace(/<script\b([^>]*)\bsrc\s*=\s*["']([^"']+)["']([^>]*)>\s*<\/script>/gi, (tag, a, src, b) => {
    const isModule = /type\s*=\s*["']module["']/i.test(a + b);
    if (/^https?:/.test(src)) {
      const r = resolveCdn(src);
      if (!r) { report.unresolved.push({ kind: 'script', url: src }); return `<!-- qft: blocked ${src} -->`; }
      if (r.requested !== r.served) report.coerced.push({ lib: r.lib, requested: r.requested, served: r.served, url: src });
      if (r.lib === 'reveal.js' && /plugin\/math\.js$/.test(r.path)) {
        report.inlined.push({ kind: 'script', from: src, lib: 'reveal.js math plugin -> offline shim + KaTeX' });
        return `<style>${inlineCss(txt(join(KATEX, 'katex.min.css')), KATEX, report)}</style><script>${esc(txt(join(KATEX, 'katex.min.js')))}</script><script>${esc(txt(join(KATEX, 'contrib/auto-render.min.js')))}</script><script>${SHIM_MATH}</script>`;
      }
      report.inlined.push({ kind: 'script', from: src, lib: r.lib });
      return `<script data-qft-from="${src}"${isModule ? ' type="module"' : ''}>${esc(txt(r.path))}</script>`;
    }
    const f = local(src);
    if (!f) { report.unresolved.push({ kind: 'script', url: src }); return `<!-- qft: missing ${src} -->`; }
    report.inlined.push({ kind: 'script', from: src });
    return `<script data-qft-from="${src}"${isModule ? ' type="module"' : ''}>${esc(f.toString('utf8'))}</script>`;
  });

  // <img src> relative -> data URI
  html = html.replace(/(<img\b[^>]*\bsrc\s*=\s*["'])([^"']+)(["'])/gi, (whole, pre, src, post) => {
    if (/^(?:data:|blob:)/.test(src)) return whole;
    if (/[${}]/.test(src)) return whole; // template literal inside library code, not markup
    if (/^https?:/.test(src)) { report.unresolved.push({ kind: 'image', url: src.slice(0, 160) }); return whole; }
    const f = local(src); if (!f) { report.unresolved.push({ kind: 'image', url: src }); return whole; }
    const ext = src.split('.').pop().toLowerCase(); const mime = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp', svg: 'image/svg+xml' }[ext] || 'application/octet-stream';
    report.inlined.push({ kind: 'image', from: src });
    return `${pre}data:${mime};base64,${f.toString('base64')}${post}`;
  });
  // static hazards that inlining cannot fix
  const body = authored;
  const hazards = [];
  if (/<[a-z][^>]*\s+on[a-z]+\s*=\s*["']/i.test(body)) hazards.push('inline-event-attributes (blocked by script-src-attr none)');
  if (/\bfetch\s*\(|XMLHttpRequest|WebSocket\(/.test(body)) hazards.push('network calls (connect-src none)');
  if (/\b(?:localStorage|sessionStorage|indexedDB)\b/.test(body)) hazards.push('browser storage (opaque origin)');
  if (/\beval\s*\(|new\s+Function\s*\(/.test(body)) hazards.push('eval/new Function');
  if (/<iframe\b/i.test(body)) hazards.push('nested iframe');
  if (/\bhash\s*:\s*true|\bhistory\s*:\s*true/.test(body)) hazards.push('Reveal hash/history:true (history.replaceState throws in an opaque-origin blob document)');
  if (/data-markdown\s*=\s*["'][^"']+\.md/i.test(body)) hazards.push('external markdown file (needs fetch)');
  if (usesRevealMath && !report.inlined.some((i) => /math plugin/.test(i.lib || ''))) hazards.push('RevealMath referenced but plugin script not resolved');
  report.hazards = hazards;
  if (options.historyShim) html = html.replace(/<head[^>]*>/i, (m) => m + HISTORY_SHIM);
  report.bytes = Buffer.byteLength(html);
  return { html, report };
}
