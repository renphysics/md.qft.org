---
routerMode: hash
fonts:
  provider: none
theme: default
title: Quantum interference
transition: slide-left
mdc: true
---

# Quantum interference

Two waves, one relative phase

---

# Amplitudes add

$$
A(\phi)=\frac{1+e^{i\phi}}{2},\qquad I(\phi)=\cos^2\!\left(\frac{\phi}{2}\right)
$$

<v-clicks>

- In phase: reinforce
- Out of phase: cancel

</v-clicks>

---

# Try it

<QuantumInterference />

---

# Code

```ts {1|2-3|all}
const phi = Math.PI
const amplitude = (1 + Math.cos(phi)) / 2
console.log(amplitude)
```

---
layout: center
---

# Thanks
