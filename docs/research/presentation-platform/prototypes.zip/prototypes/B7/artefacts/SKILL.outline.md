---
name: qft-deck
description: Build or revise Reveal.js and Slidev decks that play offline in md.qft.org. Use for slides, lectures or interactive presentations for md.qft.org, or when given a md.qft.org deck check report.
license: MIT
compatibility: Reveal decks need no tools. Slidev decks need Node.js 22.22+ (required by @slidev/cli 53) and npm registry access. The checker runs on Node 20+ with no dependencies.
metadata:
  author: md.qft.org
  version: "1.0"
  profile: qft-deck/1
---

# qft-deck — decks for the offline player at md.qft.org

md.qft.org plays a deck inside a sandbox with **no network**. It bundles reveal.js 6 and KaTeX itself; everything
else must travel inside the deck. Follow one of the two workflows, run the checker, deliver ONE file.

## 0. Choose the engine
- Default: **Reveal.js, one `index.html`** (works from every AI tool, editable in the browser).
- **Slidev** only if the user asks for it or wants Vue components; it must be built (section 2).
- Revising an existing deck: never start over. Go to section 3.

## 1. Reveal.js workflow
1. Copy `assets/reveal-starter/index.html` to `deck/index.html`.
2. Write slides as `<section>` elements. One idea per slide; `class="fragment"` for steps; `<aside class="notes">`.
3. Maths: `$…$`, `$$…$$` (plugin `RevealMath.KaTeX` is already wired in the starter).
4. Interactive demos: canvas or inline SVG + labelled `<input type="range">` + Reset button, in one classic inline
   `<script>`; `addEventListener` only.
5. Assets: inline SVG; raster images as files in `deck/images/` (ZIP delivery) or `data:` URIs (single file).
6. Hard rules (each maps to a check code in `references/check-codes.md`):
   only the four pinned reveal.js URLs or files inside the deck · no other URL loads · no `fetch`/XHR/WebSocket ·
   no `<iframe>` · no remote ES modules · no workers · no `eval`/`new Function` · no `on…=` attributes ·
   `hash: false`.
7. `node scripts/check.mjs deck/` → fix every `mustFix` → repeat until exit code 0.
8. Deliver `deck/index.html` if it is the only file, else `node scripts/pack.mjs deck deck.zip`.

## 2. Slidev workflow
1. Copy `assets/slidev-starter/` (slides.md, components/Demo.vue, package.json, package-lock.json).
2. Keep the headmatter keys `routerMode: memory` (or `hash`; never the default `history`) and `fonts: { provider: none }`.
3. Demos are Vue SFCs in `components/`, importing only from `vue`. Pictures in `public/`, referenced as `/name.png`.
4. Not available in the player: Monaco, PlantUML, remote themes/fonts/images, presenter window, recording, PWA. Mermaid works but adds about 5 MB; prefer inline SVG.
5. Check `node -v` is 22.22 or newer (else go to step 7). Build: `npm ci` (or `npm install -D @slidev/cli@53 @slidev/theme-default vue`), then `npx slidev build --base ./`.
   If the build says a theme "was not found and cannot prompt for installation", install that theme package.
6. `node scripts/check.mjs .` → fix → `node scripts/pack.mjs . deck.zip` (adds source + dist/, skips node_modules).
7. If you cannot run npm: deliver the source files, state **NOT BUILT**, and point the user to
   `references/build-without-node.md` (GitHub template whose Action attaches `deck.zip`).

## 3. Revising a deck (keeps both sides in sync)
- The file or ZIP exported from md.qft.org is the source of truth; the user may have edited it there.
- Keep `<meta name="qft-deck" content="id=…">` (Reveal) / `qft-deck.json` (Slidev) byte-for-byte.
- Change only what was asked. Address slides by their `id`/`data-qft-id`, not by counting.
- Given a ```json block whose "report" is "qft-deck-check/1": check that `deck.rev` matches the file you hold
  (`node scripts/check.mjs --rev file`); if not, ask for the current export. Fix `mustFix` in order using the `fix`
  text; treat `shouldFix` as optional; do not touch anything listed under `handledForYou`.

## 4. Report back honestly
State: engine, slide count, checker verdict and exit code, what you could not test. Never say it was tested in
md.qft.org. Finish with: "Open https://md.qft.org/ and drop <file> onto the page."

## References (load only when needed)
- `references/reveal-profile.md` — full rule list with reasons and examples
- `references/slidev-profile.md` — headmatter, supported features, build flags
- `references/check-codes.md` — every checker code → cause → fix
- `references/teaching.md` — lesson structure, prediction-before-demo, accessibility, units and limits
- `references/build-without-node.md` — template repository + GitHub Action route
