// V2: new messy AI-answer cases for B6's patch-apply.mjs (imported read-only from B6's directory).
import { parseAnswer, applyAnswer } from '../../B6/patch-lab/patch-apply.mjs';
const F = '```';
const html = '<!doctype html>\n<html>\n\t<body>\n\t\t<div class="reveal">\n\t\t\t<div class="slides">\n\t\t\t\t<section>\n\t\t\t\t\t<h2>Energy levels</h2>\n\t\t\t\t\t<p class="lead">It\'s "quantised" - really.</p>\n\t\t\t\t</section>\n\t\t\t\t<section>\n\t\t\t\t\t<h2>Summary</h2>\n\t\t\t\t\t<p>Done.</p>\n\t\t\t\t</section>\n\t\t\t\t<section>\n\t\t\t\t\t<h2>Appendix</h2>\n\t\t\t\t\t<p>Done.</p>\n\t\t\t\t</section>\n\t\t\t</div>\n\t\t</div>\n\t</body>\n</html>\n';
const md = '# One\n\nalpha\n\n---\n\n# Two\n\nbeta\ngamma\n\n---\n\n# Three\n\ndelta\n';
const css = '.reveal h2 { color: #333; }\r\n.reveal p { font-size: 1.1em; }\r\n';
const project = () => new Map([['index.html', html], ['slides.md', md], ['css/custom.css', css]]);
const cases = [];
const add = (name, answer, check, options) => cases.push({ name, answer, check, options });

add('N1 wrong, inconsistent indentation (3 then 6 spaces) vs tabs', `index.html\n${F}html\n<<<<<<< SEARCH\n   <h2>Summary</h2>\n      <p>Done.</p>\n=======\n   <h2>Summary</h2>\n      <p>Done, with feeling.</p>\n>>>>>>> REPLACE\n${F}`,
  (f) => f.get('index.html').includes('\t\t\t\t\t<h2>Summary</h2>\n\t\t\t\t\t<p>Done, with feeling.</p>') && f.get('index.html').split('<p>Done.</p>').length === 2);
add('N2 smart quotes + typographic apostrophe/en dash in SEARCH, straight in file', `index.html\n<<<<<<< SEARCH\n<p class=“lead”>It’s “quantised” – really.</p>\n=======\n<p class="lead">It's "quantised" (Bohr, 1913).</p>\n>>>>>>> REPLACE\n`,
  (f) => f.get('index.html').includes('\t\t\t\t\t<p class="lead">It\'s "quantised" (Bohr, 1913).</p>\n'));
add('N3 unified diff, wrong line numbers, context with trailing spaces, @@ with section text', `${F}diff\n--- a/slides.md\n+++ b/slides.md\n@@ -90,4 +90,5 @@ # Two\n # Two  \n \n beta\n+beta-prime\n gamma\n${F}`,
  (f) => f.get('slides.md') === md.replace('beta\ngamma', 'beta\nbeta-prime\ngamma'));
add('N4a two identical candidates, no hint -> must not silently edit the wrong one (refuse or report ambiguity)', `index.html\n<<<<<<< SEARCH\n<p>Done.</p>\n=======\n<p>Finished.</p>\n>>>>>>> REPLACE\n`,
  (f, r) => (f.get('index.html') === html && r.some((x) => x.status === 'failed')) || r.some((x) => /occurs 2 times|ambiguous|2 times/i.test(x.detail || '')));
add('N4b two identical candidates, hint on the Appendix slide (line 16) -> second one edited', `index.html\n<<<<<<< SEARCH\n<p>Done.</p>\n=======\n<p>Finished.</p>\n>>>>>>> REPLACE\n`,
  (f) => { const t = f.get('index.html'); return t.indexOf('<p>Finished.</p>') > t.indexOf('Appendix') && t.includes('<h2>Summary</h2>\n\t\t\t\t\t<p>Done.</p>'); }, { hintLine: () => 16 });
add('N5 truncated whole file with a bare "..." line must be refused', `slides.md\n${F}md\n# One\n\nalpha (revised)\n\n...\n\n# Three\n\ndelta\n${F}`,
  (f, r) => f.get('slides.md') === md && r.some((x) => x.status === 'failed'));
add('N5b truncated SEARCH/REPLACE answer (no >>>>>>> REPLACE marker, cut off) must not corrupt the file', `slides.md\n<<<<<<< SEARCH\n# Two\n\nbeta\n=======\n# Two\n\nbeta (new`,
  (f) => f.get('slides.md') === md);
add('N6 Windows CRLF answer text applied to an LF file, and LF answer to a CRLF file', `slides.md\r\n<<<<<<< SEARCH\r\n# Three\r\n\r\ndelta\r\n=======\r\n# Three\r\n\r\ndelta\r\nepsilon\r\n>>>>>>> REPLACE\r\n\r\ncss/custom.css\n<<<<<<< SEARCH\n.reveal p { font-size: 1.1em; }\n=======\n.reveal p { font-size: 1.3em; }\n>>>>>>> REPLACE\n`,
  (f) => f.get('slides.md') === md.replace('delta\n', 'delta\nepsilon\n') && f.get('css/custom.css') === css.replace('1.1em', '1.3em'));

let pass = 0;
for (const c of cases) {
  const files = project();
  let ops, next, report;
  try { ops = parseAnswer(c.answer, files, {}); ({ files: next, report } = applyAnswer(files, ops, { hintLine: c.options?.hintLine })); } catch (e) { console.log('THREW ', c.name, e.message); continue; }
  let ok = false; try { ok = !!c.check(next, report); } catch { ok = false; }
  if (ok) pass += 1;
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${c.name}  ->  ${report.map((r) => `${r.format}:${r.kind}:${r.status}${r.detail ? ' (' + r.detail.replace(/\n/g, ' / ').slice(0, 110) + ')' : ''}`).join('; ') || 'no operations found'}`);
  if (!ok) for (const [k, v] of next) if (v !== files.get(k)) console.log('      changed ' + k + ': ' + JSON.stringify(v).slice(0, 260));
}
console.log(`\n${pass}/${cases.length} new cases behave as intended`);
