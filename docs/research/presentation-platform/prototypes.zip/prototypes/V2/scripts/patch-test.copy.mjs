import { createRequire } from 'node:module';
import { parseAnswer, applyAnswer, failureReport } from 'SCRATCH/research/proto/B6/patch-lab/patch-apply.mjs';
const require = createRequire('SCRATCH/research/proto/B6/cm-measure/');
const Diff = require('diff');
const F = '```';
const slides = `---
theme: default
title: Waves
---

# Waves

Two waves, one relative phase

---

# Amplitudes add

- In phase: reinforce
- Out of phase: cancel

---

# Try it

<Interference />

---

# Summary

- In phase: reinforce
- Out of phase: cancel
`;
const index = `<!doctype html>
<html>
\t<body>
\t\t<div class="reveal">
\t\t\t<div class="slides">
\t\t\t\t<section>
\t\t\t\t\t<h2>Energy levels</h2>
\t\t\t\t\t<p>The spectrum is “discrete”.</p>
\t\t\t\t</section>
\t\t\t\t<section>
\t\t\t\t\t<h2>Summary</h2>
\t\t\t\t</section>
\t\t\t</div>
\t\t</div>
\t</body>
</html>
`;
const css = `.reveal h2 { color: #333; }\r\n.reveal p { font-size: 1.1em; }\r\n`;
const project = () => new Map([['slides.md', slides], ['index.html', index], ['css/custom.css', css]]);
const cases = [];
const add = (name, answer, check, options) => cases.push({ name, answer, check, options });

add('1 SEARCH/REPLACE in a fence, filename on the line above', `Here is the change:

slides.md
${F}
<<<<<<< SEARCH
# Try it
=======
# Try it yourself
>>>>>>> REPLACE
${F}
`, (f) => f.get('slides.md') === slides.replace('# Try it', '# Try it yourself'));

add('2 SEARCH/REPLACE, spaces instead of the file\'s tabs', `**index.html**
<<<<<<< SEARCH
        <h2>Energy levels</h2>
        <p>The spectrum is “discrete”.</p>
=======
        <h2>Energy levels of hydrogen</h2>
        <p>The spectrum is “discrete”.</p>
        <p class="fragment">E_n = -13.6 eV / n²</p>
>>>>>>> REPLACE
`, (f) => f.get('index.html').includes('\t\t\t\t\t<h2>Energy levels of hydrogen</h2>\n') && f.get('index.html').includes('\t\t\t\t\t<p class="fragment">E_n = -13.6 eV / n²</p>\n'));

add('3 well-formed unified diff', `${F}diff
--- a/slides.md
+++ b/slides.md
@@ -11,6 +11,7 @@
 # Amplitudes add
 
 - In phase: reinforce
+- Quadrature: half intensity
 - Out of phase: cancel
 
 ---
${F}`, (f) => f.get('slides.md').includes('- In phase: reinforce\n- Quadrature: half intensity\n- Out of phase: cancel\n\n---\n\n# Try it'));

add('4 unified diff with wrong line numbers/counts and blank context lines stripped', `--- slides.md
+++ slides.md
@@ -40,3 +40,4 @@
 # Summary

 - In phase: reinforce
-- Out of phase: cancel
+- Out of phase: cancel completely
+- Everything in between: partial interference
`, (f) => f.get('slides.md').endsWith('# Summary\n\n- In phase: reinforce\n- Out of phase: cancel completely\n- Everything in between: partial interference\n') && f.get('slides.md').includes('# Amplitudes add\n\n- In phase: reinforce\n- Out of phase: cancel\n\n---'));

add('5 whole file in a fence under a bold filename', `Updated file:

**css/custom.css**
${F}css
.reveal h2 { color: #7a1f3d; }
.reveal p { font-size: 1.2em; }
${F}`, (f) => f.get('css/custom.css') === '.reveal h2 { color: #7a1f3d; }\r\n.reveal p { font-size: 1.2em; }\r\n');

add('6 lazy whole file with an elision placeholder must be refused', `### slides.md
${F}md
---
theme: default
title: Waves
---

# Waves (revised)

<!-- ... rest of the slides unchanged ... -->
${F}`, (f, report) => f.get('slides.md') === slides && report[0].status === 'failed');

add('7 OpenAI V4A patch', `*** Begin Patch
*** Update File: slides.md
@@ # Try it
-<Interference />
+<Interference :phase="0.5" />
*** Add File: notes/teacher.md
+# Teacher notes
+Ask for predictions first.
*** End Patch`, (f) => f.get('slides.md').includes('<Interference :phase="0.5" />') && f.get('notes/teacher.md') === '# Teacher notes\nAsk for predictions first.\n');

add('8 two files in one answer (whole file + search/replace)', `I changed two files.

\`css/custom.css\`:
${F}css
.reveal h2 { color: teal; }
${F}

And in \`index.html\`:

${F}html
<<<<<<< SEARCH
					<h2>Summary</h2>
=======
					<h2>Summary and outlook</h2>
>>>>>>> REPLACE
${F}`, (f) => f.get('css/custom.css') === '.reveal h2 { color: teal; }\r\n' && f.get('index.html') === index.replace('<h2>Summary</h2>', '<h2>Summary and outlook</h2>'));

add('9 ambiguous SEARCH resolved by the current-slide hint', `slides.md
<<<<<<< SEARCH
- Out of phase: cancel
=======
- Out of phase: cancel (dark fringe)
>>>>>>> REPLACE`, (f) => f.get('slides.md').endsWith('- Out of phase: cancel (dark fringe)\n') && f.get('slides.md').includes('# Amplitudes add\n\n- In phase: reinforce\n- Out of phase: cancel\n\n---'), { hintLine: () => 24 });

add('10 straight quotes in the answer, curly quotes in the file', `index.html
<<<<<<< SEARCH
<p>The spectrum is "discrete".</p>
=======
<p>The spectrum is “discrete” and bounded below.</p>
>>>>>>> REPLACE`, (f) => f.get('index.html').includes('\t\t\t\t\t<p>The spectrum is “discrete” and bounded below.</p>'));

add('11 text that is not in the file gives a report, not a guess', `slides.md
<<<<<<< SEARCH
# A heading that does not exist
=======
# Replacement
>>>>>>> REPLACE`, (f, report) => f.get('slides.md') === slides && report[0].status === 'failed' && /Could not find/.test(failureReport(report)));

add('12 bare hunk without file header uses the open file', `@@
 # Try it
 
-<Interference />
+<Interference color="crimson" />
`, (f) => f.get('slides.md').includes('<Interference color="crimson" />'), { defaultPath: 'slides.md' });

add('13 new file from a labelled fence', `Create \`components/Counter.vue\`:

${F}vue
<script setup>
import { ref } from 'vue'
const n = ref(0)
</script>
<template><button @click="n++">{{ n }}</button></template>
${F}`, (f) => f.get('components/Counter.vue')?.startsWith('<script setup>') && f.size === 4);

let pass = 0;
for (const c of cases) {
  const files = project();
  const ops = parseAnswer(c.answer, files, { defaultPath: c.options?.defaultPath });
  const { files: next, report } = applyAnswer(files, ops, { hintLine: c.options?.hintLine });
  let ok = false; try { ok = !!c.check(next, report); } catch (e) { ok = false; }
  if (ok) pass += 1;
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${c.name}  ->  ${report.map((r) => `${r.format}:${r.kind}:${r.status}${r.detail ? ' (' + r.detail.replace(/\n/g, ' / ').slice(0, 90) + ')' : ''}`).join('; ') || 'no operations found'}`);
}
console.log(`\n${pass}/${cases.length} cases behave as intended`);

// Comparison: jsdiff 9 applyPatch on the two unified-diff cases.
console.log('\njsdiff@9 applyPatch on the same unified diffs:');
for (const c of cases.filter((x) => /^[34] /.test(x.name))) {
  const patchText = c.answer.replace(/^```diff\n/, '').replace(/\n```$/, '\n');
  for (const fuzz of [0, 2]) {
    let result;
    try { const out = Diff.applyPatch(slides, patchText, { fuzzFactor: fuzz }); result = out === false ? 'returned false (hunk did not fit)' : (c.check(new Map([['slides.md', out]]), []) ? 'applied correctly' : 'applied but result differs from intent'); }
    catch (e) { result = 'threw: ' + e.message.slice(0, 80); }
    console.log(`  ${c.name.slice(0, 60).padEnd(62)} fuzzFactor=${fuzz}: ${result}`);
  }
}
