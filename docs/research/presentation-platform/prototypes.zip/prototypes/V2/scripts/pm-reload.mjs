// V2.5 / V2.6: Reveal postMessage across the opaque runner->blob boundary, and reload / in-place-swap timings.
// Runs inside the shipped presentation-sandbox.html runner (opaque origin) after the real runtime started the deck.
import { createRequire } from 'node:module';
import { readFileSync } from 'node:fs';
const require = createRequire(import.meta.url); const { chromium } = require('playwright');
const V = new URL('..', import.meta.url).pathname;
const runtime = readFileSync(V + 'scripts/presentation-runtime.iife.js', 'utf8');
const runner = readFileSync('/home/user/md.qft.org/dist/presentation-sandbox.html', 'utf8');
const browser = await chromium.launch(process.env.CH === 'shell' ? {} : { channel: 'chromium' });
for (const file of process.argv.slice(2)) {
  const html = readFileSync(file, 'utf8');
  const ctx = await browser.newContext(); const blocked = [];
  await ctx.route('**/*', (r) => { const u = r.request().url(); if (u.startsWith('http://v2.test/')) { const p = u.slice(14); return r.fulfill(p === '/runtime.js' ? { contentType: 'text/javascript', body: runtime } : p === '/presentation-sandbox.html' ? { contentType: 'text/html', body: runner } : { contentType: 'text/html', body: '<!doctype html><body style="margin:0"><div id="host" style="width:1280px;height:720px"></div><script src="/runtime.js"></script>' }); } if (/^(blob|data):/.test(u)) return r.continue(); blocked.push(u); return r.abort(); });
  const page = await ctx.newPage(); await page.goto('http://v2.test/h');
  await page.evaluate((html) => new Promise((res) => { const p = QFT.createPresentationPlayer(document.getElementById('host'), html, { title: 't', sandboxUrl: '/presentation-sandbox.html', onState(s) { if (s === 'ready' || s === 'error') setTimeout(res, 600); } }); p.start(); }), html);
  const runnerFrame = page.frames().find((f) => f.url().endsWith('/presentation-sandbox.html'));
  const deck = page.frames().find((f) => f.url().startsWith('blob:'));
  const pm = await runnerFrame.evaluate(async () => {
    const w = document.querySelector('iframe').contentWindow; const got = [];
    addEventListener('message', (e) => { if (e.source === w && typeof e.data === 'string' && e.data.includes('"namespace":"reveal"')) got.push(JSON.parse(e.data)); });
    const send = (m) => w.postMessage(JSON.stringify(m), '*'); const wait = (ms) => new Promise((r) => setTimeout(r, ms));
    send({ method: 'getTotalSlides' }); await wait(300); const before = got.length;
    send({ method: 'configure', args: [{ postMessageEvents: true }] }); await wait(200);
    send({ method: 'getTotalSlides' }); send({ method: 'getSlideNotes' }); send({ method: 'getState' }); send({ method: 'slide', args: [3, 0] }); await wait(800);
    return { messagesBeforeConfigure: before, events: got.map((m) => m.eventName + (m.method ? ':' + m.method + '=' + String(JSON.stringify(m.result)).slice(0, 60) : '') + (m.state ? ' ' + JSON.stringify({ h: m.state.indexh, v: m.state.indexv, f: m.state.indexf }) : '')).slice(0, 12) };
  });
  pm.deckIndicesAfter = await deck.evaluate(() => JSON.stringify(Reveal.getIndices()));
  // in-place swap: replace the content of the current slide and Reveal.sync()
  const swap = await deck.evaluate(() => { const out = []; for (let i = 0; i < 5; i++) { const s = Reveal.getCurrentSlide(); const t = performance.now(); s.innerHTML = s.innerHTML + '<p class="v2-edit">edit ' + i + '</p>'; Reveal.sync(); Reveal.layout(); out.push(+(performance.now() - t).toFixed(1)); } return { ms: out, indices: Reveal.getIndices() }; });
  // full reload: new blob document (same html + ready beacon) with #/h/v/f, measured from src assignment to Reveal 'ready'
  const target = await deck.evaluate(() => { const sl = Reveal.getSlides(); for (const s of sl) { const n = s.querySelectorAll('.fragment').length; if (n >= 2) { const i = Reveal.getIndices(s); return { h: i.h, v: i.v || 0, f: 1 }; } } return { h: 2, v: 0, f: -1 }; });
  const beacon = '<script>(function(){var t=setInterval(function(){try{if(window.Reveal&&Reveal.isReady()){clearInterval(t);parent.postMessage({v2ready:1,i:Reveal.getIndices()},"*")}}catch(e){parent.postMessage({v2ready:1,i:"ERR "+e.message},"*")}},5)})();</' + 'script>';
  const html2 = html.replace(/<\/body>/i, beacon + '</body>');
  const reload = await runnerFrame.evaluate(async ({ html2, target }) => { const out = []; for (let k = 0; k < 4; k++) { const fr = document.querySelector('iframe'); const url = URL.createObjectURL(new Blob([html2], { type: 'text/html' })); const t = performance.now(); const r = await new Promise((res) => { const on = (e) => { if (e.data && e.data.v2ready) { removeEventListener('message', on); res(e.data.i); } }; addEventListener('message', on); setTimeout(() => res('timeout'), 8000); fr.src = url + `#/${target.h}/${target.v}/${target.f}`; }); out.push({ ms: Math.round(performance.now() - t), restored: r }); } return out; }, { html2, target });
  console.log(file.split('/').pop(), JSON.stringify({ pm, swap, target, reload, blocked: blocked.length }));
  await ctx.close();
}
await browser.close();
