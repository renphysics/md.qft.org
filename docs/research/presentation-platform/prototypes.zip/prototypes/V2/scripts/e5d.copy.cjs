const { launch, openApp, openFile, state } = require('./lib.cjs');
const { join, resolve } = require('node:path');
const { writeFileSync } = require('node:fs');
const fixtures = resolve(process.argv[2]);
(async () => {
  const browser = await launch();
  const results = {};
  const start = async (file) => {
    const { context, page, logs } = await openApp(browser);
    await openFile(page, join(fixtures, file), 2000);
    await page.locator('[data-pres-start-button]').click();
    await page.waitForFunction(() => /Playing|attention/.test(document.querySelector('[data-pres-player-status]')?.textContent || ''), null, { timeout: 30000 }).catch(() => {});
    await page.waitForTimeout(2500);
    const frame = page.frames().find((f) => f.url().startsWith('blob:'));
    const s = await state(page);
    return { context, page, logs, frame, status: await page.evaluate(() => document.querySelector('[data-pres-player-status]')?.textContent), notice: s.presNotice };
  };
  { // backgrounds
    const { context, frame, status } = await start('reveal-wrapped.zip');
    results.backgrounds = { status, ...(await frame.evaluate(() => {
      Reveal.slide(5); const colour = getComputedStyle(Reveal.getSlideBackground(5)).backgroundColor;
      Reveal.slide(6); const content = Reveal.getSlideBackground(6).querySelector('.slide-background-content'); const image = getComputedStyle(content).backgroundImage.slice(0, 50);
      Reveal.slide(4); const aa = { hasAutoAnimateAttr: Reveal.getCurrentSlide().hasAttribute('data-auto-animate'), state: Reveal.getCurrentSlide().getAttribute('data-auto-animate') };
      return { colour, image, aa, transition: Reveal.getSlide(5).getAttribute('data-transition') };
    })) };
    await context.close();
  }
  for (const name of ['katex', 'mathjax3', 'default']) {
    const { context, frame, status, notice, logs } = await start(`reveal-wrapped-math-${name}.zip`);
    let inner = null;
    if (frame) inner = await frame.evaluate(() => ({ katex: document.querySelectorAll('.katex').length, mjx: document.querySelectorAll('mjx-container').length, ready: document.querySelector('.reveal').classList.contains('ready'), text: document.querySelector('section')?.innerText.slice(0, 80) })).catch((e) => String(e).slice(0, 100));
    results[`math-${name}`] = { status, notice, inner, logs: logs.slice(0, 3).map((l) => l.slice(0, 260)) };
    await context.close();
  }
  console.log(JSON.stringify(results, null, 1));
  writeFileSync(resolve(fixtures, '../out/e5d-' + (process.env.CH||'shell') + '.json'), JSON.stringify(results, null, 2));
  await browser.close();
})();
