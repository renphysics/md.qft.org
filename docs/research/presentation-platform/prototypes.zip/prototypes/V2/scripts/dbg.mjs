// load an adapted deck html directly at http://dbg.test/ (no CSP) and list every non-data request it makes
import { createRequire } from 'node:module'; import { readFileSync } from 'node:fs';
const require = createRequire(import.meta.url); const { chromium } = require('playwright');
const { unzipSync, strFromU8 } = createRequire('/home/user/md.qft.org/package.json')('fflate');
const b = await chromium.launch({ channel: 'chromium' });
for (const z of process.argv.slice(2)) {
  const html = strFromU8(unzipSync(new Uint8Array(readFileSync(z)))['presentation.html']);
  const ctx = await b.newContext(); const reqs = [];
  await ctx.route('**/*', (r) => { const u = r.request().url(); if (u === 'http://dbg.test/') return r.fulfill({ contentType: 'text/html', body: html }); if (!u.startsWith('data:') && !u.startsWith('blob:')) reqs.push(u.slice(0, 100)); return r.abort(); });
  const p = await ctx.newPage(); const logs = []; p.on('console', (m) => m.type() === 'error' && logs.push(m.text().slice(0, 150))); p.on('pageerror', (e) => logs.push('PE ' + String(e).slice(0, 150)));
  await p.goto('http://dbg.test/'); await p.waitForTimeout(2500);
  const st = await p.evaluate(() => ({ ready: window.Reveal?.isReady?.(), total: window.Reveal?.getTotalSlides?.(), text: document.querySelector('.slides')?.innerText.slice(0, 200) }));
  console.log(z.split('/').pop(), JSON.stringify(st), '\n  requests:', [...new Set(reqs)].slice(0, 6), '\n  logs:', logs.slice(0, 4));
  await ctx.close();
}
await b.close();
