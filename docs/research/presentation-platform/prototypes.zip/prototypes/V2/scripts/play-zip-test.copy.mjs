// O2 check: standard reveal.js project ZIPs (index.html + relative dist/, enclosing folder, README alongside) through
// the inliner and the site's real player, network blocked.
import { createRequire } from 'node:module';
import { readFileSync } from 'node:fs';
import { inlineDeck } from './inline-deck.copy.mjs';
const require = createRequire(import.meta.url); const { chromium } = require('playwright');
const { unzipSync } = createRequire('/home/user/md.qft.org/package.json')('fflate');
const P = 'SCRATCH/research/proto/B7/'; const W = 'SCRATCH/research/proto/V2/out/b7rerun/';
const runtime = readFileSync(P + 'bundles/presentation-runtime.iife.js', 'utf8'); const runner = readFileSync('/home/user/md.qft.org/dist/presentation-sandbox.html', 'utf8');
const browser = await chromium.launch(process.env.CH === 'chromium' ? { channel: 'chromium' } : {});
for (const zip of ['A-single-html-cdn.zip', 'B-html-cdn+README.zip', 'C-reveal6-project.zip', 'D-reveal6-project+README.zip', 'E-reveal6-project-in-folder.zip']) {
  let files = new Map(Object.entries(unzipSync(new Uint8Array(readFileSync(P + 'corpus/' + zip)))).filter(([k]) => !k.endsWith('/')).map(([k, v]) => [k, Buffer.from(v)]));
  const keys = [...files.keys()]; const top = keys[0].split('/')[0];
  if (keys.length > 1 && keys.every((k) => k.startsWith(top + '/'))) files = new Map(keys.map((k) => [k.slice(top.length + 1), files.get(k)]));
  const entry = [...files.keys()].filter((k) => /(^|\/)index\.html?$/i.test(k)).sort((a, b) => a.length - b.length)[0];
  const { html, report } = inlineDeck(files.get(entry).toString('utf8'), files, { historyShim: true });
  const ctx = await browser.newContext(); const page = await ctx.newPage(); const blocked = [];
  await ctx.route('**/*', (route) => { const url = route.request().url();
    if (url === 'http://b7.test/harness.html') return route.fulfill({ contentType: 'text/html', body: `<!doctype html><body><div id="host" style="width:1280px;height:720px"></div><script src="/runtime.js"></script>` });
    if (url === 'http://b7.test/runtime.js') return route.fulfill({ contentType: 'text/javascript', body: runtime });
    if (url === 'http://b7.test/presentation-sandbox.html') return route.fulfill({ contentType: 'text/html', body: runner });
    if (url.startsWith('blob:') || url.startsWith('data:')) return route.continue(); blocked.push(url); route.abort(); });
  await page.goto('http://b7.test/harness.html');
  const o = await page.evaluate((html) => new Promise((res) => { const s = []; let err = null; const p = QFT.createPresentationPlayer(document.getElementById('host'), html, { title: 't', sandboxUrl: '/presentation-sandbox.html', onState(x) { s.push(x); if (x === 'ready' || x === 'error') setTimeout(() => res({ s, err }), 400); }, onError(m) { err = m; } }); p.start(); setTimeout(() => res({ s, err: err || 'timeout' }), 20000); }), html);
  let inside = null; if (o.s.at(-1) === 'ready') inside = await page.frames().find((f) => f.url().startsWith('blob:')).evaluate(() => ({ version: Reveal.VERSION, slides: Reveal.getTotalSlides(), plugins: Object.keys(Reveal.getPlugins()) }));
  console.log(zip.padEnd(36), 'entry=' + entry, '|', o.s.join('>'), o.err ? '| ERROR: ' + o.err : '', inside ? '| ' + JSON.stringify(inside) : '', '| unresolved:', report.unresolved.length, '| network:', blocked.length, '| played bytes:', Buffer.byteLength(html));
  await ctx.close();
}
await browser.close();
