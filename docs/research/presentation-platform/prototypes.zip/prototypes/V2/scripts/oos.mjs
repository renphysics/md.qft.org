// V2 out-of-sample run: every deck through B7 inline-deck (copy) and A2 wrap-reveal (copy), then through
// (H) B7's harness method (bundled presentation-runtime + shipped dist/presentation-sandbox.html, route-fulfilled) and
// (S) the production site (astro preview of /home/user/md.qft.org/dist, ZIP uploaded via [data-file-input], A2 method).
// All external network aborted in both. Usage: node oos.mjs <channel: chromium|shell> <site base url> [deckFilter]
import { createRequire } from 'node:module';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { join, basename } from 'node:path';
import { inlineDeck } from './inline-deck.copy.mjs';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const { unzipSync, zipSync, strToU8, strFromU8 } = createRequire('/home/user/md.qft.org/package.json')('fflate');
const V = new URL('..', import.meta.url).pathname;
const S = V + '../../';
const [channel = 'chromium', SITE = 'http://127.0.0.1:4680/', filter = ''] = process.argv.slice(2);
const runtime = readFileSync(V + 'scripts/presentation-runtime.iife.js', 'utf8');
const runner = readFileSync('/home/user/md.qft.org/dist/presentation-sandbox.html', 'utf8');
mkdirSync(V + 'out/pkg', { recursive: true });

const decks = [
  ['n1-reveal-zip', S + 'corpus/naive/n1-reveal-zip.zip'],
  ['n2-reveal-chat-nonet', S + 'corpus/naive/n2-reveal-chat-nonet.zip'],
  ['r1sub-jsdelivr-4.6.1', V + 'inputs/r1sub.zip'],
  ['r1bsub-cdnjs-5.1.0', V + 'inputs/r1bsub.zip'],
  ['B1-extmd6 (r2 stand-in: external md)', S + 'proto/B1/zips/extmd6.zip'],
  ['B1-esm6 (r2 stand-in: ES module)', S + 'proto/B1/zips/esm6.zip'],
  ['B1-classic3 (3.9.2)', S + 'proto/B1/zips/classic3.zip'],
  ['B1-classic4 (4.6.1)', S + 'proto/B1/zips/classic4.zip'],
  ['B1-corpus-n1', S + 'proto/B1/zips/corpus-n1.zip'],
].filter(([id]) => id.includes(filter));

function loadZip(path) {
  let files = new Map(Object.entries(unzipSync(new Uint8Array(readFileSync(path)))).filter(([k]) => !k.endsWith('/')).map(([k, v]) => [k, Buffer.from(v)]));
  const keys = [...files.keys()]; const top = keys[0].split('/')[0];
  if (keys.length > 1 && keys.every((k) => k.startsWith(top + '/'))) files = new Map(keys.map((k) => [k.slice(top.length + 1), files.get(k)]));
  const entry = [...files.keys()].filter((k) => /(^|\/)index\.html?$/i.test(k)).sort((a, b) => a.length - b.length)[0];
  return { files, entry };
}
const pkg = (html, title) => Buffer.from(zipSync({ 'qft-presentation.json': strToU8(JSON.stringify({ format: 'qft-presentation', version: 1, engine: 'slidev', title, entry: 'presentation.html', aspectRatio: '16:9', generator: 'v2' })), 'presentation.html': strToU8(html) }, { level: 6 }));

function adapt(id, zipPath, which) {
  const safe = id.replace(/[^\w.-]+/g, '_');
  if (which === 'B7') {
    const { files, entry } = loadZip(zipPath);
    if (!entry) return { error: 'no index.html' };
    const { html, report } = inlineDeck(files.get(entry).toString('utf8'), files, { historyShim: true });
    const zip = V + `out/pkg/${safe}.B7.zip`; writeFileSync(zip, pkg(html, id));
    return { html, zip, report: { unresolved: report.unresolved.map((u) => u.kind + ' ' + u.url.slice(0, 90)), coerced: [...new Set(report.coerced.map((c) => `${c.lib} ${c.requested}->${c.served}`))], hazards: report.hazards, bytes: report.bytes } };
  }
  const zip = V + `out/pkg/${safe}.A2.zip`;
  try {
    const out = execFileSync('node', [V + 'scripts/wrap-reveal.copy.mjs', zipPath, zip], { encoding: 'utf8' });
    const html = strFromU8(unzipSync(new Uint8Array(readFileSync(zip)))['presentation.html']);
    const st = JSON.parse(out); return { html, zip, report: { remote: st.remote.map((r) => r.slice(0, 90)), missing: st.missing, handlers: st.handlers, bytes: st.htmlBytes } };
  } catch (e) { return { error: String(e.stderr || e).split('\n').filter(Boolean).slice(-2).join(' | ').slice(0, 300) }; }
}

// ---- measurements inside the deck frame -------------------------------------------------------------
const metrics = (frame) => frame.evaluate(() => {
  const R = window.Reveal;
  let raw = 0; const w = document.createTreeWalker(document.querySelector('.slides') || document.body, NodeFilter.SHOW_TEXT);
  for (let n; (n = w.nextNode());) { if (n.parentElement.closest('.katex,script,style,textarea,code,pre,mjx-container')) continue; raw += (n.nodeValue.match(/\\\(|\\\[|\$\$|\$[^$\s][^$\n]{0,60}\$/g) || []).length; }
  return { reveal: typeof R, version: R?.VERSION, total: R?.getTotalSlides?.() ?? document.querySelectorAll('.slides section:not(.stack)').length,
    katex: document.querySelectorAll('.katex').length, mathjax: document.querySelectorAll('mjx-container').length, rawTexLeft: raw,
    hljs: document.querySelectorAll('code.hljs').length, mdParsed: document.querySelectorAll('[data-markdown-parsed]').length,
    imgsBroken: [...document.images].filter((i) => !i.naturalWidth).length, imgs: document.images.length };
});
const where = (frame) => frame.evaluate(() => { if (window.Reveal?.getIndices) { const i = Reveal.getIndices(); return `${i.h}.${i.v ?? 0}${i.f !== undefined && i.f !== -1 ? 'f' + i.f : ''}`; } const top = [...document.querySelectorAll('.slides > section')]; return 'dom ' + top.findIndex((s) => s.classList.contains('present')); });
async function interaction(frame, page) {
  const target = await frame.evaluate(async (pref) => {
    const inSlides = (sel) => [...document.querySelectorAll('.slides section ' + sel)].filter((e) => !e.closest('aside'));
    const el = (pref === 'button' ? inSlides('button')[0] : null) || inSlides('input[type=range]')[0] || inSlides('button')[0];
    if (!el) return null;
    const sec = el.closest('section'); el.setAttribute('data-v2-target', '1');
    if (window.Reveal?.getIndices) { const i = Reveal.getIndices(sec); Reveal.slide(i.h, i.v || 0, 99); }
    else { const top = [...document.querySelectorAll('.slides > section')]; window.postMessage(JSON.stringify({ method: 'slide', args: [top.indexOf(sec.closest('.slides > section')), 0] }), '*'); }
    await new Promise((r) => setTimeout(r, 900));
    return el.tagName.toLowerCase() + (el.type === 'range' ? '[range]' : '') + ' "' + (el.textContent || el.id || '').trim().slice(0, 30) + '"';
  }, process.env.V2_TARGET || '');
  if (!target) return { target: null };
  const fp = () => frame.evaluate(() => { const el = document.querySelector('[data-v2-target]'); const sec = el.closest('section'); const t = sec.innerText.replace(/\s+/g, ' '); const c = [...sec.querySelectorAll('canvas')].map((cv) => { try { const d = cv.toDataURL(); let h = 0; for (let i = 0; i < d.length; i += 7) h = (h * 31 + d.charCodeAt(i)) | 0; return h; } catch (e) { return 'ERR'; } }).join(','); return { t, c, svg: sec.querySelector('svg')?.innerHTML.length ?? null, visible: sec.classList.contains('present') }; });
  const a = await fp(); await page.waitForTimeout(400); const a2 = await fp();
  if (target.includes('[range]')) await frame.evaluate(() => { const el = document.querySelector('[data-v2-target]'); const min = +el.min || 0, max = +el.max || 100; el.value = String(+el.value === max ? min : max); el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); });
  else await frame.locator('[data-v2-target]').click({ timeout: 3000 }).catch((e) => frame.evaluate(() => document.querySelector('[data-v2-target]').click()));
  await page.waitForTimeout(500); const b = await fp();
  const dw = (x, y) => { const A = x.t.split(' '), B = y.t.split(' '); const o = []; for (let i = 0; i < Math.max(A.length, B.length) && o.length < 6; i++) if (A[i] !== B[i]) o.push((A[i] || '') + '=>' + (B[i] || '')); return o.join(' ; '); };
  return { target, autonomousDiff: dw(a, a2), interactionDiff: dw(a2, b), slideVisible: a.visible, autonomousAnimation: a.c !== a2.c || a.t !== a2.t, textChanged: a2.t !== b.t, canvasChanged: a2.c !== b.c, svgChanged: a2.svg !== b.svg, textAfter: b.t.slice(0, 120) };
}
async function probe(page, frame) {
  const r = { inside: await metrics(frame) };
  await frame.locator('.reveal').click({ position: { x: 4, y: 4 } }).catch(() => {});
  const p0 = await where(frame); await page.keyboard.press('ArrowRight'); await page.waitForTimeout(450); await page.keyboard.press('ArrowRight'); await page.waitForTimeout(450);
  r.keyboardNav = p0 + ' -> ' + await where(frame);
  r.interaction = await interaction(frame, page).catch((e) => ({ error: String(e).slice(0, 200) }));
  return r;
}

async function newCtx(browser, allowOrigin) {
  const ctx = await browser.newContext({ viewport: { width: 1360, height: 860 } });
  const blocked = []; const logs = [];
  await ctx.route('**/*', (route) => { const url = route.request().url();
    if (allowOrigin && url.startsWith(allowOrigin)) return route.continue();
    if (url.startsWith('http://v2.test/')) { const p = url.slice(14); return route.fulfill(p === '/runtime.js' ? { contentType: 'text/javascript', body: runtime } : p === '/presentation-sandbox.html' ? { contentType: 'text/html', body: runner } : { contentType: 'text/html', body: '<!doctype html><meta charset="utf-8"><body style="margin:0"><div id="host" style="width:1280px;height:720px"></div><script src="/runtime.js"></script>' }); }
    if (url.startsWith('blob:') || url.startsWith('data:')) return route.continue();
    blocked.push(url.slice(0, 120)); return route.abort(); });
  const page = await ctx.newPage();
  page.on('console', (m) => { if (m.type() === 'error') logs.push(m.text().slice(0, 220)); });
  page.on('pageerror', (e) => logs.push('[pageerror] ' + String(e).slice(0, 220)));
  return { ctx, page, blocked, logs };
}
async function playHarness(browser, html, id) {
  const { ctx, page, blocked, logs } = await newCtx(browser, null);
  await page.goto('http://v2.test/harness.html');
  const o = await page.evaluate(({ html, id }) => new Promise((res) => { const s = []; let err = null; window.__states = s;
    const p = QFT.createPresentationPlayer(document.getElementById('host'), html, { title: id, sandboxUrl: '/presentation-sandbox.html', onState(x) { s.push(x); if (x === 'ready' || x === 'error') setTimeout(() => res({ s: [...s], err }), 800); }, onError(m) { err = m; window.__err = m; } });
    window.__player = p; p.start(); setTimeout(() => res({ s: [...s], err: err || 'timeout 25s' }), 25000); }), { html, id });
  const r = { states: o.s.join('>'), error: o.err };
  if (o.s.at(-1) === 'ready') { const f = page.frames().find((x) => x.url().startsWith('blob:')); Object.assign(r, await probe(page, f).catch((e) => ({ probeError: String(e).slice(0, 200) }))); r.finalState = (await page.evaluate(() => window.__states.at(-1) + (window.__err ? ' ERR ' + window.__err : ''))); }
  r.blocked = [...new Set(blocked)].slice(0, 5); r.blockedCount = blocked.length; r.console = logs.slice(0, 4);
  await page.screenshot({ path: V + 'shots/' + id.replace(/[^\w.-]+/g, '_') + '.H.png' }).catch(() => {});
  await ctx.close(); return r;
}
async function playSite(browser, zip, id) {
  const { ctx, page, blocked, logs } = await newCtx(browser, SITE.replace(/\/$/, ''));
  await page.goto(SITE, { waitUntil: 'load' });
  await page.waitForSelector('[data-editor] .cm-content', { timeout: 20000 });
  await page.waitForFunction(() => document.querySelector('[data-save-label]')?.textContent !== 'Getting ready', null, { timeout: 20000 });
  await page.setInputFiles('[data-file-input]', zip); await page.waitForTimeout(2500);
  const r = {};
  r.opened = await page.evaluate(() => document.querySelector('[data-pres-dialog]')?.open ? document.querySelector('[data-pres-title]')?.textContent.trim() : (document.querySelector('[data-toast]')?.textContent.trim() || 'no dialog'));
  if (await page.locator('[data-pres-start-button]').isVisible().catch(() => false)) {
    await page.locator('[data-pres-start-button]').click();
    await page.waitForFunction(() => !/Opening|Loading|Starting/i.test(document.querySelector('[data-pres-player-status]')?.textContent || 'Opening'), null, { timeout: 30000 }).catch(() => {});
    await page.waitForTimeout(1500);
    const st = () => page.evaluate(() => { const n = document.querySelector('[data-pres-notice]'); return (document.querySelector('[data-pres-player-status]')?.textContent || '').trim() + (n && !n.hidden ? ' | NOTICE: ' + n.textContent.trim().slice(0, 200) : ''); });
    r.status = await st();
    const f = page.frames().find((x) => x.url().startsWith('blob:'));
    if (f) Object.assign(r, await probe(page, f).catch((e) => ({ probeError: String(e).slice(0, 200) })));
    r.statusEnd = await st();
  }
  r.blocked = [...new Set(blocked)].slice(0, 5); r.blockedCount = blocked.length; r.console = logs.filter((l) => !/favicon/.test(l)).slice(0, 4);
  await page.screenshot({ path: V + 'shots/' + id.replace(/[^\w.-]+/g, '_') + '.S.png' }).catch(() => {});
  await ctx.close(); return r;
}

const browser = await chromium.launch(channel === 'chromium' ? { channel: 'chromium' } : {});
const results = [];
if (process.env.V2_HTML) { for (const f of process.env.V2_HTML.split(',')) { const r = await playHarness(browser, readFileSync(f, 'utf8'), basename(f)); console.log(basename(f), JSON.stringify({ states: r.states, error: r.error, v: r.inside?.version, total: r.inside?.total, katex: r.inside?.katex, nav: r.keyboardNav, end: r.finalState, blocked: r.blockedCount })); } await browser.close(); process.exit(0); }
for (const [id, zipPath] of decks) for (const which of ['B7', 'A2']) {
  const a = adapt(id, zipPath, which);
  const row = { deck: id, adapter: which, browser: channel, adapterReport: a.report, adapterError: a.error };
  if (!a.error) { row.H = await playHarness(browser, a.html, id + '.' + which); if (!SITE.startsWith('none')) row.S = await playSite(browser, a.zip, id + '.' + which); }
  results.push(row); console.log(JSON.stringify(row));
}
await browser.close();
writeFileSync(V + `out/oos-${channel}${filter ? '-' + filter.replace(/\W+/g, '_') : ''}.json`, JSON.stringify(results, null, 1));
