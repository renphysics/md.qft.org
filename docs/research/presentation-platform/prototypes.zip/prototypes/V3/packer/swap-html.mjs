// Replace presentation.html in a portable ZIP: node swap-html.mjs <in.zip> <new.html> <out.zip>
import { readFileSync, writeFileSync } from 'node:fs';
import { unzipSync, zipSync } from 'fflate';
const [inp, html, out] = process.argv.slice(2);
const files = unzipSync(readFileSync(inp));
files['presentation.html'] = new Uint8Array(readFileSync(html));
writeFileSync(out, zipSync(files, { level: 6, mtime: new Date('2026-01-01') }));
console.log(Object.keys(files));
