---
title: The Simple Pendulum
info: A short physics lesson
transition: slide-left
---

# The Simple Pendulum

A tiny lesson on periodic motion

<!--
Welcome the class. Ask who has seen a grandfather clock.
-->

---
layout: two-cols
class: pt-6
---

# Ingredients

- A mass $m$
- A string of length $L$
- Gravity $g$

::right::

<img src="/sun.png" class="w-40 rounded" alt="bob" />

A bob, seen from the side.

<!--
Point at the picture on the right.
-->

---

# What we will see

<v-clicks>

- Small swings are periodic
- The period does not depend on mass
- The period grows with length

</v-clicks>

<div v-click class="text-orange-600 mt-4">Surprise: no mass in the formula!</div>

---
layout: center
---

# The formula

$$
T = 2\pi \sqrt{\frac{L}{g}}
$$

Small angle approximation: $\sin\theta \approx \theta$.

---

# Try it

<PendulumSlider />

<!--
Let students drag the slider and predict the value for L = 4 m.
-->

---

# Simulating it

```python {2-3|5}
import math
g = 9.81
L = 1.0
for t in range(5):
    theta = 0.1 * math.cos(math.sqrt(g / L) * t)
    print(t, round(theta, 4))
```

---
layout: end
---

# Thanks

Questions?
