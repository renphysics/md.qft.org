// Copy of B2 test-wasm-converter flow (same page, same worker), saving the produced HTML.
import { createRequire } from 'node:module';
import { writeFile } from 'node:fs/promises';
const { chromium } = createRequire(import.meta.url)('playwright');
const [url, outDir, chan, ...names] = process.argv.slice(2);
const b = await chromium.launch(chan && chan !== 'shell' ? { channel: chan } : {});
const page = await b.newPage({ viewport: { width: 1280, height: 720 } });
const ext = []; await page.route(u => !/^(?:http:\/\/localhost|blob:|data:|about:)/.test(u.href), r => { ext.push(r.request().url().slice(0, 100)); return r.abort(); });
const logs = []; page.on('console', m => { if (m.type() === 'error') logs.push(m.text().slice(0, 200)); });
await page.goto(url); await page.waitForFunction(() => window.__app?.ready, null, { timeout: 60000 });
console.log('init', JSON.stringify(await page.evaluate(() => window.__app.init)));
for (const n of names) {
  const r = await page.evaluate(n => window.__convertAndPlay(n).catch(e => ({ error: String(e.message) })), n);
  if (r.error) { console.log(n, 'ERROR', r.error); continue; }
  await writeFile(`${outDir}/wasm-${n}.html`, await page.evaluate(() => window.__app.lastHtml));
  await page.waitForTimeout(800);
  const deck = page.frames().find(f => f.url().startsWith('blob:'));
  const s = deck ? await deck.evaluate(() => ({ h1: document.querySelector('.slidev-page h1')?.textContent, pages: document.querySelectorAll('.slidev-page').length })).catch(e => String(e)) : 'no deck';
  console.log(n, JSON.stringify({ totalMs: Math.round(r.report.totalMs), bundleMs: Math.round(r.report.bundleMs), htmlMB: (r.htmlBytes / 1048576).toFixed(2), states: r.playerStates, errors: r.playerErrors, report: { ...r.report, bundleMs: undefined, totalMs: undefined } }), JSON.stringify(s));
}
console.log('errors', [...new Set(logs)].slice(0, 6), 'external', [...new Set(ext)]);
await b.close();
