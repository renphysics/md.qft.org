import { createRequire } from 'node:module';
const { chromium } = createRequire(import.meta.url)('playwright');
const [dist] = process.argv.slice(2);
const b = await chromium.launch({ channel: 'chromium' });
const state = f => f.evaluate(() => ({ app: document.querySelector('#app')?.childElementCount ?? -1, pages: document.querySelectorAll('.slidev-page').length, h1: document.querySelector('.slidev-page h1')?.textContent ?? null, text: document.body?.innerText.replace(/\s+/g, ' ').slice(0, 80) })).catch(e => ({ err: String(e).slice(0, 120) }));
async function run(name, url, fn) {
  const p = await b.newPage(); const l = [];
  p.on('console', m => m.type() === 'error' && l.push(m.text().slice(0, 170))); p.on('pageerror', e => l.push('pageerror ' + e.message.slice(0, 170)));
  p.on('response', r => r.status() >= 400 && l.push(r.status() + ' ' + r.url().slice(0, 90)));
  await p.route(u => !/^(?:http:\/\/localhost|file:|blob:|data:|about:)/.test(u.href), r => r.abort());
  await p.goto(url).catch(e => l.push('goto ' + e.message.slice(0, 80))); await p.waitForTimeout(3000);
  const s = fn ? await fn(p) : await state(p);
  console.log(name, JSON.stringify(s), [...new Set(l)].slice(0, 4)); await p.close();
}
await run('A file://', 'file://' + dist + '/index.html');
await run('B sub-path http /sub/deck/', 'http://localhost:4709/sub/deck/');
await run('C opaque sandbox (sub-path)', 'http://localhost:4709/sandbox.html', async p => { const f = p.frames()[1]; return f ? state(f) : 'no frame'; });
await run('C2 opaque sandbox (deck at root of :4702)', 'http://localhost:4709/rootsandbox.html', async p => { const f = p.frames()[1]; return f ? { url: f.url(), ...(await state(f)) } : 'no frame'; });
await run('D blob: document', 'http://localhost:4702/1', async p => { const u = await p.evaluate(async () => URL.createObjectURL(new Blob([await (await fetch('/index.html')).text()], { type: 'text/html' }))); await p.goto(u); await p.waitForTimeout(3000); return state(p); });
await run('E control: root http', 'http://localhost:4702/1');
await b.close();
