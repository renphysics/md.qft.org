import { spawn } from 'node:child_process';
import { resolve } from 'node:path';
import { chromium } from './deck-probe.mjs';
const here = import.meta.dirname;
const server = spawn(process.execPath, [resolve(here, 'static-server.mjs'), '4710', JSON.stringify([{ prefix: '/', dir: resolve(here, '../csptest'), spa: false }])], { stdio: ['ignore', 'pipe', 'inherit'] });
await new Promise(r => server.stdout.once('data', r));
const browser = await chromium.launch(process.env.CHANNEL === 'chromium' ? { channel: 'chromium' } : {});
try {
  const page = await browser.newPage();
  const logs = []; page.on('console', m => logs.push(m.text().slice(0, 200)));
  await page.goto('http://localhost:4710/'); await page.waitForFunction(() => window.__r.done, null, { timeout: 20000 });
  console.log(JSON.stringify(await page.evaluate(() => window.__r), null, 1)); console.log('console:', logs.slice(0, 8));
} finally { await browser.close(); server.kill(); }
