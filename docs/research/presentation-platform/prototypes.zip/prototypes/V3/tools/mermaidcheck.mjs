import { createRequire } from 'node:module';
const { chromium } = createRequire(import.meta.url)('playwright');
const [siteUrl, zip, refUrl] = process.argv.slice(2);
const b = await chromium.launch({ channel: 'chromium' });
if (refUrl) { const p = await b.newPage(); await p.route(u => !u.href.startsWith('http://localhost'), r => r.abort()); const l = []; p.on('console', m => m.type() === 'error' && l.push(m.text().slice(0, 150)));
  await p.goto(refUrl); await p.waitForTimeout(4000); console.log('REF', await p.evaluate(() => ({ svgs: document.querySelector('.slidev-page-7 .mermaid')?.shadowRoot?.querySelectorAll('svg').length, shadowText: document.querySelector('.slidev-page-7 .mermaid')?.shadowRoot?.textContent.replace(/\s+/g,' ').slice(0,200), text: document.querySelector('.slidev-page-7')?.innerText.slice(0, 120) })), l.slice(0, 3)); }
const page = await b.newPage({ viewport: { width: 1280, height: 800 } }); const logs = [];
page.on('console', m => logs.push(`[${m.type()}] ${m.text().slice(0, 250)}`)); page.on('pageerror', e => logs.push('[pageerror] ' + e.message.slice(0, 250)));
await page.goto(siteUrl); await page.locator('[data-pres-input]').setInputFiles(zip); await page.waitForTimeout(1200);
await page.locator('[data-pres-start-button]').click(); await page.waitForTimeout(3000);
const deck = page.frames().find(f => f.url().startsWith('blob:'));
await deck.evaluate(() => document.querySelector('#app').__vue_app__.config.globalProperties.$router.push('/7'));
await page.waitForTimeout(5000);
console.log('CONVERTED', await deck.evaluate(() => { const p = document.querySelector('.slidev-page-7'); const sr = p?.querySelector('.mermaid')?.shadowRoot; return { svgs: sr?.querySelectorAll('svg').length, shadowText: sr?.textContent.replace(/\s+/g,' ').slice(0,200), html: p?.querySelector('.slidev-layout')?.innerHTML.replace(/\s+/g, ' ').slice(0, 400) }; }));
console.log('status', (await page.locator('[data-pres-player-status]').first().textContent())?.trim(), (await page.locator('[data-pres-notice]').first().textContent())?.trim().slice(0, 200));
console.log(logs.filter(l => !/^\[(log|debug|info)\]/.test(l)).slice(0, 10));
await b.close();
