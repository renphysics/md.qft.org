import { createRequire } from 'node:module';
const { chromium } = createRequire(import.meta.url)('playwright');
const b = await chromium.launch({ channel: 'chromium' });
for (const block of [true, false]) {
  const p = await b.newPage(); const req = []; const fail = [];
  if (block) await p.route(u => !u.href.startsWith('http://localhost'), r => r.abort());
  p.on('requestfailed', r => fail.push(r.url().slice(0, 120) + ' ' + r.failure()?.errorText));
  p.on('request', r => { if (!r.url().startsWith('http://localhost')) req.push(r.url().slice(0, 120)); });
  p.on('pageerror', e => fail.push('pageerror ' + e.message.slice(0, 150)));
  await p.goto('http://localhost:4707/7'); await p.waitForTimeout(6000);
  console.log(block ? 'BLOCKED' : 'OPEN', await p.evaluate(() => document.querySelectorAll('.slidev-page-7 svg').length), 'external:', [...new Set(req)], 'failed:', [...new Set(fail)].slice(0, 8));
  await p.close();
}
await b.close();
