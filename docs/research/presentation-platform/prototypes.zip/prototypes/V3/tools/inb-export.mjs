// Compile a deck source in the B2 in-browser compiler page (site CSP) and save the playable HTML.
import { createRequire } from 'node:module';
import { writeFile } from 'node:fs/promises';
const { chromium } = createRequire(import.meta.url)('playwright');
const [url, deck, out] = process.argv.slice(2);
const b = await chromium.launch({ channel: 'chromium' }); const p = await b.newPage();
const logs = []; p.on('console', m => { if (m.type() === 'error') logs.push(m.text().slice(0, 200)); });
await p.goto(url); await p.waitForFunction(() => window.__app?.ready, null, { timeout: 30000 });
const r = await p.evaluate(async d => { const x = await window.__compileOnly(await window.__loadFiles(d)); return { ms: x.compileMs, html: x.html, info: x.info, diag: x.diagnostics }; }, deck);
await writeFile(out, r.html);
console.log(JSON.stringify({ compileMs: Math.round(r.ms), bytes: r.html.length, unsupported: r.info?.unsupported, diagnostics: r.diag, logs }));
await b.close();
