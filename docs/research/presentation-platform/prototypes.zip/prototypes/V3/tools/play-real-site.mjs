// V3: upload a portable ZIP into the REAL md.qft.org production build (served from /home/user/md.qft.org/dist
// by the caller) through the presentation library's file input, start it, and probe the Slidev deck inside.
// Usage: CHANNEL=chromium|shell node play-real-site.mjs <siteUrl> <zip>...
import { createRequire } from 'node:module';
import { basename, resolve } from 'node:path';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const [siteUrl, ...zips] = process.argv.slice(2);
const channel = process.env.CHANNEL === 'chromium' ? 'chromium' : undefined;
const sleep = ms => new Promise(r => setTimeout(r, ms));
const out = [];
for (const zip of zips) {
  const browser = await chromium.launch(channel ? { channel } : {});
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 800 } });
  const external = [];
  await ctx.route(u => !/^(?:http:\/\/localhost|blob:|data:|about:)/.test(u.href), r => { external.push(r.request().url().slice(0, 120)); return r.abort(); });
  const page = await ctx.newPage();
  const logs = [];
  page.on('console', m => { if (['error', 'warning'].includes(m.type())) logs.push(`[${m.type()}] ${m.text().slice(0, 220)}`); });
  page.on('pageerror', e => logs.push('[pageerror] ' + e.message.slice(0, 200)));
  const res = { zip: basename(zip), browser: channel || 'chrome-headless-shell' };
  try {
    await page.goto(siteUrl, { waitUntil: 'load' });
    await page.locator('[data-pres-input]').setInputFiles(resolve(zip));
    await sleep(1500);
    res.noticeAfterUpload = (await page.locator('[data-pres-notice]').first().textContent().catch(() => ''))?.trim().slice(0, 300);
    const startBtn = page.locator('[data-pres-start-button]');
    if (await startBtn.isVisible().catch(() => false)) await startBtn.click();
    else res.startButton = 'not visible';
    const t0 = Date.now();
    let status = '';
    for (let i = 0; i < 60; i++) {
      status = (await page.locator('[data-pres-player-status]').first().textContent().catch(() => ''))?.trim();
      const hasDeck = page.frames().some(f => f.url().startsWith('blob:'));
      if (hasDeck && i > 4 && /ready|running|playing/i.test(status)) break;
      if (/error|failed|stopped/i.test(status)) break;
      await sleep(250);
    }
    res.statusText = status; res.waitMs = Date.now() - t0;
    await sleep(1000);
    const deck = () => page.frames().find(f => f.url().startsWith('blob:'));
    const probe = () => deck()?.evaluate(() => {
      const shown = [...document.querySelectorAll('.slidev-page')].filter(p => { let e = p; while (e && e !== document.body) { if (getComputedStyle(e).display === 'none') return false; e = e.parentElement; } return true; });
      const p = shown[shown.length - 1];
      return { page: p ? (p.className.match(/slidev-page-\d+/) || ['?'])[0] : null, h1: p?.querySelector('h1')?.textContent.trim(), katex: p?.querySelectorAll('.katex').length ?? 0,
        img: [...(p?.querySelectorAll('img') || [])].map(i => `${i.naturalWidth}x${i.naturalHeight} ${i.src.slice(0, 30)}`), mermaid: p?.querySelectorAll('.mermaid svg, svg[id^=mermaid]').length ?? 0, svgs: p?.querySelectorAll('svg').length ?? 0, svgText: [...(p?.querySelectorAll('svg') || [])].map(s => s.textContent.replace(/\s+/g, ' ').trim()).join('|').slice(0, 80),
        visibleClicks: p ? [...p.querySelectorAll('.slidev-vclick-target')].filter(e => !e.classList.contains('slidev-vclick-hidden')).length : 0,
        highlighted: p ? p.querySelectorAll('.slidev-code .line.highlighted, .slidev-code .highlighted').length : 0, dimmed: p ? p.querySelectorAll('.slidev-code .line.dishonored').length : 0, slider: document.querySelector('.len-slider')?.value, focus: document.activeElement?.tagName + '.' + (document.activeElement?.className || '') };
    }).catch(e => ({ err: String(e).slice(0, 150) }));
    res.frames = page.frames().map(f => f.url().slice(0, 50));
    const steps = [];
    if (deck()) {
      steps.push(['start', await probe()]);
      await deck().locator('body').click({ position: { x: 20, y: 20 } }).catch(() => {}); await sleep(200);
      const press = async k => { await page.keyboard.press(k).catch(() => {}); await sleep(350); };
      for (let s = 2; s <= 9; s++) {
        // slide 3: walk the clicks with ArrowRight; otherwise ArrowDown = next slide
        await press('ArrowDown');
        const p = await probe();
        steps.push([`down${s}`, p]);
        if (p?.h1 === 'What we will see') for (let c = 0; c < 4; c++) { await press('ArrowRight'); steps.push([`click${c + 1}`, await probe()]); }
        if (p?.h1 === 'Simulating it') { await press('ArrowRight'); steps.push(['codeclick', await probe()]); }
        if (p?.h1 === 'Try it' && !res.slider) {
          res.slider = await deck().evaluate(async () => {
            const s = document.querySelector('.len-slider'); if (!s) return 'no slider';
            const read = () => `${document.querySelector('.len-out')?.textContent}/${document.querySelector('.period-out')?.textContent}/${getComputedStyle(document.querySelector('.bar')).width}`;
            const before = read(); s.value = '4'; s.dispatchEvent(new Event('input', { bubbles: true })); await new Promise(r => setTimeout(r, 150));
            return `${before} -> ${read()} | scoped border=${getComputedStyle(document.querySelector('.pendulum-box')).borderTopStyle}`;
          }).catch(e => 'eval error ' + String(e).slice(0, 100));
          // real pointer drag on the slider
          const box = await deck().locator('.len-slider').boundingBox().catch(() => null);
          if (box) { await page.mouse.click(box.x + box.width * 0.75, box.y + box.height / 2); await sleep(200); res.sliderMouse = await deck().evaluate(() => `${document.querySelector('.len-out')?.textContent}/${document.querySelector('.period-out')?.textContent}`).catch(e => String(e).slice(0, 80)); await deck().locator('body').click({ position: { x: 20, y: 20 } }).catch(() => {}); await sleep(200); }
        }
      }
      for (let k = 0; k < 12; k++) await press('ArrowLeft');
      steps.push(['backHome', await probe()]);
    }
    res.steps = steps.map(([k, v]) => `${k}: ${JSON.stringify(v)}`);
    res.finalStatus = (await page.locator('[data-pres-player-status]').first().textContent().catch(() => ''))?.trim();
    res.finalNotice = (await page.locator('[data-pres-notice]').first().textContent().catch(() => ''))?.trim().slice(0, 300);
    await page.screenshot({ path: resolve(import.meta.dirname, '../out', `real-${basename(zip)}-${res.browser}.png`) });
  } catch (e) { res.error = String(e.message).split('\n')[0].slice(0, 300); }
  res.logs = [...new Set(logs)].slice(0, 12); res.external = [...new Set(external)];
  out.push(res);
  console.log(JSON.stringify(res, null, 1));
  await browser.close();
}
