import { createRequire } from 'node:module';
const { chromium } = createRequire(import.meta.url)('playwright');
const b = await chromium.launch({ channel: 'chromium' }); const p = await b.newPage(); const l = [];
p.on('console', m => ['error', 'warning'].includes(m.type()) && l.push(m.text().slice(0, 160)));
await p.route(u => !u.href.startsWith('http://localhost'), r => r.abort());
await p.goto(process.argv[2]); await p.waitForTimeout(3000); console.log('REF console', process.argv[2], l); await b.close();
