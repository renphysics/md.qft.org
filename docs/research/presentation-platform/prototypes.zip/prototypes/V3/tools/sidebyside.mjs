import { createRequire } from 'node:module';
import { readFileSync } from 'node:fs';
const { chromium } = createRequire(import.meta.url)('playwright');
const [dir, ...nums] = process.argv.slice(2);
const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1280, height: 370 * nums.length } });
const img = f => 'data:image/png;base64,' + readFileSync(f).toString('base64');
await p.setContent('<body style="margin:0;display:grid;grid-template-columns:1fr 1fr">' + nums.map(n => `<img src="${img(`${dir}/slide${n}-ref.png`)}" style="width:640px"><img src="${img(`${dir}/slide${n}-inbrowser.png`)}" style="width:640px">`).join('') + '</body>');
await p.waitForTimeout(300); await p.screenshot({ path: `${dir}/compare-${nums.join('-')}.png`, fullPage: true }); await b.close();
