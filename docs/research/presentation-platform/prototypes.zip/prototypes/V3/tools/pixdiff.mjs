// Pixel diff of slideN-ref.png vs slideN-inbrowser.png in a directory, via canvas in Chromium.
import { createRequire } from 'node:module';
import { readFileSync, readdirSync } from 'node:fs';
const { chromium } = createRequire(import.meta.url)('playwright');
const dir = process.argv[2];
const b = await chromium.launch(); const p = await b.newPage();
const nums = readdirSync(dir).map(f => f.match(/^slide(\d+)-ref\.png$/)?.[1]).filter(Boolean).map(Number).sort((a, b) => a - b);
for (const n of nums) {
  const a = readFileSync(`${dir}/slide${n}-ref.png`).toString('base64'), c = readFileSync(`${dir}/slide${n}-inbrowser.png`).toString('base64');
  const r = await p.evaluate(async ([a, c]) => {
    const load = s => new Promise(res => { const i = new Image(); i.onload = () => res(i); i.src = 'data:image/png;base64,' + s; });
    const [ia, ic] = await Promise.all([load(a), load(c)]);
    const px = i => { const cv = new OffscreenCanvas(i.width, i.height); const x = cv.getContext('2d'); x.drawImage(i, 0, 0); return x.getImageData(0, 0, i.width, i.height).data; };
    const da = px(ia), dc = px(ic); let diff = 0; for (let k = 0; k < da.length; k += 4) if (da[k] !== dc[k] || da[k + 1] !== dc[k + 1] || da[k + 2] !== dc[k + 2]) diff++;
    return `${ia.width}x${ia.height} vs ${ic.width}x${ic.height} differing px=${diff}`;
  }, [a, c]);
  console.log('slide', n, r);
}
await b.close();
