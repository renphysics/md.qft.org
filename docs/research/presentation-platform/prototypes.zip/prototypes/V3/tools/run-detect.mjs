import { readdir, readFile, stat } from 'node:fs/promises';
import { join, relative, sep } from 'node:path';
import { unzipSync } from 'fflate';
import { detectUpload } from './detect.mjs';
async function fromDir(dir, prefix = '', skip = /^(?:node_modules|\.git)$/) {
  const files = new Map();
  async function walk(d) { for (const e of await readdir(d, { withFileTypes: true })) { if (skip.test(e.name)) continue; const p = join(d, e.name); if (e.isSymbolicLink()) continue; if (e.isDirectory()) await walk(p); else { const rel = prefix + relative(dir, p).split(sep).join('/'); const size = (await stat(p)).size; let cache; files.set(rel, { size, text: () => cache ??= require_text(p) }); } } }
  const fs = await import('node:fs'); const require_text = p => fs.readFileSync(p, 'utf8');
  await walk(dir); return files;
}
async function fromZip(path) { const z = unzipSync(new Uint8Array(await readFile(path))); const files = new Map(); for (const [name, bytes] of Object.entries(z)) if (!name.endsWith('/')) files.set(name, { size: bytes.length, text: () => new TextDecoder().decode(bytes) }); return files; }
const R = process.argv[2];
const cases = [
  ['V3 NEW SOURCE newdeck', () => fromDir('SCRATCH/research/proto/V3/newdeck', '', /^(?:node_modules|\.git|dist)$/)],
  ['V3 NEW DIST newdeck default 53.1.0', () => fromDir('SCRATCH/research/proto/V3/newdeck/dist')],
  ['V3 NEW DIST mermaid 53.1.0', () => fromDir('SCRATCH/research/proto/V3/newdeck-mermaid/dist')],
  ['V3 NEW DIST newdeck 52.11.5', () => fromDir('SCRATCH/research/proto/V3/old52/dist')],
  ['V3 NEW converted portable ZIP', () => fromZip('SCRATCH/research/proto/V3/out/newdeck-conv.zip')],
  ['SOURCE create-slidev template (official starter)', () => fromDir(`${R}/proto/B2/create-slidev-template`)],
  ['SOURCE ordinary deck (slides.md + components + package.json)', () => fromDir(`${R}/shared/slidev-ordinary`, '', /^(?:node_modules|\.git|dist|dist-relative)$/)],
  ['SOURCE ordinary deck nested in a top-level folder', () => fromDir(`${R}/shared/slidev-ordinary`, 'my-talk/', /^(?:node_modules|\.git|dist|dist-relative)$/)],
  ['SOURCE repo tools/slidev starter', () => fromDir('/home/user/md.qft.org/tools/slidev')],
  ['SOURCE markdown only, no package.json (Slidev syntax)', () => fromDir(`${R}/proto/B2/detect-fixtures/md-only-slidev`)],
  ['SOURCE + DIST together (ordinary incl. dist/)', () => fromDir(`${R}/shared/slidev-ordinary`, '', /^(?:node_modules|\.git|dist-relative)$/)],
  ['DIST history base=/', () => fromDir(`${R}/proto/B2/cold-install/dist-history-abs`)],
  ['DIST history base=./', () => fromDir(`${R}/proto/B2/cold-install/dist-history-rel`)],
  ['DIST history base=/sub/deck/', () => fromDir(`${R}/proto/B2/cold-install/dist-history-sub`)],
  ['DIST hash base=/', () => fromDir(`${R}/proto/B2/cold-install/dist-hash-abs`)],
  ['DIST hash base=./ (zipped as dist/…)', () => fromDir(`${R}/proto/B2/cold-install/dist-hash-rel`, 'dist/')],
  ['DIST memory base=./', () => fromDir(`${R}/proto/B2/cold-install/dist-memory-rel`)],
  ['DIST official starter (monaco, mermaid, tweet)', () => fromDir(`${R}/proto/B2/starter-deck/dist`)],
  ['QFT portable lesson.zip', () => fromZip(`${R}/shared/slidev-starter/lesson.zip`)],
  ['reveal.js project', () => fromDir(`${R}/proto/B2/detect-fixtures/revealjs`)],
  ['Marp markdown', () => fromDir(`${R}/proto/B2/detect-fixtures/marp`)],
  ['plain markdown', () => fromDir(`${R}/proto/B2/detect-fixtures/plainmd`)],
];
for (const [name, load] of cases) {
  const files = await load(); const t0 = performance.now(); const r = detectUpload(files); const ms = (performance.now() - t0).toFixed(1);
  const { kind, ...rest } = r;
  console.log(`\n## ${name}\n   kind=${kind} (${ms} ms)`, JSON.stringify(rest).slice(0, 900));
}
