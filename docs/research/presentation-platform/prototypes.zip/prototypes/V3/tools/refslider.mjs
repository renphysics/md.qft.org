import { createRequire } from 'node:module';
const { chromium } = createRequire(import.meta.url)('playwright');
const b = await chromium.launch({ channel: 'chromium' }); const p = await b.newPage({ viewport: { width: 1280, height: 720 } });
await p.route(u => !u.href.startsWith('http://localhost'), r => r.abort());
await p.goto(process.argv[2]); await p.waitForTimeout(2500);
console.log(await p.evaluate(() => `${document.querySelector('.len-out')?.textContent}/${document.querySelector('.period-out')?.textContent} slider.value=${document.querySelector('.len-slider')?.value} min=${document.querySelector('.len-slider')?.min}`));
await b.close();
