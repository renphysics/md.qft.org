import { readFileSync, writeFileSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
const dir = resolve(dirname(fileURLToPath(import.meta.url)), '../decks/plugins6');
const base = readFileSync(resolve(dir, '../classic6/index.html'), 'utf8');
const variant = (name, { head = '', scripts = '', plugins = '', slides = '', opts = '' }) => {
  let html = base.replace('</head>', head + '</head>')
    .replace('<section id="last">', slides + '<section id="last">')
    .replace('<script>Reveal.initialize({ hash: true, plugins: [ RevealMarkdown, RevealHighlight, RevealNotes, RevealZoom, RevealSearch ] });</script>', `${scripts}<script>Reveal.initialize({ hash: true, ${opts} plugins: [ RevealMarkdown, RevealHighlight, RevealNotes${plugins} ] });</script>`);
  writeFileSync(resolve(dir, name), html);
};
variant('menu.html', { scripts: '<script src="plugin/menu/menu.js"></script>', plugins: ', RevealMenu' });
variant('chalkboard.html', { head: '<link rel="stylesheet" href="plugin/chalkboard/style.css">', scripts: '<script src="plugin/chalkboard/plugin.js"></script>', plugins: ', RevealChalkboard' });
variant('mermaid.html', { scripts: '<script src="plugin/mermaid/mermaid.js"></script>', plugins: ', RevealMermaid', slides: '<section id="mm"><div class="mermaid"><pre>\nflowchart TD\n  A[Start] --> B{Is it?}\n  B -- Yes --> C[OK]\n  B -- No --> D[End]\n</pre></div></section>' });
variant('copycode.html', { scripts: '<script src="plugin/copycode/copycode.js"></script>', plugins: ', CopyCode' });
variant('math-katex-default.html', { scripts: '<script src="dist/plugin/math.js"></script>', plugins: ', RevealMath.KaTeX', slides: '<section id="math">$$ e^{i\\pi} + 1 = 0 $$ and inline $a^2+b^2=c^2$</section>' });
variant('math-mathjax-default.html', { scripts: '<script src="dist/plugin/math.js"></script>', plugins: ', RevealMath', slides: '<section id="math">$$ e^{i\\pi} + 1 = 0 $$ and inline $a^2+b^2=c^2$</section>' });
console.log('ok');
