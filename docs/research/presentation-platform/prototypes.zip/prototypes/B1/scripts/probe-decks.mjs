// Opens decks via file:// and http:// and records what breaks. Usage: node probe-decks.mjs <decksDir> <httpBase> <out.json> [filter]
import { createRequire } from 'node:module';
import { readdirSync, statSync, writeFileSync } from 'node:fs';
import { resolve, join } from 'node:path';
import { pathToFileURL } from 'node:url';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const [decksDir, httpBase, outFile, filter] = process.argv.slice(2);
const targets = [];
for (const name of readdirSync(decksDir).sort()) {
  const dir = join(decksDir, name);
  if (!statSync(dir).isDirectory()) continue;
  if (name === 'cdn') { for (const f of readdirSync(dir).sort()) targets.push({ name: 'cdn/' + f, rel: 'cdn/' + f }); }
  else targets.push({ name, rel: name + '/index.html' });
}
const browser = await chromium.launch();
const results = [];
for (const t of targets) {
  if (filter && !t.name.includes(filter)) continue;
  for (const proto of ['file', 'http']) {
    const url = proto === 'file' ? pathToFileURL(resolve(decksDir, t.rel)).href : httpBase + '/' + t.rel;
    const context = await browser.newContext({ viewport: { width: 1280, height: 720 } });
    const page = await context.newPage();
    const log = { console: [], pageErrors: [], failed: [], bad: [], cdnVersions: {} };
    page.on('console', m => { if (['error', 'warning'].includes(m.type())) log.console.push(`[${m.type()}] ${m.text()}`.slice(0, 400)); });
    page.on('pageerror', e => log.pageErrors.push(String(e.message || e).slice(0, 400)));
    page.on('requestfailed', r => log.failed.push(`${r.url().slice(0, 160)} :: ${r.failure()?.errorText}`));
    page.on('response', r => { if (r.status() >= 400) log.bad.push(`${r.status()} ${r.url().slice(0, 160)}`); const v = r.headers()['x-jsd-version']; if (v) log.cdnVersions[r.url().replace(/^https:\/\/cdn\.jsdelivr\.net\/npm\//, '')] = v; });
    const t0 = Date.now();
    let nav = 'ok';
    try { await page.goto(url, { waitUntil: 'load', timeout: 30000 }); } catch (e) { nav = 'goto: ' + e.message.split('\n')[0]; }
    await page.waitForTimeout(2500);
    const state = await page.evaluate(() => {
      const R = window.Reveal || window.__deck;
      const q = (s) => document.querySelector(s);
      const out = { revealGlobal: typeof window.Reveal, version: R && R.VERSION, ready: false, total: null, sections: document.querySelectorAll('.reveal .slides section').length };
      try { out.ready = !!(R && R.isReady && R.isReady()); } catch (e) { out.ready = 'threw ' + e.message; }
      try { out.total = R && R.getTotalSlides && R.getTotalSlides(); } catch (e) { out.total = 'threw ' + e.message; }
      out.readyClass = !!q('.reveal.ready');
      out.mdRendered = !!(q('#md h2') || q('.slides h1#external-markdown, .slides h1'));
      out.mdRaw = !!q('section[data-markdown]:not([data-markdown-parsed])');
      out.mdError = (q('section[data-state="alert"]') || {}).textContent || null;
      out.hljs = !!q('code.hljs');
      out.plainImg = q('#img-plain') ? q('#img-plain').naturalWidth : null;
      out.mdImg = q('#md img') ? q('#md img').naturalWidth : (q('.slides img') ? q('.slides img').naturalWidth : null);
      out.themeFont = getComputedStyle(q('.reveal')).fontFamily.slice(0, 60);
      out.revealPosition = getComputedStyle(q('.reveal')).position;
      out.hash = location.hash;
      out.origin = location.origin;
      return out;
    }).catch(e => ({ evalError: e.message }));
    results.push({ deck: t.name, proto, url: url.slice(0, 200), nav, ms: Date.now() - t0, ...state, ...log });
    await context.close();
  }
}
await browser.close();
writeFileSync(outFile, JSON.stringify(results, null, 2));
for (const r of results) {
  console.log(`\n## ${r.deck} [${r.proto}] ready=${r.ready} version=${r.version} total=${r.total} sections=${r.sections} md=${r.mdRendered} mdRaw=${r.mdRaw} hljs=${r.hljs} img=${r.plainImg}/${r.mdImg} hash=${r.hash} origin=${r.origin}`);
  if (r.mdError) console.log('  mdError: ' + r.mdError.slice(0, 300));
  for (const k of ['pageErrors', 'console', 'failed', 'bad']) for (const m of [...new Set(r[k])].slice(0, 6)) console.log(`  ${k}: ${m}`);
  if (Object.keys(r.cdnVersions).length) console.log('  jsdelivr versions: ' + JSON.stringify(r.cdnVersions));
}
