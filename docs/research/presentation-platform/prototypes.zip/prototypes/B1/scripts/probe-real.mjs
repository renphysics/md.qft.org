// Real-world style decks through the site's chain, as-is and with the compat shim. Usage: node probe-real.mjs <hostUrl> <shimFile> deck...
import { createRequire } from 'node:module';
import { readFileSync } from 'node:fs';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const [hostUrl, shimFile, ...decks] = process.argv.slice(2);
const shim = `<script>${readFileSync(shimFile, 'utf8')}</script>`;
const browser = await chromium.launch();
for (const deck of decks) for (const mode of ['as-is', 'with-shim']) {
  const page = await (await browser.newContext({ viewport: { width: 1400, height: 800 } })).newPage();
  const errs = []; page.on('pageerror', (e) => errs.push(String(e.message).slice(0, 140))); page.on('console', (m) => { if (m.type() === 'error') errs.push('[console] ' + m.text().slice(0, 150)); });
  await page.goto(hostUrl); await page.waitForFunction(() => typeof window.mount === 'function');
  await page.evaluate((o) => window.mount(o), { deck, inject: mode === 'with-shim' ? shim : '' });
  await page.waitForFunction(() => window.__states.some((x) => x.s === 'ready' || x.s === 'error'), null, { timeout: 25000 }).catch(() => {});
  await page.waitForTimeout(2500);
  const host = await page.evaluate(() => ({ states: window.__states.map((x) => x.s + '@' + Math.round(x.t - window.__t0)).join('>'), errors: window.__errors.map((e) => e.slice(0, 170)) }));
  const frame = page.frames().find((f) => f.url().startsWith('blob:'));
  const inner = frame ? await frame.evaluate(() => ({ reveal: typeof window.Reveal, version: window.Reveal && Reveal.VERSION, ready: !!(window.Reveal && Reveal.isReady && Reveal.isReady()), readyClass: !!document.querySelector('.reveal.ready'), total: window.Reveal && Reveal.getTotalSlides && Reveal.getTotalSlides(), katex: document.querySelectorAll('.katex').length, mathjax: document.querySelectorAll('.MathJax, mjx-container').length, canvases: document.querySelectorAll('canvas').length })).catch((e) => ({ evalError: e.message.slice(0, 90) })) : null;
  console.log(`${deck} [${mode}] host=${JSON.stringify(host)} inner=${JSON.stringify(inner)} errs=${JSON.stringify([...new Set(errs)].slice(0, 4))}`);
  await page.context().close();
}
await browser.close();
