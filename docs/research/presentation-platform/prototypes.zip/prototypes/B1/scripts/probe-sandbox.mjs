// Tests reveal.js behaviours inside <iframe sandbox="allow-scripts"> (opaque origin) with blob: and srcdoc documents.
// Usage: node probe-sandbox.mjs <hostUrl> <out.json> [deck=single/classic6.html]
import { createRequire } from 'node:module';
import { writeFileSync } from 'node:fs';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const [hostUrl, outFile, deckArg] = process.argv.slice(2);
const deck = deckArg || 'single/classic6.html';
const browser = await chromium.launch();
const results = {};
async function session(name, opts, body) {
  const context = await browser.newContext({ viewport: { width: 1400, height: 800 } });
  const page = await context.newPage();
  const log = { pageErrors: [], console: [], popups: 0 };
  page.on('pageerror', (e) => log.pageErrors.push(String(e.message || e).slice(0, 300)));
  page.on('console', (m) => { if (['error', 'warning'].includes(m.type())) log.console.push(`[${m.type()}] ${m.text()}`.slice(0, 300)); });
  page.on('popup', () => { log.popups++; });
  await page.goto(hostUrl);
  await page.evaluate((o) => window.mount(o), { deck, ...opts });
  await page.waitForTimeout(1200);
  const frame = page.frames().find((f) => f !== page.mainFrame());
  const out = { opts, frameUrl: frame ? frame.url().slice(0, 60) : null };
  try { Object.assign(out, await body({ page, frame, log })); } catch (e) { out.threw = String(e.message).split('\n')[0]; }
  out.pageErrors = [...new Set(log.pageErrors)]; out.console = [...new Set(log.console)]; out.popups = log.popups;
  results[name] = out;
  console.log('\n## ' + name + '\n' + JSON.stringify(out, null, 1).slice(0, 2600));
  await context.close();
}
const basic = () => { const R = window.Reveal; return { ready: R.isReady(), version: R.VERSION, windowOrigin: self.origin, locationOrigin: location.origin, readyClass: !!document.querySelector('.reveal.ready'), noTransition: !!document.querySelector('.slides.no-transition'), href: location.href.slice(0, 20) + '…' + location.hash, total: R.getTotalSlides(), indices: R.getIndices(), hashCfg: R.getConfig().hash, historyCfg: R.getConfig().history, md: !!document.querySelector('#md h2'), hljs: !!document.querySelector('code.hljs') }; };
const noId = [['<section id="title">', '<section>']];

// T1: init + hash:true in blob document
await session('T1-blob-hash-true', { transforms: noId }, async ({ frame }) => {
  const a = await frame.evaluate(basic);
  await frame.evaluate(() => Reveal.slide(4)); await frame.waitForTimeout(1300);
  const h1 = await frame.evaluate(() => location.hash);
  await frame.evaluate(() => Reveal.slide(0)); await frame.waitForTimeout(1300);
  const h2 = await frame.evaluate(() => ({ hash: location.hash, pathname: location.pathname, search: location.search, idx: Reveal.getIndices() }));
  let direct; try { direct = await frame.evaluate(() => { try { history.replaceState(null, null, location.pathname + location.search); return 'ok'; } catch (e) { return e.name + ': ' + e.message; } }); } catch (e) { direct = 'eval failed ' + e.message; }
  const frag = await frame.evaluate(() => { try { history.replaceState(null, null, '#/3'); return 'ok ' + location.hash; } catch (e) { return e.name + ': ' + e.message; } });
  return { basic: a, hashAfterSlide4: h1, afterBackToFirst: h2, replaceStatePathname: direct, replaceStateFragment: frag };
});
// T1b: same in srcdoc
await session('T1b-srcdoc-hash-true', { mode: 'srcdoc', transforms: noId }, async ({ frame }) => {
  const a = await frame.evaluate(basic);
  await frame.evaluate(() => Reveal.slide(4)); await frame.waitForTimeout(1300);
  const h1 = await frame.evaluate(() => location.hash);
  await frame.evaluate(() => Reveal.slide(0)); await frame.waitForTimeout(1300);
  const h2 = await frame.evaluate(() => ({ hash: location.hash, pathname: location.pathname, href: location.href, base: document.baseURI.slice(0, 60), idx: Reveal.getIndices() }));
  const direct = await frame.evaluate(() => { try { history.replaceState(null, null, location.pathname + location.search); return 'ok'; } catch (e) { return e.name + ': ' + e.message; } });
  return { basic: a, hashAfterSlide4: h1, afterBackToFirst: h2, replaceStatePathname: direct };
});
// T2: deep link via blob URL fragment
await session('T2-blob-deeplink-hash', { hash: '#/3/0/1' }, async ({ frame }) => ({ basic: await frame.evaluate(basic), state: await frame.evaluate(() => Reveal.getState()) }));
await session('T2b-blob-deeplink-named', { hash: '#/code' }, async ({ frame }) => ({ state: await frame.evaluate(() => Reveal.getState()), href: await frame.evaluate(() => location.hash) }));
// T2c: query string on a blob URL
await session('T2c-blob-query', { hash: '?view=scroll' }, async ({ frame }) => ({ url: frame ? frame.url() : null, doc: frame ? await frame.evaluate(() => document.body ? document.body.innerText.slice(0, 80) : '').catch((e) => 'eval failed') : null }));
// T3: history:true
await session('T3-blob-history-true', { transforms: [...noId, ['hash: true', 'history: true']] }, async ({ frame }) => {
  await frame.evaluate(() => Reveal.slide(3)); await frame.waitForTimeout(300);
  const h1 = await frame.evaluate(() => location.hash);
  await frame.evaluate(() => Reveal.slide(0)); await frame.waitForTimeout(300);
  await frame.evaluate(() => history.back()); await frame.waitForTimeout(500);
  return { basic: await frame.evaluate(basic), h1, afterBack: await frame.evaluate(() => ({ hash: location.hash, idx: Reveal.getIndices() })) };
});
// T4: keyboard + UI features
await session('T4-keyboard-ui', {}, async ({ page, frame, log }) => {
  const out = {};
  await page.mouse.click(640, 360);
  await page.keyboard.press('ArrowRight'); await page.waitForTimeout(200);
  out.afterRight = await frame.evaluate(() => Reveal.getIndices());   // first slide has 2 fragments
  await page.keyboard.press('Space'); await page.keyboard.press('Space'); await page.waitForTimeout(300);
  out.afterSpaces = await frame.evaluate(() => Reveal.getIndices());
  await page.keyboard.press('o'); await page.waitForTimeout(300);
  out.overview = await frame.evaluate(() => Reveal.isOverview());
  await page.keyboard.press('Escape'); await page.waitForTimeout(300);
  out.overviewAfterEsc = await frame.evaluate(() => Reveal.isOverview());
  await page.keyboard.press('b'); await page.waitForTimeout(200);
  out.paused = await frame.evaluate(() => Reveal.isPaused());
  await page.keyboard.press('b'); await page.waitForTimeout(200);
  out.resumed = await frame.evaluate(() => !Reveal.isPaused());
  await page.keyboard.press('F1'); await page.waitForTimeout(300);
  out.help = await frame.evaluate(() => { const o = document.querySelector('.r-overlay'); return o ? o.className : null; });
  await page.keyboard.press('Escape'); await page.waitForTimeout(200);
  out.helpClosed = await frame.evaluate(() => !document.querySelector('.r-overlay'));
  await page.keyboard.press('g'); await page.waitForTimeout(200);
  out.jump = await frame.evaluate(() => !!document.querySelector('.jump-to-slide'));
  await page.keyboard.type('5'); await page.keyboard.press('Enter'); await page.waitForTimeout(300);
  out.afterJump = await frame.evaluate(() => Reveal.getIndices());
  const before = log.pageErrors.length + log.console.length;
  await page.keyboard.press('f'); await page.waitForTimeout(500);
  out.fullscreenElement = await frame.evaluate(() => !!document.fullscreenElement);
  out.fullscreenEnabled = await frame.evaluate(() => document.fullscreenEnabled);
  out.fullscreenMsgs = [...log.pageErrors, ...log.console].slice(before);
  const before2 = log.pageErrors.length + log.console.length;
  await page.keyboard.press('s'); await page.waitForTimeout(700);
  out.speakerMsgs = [...log.pageErrors, ...log.console].slice(before2);
  out.stillAlive = await frame.evaluate(() => { Reveal.next(); return Reveal.getIndices(); });
  const before3 = log.pageErrors.length + log.console.length;
  out.print = await frame.evaluate(() => { try { window.print(); return 'called'; } catch (e) { return e.name + ': ' + e.message; } });
  await page.waitForTimeout(300);
  out.printMsgs = [...log.pageErrors, ...log.console].slice(before3);
  out.storage = await frame.evaluate(() => { const r = {}; for (const n of ['localStorage', 'sessionStorage']) { try { window[n].setItem('a', '1'); r[n] = 'ok'; } catch (e) { r[n] = e.name + ': ' + e.message.slice(0, 90); } } try { document.cookie = 'a=1'; r.cookie = 'ok:' + document.cookie; } catch (e) { r.cookie = e.name + ': ' + e.message.slice(0, 90); } return r; });
  return out;
});
// T4b: fullscreen with allow="fullscreen" + speaker with allow-popups
await session('T4b-fullscreen-allowed', { allow: 'fullscreen' }, async ({ page, frame, log }) => {
  await page.mouse.click(640, 360); await page.keyboard.press('f'); await page.waitForTimeout(600);
  return { fullscreenElement: await frame.evaluate(() => !!document.fullscreenElement), enabled: await frame.evaluate(() => document.fullscreenEnabled) };
});
await session('T4c-speaker-allow-popups', { sandbox: 'allow-scripts allow-popups' }, async ({ page, frame, log }) => {
  await page.mouse.click(640, 360);
  const popupPromise = page.waitForEvent('popup', { timeout: 4000 }).catch(() => null);
  await page.keyboard.press('s');
  const popup = await popupPromise; await page.waitForTimeout(6000);
  let info = null;
  if (popup) { info = await popup.evaluate(() => ({ url: location.href, origin: location.origin, status: (document.querySelector('#connection-status') || {}).innerText, iframes: [...document.querySelectorAll('iframe')].map((f) => (f.getAttribute('src') || '').slice(0, 120)), bodyLen: document.body ? document.body.innerHTML.length : 0 })).catch((e) => 'eval failed: ' + e.message.split('\n')[0]); }
  return { popupOpened: !!popup, info };
});
await session('T4d-speaker-allow-popups-same-origin', { sandbox: 'allow-scripts allow-popups allow-same-origin' }, async ({ page, frame, log }) => {
  await page.mouse.click(640, 360);
  const popupPromise = page.waitForEvent('popup', { timeout: 4000 }).catch(() => null);
  await page.keyboard.press('s');
  const popup = await popupPromise; await page.waitForTimeout(6000);
  let info = null;
  if (popup) { info = await popup.evaluate(() => ({ url: location.href, origin: location.origin, status: (document.querySelector('#connection-status') || {}).innerText, statusDisplay: (document.querySelector('#connection-status') || { style: {} }).style.display, iframes: [...document.querySelectorAll('iframe')].map((f) => (f.getAttribute('src') || '').slice(0, 160)), notes: (document.querySelector('.speaker-controls-notes .value') || {}).innerText })).catch((e) => 'eval failed: ' + e.message.split('\n')[0]); }
  return { popupOpened: !!popup, info, frameOrigin: await frame.evaluate(() => location.origin) };
});
// T5: postMessage API
await session('T5-postmessage', {}, async ({ page, frame }) => {
  const out = {};
  const msgs = async () => page.evaluate(() => window.__messages.map((m) => m.data));
  await page.evaluate(() => { window.__messages.length = 0; window.send({ method: 'slide', args: [2, 1] }); window.send({ method: 'getState' }); });
  await page.waitForTimeout(400);
  out.afterSlideCall = await frame.evaluate(() => Reveal.getIndices());
  out.messagesWithoutPostMessageEvents = (await msgs()).length;
  await page.evaluate(() => { window.__messages.length = 0; window.send({ method: 'configure', args: [{ postMessageEvents: true }] }); });
  await page.waitForTimeout(300);
  out.afterConfigure = await msgs();
  await page.evaluate(() => { window.__messages.length = 0; for (const m of ['getState', 'getTotalSlides', 'getProgress', 'getSlidePastCount', 'getIndices', 'isLastSlide', 'getSlideNotes', 'availableRoutes', 'availableFragments', 'getSlidesAttributes', 'isOverview', 'isReady']) window.send({ method: m }); window.send({ method: 'slide', args: [0, 0, 0] }); window.send({ method: 'getSlideNotes' }); window.send({ method: 'next' }); window.send({ method: 'toggleOverview' }); window.send({ method: 'toggleOverview' }); window.send({ method: 'getConfig' }); window.send({ method: 'getCurrentSlide' }); window.send({ method: 'registerPlugin', args: [{ id: 'x' }] }); window.send({ method: 'addEventListener', args: ['x'] }); });
  await page.waitForTimeout(800);
  const all = await msgs();
  out.callbacks = all.filter((m) => m && m.eventName === 'callback').map((m) => ({ method: m.method, result: typeof m.result === 'object' && m.result !== null ? JSON.stringify(m.result).slice(0, 140) : m.result }));
  out.events = all.filter((m) => m && m.eventName !== 'callback').map((m) => m.eventName + (m.state ? ' ' + JSON.stringify(m.state) : ''));
  out.sampleEvent = all.find((m) => m && m.eventName === 'slidechanged');
  await page.evaluate(() => { window.__messages.length = 0; window.send({ method: 'setState', args: [{ indexh: 3, indexv: 0, indexf: 1, paused: false, overview: false }] }); });
  await page.waitForTimeout(400);
  out.afterSetState = await frame.evaluate(() => Reveal.getState());
  // non-JSON / object messages
  await page.evaluate(() => { window.__frame.contentWindow.postMessage({ method: 'slide', args: [0] }, '*'); });
  await page.waitForTimeout(200);
  out.objectMessageIgnored = await frame.evaluate(() => Reveal.getIndices());
  return out;
});
// T6: print view via config (blob URL cannot carry ?print-pdf)
await session('T6-print-view-config', { transforms: [['hash: true', "hash: true, view: 'print'"]] }, async ({ frame }) => frame.evaluate(() => ({ isPrintView: Reveal.isPrintView && Reveal.isPrintView(), htmlClass: document.documentElement.className, bodyClass: document.body.className.slice(0, 80), pages: document.querySelectorAll('.pdf-page').length, scrollH: document.documentElement.scrollHeight })));
// T7: scroll view (explicit and narrow auto-activation)
await session('T7-scroll-view-config', { transforms: [['hash: true', "hash: true, view: 'scroll'"]] }, async ({ page, frame }) => {
  const a = await frame.evaluate(() => ({ isScroll: Reveal.isScrollView(), viewportClass: document.body.className.slice(0, 100) }));
  await page.mouse.move(640, 360); await page.mouse.wheel(0, 1500); await page.waitForTimeout(600);
  return { ...a, afterWheel: await frame.evaluate(() => ({ idx: Reveal.getIndices(), scrollTop: document.body.scrollTop })) };
});
await session('T7b-narrow-auto-scroll', { width: 400, height: 700 }, async ({ page, frame }) => {
  const a = await frame.evaluate(() => ({ isScroll: Reveal.isScrollView(), w: innerWidth }));
  await page.mouse.move(200, 360); await page.mouse.wheel(0, 1200); await page.waitForTimeout(600);
  return { ...a, afterWheel: await frame.evaluate(() => ({ idx: Reveal.getIndices(), scrollTop: document.body.scrollTop })) };
});
// T8: lightbox + link preview
await session('T8-lightbox', { transforms: [['<img id="img-plain" ', '<img id="img-plain" data-preview-image '], ['<h2>Last</h2>', '<h2>Last</h2><a id="plink" href="https://example.com/" data-preview-link>preview link</a> <a id="ilink" href="#/code">internal</a> <a id="xlink" href="https://example.com/">external</a>']] }, async ({ page, frame }) => {
  const out = {};
  await frame.evaluate(() => Reveal.slide(1, 0)); await page.waitForTimeout(500);
  await frame.evaluate(() => document.querySelector('#img-plain').click()); await page.waitForTimeout(500);
  out.imageOverlay = await frame.evaluate(() => { const o = document.querySelector('.r-overlay, .overlay'); return o ? o.className : null; });
  out.stateWithLightbox = await frame.evaluate(() => Reveal.getState());
  await page.keyboard.press('Escape'); await page.waitForTimeout(300);
  await frame.evaluate(() => Reveal.slide(Reveal.getHorizontalSlides().length - 1)); await page.waitForTimeout(400);
  await frame.evaluate(() => document.querySelector('#ilink').click()); await page.waitForTimeout(500);
  out.afterInternalLink = await frame.evaluate(() => ({ idx: Reveal.getIndices(), hash: location.hash }));
  await frame.evaluate(() => Reveal.slide(Reveal.getHorizontalSlides().length - 1)); await page.waitForTimeout(300);
  await frame.evaluate(() => document.querySelector('#plink').click()); await page.waitForTimeout(1500);
  out.linkPreview = await frame.evaluate(() => { const o = document.querySelector('.r-overlay iframe, .overlay iframe'); return o ? o.getAttribute('src') : null; });
  return out;
});
// T9: lifecycle: sync / destroy / re-initialize / second instance
await session('T9-lifecycle', {}, async ({ frame }) => frame.evaluate(async () => {
  const out = {};
  const slides = document.querySelector('.reveal .slides');
  const s = document.createElement('section'); s.innerHTML = '<h2>Added later</h2><p class="fragment">f</p>'; slides.appendChild(s);
  Reveal.sync(); out.totalAfterSync = Reveal.getTotalSlides();
  Reveal.slide(99); out.lastIdx = Reveal.getIndices();
  Reveal.destroy(); out.readyAfterDestroy = Reveal.isReady(); out.hasViewportClass = document.body.classList.contains('reveal-viewport');
  try { await Reveal.initialize({ hash: false }); out.reinit = 'ok total=' + Reveal.getTotalSlides(); } catch (e) { out.reinit = 'threw: ' + (e.message || e); }
  try { const el = document.createElement('div'); el.className = 'reveal'; el.style.cssText = 'position:absolute;right:0;top:0;width:300px;height:200px'; el.innerHTML = '<div class="slides"><section>A</section><section>B</section></div>'; document.body.appendChild(el); const d = new Reveal(el, { embedded: true, keyboardCondition: 'focused' }); await d.initialize(); d.next(); out.second = 'ok idx=' + JSON.stringify(d.getIndices()) + ' main=' + JSON.stringify(Reveal.getIndices()); } catch (e) { out.second = 'threw: ' + (e.message || e); }
  return out;
}));
// T10: auto-slide + events
await session('T10-autoslide', { transforms: [['hash: true', 'hash: true, autoSlide: 300, loop: true']] }, async ({ page, frame }) => { await page.waitForTimeout(1500); return { idx: await frame.evaluate(() => Reveal.getIndices()), autoSliding: await frame.evaluate(() => Reveal.isAutoSliding()) }; });
await browser.close();
writeFileSync(outFile, JSON.stringify(results, null, 2));
