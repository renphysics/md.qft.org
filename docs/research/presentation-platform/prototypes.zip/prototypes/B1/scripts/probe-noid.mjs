// Which majors abort start() on replaceState in the site's chain when the first slide has no id? Usage: node probe-noid.mjs <hostUrl>
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const browser = await chromium.launch();
for (const d of ['classic3', 'classic4', 'classic5', 'classic6']) {
  for (const variant of ['hash: true', 'hash: false', 'history: true', "hash: true, fragmentInURL: false"]) {
    const page = await (await browser.newContext({ viewport: { width: 1400, height: 800 } })).newPage();
    const errs = []; page.on('pageerror', (e) => errs.push(String(e.message).slice(0, 110)));
    await page.goto(process.argv[2]);
    await page.waitForFunction(() => typeof window.mount === 'function');
    await page.evaluate((o) => window.mount(o), { deck: 'single/' + d + '.html', transforms: [['<section id="title">', '<section>'], ['hash: true', variant]] });
    await page.waitForFunction(() => window.__states.some((x) => x.s === 'ready' || x.s === 'error'), null, { timeout: 25000 }).catch(() => {});
    await page.waitForTimeout(600);
    const r = await page.evaluate(() => ({ states: window.__states.map((x) => x.s).join('>'), errors: window.__errors.map((e) => e.slice(0, 100)) }));
    console.log(`${d} [${variant}] -> ${r.states} ${JSON.stringify(r.errors)} ${JSON.stringify(errs)}`);
    await page.context().close();
  }
}
await browser.close();
