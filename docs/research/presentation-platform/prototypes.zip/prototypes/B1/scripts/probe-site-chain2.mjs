// Second batch for the site's real chain: compat shim, 3.x deck. Usage: node probe-site-chain2.mjs <hostUrl> <out.json> <shimFile>
import { createRequire } from 'node:module';
import { writeFileSync, readFileSync } from 'node:fs';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const [hostUrl, outFile, shimFile] = process.argv.slice(2);
const shim = `<script>${readFileSync(shimFile, 'utf8')}</script>`;
const browser = await chromium.launch();
const results = {};
async function session(name, opts, body) {
  const context = await browser.newContext({ viewport: { width: 1400, height: 800 } });
  const page = await context.newPage();
  const log = { pageErrors: [], console: [] };
  page.on('pageerror', (e) => log.pageErrors.push(String(e.message || e).slice(0, 260)));
  page.on('console', (m) => { if (['error', 'warning'].includes(m.type())) log.console.push(`[${m.type()}] ${m.text()}`.slice(0, 260)); });
  await page.goto(hostUrl);
  await page.waitForFunction(() => typeof window.mount === 'function');
  await page.evaluate((o) => window.mount(o), opts);
  await page.waitForFunction(() => window.__states.some((x) => x.s === 'ready' || x.s === 'error'), null, { timeout: 25000 }).catch(() => {});
  await page.waitForTimeout(1200);
  const host = async () => page.evaluate(() => ({ states: window.__states.map((x) => x.s + '@' + Math.round(x.t - window.__t0)), errors: window.__errors.slice(), running: window.__player.isRunning() }));
  const frame = () => page.frames().find((f) => f.url().startsWith('blob:'));
  const out = { deck: opts.deck, host: await host() };
  try { if (body) Object.assign(out, await body({ page, frame, log, host })); } catch (e) { out.threw = String(e.message).split('\n')[0].slice(0, 300); }
  out.pageErrors = [...new Set(log.pageErrors)]; out.console = [...new Set(log.console)];
  results[name] = out; console.log('\n## ' + name + '\n' + JSON.stringify(out));
  await context.close();
}
const info = () => { const R = window.Reveal; return { ready: R.isReady(), version: R.VERSION, readyClass: !!document.querySelector('.reveal.ready'), total: R.getTotalSlides(), md: !!document.querySelector('#md h2'), hljs: !!document.querySelector('code.hljs'), imgs: [...document.querySelectorAll('.slides img')].map((i) => i.naturalWidth).join(',') }; };
const noId = [['<section id="title">', '<section>']];
await session('C1-classic3-inlined', { deck: 'single/classic3.html' }, async ({ frame }) => frame() ? { info: await frame().evaluate(info) } : {});
await session('C1b-classic3-inlined-noid', { deck: 'single/classic3.html', transforms: noId }, async ({ frame }) => frame() ? { info: await frame().evaluate(info) } : {});
for (const d of ['classic6', 'classic5', 'classic4', 'classic3']) {
  await session('C2-' + d + '-noid-with-shim-F-S-keys', { deck: 'single/' + d + '.html', transforms: noId, inject: shim }, async ({ frame, page, host }) => {
    const a = await frame().evaluate(info);
    await page.mouse.click(640, 360);
    await page.keyboard.press('ArrowRight'); await page.keyboard.press('ArrowRight'); await page.keyboard.press('ArrowRight'); await page.waitForTimeout(1300);
    const hash1 = await frame().evaluate(() => location.hash);
    await page.keyboard.press('f'); await page.waitForTimeout(400);
    await page.keyboard.press('s'); await page.waitForTimeout(900);
    await page.keyboard.press('Home'); await page.waitForTimeout(1300);
    const b = await frame().evaluate(() => ({ idx: Reveal.getIndices(), hash: location.hash }));
    const msgs = await page.evaluate(() => window.__messages.filter((m) => m && m.qftReveal).map((m) => m.kind));
    return { info: a, hash1, afterHome: b, shimMessagesAtTop: msgs, after: await host() };
  });
}
await session('C3-extmd6-inlined-with-shim', { deck: 'single/extmd6.html', inject: shim }, async ({ frame }) => frame() ? { info: await frame().evaluate(info), h1: await frame().evaluate(() => (document.querySelector('.slides h1') || {}).textContent), total: await frame().evaluate(() => Reveal.getTotalSlides()) } : {});
await browser.close();
writeFileSync(outFile, JSON.stringify(results, null, 2));
