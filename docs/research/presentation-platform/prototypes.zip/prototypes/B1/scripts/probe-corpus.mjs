import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const browser = await chromium.launch();
for (const file of process.argv.slice(2)) {
  const page = await (await browser.newContext({ viewport: { width: 1280, height: 720 } })).newPage(); const errs = [], failed = [];
  page.on('pageerror', (e) => errs.push(String(e.message).slice(0, 120))); page.on('requestfailed', (r) => failed.push(r.url().slice(-60) + ' ' + r.failure()?.errorText));
  let n = 0; page.on('request', () => n++);
  await page.goto(pathToFileURL(file).href, { waitUntil: 'load' }); await page.waitForTimeout(2500);
  const s = await page.evaluate(() => ({ version: window.Reveal && Reveal.VERSION, ready: !!(window.Reveal && Reveal.isReady()), readyClass: !!document.querySelector('.reveal.ready'), total: Reveal.getTotalSlides(), katex: document.querySelectorAll('.katex').length, canvases: document.querySelectorAll('canvas').length, svgs: document.querySelectorAll('svg').length, hash: location.hash }));
  console.log(file.split('/').slice(-3).join('/'), JSON.stringify(s), 'requests=' + n, 'errs=' + JSON.stringify(errs), 'failed=' + JSON.stringify(failed.slice(0, 4)));
  await page.context().close();
}
await browser.close();
