import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const browser = await chromium.launch();
const page = await (await browser.newContext()).newPage();
page.on('response', (r) => { if (/unpkg/.test(r.url())) console.log(r.status(), r.url(), r.headers()['location'] || '', r.headers()['content-type'] || ''); });
await page.goto(process.argv[2], { waitUntil: 'load' }).catch(() => {}); await page.waitForTimeout(2000);
console.log(await page.evaluate(() => ({ v: window.Reveal && Reveal.VERSION, ready: Reveal.isReady() })));
await browser.close();
