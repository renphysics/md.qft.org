// Naive "ZIP folder -> single self-contained HTML" inliner for reveal.js decks (research prototype).
// Usage: node inline-deck.mjs <deckDir> <entry.html> <out.html> [--keep-remote-imports]
// Handles: <link rel=stylesheet href=local>, <script src=local>, CSS @import + url(), <img src>, data-src,
// data-background-image/-video, reveal 3.x `dependencies: [{src}]`, external data-markdown, markdown image links.
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { dirname, resolve, extname, posix } from 'node:path';
const [deckDir, entry, out, ...flags] = process.argv.slice(2);
const keepRemote = flags.includes('--keep-remote-imports');
const mime = { '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.svg': 'image/svg+xml', '.webp': 'image/webp', '.woff': 'font/woff', '.woff2': 'font/woff2', '.ttf': 'font/ttf', '.eot': 'application/vnd.ms-fontobject', '.mp4': 'video/mp4', '.webm': 'video/webm', '.mp3': 'audio/mpeg' };
const stats = { css: 0, js: 0, assets: 0, missing: [], remote: [] };
const isRemote = (u) => /^(?:[a-z][a-z0-9+.-]*:)?\/\//i.test(u) || /^(?:data|blob|javascript|mailto|about):/i.test(u);
const clean = (u) => u.split('#')[0].split('?')[0];
const read = (path) => { const p = resolve(deckDir, path); if (!existsSync(p)) { stats.missing.push(path); return null; } return readFileSync(p); };
const dataUri = (path) => { const b = read(path); if (!b) return null; stats.assets += b.length; return `data:${mime[extname(path).toLowerCase()] || 'application/octet-stream'};base64,${b.toString('base64')}`; };
const join = (base, rel) => posix.normalize(posix.join(posix.dirname(base), clean(rel)));
function css(path, seen = new Set()) {
  if (seen.has(path)) return ''; seen.add(path);
  const b = read(path); if (!b) return `/* missing ${path} */`;
  let text = b.toString('utf8');
  text = text.replace(/@import\s+(?:url\(\s*)?["']?([^"')\s;]+)["']?\s*\)?\s*([^;]*);/g, (m, u) => {
    if (isRemote(u)) { stats.remote.push(u); return keepRemote ? m : `/* removed remote import ${u} */`; }
    return css(join(path, u), seen);
  });
  text = text.replace(/url\(\s*["']?([^"')]+)["']?\s*\)/g, (m, u) => {
    if (isRemote(u)) { if (!/^data:/i.test(u)) stats.remote.push(u); return m; }
    const d = dataUri(join(path, u)); return d ? `url(${d})` : m;
  });
  stats.css += text.length;
  return text;
}
const js = (path) => { const b = read(path); if (!b) return `console.error(${JSON.stringify('missing script ' + path)});`; stats.js += b.length; return b.toString('utf8').replace(/<\/script/gi, '<\\/script'); };
let html = readFileSync(resolve(deckDir, entry), 'utf8');
// reveal 3.x dependency loader -> inline scripts before the init script (order preserved, conditions ignored)
const deps = [];
html = html.replace(/dependencies\s*:\s*\[([\s\S]*?)\]\s*,?/, (m, body) => { for (const d of body.matchAll(/src\s*:\s*['"]([^'"]+)['"]/g)) deps.push(d[1]); return ''; });
html = html.replace(/<link\b[^>]*rel=["']?stylesheet["']?[^>]*>/gi, (tag) => {
  const href = (tag.match(/href=["']([^"']+)["']/i) || [])[1];
  if (!href) return tag; if (isRemote(href)) { stats.remote.push(href); return tag; }
  return `<style data-from="${href}">${css(clean(href)).replace(/<\/style/gi, '<\\/style')}</style>`;
});
let injectedDeps = false;
html = html.replace(/<script\b([^>]*)\bsrc=["']([^"']+)["']([^>]*)>\s*<\/script>/gi, (tag, a, src, b) => {
  if (isRemote(src)) { stats.remote.push(src); return tag; }
  const isModule = /type=["']module["']/i.test(a + b);
  return `<script${isModule ? ' type="module"' : ''} data-from="${src}">${js(clean(src))}</script>`;
});
if (deps.length) {
  // put dependency scripts right before the script that calls Reveal.initialize
  // the deck's own init script is the last inline script without a data-from marker that mentions Reveal.initialize
  let at = -1; for (const m of html.matchAll(/<script(?![^>]*data-from)[^>]*>(?:(?!<\/script>)[\s\S])*?Reveal\.initialize/gi)) at = m.index;
  const block = deps.map((d) => isRemote(d) ? (stats.remote.push(d), `<script src="${d}"></script>`) : `<script data-from="${d}">${js(clean(d))}</script>`).join('\n');
  html = html.slice(0, at) + block + '\n' + html.slice(at);
}
// external markdown -> inline textarea template
html = html.replace(/<section\b([^>]*)\bdata-markdown=["']([^"']+)["']([^>]*)>\s*<\/section>/gi, (tag, a, src, b) => {
  if (isRemote(src)) { stats.remote.push(src); return tag; }
  const md = read(clean(src)); if (!md) return tag;
  return `<section${a} data-markdown${b}><textarea data-template>\n${md.toString('utf8').replace(/<\/textarea/gi, '&lt;/textarea')}\n</textarea></section>`;
});
// attribute URLs
html = html.replace(/\b(src|data-src|poster|data-background-image|data-background-video|data-preview-image|data-preview-video)=(["'])([^"']+)\2/gi, (m, name, q, value) => {
  if (/^<script/i.test(m)) return m;
  const parts = value.split(',').map((v) => v.trim());
  if (parts.some(isRemote)) { for (const p of parts) if (isRemote(p) && !/^data:/i.test(p)) stats.remote.push(p); return m; }
  const mapped = parts.map((p) => dataUri(clean(p)));
  return mapped.every(Boolean) ? `${name}=${q}${mapped.join(name === 'data-background-video' ? ',' : ', ')}${q}` : m;
});
// markdown image syntax inside the page: ![alt](relative)
html = html.replace(/(!\[[^\]]*\]\()([^)\s]+)(\))/g, (m, a, u, c) => { if (isRemote(u)) return m; const d = dataUri(clean(u)); return d ? a + d + c : m; });
writeFileSync(out, html);
console.log(JSON.stringify({ out, bytes: html.length, css: stats.css, js: stats.js, assetBytes: stats.assets, deps, missing: [...new Set(stats.missing)], remote: [...new Set(stats.remote)] }));
