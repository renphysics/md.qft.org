// Reveal.js ZIPs served by a service worker on a separate player origin. Usage: node probe-vfs.mjs <siteUrl> <out.json>
import { createRequire } from 'node:module';
import { writeFileSync } from 'node:fs';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const [siteUrl, outFile] = process.argv.slice(2);
const browser = await chromium.launch();
const rows = [];
async function run(name, opts, body) {
  const context = await browser.newContext({ viewport: { width: 1400, height: 800 } });
  const page = await context.newPage(); const errs = [], bad = [];
  context.on('weberror', (e) => errs.push(String(e.error().message).slice(0, 130)));
  page.on('console', (m) => { if (m.type() === 'error') errs.push('[console] ' + m.text().slice(0, 150)); });
  context.on('response', (r) => { if (r.status() >= 400) bad.push(r.status() + ' ' + r.url().replace(/^.*\/vfs\/[^/]+\//, '').slice(0, 70)); });
  await page.goto(siteUrl); await page.waitForFunction(() => typeof window.openZip === 'function');
  const open = await page.evaluate((o) => window.openZip(o), opts);
  await page.waitForTimeout(opts.settle ?? 2500);
  const frame = page.frames().find((f) => f.url().includes('/vfs/'));
  const probe = () => { const R = window.Reveal || window.__deck; const q = (s) => document.querySelector(s); return { origin: self.origin, controlled: !!navigator.serviceWorker.controller, version: R && R.VERSION, ready: !!(R && R.isReady && R.isReady()), readyClass: !!q('.reveal.ready'), total: R && R.getTotalSlides && R.getTotalSlides(), hash: location.hash, search: location.search.slice(0, 30), md: !!q('.slides h2, .slides h1'), hljs: !!q('code.hljs'), katex: document.querySelectorAll('.katex').length, menuBtn: !!q('.slide-menu-button'), copyBtn: document.querySelectorAll('.codeblock button, button[class*="copy"]').length, pdfPages: document.querySelectorAll('.pdf-page').length, imgs: [...document.querySelectorAll('.slides img')].map((i) => i.naturalWidth).join(',') }; };
  const row = { name, open: { files: open.files, zipBytes: open.zipBytes, unzipMs: open.unzipMs, storeMs: open.storeMs, loadMs: open.loadMs }, state: frame ? await frame.evaluate(probe).catch((e) => ({ evalError: e.message.slice(0, 100) })) : 'no frame' };
  try { if (body) Object.assign(row, await body({ page, frame, context })); } catch (e) { row.threw = String(e.message).split('\n')[0].slice(0, 200); }
  row.errors = [...new Set(errs)].slice(0, 5); row.bad = [...new Set(bad)].slice(0, 6);
  rows.push(row); console.log(JSON.stringify(row));
  await context.close();
}
await run('classic6', { zip: 'zips/classic6.zip' }, async ({ page, frame, context }) => {
  // deep link by hash + postMessage API straight from the site page (cross-origin frame)
  await page.evaluate(() => { window.__messages.length = 0; window.send({ method: 'configure', args: [{ postMessageEvents: true }] }); window.send({ method: 'slide', args: [3] }); window.send({ method: 'getSlideNotes' }); window.send({ method: 'getState' }); });
  await page.waitForTimeout(1300);
  const msgs = await page.evaluate(() => window.__messages.filter((m) => m && m.namespace === 'reveal').map((m) => m.eventName + (m.method ? ':' + m.method : '')));
  const hash = await frame.evaluate(() => location.hash);
  // speaker view
  await page.mouse.click(640, 360);
  const popupPromise = context.waitForEvent('page', { timeout: 5000 }).catch(() => null);
  await page.keyboard.press('s'); const popup = await popupPromise; await page.waitForTimeout(6000);
  const speaker = popup ? await popup.evaluate(() => ({ origin: location.origin, statusDisplay: (document.querySelector('#connection-status') || { style: {} }).style.display, iframes: [...document.querySelectorAll('iframe')].map((f) => { try { return f.contentWindow.location.pathname.replace(/^\/vfs\/[^/]+/, '') + ' ready=' + f.contentWindow.Reveal.isReady(); } catch (e) { return 'blocked ' + e.name; } }), notes: ((document.querySelector('.speaker-controls-notes .value') || {}).innerText || '').slice(0, 40) })).catch((e) => 'eval failed ' + e.message.slice(0, 80)) : null;
  await page.bringToFront(); await page.keyboard.press('f'); await page.waitForTimeout(500);
  const fs = await frame.evaluate(() => !!document.fullscreenElement);
  return { postMessage: msgs.slice(0, 12), hashAfterSlide3: hash, speakerPopup: !!popup, speaker, fullscreenByF: fs };
});
await run('classic6 ?print-pdf', { zip: 'zips/classic6.zip', query: '?print-pdf' });
await run('classic6 #/3 (first slide without id irrelevant)', { zip: 'zips/classic6.zip', hash: '#/3' });
await run('classic5', { zip: 'zips/classic5.zip' });
await run('classic4 ?print-pdf', { zip: 'zips/classic4.zip', query: '?print-pdf' });
await run('classic3', { zip: 'zips/classic3.zip' }, async ({ page, context }) => { await page.mouse.click(640, 360); const pp = context.waitForEvent('page', { timeout: 5000 }).catch(() => null); await page.keyboard.press('s'); const popup = await pp; await page.waitForTimeout(4000); return { speakerPopup: !!popup, speakerUrl: popup ? popup.url().replace(/^.*\/vfs\/[^/]+/, '') : null }; });
await run('extmd6 (external markdown)', { zip: 'zips/extmd6.zip' });
await run('esm6 (ES modules)', { zip: 'zips/esm6.zip' });
await run('plugins6/menu.html', { zip: 'zips/plugins6.zip', entry: 'menu.html' });
await run('plugins6/chalkboard.html', { zip: 'zips/plugins6.zip', entry: 'chalkboard.html' }, async ({ frame }) => ({ chalkImgs: await frame.evaluate(() => performance.getEntriesByType('resource').filter((r) => /chalkboard\/img/.test(r.name)).length) }));
await run('plugins6/copycode.html', { zip: 'zips/plugins6.zip', entry: 'copycode.html' });
await run('plugins6/mermaid.html', { zip: 'zips/plugins6.zip', entry: 'mermaid.html' }, async ({ frame }) => ({ mermaidSvg: await frame.evaluate(() => !!document.querySelector('.mermaid svg')) }));
await run('plugins6/math-katex-default.html (CDN blocked by CSP)', { zip: 'zips/plugins6.zip', entry: 'math-katex-default.html' });
await run('corpus-n1 (AI deck, local KaTeX via math plugin)', { zip: 'zips/corpus-n1.zip' }, async ({ frame }) => ({ canvases: await frame.evaluate(() => document.querySelectorAll('canvas').length) }));
await run('reveal repo-style zip (nested folder)', { zip: 'zips/reveal-repo-style-6.0.2.zip', entry: 'reveal.js-master/demo.html' });
await run('classic6 opaque sandbox (no allow-same-origin)', { zip: 'zips/classic6.zip', sandbox: 'allow-scripts' });
await browser.close();
writeFileSync(outFile, JSON.stringify(rows, null, 2));
