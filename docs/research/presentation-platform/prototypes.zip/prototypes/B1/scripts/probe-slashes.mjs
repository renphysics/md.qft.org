import { createRequire } from 'node:module';
import { createServer } from 'node:http';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const seen = [];
const server = createServer((req, res) => { seen.push(req.url); res.writeHead(200, { 'content-type': 'text/css', 'access-control-allow-origin': '*' }).end('/* ok */'); }).listen(4503, '127.0.0.1');
const browser = await chromium.launch();
const page = await (await browser.newContext()).newPage();
await page.goto('http://127.0.0.1:4503/start');
await page.evaluate(async () => { await fetch('http://127.0.0.1:4503/pkg@^4//dist/reveal.css'); });
console.log('Chromium sent to local server:', JSON.stringify(seen));
// what does the public network path do to the same shape of URL when it comes from Chromium?
for (const u of ['https://unpkg.com/reveal.js@^4//dist/theme/sky.css', 'https://unpkg.com/reveal.js@4.6.1//dist/theme/sky.css', 'https://cdn.jsdelivr.net/npm/reveal.js@4.6.1//dist/theme/sky.css']) {
  const chain = []; const on = (r) => { if (r.url().includes('sky.css')) chain.push(r.status() + ' ' + r.url().replace('https://', '') + (r.headers()['location'] ? ' -> ' + r.headers()['location'] : '')); };
  page.on('response', on);
  await page.evaluate((u) => new Promise((resolve) => { const l = document.createElement('link'); l.rel = 'stylesheet'; l.href = u; l.onload = l.onerror = () => resolve(); document.head.appendChild(l); }), u);
  await page.waitForTimeout(500); page.off('response', on);
  console.log('Chromium:', JSON.stringify(chain));
}
await browser.close(); server.close();
