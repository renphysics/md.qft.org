// Runs reveal.js decks through the site's real player chain (createPresentationPlayer -> runner -> blob child, strict CSP + error bootstrap).
// Usage: node probe-site-chain.mjs <hostUrl> <out.json>
import { createRequire } from 'node:module';
import { writeFileSync } from 'node:fs';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const [hostUrl, outFile] = process.argv.slice(2);
const browser = await chromium.launch();
const results = {};
async function session(name, opts, body) {
  const context = await browser.newContext({ viewport: { width: 1400, height: 800 } });
  const page = await context.newPage();
  const log = { pageErrors: [], console: [] };
  page.on('pageerror', (e) => log.pageErrors.push(String(e.message || e).slice(0, 260)));
  page.on('console', (m) => { if (['error', 'warning'].includes(m.type())) log.console.push(`[${m.type()}] ${m.text()}`.slice(0, 260)); });
  await page.goto(hostUrl);
  await page.waitForFunction(() => typeof window.mount === 'function');
  await page.evaluate((o) => window.mount(o), opts);
  await page.waitForFunction(() => window.__states.some((x) => x.s === 'ready' || x.s === 'error'), null, { timeout: 25000 }).catch(() => {});
  await page.waitForTimeout(opts.settle ?? 1200);
  const host = async () => page.evaluate(() => ({ states: window.__states.map((x) => x.s + '@' + Math.round(x.t - window.__t0)), errors: window.__errors.slice(), running: window.__player.isRunning() }));
  const frame = () => page.frames().find((f) => f.url().startsWith('blob:'));
  const out = { deck: opts.deck, host: await host(), frameUrl: frame() ? frame().url().slice(0, 18) : null };
  try { if (body) Object.assign(out, await body({ page, frame, log, host })); } catch (e) { out.threw = String(e.message).split('\n')[0].slice(0, 300); }
  out.pageErrors = [...new Set(log.pageErrors)]; out.console = [...new Set(log.console)];
  results[name] = out;
  console.log('\n## ' + name + '\n' + JSON.stringify(out));
  await context.close();
}
const info = () => { const R = window.Reveal; return { ready: R.isReady(), version: R.VERSION, windowOrigin: self.origin, locationOrigin: location.origin, pathname: location.pathname.slice(0, 12), readyClass: !!document.querySelector('.reveal.ready'), noTransition: !!document.querySelector('.slides.no-transition'), total: R.getTotalSlides(), md: !!document.querySelector('#md h2'), hljs: !!document.querySelector('code.hljs'), font: getComputedStyle(document.querySelector('.reveal')).fontFamily.slice(0, 40), imgs: [...document.querySelectorAll('.slides img')].map((i) => i.naturalWidth).join(',') }; };
const noId = [['<section id="title">', '<section>']];
const historyShim = `<script>(function(){for(const m of ['replaceState','pushState']){const o=History.prototype[m];History.prototype[m]=function(s,t,u){try{return o.call(this,s,t,u)}catch(e){try{if(typeof u==='string'&&u.includes('#'))return o.call(this,s,t,u.slice(u.indexOf('#')))}catch(_){}}}}})();</script>`;

for (const d of ['classic6', 'classic5', 'classic4', 'classic3']) {
  await session('S1-' + d + '-as-is', { deck: 'single/' + d + '.html' }, async ({ frame }) => frame() ? { info: await frame().evaluate(info) } : {});
}
await session('S2-classic6-first-slide-without-id', { deck: 'single/classic6.html', transforms: noId }, async ({ frame }) => frame() ? { info: await frame().evaluate(info) } : {});
await session('S2b-classic6-noid-hash-false', { deck: 'single/classic6.html', transforms: [...noId, ['hash: true', 'hash: false']] }, async ({ frame, page, host }) => {
  const a = await frame().evaluate(info);
  await frame().evaluate(() => { Reveal.slide(3); }); await page.waitForTimeout(300);
  await frame().evaluate(() => { Reveal.slide(0); }); await page.waitForTimeout(1300);
  return { info: a, after: await host() };
});
await session('S2c-classic6-noid-with-history-shim', { deck: 'single/classic6.html', transforms: noId, inject: historyShim }, async ({ frame, page, host }) => {
  const a = await frame().evaluate(info);
  await frame().evaluate(() => { Reveal.slide(3); }); await page.waitForTimeout(1300);
  const h = await frame().evaluate(() => location.hash);
  await frame().evaluate(() => { Reveal.slide(0, 0, -1); }); await page.waitForTimeout(1300);
  return { info: a, hashAfter3: h, hashAfter0: await frame().evaluate(() => location.hash), after: await host() };
});
await session('S3-classic6-history-true', { deck: 'single/classic6.html', transforms: [...noId, ['hash: true', 'history: true']] }, async ({ frame, page, host }) => {
  if (!frame()) return {};
  const a = await frame().evaluate(info);
  await frame().evaluate(() => { Reveal.slide(3); }); await page.waitForTimeout(500);
  return { info: a, hash: frame() ? await frame().evaluate(() => location.hash).catch(() => 'gone') : 'gone', after: await host() };
});
await session('S4-press-F', { deck: 'single/classic6.html' }, async ({ frame, page, host }) => {
  await page.mouse.click(640, 360); await page.keyboard.press('ArrowRight'); await page.waitForTimeout(200);
  const idx = await frame().evaluate(() => Reveal.getIndices());
  await page.keyboard.press('f'); await page.waitForTimeout(800);
  return { idxAfterRight: idx, after: await host(), frameStillThere: !!frame() };
});
await session('S5-press-S', { deck: 'single/classic6.html' }, async ({ frame, page, host }) => {
  await page.mouse.click(640, 360); await page.keyboard.press('s'); await page.waitForTimeout(800);
  return { after: await host(), frameStillThere: !!frame() };
});
await session('S6-press-Esc-and-O', { deck: 'single/classic6.html' }, async ({ frame, page, host }) => {
  await page.mouse.click(640, 360); await page.keyboard.press('Escape'); await page.waitForTimeout(400);
  const ov = await frame().evaluate(() => Reveal.isOverview());
  return { overviewAfterEsc: ov, escapes: await page.evaluate(() => window.__escapes), after: await host() };
});
await session('S7-narrow-400px-scroll-view', { deck: 'single/classic6.html', width: 400, height: 700 }, async ({ frame, page, host }) => {
  const a = await frame().evaluate(() => ({ isScroll: Reveal.isScrollView(), w: innerWidth }));
  await page.mouse.move(200, 300); await page.mouse.wheel(0, 1500); await page.waitForTimeout(700);
  return { ...a, after: await host() };
});
await session('S8-internal-and-external-links', { deck: 'single/classic6.html', transforms: [['<h2>Last</h2>', '<h2>Last</h2><a id="ilink" href="#/code">internal</a> <a id="xlink" href="https://example.com/">external</a>']] }, async ({ frame, page, host }) => {
  await frame().evaluate(() => Reveal.slide(Reveal.getHorizontalSlides().length - 1)); await page.waitForTimeout(400);
  await frame().evaluate(() => document.querySelector('#ilink').click()); await page.waitForTimeout(600);
  const a = await frame().evaluate(() => ({ idx: Reveal.getIndices(), hash: location.hash }));
  await frame().evaluate(() => Reveal.slide(Reveal.getHorizontalSlides().length - 1)); await page.waitForTimeout(300);
  await frame().evaluate(() => document.querySelector('#xlink').click()); await page.waitForTimeout(800);
  return { afterInternal: a, afterExternal: await host(), frameUrl2: frame() ? frame().url().slice(0, 12) : null };
});
await session('S9-postMessage-api-through-runner', { deck: 'single/classic6.html' }, async ({ frame, page, host }) => {
  // The host can only reach the runner window; reveal's own listener lives two frames down.
  await page.evaluate(() => { const f = document.querySelector('#stage iframe'); f.contentWindow.postMessage(JSON.stringify({ method: 'slide', args: [3] }), '*'); });
  await page.waitForTimeout(400);
  const idx = await frame().evaluate(() => Reveal.getIndices());
  // enable events inside and see whether anything reaches the top page
  await frame().evaluate(() => { Reveal.configure({ postMessageEvents: true }); Reveal.next(); });
  await page.waitForTimeout(400);
  return { idxAfterHostPostMessage: idx, topLevelRevealMessages: await page.evaluate(() => window.__messages.filter((m) => typeof m === 'string' && m.includes('"reveal"')).length), after: await host() };
});
await session('S10-google-font-theme', { deck: 'single/classic6-league.html' }, async ({ frame }) => frame() ? { info: await frame().evaluate(info) } : {});
await session('S11-extmd6-inlined', { deck: 'single/extmd6.html' }, async ({ frame }) => frame() ? { info: await frame().evaluate(info), h1: await frame().evaluate(() => (document.querySelector('.slides h1') || {}).textContent) } : {});
await session('S12-unprocessed-folder-index', { deck: 'decks/classic6/index.html' }, null);
await session('S13-cdn-deck', { deck: 'decks/cdn/jsdelivr-pinned-5.2.1.html' }, null);
await session('S14-lightbox-and-preview-link', { deck: 'single/classic6.html', transforms: [['<img id="img-plain" ', '<img id="img-plain" data-preview-image '], ['<h2>Last</h2>', '<h2>Last</h2><a id="plink" href="https://example.com/" data-preview-link>preview</a>']] }, async ({ frame, page, host }) => {
  await frame().evaluate(() => Reveal.slide(1, 0)); await page.waitForTimeout(400);
  await frame().evaluate(() => document.querySelector('#img-plain').click()); await page.waitForTimeout(500);
  const overlay = await frame().evaluate(() => (document.querySelector('.r-overlay') || {}).className);
  await page.keyboard.press('Escape'); const mid = await host();
  await frame().evaluate(() => Reveal.slide(Reveal.getHorizontalSlides().length - 1)); await page.waitForTimeout(300);
  await frame().evaluate(() => document.querySelector('#plink').click()).catch(() => {}); await page.waitForTimeout(900);
  return { overlay, mid, afterPreviewLink: await host() };
});
await browser.close();
writeFileSync(outFile, JSON.stringify(results, null, 2));
