// Speaker view from file:// vs http:// for several majors. Usage: node probe-speaker.mjs <decksDir> <httpBase>
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const [decksDir, httpBase] = process.argv.slice(2);
const browser = await chromium.launch();
for (const d of ['classic3', 'classic5', 'classic6']) for (const proto of ['file', 'http']) {
  const context = await browser.newContext({ viewport: { width: 1280, height: 720 } });
  const page = await context.newPage(); const errs = [];
  page.on('pageerror', (e) => errs.push(String(e.message).slice(0, 120)));
  const url = proto === 'file' ? pathToFileURL(resolve(decksDir, d, 'index.html')).href : `${httpBase}/decks/${d}/index.html`;
  await page.goto(url, { waitUntil: 'load' }); await page.waitForTimeout(800);
  await page.mouse.click(600, 300);
  const popupPromise = context.waitForEvent('page', { timeout: 5000 }).catch(() => null);
  await page.keyboard.press('s');
  const popup = await popupPromise; await page.waitForTimeout(7000);
  let info = null;
  if (popup) {
    popup.on('pageerror', (e) => errs.push('popup: ' + String(e.message).slice(0, 120)));
    info = await popup.evaluate(() => ({ url: location.href.slice(0, 60), origin: location.origin, status: (document.querySelector('#connection-status') || {}).innerText || null, statusDisplay: (document.querySelector('#connection-status') || { style: {} }).style.display, iframes: [...document.querySelectorAll('iframe')].map((f) => (f.getAttribute('src') || '').replace(/^.*\/decks\//, '…/decks/').slice(0, 90)), notes: ((document.querySelector('.speaker-controls-notes .value') || {}).innerText || '').slice(0, 50) })).catch((e) => 'eval failed: ' + e.message.split('\n')[0].slice(0, 100));
    await page.bringToFront(); await page.keyboard.press('ArrowRight'); await page.keyboard.press('ArrowRight'); await page.keyboard.press('ArrowRight'); await page.waitForTimeout(1500);
    const sync = await popup.evaluate(() => { const f = document.querySelector('#current-slide iframe'); let hash = null; try { hash = f.contentWindow.location.hash; } catch (e) { hash = 'blocked: ' + e.name; } return { hash, notes: ((document.querySelector('.speaker-controls-notes .value') || {}).innerText || '').slice(0, 50) }; }).catch((e) => 'eval failed');
    info = { ...info, afterNav: sync, mainIdx: await page.evaluate(() => Reveal.getIndices()) };
  }
  console.log(`${d} [${proto}] popup=${!!popup} ${JSON.stringify(info)} errs=${JSON.stringify([...new Set(errs)])}`);
  await context.close();
}
await browser.close();
