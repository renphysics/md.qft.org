// Runs www/detect-reveal.js in Chromium against sample folders/files. Usage: node test-detect.mjs <detector.js> <out.json> name=path ...
import { createRequire } from 'node:module';
import { readdirSync, statSync, readFileSync, writeFileSync } from 'node:fs';
import { join, relative, basename } from 'node:path';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const [detector, outFile, ...samples] = process.argv.slice(2);
const walk = (root, dir = root, out = []) => { for (const n of readdirSync(dir)) { const p = join(dir, n); const s = statSync(p); if (s.isDirectory()) { if (n === '_scratch' || n === '.build') continue; walk(root, p, out); } else out.push({ full: p, path: relative(root, p).split('\\').join('/'), size: s.size }); } return out; };
const wantText = (f) => (/\.html?$/i.test(f.path) && f.size < 6e6) || /(?:^|\/)package\.json$/.test(f.path) || (/(?:^|\/)reveal(?:\.min|\.esm)?(?:\.min)?\.m?js$/i.test(f.path) && f.size < 2e6);
const browser = await chromium.launch(); const page = await browser.newPage(); await page.setContent('<!doctype html><title>t</title>'); await page.addScriptTag({ path: detector });
const results = {};
for (const s of samples) {
  const [name, path] = s.split('=');
  const list = statSync(path).isDirectory() ? walk(path) : [{ full: path, path: basename(path), size: statSync(path).size }];
  const files = list.map((f) => ({ path: f.path, size: f.size, ...(wantText(f) ? { text: readFileSync(f.full, 'utf8') } : {}) }));
  const t0 = Date.now();
  const r = await page.evaluate((files) => { const t = performance.now(); const r = window.detectRevealDeck(files); r.ms = +(performance.now() - t).toFixed(1); return r; }, files);
  results[name] = r;
  const top = (r.entries || []).slice(0, 3).map((e) => `${e.path}(${e.score})`).join(', ');
  console.log(`${name.padEnd(34)} files=${String(files.length).padStart(4)} ${r.kind.padEnd(10)} entry=${r.entry || '-'} v=${r.version ? r.version.exact + '/' + r.version.major : '-'} layout=${r.layout || '-'} runtime=${r.runtime || '-'} gen=${r.generator || '-'} ${r.ms}ms`);
  if (r.kind === 'reveal') console.log(`${' '.repeat(36)}plugins=[${r.features.plugins.join(',')}] deps=${r.features.dependenciesLoader} esm=${r.features.esm} amd=${r.features.amd} math=${r.features.math} extmd=[${r.features.externalMarkdown}] missing=${r.localRefs.missing.length} problems=[${r.problems.map((p) => p.code).filter((v, i, a) => a.indexOf(v) === i).join(', ')}]`);
  if ((r.entries || []).length > 1) console.log(`${' '.repeat(36)}candidates: ${top}`);
}
await browser.close(); writeFileSync(outFile, JSON.stringify(results, null, 1));
