// Measures live-edit refresh strategies for a reveal.js 6.0.2 deck in a sandboxed blob iframe.
// Usage: node measure-live.mjs <hostUrl> <out.json> [runs=12]
import { createRequire } from 'node:module';
import { writeFileSync } from 'node:fs';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const [hostUrl, outFile, runsArg] = process.argv.slice(2);
const runs = Number(runsArg || 12);
const browser = await chromium.launch();
const stats = (a) => { const s = [...a].sort((x, y) => x - y); const q = (p) => s[Math.min(s.length - 1, Math.floor(p * s.length))]; return { n: s.length, min: +s[0].toFixed(1), median: +q(0.5).toFixed(1), p90: +q(0.9).toFixed(1), max: +s[s.length - 1].toFixed(1) }; };
const results = {};
for (const [n, imgs] of [[20, 0], [200, 0], [20, 12]]) {
  const page = await (await browser.newContext({ viewport: { width: 1400, height: 800 } })).newPage();
  const errors = []; page.on('pageerror', (e) => errors.push(String(e.message).slice(0, 200)));
  page.on('console', (m) => { if (m.type() === 'error') errors.push('[console] ' + m.text().slice(0, 200)); });
  await page.goto(hostUrl); await page.evaluate(() => window.whenReady);
  const out = { slides: n, images: imgs };
  if (imgs) out.imageChars = await page.evaluate((k) => window.makeImages(k), imgs);
  // initial load
  const first = await page.evaluate((n) => window.reload(window.genSections(n)), n);
  out.initialLoad = { total: +first.total.toFixed(1), bytes: first.bytes, build: +first.build.toFixed(1) };
  // target position: a slide with fragments, in the second half, with 2 fragments shown
  const target = n === 20 ? 12 : 152;
  await page.evaluate((t) => { window.remote('slide', [t, 0, 1]); }, target); await page.waitForTimeout(400);
  const before = await page.evaluate(() => window.getState());
  out.positionBefore = before.state;
  const check = (r, label, i) => { if (r.error) throw new Error(label + ': ' + r.error); const s = r.state; const ok = s.indexh === before.state.indexh && s.indexv === before.state.indexv && s.indexf === before.state.indexf; return ok; };
  for (const [label, fn] of [
    ['A1 reload + restore via #hash', (i) => page.evaluate(async ([n, t, i]) => { const st = (await window.getState()).state; const r = await window.reload(window.genSections(n, { [t]: 'edit' + i }), { state: st }); const g = await window.getState(); return { ...r, state: g.state, text: g.text, slideCount: g.slideCount }; }, [n, target, i])],
    ['A2 reload buffered (no blank frame)', (i) => page.evaluate(async ([n, t, i]) => { const st = (await window.getState()).state; const r = await window.reload(window.genSections(n, { [t]: 'edit' + i }), { state: st, buffered: true }); const g = await window.getState(); return { ...r, state: g.state, text: g.text, slideCount: g.slideCount }; }, [n, target, i])],
    ['B1 full .slides swap + sync()', (i) => page.evaluate(([n, t, i]) => window.swapFull(window.genSections(n, { [t]: 'edit' + i })), [n, target, i])],
    ['B2 keyed section swap + sync()', (i) => page.evaluate(([n, t, i]) => window.swapKeyed(window.genSections(n, { [t]: 'edit' + i })), [n, target, i])],
    ['C  CSS-only swap + layout()', (i) => page.evaluate((i) => window.setCss(`.reveal h2{color:hsl(${i * 30},80%,60%)}`), i)],
  ]) {
    const totals = [], applied = [], inner = []; let okCount = 0; let sample;
    for (let i = 0; i < runs + 2; i++) {
      const r = await fn(i);
      const ok = check(r, label, i) && (label.startsWith('C') || (r.text || '').toLowerCase().includes('edit' + i));
      if (i >= 2) { totals.push(r.total); if (r.applied !== undefined) applied.push(r.applied); if (r.innerReadyMs !== undefined) inner.push(r.innerReadyMs); okCount += ok ? 1 : 0; }
      sample = { state: r.state, text: (r.text || '').replace(/\n/g, ' | ').slice(0, 40), slideCount: r.slideCount };
      await page.waitForTimeout(60);
    }
    out[label] = { hostRoundTripMs: stats(totals), ...(applied.length ? { domWorkMs: stats(applied) } : {}), ...(inner.length ? { frameStartToReadyMs: stats(inner) } : {}), positionAndTextPreserved: okCount + '/' + runs, sample };
    console.log(n + ' slides' + (imgs ? ' +' + imgs + ' images' : '') + ' | ' + label + ' | ' + JSON.stringify(out[label]));
  }
  // structural edits with the keyed strategy: insert a slide before the current one, delete it again
  await page.evaluate(([n]) => window.swapKeyed(window.genSections(n)), [n]);
  const ins = await page.evaluate(([n, t]) => { const s = window.genSections(n); s.splice(2, 0, '<section><h2>Inserted</h2></section>'); return window.swapKeyed(s); }, [n, target]);
  const del = await page.evaluate(([n, t]) => window.swapKeyed(window.genSections(n)), [n, target]);
  out.structural = { insertBeforeCurrent: { total: +ins.total.toFixed(1), state: ins.state, text: (ins.text || '').slice(0, 30), slideCount: ins.slideCount }, removeAgain: { total: +del.total.toFixed(1), state: del.state, text: (del.text || '').slice(0, 30), slideCount: del.slideCount } };
  console.log(n + ' slides | structural | ' + JSON.stringify(out.structural));
  out.errors = [...new Set(errors)];
  if (out.errors.length) console.log('errors: ' + JSON.stringify(out.errors));
  results['slides' + n + (imgs ? '+images' + imgs : '')] = out;
  await page.context().close();
}
await browser.close();
writeFileSync(outFile, JSON.stringify(results, null, 2));
