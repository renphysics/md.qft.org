// Third-party / math plugins: folder over http, inlined in a plain sandbox, and inlined in the site's chain (with compat shim).
// Usage: node probe-plugins.mjs <base> <out.json> <shimFile>
import { createRequire } from 'node:module';
import { writeFileSync, readFileSync } from 'node:fs';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const [base, outFile, shimFile] = process.argv.slice(2);
const shim = `<script>${readFileSync(shimFile, 'utf8')}</script>`;
const browser = await chromium.launch();
const rows = [];
const probe = () => { const R = window.Reveal; const q = (s) => document.querySelector(s); return { ready: !!(R && R.isReady && R.isReady()), readyClass: !!q('.reveal.ready'), plugins: R && R.getPlugins ? Object.keys(R.getPlugins()) : [], menuBtn: !!q('.slide-menu-button'), menuCss: q('.slide-menu-button') ? getComputedStyle(q('.slide-menu-button')).position : null, chalkBtns: document.querySelectorAll('#toggle-chalkboard, #toggle-notes, .chalkboard-button, [class*="chalkboard"]').length, mermaidSvg: !!q('.mermaid svg'), katex: document.querySelectorAll('.katex').length, mathjax: document.querySelectorAll('.MathJax, mjx-container').length, copyBtn: document.querySelectorAll('.codeblock button, button[class*="copy"], .code-copy-button').length }; };
for (const d of ['menu', 'chalkboard', 'mermaid', 'copycode', 'math-katex-default', 'math-mathjax-default']) {
  // 1. folder over http (the reference behaviour)
  { const page = await (await browser.newContext({ viewport: { width: 1300, height: 760 } })).newPage(); const errs = [], reqs = [];
    page.on('pageerror', (e) => errs.push(String(e.message).slice(0, 150))); page.on('requestfailed', (r) => errs.push('FAILED ' + r.url().slice(0, 110)));
    page.on('request', (r) => { const u = r.url(); if (!u.includes('/dist/') && !u.endsWith('.html') && !u.startsWith('data:')) reqs.push(u.replace(base, '').slice(0, 90)); });
    await page.goto(`${base}/decks/plugins6/${d}.html`, { waitUntil: 'load' }); await page.waitForTimeout(3500);
    rows.push({ deck: d, mode: 'folder-http', ...(await page.evaluate(probe)), extraRequests: [...new Set(reqs)].slice(0, 14), extraRequestCount: new Set(reqs).size, errors: [...new Set(errs)].slice(0, 5) }); await page.context().close(); }
  // 2. inlined, generic sandbox (network allowed, no CSP)
  { const page = await (await browser.newContext({ viewport: { width: 1400, height: 800 } })).newPage(); const errs = [], reqs = [];
    page.on('pageerror', (e) => errs.push(String(e.message).slice(0, 150))); page.on('requestfailed', (r) => errs.push('FAILED ' + r.url().slice(0, 110)));
    page.on('request', (r) => { const u = r.url(); if (!u.startsWith('data:') && !u.startsWith('blob:') && !u.startsWith(base)) reqs.push(u.slice(0, 90)); });
    await page.goto(`${base}/generic.html`); await page.evaluate((o) => window.mount(o), { deck: `single/p6-${d}.html`, inject: shim }); await page.waitForTimeout(3500);
    const frame = page.frames().find((f) => f !== page.mainFrame());
    rows.push({ deck: d, mode: 'inlined-sandbox-network', ...(await frame.evaluate(probe).catch((e) => ({ evalError: e.message.slice(0, 100) }))), extraRequests: [...new Set(reqs)].slice(0, 8), extraRequestCount: new Set(reqs).size, errors: [...new Set(errs)].slice(0, 5) }); await page.context().close(); }
  // 3. inlined, the site's chain (CSP: no network, no eval) + compat shim
  { const page = await (await browser.newContext({ viewport: { width: 1400, height: 800 } })).newPage(); const errs = [];
    page.on('pageerror', (e) => errs.push(String(e.message).slice(0, 150))); page.on('console', (m) => { if (m.type() === 'error') errs.push('[console] ' + m.text().slice(0, 170)); });
    await page.goto(`${base}/site.html`); await page.waitForFunction(() => typeof window.mount === 'function');
    await page.evaluate((o) => window.mount(o), { deck: `single/p6-${d}.html`, inject: shim });
    await page.waitForFunction(() => window.__states.some((x) => x.s === 'ready' || x.s === 'error'), null, { timeout: 25000 }).catch(() => {}); await page.waitForTimeout(3000);
    const host = await page.evaluate(() => ({ states: window.__states.map((x) => x.s).join('>'), errors: window.__errors.map((e) => e.slice(0, 160)) }));
    const frame = page.frames().find((f) => f.url().startsWith('blob:'));
    rows.push({ deck: d, mode: 'inlined-site-chain', host, ...(frame ? await frame.evaluate(probe).catch((e) => ({ evalError: e.message.slice(0, 100) })) : {}), errors: [...new Set(errs)].slice(0, 4) }); await page.context().close(); }
}
await browser.close();
writeFileSync(outFile, JSON.stringify(rows, null, 2));
for (const r of rows) console.log(JSON.stringify(r).slice(0, 1100));
