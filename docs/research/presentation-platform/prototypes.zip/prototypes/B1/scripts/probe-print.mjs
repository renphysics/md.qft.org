import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const browser = await chromium.launch();
for (const sandbox of ['allow-scripts', 'allow-scripts allow-modals']) {
  const page = await (await browser.newContext({ viewport: { width: 1400, height: 800 } })).newPage();
  const msgs = []; page.on('console', (m) => msgs.push(`[${m.type()}] ${m.text()}`.slice(0, 160))); page.on('pageerror', (e) => msgs.push('pageerror ' + e.message.slice(0, 120)));
  await page.goto(process.argv[2]);
  await page.evaluate((o) => window.mount(o), { deck: 'single/classic6.html', sandbox, transforms: [['hash: true', "hash: false, view: 'print'"]] });
  await page.waitForTimeout(1500);
  const frame = page.frames().find((f) => f !== page.mainFrame());
  const r = await frame.evaluate(() => { let printed = 'no-event'; window.addEventListener('beforeprint', () => { printed = 'beforeprint fired'; }); try { window.print(); } catch (e) { return 'threw ' + e.message; } return { printed, pages: document.querySelectorAll('.pdf-page').length, alert: (() => { try { return typeof window.alert; } catch (e) { return e.message; } })() }; });
  await page.waitForTimeout(500);
  console.log(JSON.stringify({ sandbox, r, msgs }));
  await page.context().close();
}
await browser.close();
