import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const browser = await chromium.launch();
for (const u of process.argv.slice(2)) {
  const page = await (await browser.newContext()).newPage(); const errs = [], bad = [];
  page.on('pageerror', (e) => errs.push(String(e.message).slice(0, 100)));
  page.on('response', (r) => { if (r.status() >= 400) bad.push(r.status() + ' ' + r.url().slice(0, 70)); });
  await page.goto(u, { waitUntil: 'load' }).catch(() => {}); await page.waitForTimeout(2500);
  const s = await page.evaluate(() => ({ reveal: typeof window.Reveal, ready: !!(window.Reveal && Reveal.isReady && Reveal.isReady()), sections: document.querySelectorAll('.slides section').length }));
  console.log(u.split('/').pop(), JSON.stringify(s), 'errs=' + JSON.stringify([...new Set(errs)]), 'bad=' + JSON.stringify([...new Set(bad)].slice(0, 4)));
  await page.context().close();
}
await browser.close();
