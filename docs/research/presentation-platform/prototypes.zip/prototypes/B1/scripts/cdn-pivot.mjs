import { readFileSync } from 'node:fs';
const rows = readFileSync(process.argv[2], 'utf8').trim().split('\n').map(l => l.split('\t'));
for (const cdn of ['jsdelivr', 'unpkg', 'cdnjs']) {
  const sel = rows.filter(r => r[0] === cdn);
  const vers = [...new Set(sel.map(r => r[1]))];
  const order = ['3.6.0','3.9.2','3','4.6.1','4','5.2.1','5','6.0.2','6','latest','(none)'].filter(v => vers.includes(v));
  const paths = [...new Set(sel.map(r => r[2]))];
  console.log(`\n### ${cdn}\n`);
  console.log('| path | ' + order.join(' | ') + ' |');
  console.log('|---|' + order.map(() => '---').join('|') + '|');
  for (const p of paths) {
    const cells = order.map(v => { const r = sel.find(x => x[1] === v && x[2] === p); return r ? (r[3] === '200' ? 'OK' : r[3]) : '?'; });
    console.log(`| ${p} | ${cells.join(' | ')} |`);
  }
}
