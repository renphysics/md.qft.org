// Generates test decks under ../decks from the npm tarballs in ../pkgs. Usage: node make-decks.mjs
import { cpSync, mkdirSync, writeFileSync, rmSync, existsSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
const here = dirname(fileURLToPath(import.meta.url));
const pkgs = resolve(here, '../pkgs');
const decks = resolve(here, '../decks');
rmSync(decks, { recursive: true, force: true });
mkdirSync(decks, { recursive: true });
const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAIAAAAlC+aJAAAAT0lEQVR4nO3PQQ0AIAzAwPlXhgQk8EHFYUKTJvfv7Mz5WgNoAGuABrAGaABrgAawBmgAa4AGsAZoAGuABrAGaABrgAawBmgAa4AGsB55rWZC0Tq4/gAAAABJRU5ErkJggg==', 'base64');
const slides = (extra = '') => `
        <section id="title"><h1>Deck title</h1><p>Intro <span class="fragment">frag A</span> <span class="fragment">frag B</span></p>
          <aside class="notes">Speaker note for title slide.</aside></section>
        <section>
          <section id="v1"><h2>Vertical 1</h2><img id="img-plain" src="assets/pic.png" alt="plain"></section>
          <section id="v2"><h2>Vertical 2</h2><img id="img-lazy" data-src="assets/pic.png" alt="lazy"></section>
        </section>
        <section id="md" data-markdown><textarea data-template>
## Markdown slide

- item one
- item two <!-- .element: class="fragment" -->

![md image](assets/pic.png)

\`\`\`js [1|2]
const a = 1;
console.log(a);
\`\`\`

Note: markdown speaker note
        </textarea></section>
        <section id="code"><h2>Code</h2><pre><code class="language-js" data-trim data-line-numbers="1|2">
let x = 1;
x += 1;
        </code></pre></section>
        <section id="bg" data-background-image="assets/pic.png"><h2>Background image</h2></section>
        <section id="aa1" data-auto-animate><h2 data-id="t" style="margin-top:0">Auto</h2></section>
        <section id="aa2" data-auto-animate><h2 data-id="t" style="margin-top:200px">Auto</h2></section>
${extra}
        <section id="last"><h2>Last</h2></section>`;
const page = (head, body) => `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>Test deck</title>
${head}
</head><body>
<div class="reveal"><div class="slides">${body}
</div></div>
`;
function deck(name, files) {
  for (const [path, content] of Object.entries(files)) {
    const full = resolve(decks, name, path);
    mkdirSync(dirname(full), { recursive: true });
    writeFileSync(full, content);
  }
}
const copy = (from, name, to) => cpSync(resolve(pkgs, from), resolve(decks, name, to), { recursive: true });

// 1. canonical 6.x layout, UMD
const head6 = `<link rel="stylesheet" href="dist/reset.css"><link rel="stylesheet" href="dist/reveal.css"><link rel="stylesheet" href="dist/theme/black.css"><link rel="stylesheet" href="dist/plugin/highlight/monokai.css">`;
const init = (plugins, opts = 'hash: true') => `<script>Reveal.initialize({ ${opts}, plugins: [ ${plugins} ] });</script></body></html>`;
deck('classic6', { 'index.html': page(head6, slides()) + `<script src="dist/reveal.js"></script><script src="dist/plugin/notes.js"></script><script src="dist/plugin/markdown.js"></script><script src="dist/plugin/highlight.js"></script><script src="dist/plugin/zoom.js"></script><script src="dist/plugin/search.js"></script>\n` + init('RevealMarkdown, RevealHighlight, RevealNotes, RevealZoom, RevealSearch'), 'assets/pic.png': png });
copy('v6.0.2/package/dist', 'classic6', 'dist');

// 2. external markdown (6.x)
deck('extmd6', { 'index.html': page(head6, `
        <section data-markdown="slides.md" data-separator="^\\r?\\n---\\r?\\n$" data-separator-vertical="^\\r?\\n--\\r?\\n$" data-separator-notes="^Note:"></section>`) + `<script src="dist/reveal.js"></script><script src="dist/plugin/markdown.js"></script><script src="dist/plugin/highlight.js"></script><script src="dist/plugin/notes.js"></script>\n` + init('RevealMarkdown, RevealHighlight, RevealNotes'),
  'slides.md': `# External markdown\n\nfirst slide\n\nNote: external note\n\n---\n\n## Second\n\n![img](assets/pic.png)\n\n--\n\n## Second, vertical\n\n---\n\n## Third\n\n\`\`\`js\nconsole.log(1)\n\`\`\`\n`, 'assets/pic.png': png });
copy('v6.0.2/package/dist', 'extmd6', 'dist');

// 3. ES modules (6.x)
deck('esm6', { 'index.html': page(head6, slides()) + `<script type="module">
import Reveal from './dist/reveal.mjs';
import RevealMarkdown from './dist/plugin/markdown.mjs';
import RevealHighlight from './dist/plugin/highlight.mjs';
import RevealNotes from './dist/plugin/notes.mjs';
const deck = new Reveal({ hash: true, plugins: [ RevealMarkdown, RevealHighlight, RevealNotes ] });
deck.initialize();
window.__deck = deck;
</script></body></html>`, 'assets/pic.png': png });
copy('v6.0.2/package/dist', 'esm6', 'dist');

// 4. canonical 4.x/5.x layout (5.2.1)
const head5 = `<link rel="stylesheet" href="dist/reset.css"><link rel="stylesheet" href="dist/reveal.css"><link rel="stylesheet" href="dist/theme/black.css"><link rel="stylesheet" href="plugin/highlight/monokai.css">`;
deck('classic5', { 'index.html': page(head5, slides()) + `<script src="dist/reveal.js"></script><script src="plugin/notes/notes.js"></script><script src="plugin/markdown/markdown.js"></script><script src="plugin/highlight/highlight.js"></script>\n` + init('RevealMarkdown, RevealHighlight, RevealNotes'), 'assets/pic.png': png });
copy('v5.2.1/package/dist', 'classic5', 'dist'); copy('v5.2.1/package/plugin', 'classic5', 'plugin');
deck('classic4', { 'index.html': page(head5, slides()) + `<script src="dist/reveal.js"></script><script src="plugin/notes/notes.js"></script><script src="plugin/markdown/markdown.js"></script><script src="plugin/highlight/highlight.js"></script>\n` + init('RevealMarkdown, RevealHighlight, RevealNotes'), 'assets/pic.png': png });
copy('v4.6.1/package/dist', 'classic4', 'dist'); copy('v4.6.1/package/plugin', 'classic4', 'plugin');

// 5. canonical 3.x layout (3.9.2) with dependencies loader
const head3 = `<link rel="stylesheet" href="css/reset.css"><link rel="stylesheet" href="css/reveal.css"><link rel="stylesheet" href="css/theme/black.css"><link rel="stylesheet" href="lib/css/monokai.css">
<script>var link = document.createElement('link'); link.rel = 'stylesheet'; link.type = 'text/css'; link.href = window.location.search.match(/print-pdf/gi) ? 'css/print/pdf.css' : 'css/print/paper.css'; document.getElementsByTagName('head')[0].appendChild(link);</script>`;
deck('classic3', { 'index.html': page(head3, slides()) + `<script src="js/reveal.js"></script>
<script>Reveal.initialize({ hash: true, dependencies: [ { src: 'plugin/markdown/marked.js' }, { src: 'plugin/markdown/markdown.js' }, { src: 'plugin/highlight/highlight.js' }, { src: 'plugin/notes/notes.js', async: true } ] });</script></body></html>`, 'assets/pic.png': png });
for (const d of ['css', 'js', 'lib', 'plugin']) copy('v3.9.2/package/' + d, 'classic3', d);

// 6. 4.x-style paths against a 6.x folder (what happens when an AI writes 4.x paths but the user unpacked 6.x)
deck('paths5-on-6', { 'index.html': page(head5, slides()) + `<script src="dist/reveal.js"></script><script src="plugin/notes/notes.js"></script><script src="plugin/markdown/markdown.js"></script><script src="plugin/highlight/highlight.js"></script>\n` + init('RevealMarkdown, RevealHighlight, RevealNotes'), 'assets/pic.png': png });
copy('v6.0.2/package/dist', 'paths5-on-6', 'dist');

// 7. single-file CDN decks
const cdn = (name, head, scripts, initCode) => deck('cdn', { [name]: page(head, slides().replaceAll('assets/pic.png', 'data:image/png;base64,' + png.toString('base64'))) + scripts + '\n' + initCode });
const j = (v) => `https://cdn.jsdelivr.net/npm/reveal.js${v}`;
const u = (v) => `https://unpkg.com/reveal.js${v}`;
const c = (v) => `https://cdnjs.cloudflare.com/ajax/libs/reveal.js/${v}`;
const std = (b) => [`<link rel="stylesheet" href="${b}/dist/reset.css"><link rel="stylesheet" href="${b}/dist/reveal.css"><link rel="stylesheet" href="${b}/dist/theme/black.css"><link rel="stylesheet" href="${b}/plugin/highlight/monokai.css">`,
  `<script src="${b}/dist/reveal.js"></script><script src="${b}/plugin/notes/notes.js"></script><script src="${b}/plugin/markdown/markdown.js"></script><script src="${b}/plugin/highlight/highlight.js"></script>`];
const i4 = init('RevealMarkdown, RevealHighlight, RevealNotes');
cdn('jsdelivr-unversioned-v4paths.html', ...std(j('')), i4);
cdn('jsdelivr-at-latest-v4paths.html', ...std(j('@latest')), i4);
cdn('jsdelivr-pinned-4.6.1.html', ...std(j('@4.6.1')), i4);
cdn('jsdelivr-pinned-5.2.1.html', ...std(j('@5.2.1')), i4);
cdn('jsdelivr-range-5.html', ...std(j('@5')), i4);
cdn('unpkg-unversioned-v4paths.html', ...std(u('')), i4);
cdn('unpkg-pinned-4.6.1.html', ...std(u('@4.6.1')), i4);
cdn('unpkg-range-4.html', ...std(u('@4')), i4);
cdn('cdnjs-4.6.1.html', `<link rel="stylesheet" href="${c('4.6.1')}/reset.min.css"><link rel="stylesheet" href="${c('4.6.1')}/reveal.min.css"><link rel="stylesheet" href="${c('4.6.1')}/theme/black.min.css"><link rel="stylesheet" href="${c('4.6.1')}/plugin/highlight/monokai.min.css">`,
  `<script src="${c('4.6.1')}/reveal.min.js"></script><script src="${c('4.6.1')}/plugin/notes/notes.min.js"></script><script src="${c('4.6.1')}/plugin/markdown/markdown.min.js"></script><script src="${c('4.6.1')}/plugin/highlight/highlight.min.js"></script>`, i4);
cdn('cdnjs-6.0.2-v4paths.html', `<link rel="stylesheet" href="${c('6.0.2')}/reset.min.css"><link rel="stylesheet" href="${c('6.0.2')}/reveal.min.css"><link rel="stylesheet" href="${c('6.0.2')}/theme/black.min.css"><link rel="stylesheet" href="${c('6.0.2')}/plugin/highlight/monokai.min.css">`,
  `<script src="${c('6.0.2')}/reveal.min.js"></script><script src="${c('6.0.2')}/plugin/notes/notes.min.js"></script><script src="${c('6.0.2')}/plugin/markdown/markdown.min.js"></script><script src="${c('6.0.2')}/plugin/highlight/highlight.min.js"></script>`, i4);
cdn('cdnjs-6.0.2-v6paths.html', `<link rel="stylesheet" href="${c('6.0.2')}/reset.min.css"><link rel="stylesheet" href="${c('6.0.2')}/reveal.min.css"><link rel="stylesheet" href="${c('6.0.2')}/theme/black.min.css"><link rel="stylesheet" href="${c('6.0.2')}/plugin/highlight/monokai.min.css">`,
  `<script src="${c('6.0.2')}/reveal.min.js"></script><script src="${c('6.0.2')}/plugin/notes.min.js"></script><script src="${c('6.0.2')}/plugin/markdown.min.js"></script><script src="${c('6.0.2')}/plugin/highlight.min.js"></script>`, i4);
cdn('cdnjs-3.6.0.html', `<link rel="stylesheet" href="${c('3.6.0')}/css/reveal.min.css"><link rel="stylesheet" href="${c('3.6.0')}/css/theme/black.min.css"><link rel="stylesheet" href="${c('3.6.0')}/lib/css/zenburn.min.css">`,
  `<script src="${c('3.6.0')}/lib/js/head.min.js"></script><script src="${c('3.6.0')}/js/reveal.min.js"></script>`,
  `<script>Reveal.initialize({ hash: true, dependencies: [ { src: '${c('3.6.0')}/plugin/markdown/marked.js' }, { src: '${c('3.6.0')}/plugin/markdown/markdown.min.js' }, { src: '${c('3.6.0')}/plugin/highlight/highlight.min.js', async: true, callback: function() { hljs.initHighlightingOnLoad(); } }, { src: '${c('3.6.0')}/plugin/notes/notes.min.js', async: true } ] });</script></body></html>`);
cdn('jsdelivr-6.0.2-v6paths.html', `<link rel="stylesheet" href="${j('@6.0.2')}/dist/reset.css"><link rel="stylesheet" href="${j('@6.0.2')}/dist/reveal.css"><link rel="stylesheet" href="${j('@6.0.2')}/dist/theme/black.css"><link rel="stylesheet" href="${j('@6.0.2')}/dist/plugin/highlight/monokai.css">`,
  `<script src="${j('@6.0.2')}/dist/reveal.js"></script><script src="${j('@6.0.2')}/dist/plugin/notes.js"></script><script src="${j('@6.0.2')}/dist/plugin/markdown.js"></script><script src="${j('@6.0.2')}/dist/plugin/highlight.js"></script>`, i4);
cdn('jsdelivr-esm-unversioned-v5paths.html', `<link rel="stylesheet" href="${j('')}/dist/reveal.css"><link rel="stylesheet" href="${j('')}/dist/theme/black.css">`, '',
  `<script type="module">import Reveal from '${j('')}/dist/reveal.esm.js'; import Markdown from '${j('')}/plugin/markdown/markdown.esm.js'; Reveal.initialize({ hash: true, plugins: [ Markdown ] }); window.Reveal = Reveal;</script></body></html>`);
cdn('unpkg-esm-unversioned-v5paths.html', `<link rel="stylesheet" href="${u('')}/dist/reveal.css"><link rel="stylesheet" href="${u('')}/dist/theme/black.css">`, '',
  `<script type="module">import Reveal from '${u('')}/dist/reveal.esm.js'; import Markdown from '${u('')}/plugin/markdown/markdown.esm.js'; Reveal.initialize({ hash: true, plugins: [ Markdown ] }); window.Reveal = Reveal;</script></body></html>`);
cdn('esmsh-unversioned.html', `<link rel="stylesheet" href="${j('')}/dist/reveal.css"><link rel="stylesheet" href="${j('')}/dist/theme/black.css">`, '',
  `<script type="module">import Reveal from 'https://esm.sh/reveal.js'; import Markdown from 'https://esm.sh/reveal.js/plugin/markdown/markdown.esm.js'; Reveal.initialize({ hash: true, plugins: [ Markdown ] }); window.Reveal = Reveal;</script></body></html>`);
console.log('decks written to', decks);
