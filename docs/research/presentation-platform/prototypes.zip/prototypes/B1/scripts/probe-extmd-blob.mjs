import { createRequire } from 'node:module';
import { readFileSync } from 'node:fs';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const [base, shimFile] = process.argv.slice(2);
const shim = `<script>${readFileSync(shimFile, 'utf8')}</script>`;
const browser = await chromium.launch();
const transforms = [['<section id="md" data-markdown>', '<section id="md" data-markdown="slides.md">']];
// generic opaque sandbox
{ const page = await (await browser.newContext({ viewport: { width: 1400, height: 800 } })).newPage(); const errs = [];
  page.on('pageerror', (e) => errs.push(String(e.message).slice(0, 200))); page.on('console', (m) => { if (['error', 'warning'].includes(m.type())) errs.push(`[${m.type()}] ` + m.text().slice(0, 200)); });
  await page.goto(base + '/generic.html'); await page.evaluate((o) => window.mount(o), { deck: 'single/classic6.html', transforms, inject: shim }); await page.waitForTimeout(2500);
  const frame = page.frames().find((f) => f !== page.mainFrame());
  console.log('generic sandbox:', JSON.stringify(await frame.evaluate(() => ({ ready: Reveal.isReady(), readyClass: !!document.querySelector('.reveal.ready'), total: Reveal.getTotalSlides && (() => { try { return Reveal.getTotalSlides(); } catch (e) { return 'threw'; } })(), alert: (document.querySelector('section[data-state="alert"]') || {}).textContent || null, mdSection: (document.querySelector('#md') || {}).outerHTML ? document.querySelector('#md').outerHTML.slice(0, 120) : null }))), JSON.stringify([...new Set(errs)]));
  await page.context().close(); }
// site chain
{ const page = await (await browser.newContext({ viewport: { width: 1400, height: 800 } })).newPage(); const errs = [];
  page.on('pageerror', (e) => errs.push(String(e.message).slice(0, 200)));
  await page.goto(base + '/site.html'); await page.waitForFunction(() => typeof window.mount === 'function');
  await page.evaluate((o) => window.mount(o), { deck: 'single/classic6.html', transforms, inject: shim });
  await page.waitForFunction(() => window.__states.some((x) => x.s === 'ready' || x.s === 'error'), null, { timeout: 25000 }).catch(() => {}); await page.waitForTimeout(1500);
  console.log('site chain:', JSON.stringify(await page.evaluate(() => ({ states: window.__states.map((x) => x.s).join('>'), errors: window.__errors }))), JSON.stringify([...new Set(errs)]));
  await page.context().close(); }
await browser.close();
