// Does a blob URL fragment restore slide + fragment at init, per major and with hash:false? Usage: node probe-hash-restore.mjs <genericHost> <shim>
import { createRequire } from 'node:module';
import { readFileSync } from 'node:fs';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const [host, shimFile] = process.argv.slice(2);
const shim = `<script>${readFileSync(shimFile, 'utf8')}</script>`;
const browser = await chromium.launch();
for (const d of ['classic3', 'classic4', 'classic5', 'classic6']) for (const variant of ['hash: true', 'hash: false']) {
  const page = await (await browser.newContext({ viewport: { width: 1400, height: 800 } })).newPage(); const errs = [];
  page.on('pageerror', (e) => errs.push(String(e.message).slice(0, 80)));
  await page.goto(host);
  await page.evaluate((o) => window.mount(o), { deck: 'single/' + d + '.html', hash: '#/0/0/1', transforms: [['hash: true', variant]], inject: shim });
  await page.waitForTimeout(1500);
  const frame = page.frames().find((f) => f !== page.mainFrame());
  const a = await frame.evaluate(() => Reveal.getIndices());
  await page.evaluate((o) => window.mount(o), { deck: 'single/' + d + '.html', hash: '#/2', transforms: [['hash: true', variant]], inject: shim });
  await page.waitForTimeout(1500);
  const frame2 = page.frames().find((f) => f !== page.mainFrame());
  const b = await frame2.evaluate(() => Reveal.getIndices());
  // setState after ready (works regardless of URL support)
  const c = await frame2.evaluate(() => { Reveal.setState({ indexh: 0, indexv: 0, indexf: 1, paused: false, overview: false }); return Reveal.getIndices(); });
  console.log(`${d} [${variant}] #/0/0/1 -> ${JSON.stringify(a)} ; #/2 -> ${JSON.stringify(b)} ; setState(0,0,f1) -> ${JSON.stringify(c)} errs=${JSON.stringify([...new Set(errs)])}`);
  await page.context().close();
}
await browser.close();
