// Tests the window.Reveal setter trap on several majors in the site's chain. Usage: node probe-trap.mjs <hostUrl> <shim> <trap>
import { createRequire } from 'node:module';
import { readFileSync } from 'node:fs';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const [hostUrl, shimFile, trapFile] = process.argv.slice(2);
const browser = await chromium.launch();
for (const d of ['classic3', 'classic4', 'classic5', 'classic6']) {
  for (const [label, overrides] of [['hash-off+events', { hash: false, history: false, postMessageEvents: true, scrollActivationWidth: null }], ['print-view', { view: 'print', hash: false }]]) {
    const page = await (await browser.newContext({ viewport: { width: 1400, height: 800 } })).newPage();
    const errs = []; page.on('pageerror', (e) => errs.push(String(e.message).slice(0, 120)));
    await page.goto(hostUrl); await page.waitForFunction(() => typeof window.mount === 'function');
    const inject = `<script>window.__qftRevealOverrides=${JSON.stringify(overrides)};${readFileSync(trapFile, 'utf8')}</script>`;   // note: NO history shim here on purpose
    await page.evaluate((o) => window.mount(o), { deck: 'single/' + d + '.html', transforms: [['<section id="title">', '<section>']], inject, width: label === 'hash-off+events' ? 400 : 1280 });
    await page.waitForFunction(() => window.__states.some((x) => x.s === 'ready' || x.s === 'error'), null, { timeout: 25000 }).catch(() => {});
    await page.waitForTimeout(900);
    const host = await page.evaluate(() => ({ states: window.__states.map((x) => x.s).join('>'), errors: window.__errors.map((e) => e.slice(0, 90)) }));
    const frame = page.frames().find((f) => f.url().startsWith('blob:'));
    const inner = frame ? await frame.evaluate(() => { const c = Reveal.getConfig(); return { version: Reveal.VERSION, hash: c.hash, history: c.history, postMessageEvents: c.postMessageEvents, view: c.view, scrollActivationWidth: c.scrollActivationWidth, isScroll: Reveal.isScrollView ? Reveal.isScrollView() : 'n/a', printClass: document.documentElement.className, pages: document.querySelectorAll('.pdf-page').length, originalHash: window.__qftRevealInit && window.__qftRevealInit.original.hash }; }).catch((e) => ({ evalError: e.message.slice(0, 80) })) : null;
    console.log(`${d} [${label}] host=${JSON.stringify(host)} inner=${JSON.stringify(inner)} errs=${JSON.stringify([...new Set(errs)])}`);
    await page.context().close();
  }
}
await browser.close();
