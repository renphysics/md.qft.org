// Correctness check of the live-edit strategies on older reveal.js majors. Usage: node check-live-old.mjs <hostBase>
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const browser = await chromium.launch();
for (const v of ['4', '5', '6']) {
  const page = await (await browser.newContext({ viewport: { width: 1400, height: 800 } })).newPage();
  const errors = []; page.on('pageerror', (e) => errors.push(String(e.message).slice(0, 160)));
  await page.goto(process.argv[2] + '?v=' + v); await page.evaluate(() => window.whenReady);
  const n = 20, target = 12;
  const first = await page.evaluate((n) => window.reload(window.genSections(n)), n);
  await page.evaluate((t) => window.remote('slide', [t, 0, 1]), target); await page.waitForTimeout(400);
  const before = (await page.evaluate(() => window.getState())).state;
  const row = { version: v, initialMs: Math.round(first.total), before: `${before.indexh}/${before.indexv}/${before.indexf}` };
  for (const [label, fn] of [['A1', (i) => page.evaluate(async ([n, t, i]) => { const st = (await window.getState()).state; await window.reload(window.genSections(n, { [t]: 'edit' + i }), { state: st }); return window.getState(); }, [n, target, i])],
    ['B1', (i) => page.evaluate(([n, t, i]) => window.swapFull(window.genSections(n, { [t]: 'edit' + i })), [n, target, i])],
    ['B2', (i) => page.evaluate(([n, t, i]) => window.swapKeyed(window.genSections(n, { [t]: 'edit' + i })), [n, target, i])]]) {
    let ok = 0, last;
    for (let i = 0; i < 6; i++) { const r = await fn(i); last = r; if (!r.error && r.state.indexh === before.indexh && r.state.indexf === before.indexf && (r.text || '').toLowerCase().includes('edit' + i)) ok++; }
    row[label] = ok + '/6' + (last.error ? ' ERR ' + last.error.slice(0, 120) : '');
  }
  // markdown + highlight re-run on a swapped-in markdown slide (index 13) and code slide (14)
  const md = await page.evaluate(async ([n]) => { await window.swapKeyed(window.genSections(n, { 13: 'mdedit', 14: 'codeedit' })); window.remote('slide', [13, 0]); await new Promise((r) => setTimeout(r, 300)); const a = await window.getState(); window.remote('slide', [14, 0]); await new Promise((r) => setTimeout(r, 300)); const b = await window.getState(); return { md: a.text, code: b.text }; }, [n]);
  row.markdownRendered = /markdown slide 13 mdedit/i.test(md.md) && !/data-template|##/.test(md.md);
  row.codeText = (md.code || '').replace(/\n/g, ' ').slice(0, 40);
  row.errors = [...new Set(errors)];
  console.log(JSON.stringify(row));
  await page.context().close();
}
await browser.close();
