import { createRequire } from 'node:module';
import { readdirSync } from 'node:fs';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const [base, dir] = process.argv.slice(2);
const browser = await chromium.launch();
for (const f of readdirSync(dir).sort()) {
  const page = await (await browser.newContext()).newPage(); const errs = [], bad = [], ver = {};
  page.on('pageerror', (e) => errs.push(String(e.message).slice(0, 90)));
  page.on('response', (r) => { if (r.status() >= 400) bad.push(r.status() + ' ' + r.url().replace(/^https:\/\/(cdn\.jsdelivr\.net\/npm|unpkg\.com)\//, '').slice(0, 60)); const v = r.headers()['x-jsd-version']; if (v) ver[r.url().replace(/^.*reveal\.js[^/]*\//, '')] = v; else if (/unpkg/.test(r.url()) && r.status() === 200) ver[r.url().replace(/^.*reveal\.js@?/, '@')] = 'ok'; });
  await page.goto(`${base}/decks/cdn3/${f}`, { waitUntil: 'load' }).catch(() => {}); await page.waitForTimeout(3000);
  const s = await page.evaluate(() => ({ reveal: typeof Reveal, version: window.Reveal && Reveal.VERSION, ready: !!(window.Reveal && Reveal.isReady && Reveal.isReady()), md: !!document.querySelector('.slides h2'), hljs: !!document.querySelector('.hljs') }));
  console.log(`${f.padEnd(38)} ${JSON.stringify(s)} errs=${JSON.stringify([...new Set(errs)])} bad=${JSON.stringify([...new Set(bad)].slice(0, 6))} versions=${JSON.stringify(ver).slice(0, 330)}`);
  await page.context().close();
}
await browser.close();
