// Prototype "reveal.js compatibility shim" for an opaque-origin blob/srcdoc sandbox (research prototype B1).
// Must run before any deck script. No dependencies. ~1.3 KB minified.
(() => {
  const post = (kind, detail) => { try { parent.postMessage({ qftReveal: 1, kind, detail }, '*'); } catch (_) {} };
  // 1. history: reveal's hash:true calls replaceState(pathname+search) on the first slide, which an opaque-origin
  //    blob: document may not do (SecurityError aborts Reveal's start()). Keep fragment-only updates, swallow the rest.
  for (const name of ['replaceState', 'pushState']) {
    const original = History.prototype[name];
    History.prototype[name] = function (state, title, url) {
      try { return original.call(this, state, title, url); }
      catch (error) {
        try { const at = typeof url === 'string' ? url.indexOf('#') : -1; return original.call(this, state, title, at >= 0 ? url.slice(at) : '#'); }
        catch (_) { /* srcdoc documents cannot even change the fragment */ }
      }
    };
  }
  // 2. fullscreen: the frame has no fullscreen permission; ask the host to fullscreen its stage instead.
  const fullscreen = function () { post('fullscreen'); return Promise.resolve(); };
  for (const name of ['requestFullscreen', 'webkitRequestFullscreen', 'webkitRequestFullScreen']) {
    if (name in Element.prototype) Element.prototype[name] = fullscreen;
  }
  // 3. popups: RevealNotes does window.open('about:blank') then writes into it; a sandbox without allow-popups
  //    returns null and the plugin throws. Return an inert stand-in and tell the host a speaker view was requested.
  window.open = function (url, name) {
    post('popup', { url: String(url || ''), name: String(name || '') });
    const sink = { closed: false, focus() {}, blur() {}, close() { sink.closed = true; }, postMessage() {}, addEventListener() {},
      document: { write() {}, writeln() {}, open() {}, close() {}, body: null }, location: { origin: 'null', href: 'about:blank' } };
    return sink;
  };
  // 4. modal dialogs are ignored in the sandbox; keep them from throwing/log-spamming.
  window.print = function () { post('print'); };
})();
