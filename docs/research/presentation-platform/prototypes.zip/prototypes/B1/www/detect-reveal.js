// Reveal.js deck detector (research prototype B1). Pure function, browser-side (uses DOMParser: inert parse, nothing executes or loads).
// files: Array<{ path: string, size: number, text?: string }>   (text for .html/.htm, package.json and reveal core js files is enough)
// Returns { kind, entry, entries, version, layout, runtime, cdn, localRefs, features, generator, problems }.
function detectRevealDeck(files) {
  const byPath = new Map(files.map((f) => [f.path, f]));
  const lower = new Map(files.map((f) => [f.path.toLowerCase(), f.path]));
  const htmlFiles = files.filter((f) => /\.html?$/i.test(f.path) && typeof f.text === 'string');
  const dirname = (p) => (p.includes('/') ? p.slice(0, p.lastIndexOf('/') + 1) : '');
  const resolve = (base, rel) => {            // resolve rel against the directory of base, inside the archive
    const clean = rel.split('#')[0].split('?')[0];
    const parts = (clean.startsWith('/') ? clean.slice(1) : dirname(base) + clean).split('/');
    const out = [];
    for (const part of parts) { if (part === '..') out.pop(); else if (part !== '.' && part !== '') out.push(part); }
    return out.join('/');
  };
  const isRemote = (u) => /^(?:https?:)?\/\//i.test(u);
  const isInert = (u) => /^(?:data|blob|javascript|mailto|about|tel):|^#/i.test(u) || u === '';
  const CORE = /(?:^|\/)reveal(?:\.min)?\.(?:m?js)(?:$|[?#])|(?:^|\/)reveal\.esm(?:\.min)?\.js(?:$|[?#])/i;
  const CORE_CSS = /(?:^|\/)reveal(?:\.min)?\.css(?:$|[?#])/i;
  const PLUGIN_GLOBALS = /\bReveal(Markdown|Highlight|Notes|Math|Zoom|Search|Menu|Chalkboard|Mermaid|Pointer|Drawer|CustomControls|Chart|Animate|Anything|AudioSlideshow|Poll|QnA|Seminar|LoadContent|Fullscreen)\b|\b(CopyCode|Appearance|Simplemenu|Verticator)\b/g;

  function inspect(file) {
    const doc = new DOMParser().parseFromString(file.text, 'text/html');
    const reasons = []; let score = 0;
    const root = doc.querySelector('.reveal > .slides, .reveal .slides');
    const sections = root ? root.querySelectorAll('section').length : 0;
    const topSections = root ? [...root.children].filter((el) => el.localName === 'section').length : 0;
    if (root) { score += 10; reasons.push(`div.reveal > div.slides (${sections} <section>)`); }
    const scripts = [...doc.querySelectorAll('script')];
    const inline = scripts.filter((s) => !s.hasAttribute('src')).map((s) => s.textContent).join('\n');
    const init = /\bReveal\s*\.\s*initialize\s*\(|\bnew\s+Reveal\s*\(|\.initialize\s*\(\s*\{[\s\S]{0,400}?\b(?:plugins|hash|controls|slideNumber|transition)\s*:/.test(inline);
    if (init) { score += 6; reasons.push('Reveal.initialize()/new Reveal() call'); }
    const srcs = scripts.map((s) => s.getAttribute('src')).filter(Boolean);
    const imports = [...inline.matchAll(/\bimport\s+(?:[\w$*{}\s,]+?\s+from\s+)?["']([^"']+)["']/g)].map((m) => m[1]);
    const required = [...inline.matchAll(/["']([^"']*reveal[^"']*\.js)["']/gi)].map((m) => m[1]);
    const links = [...doc.querySelectorAll('link[rel~="stylesheet"][href]')].map((l) => l.getAttribute('href'));
    const coreRefs = [...srcs, ...imports, ...required].filter((u) => CORE.test(u) || /^https?:\/\/(?:esm\.sh|cdn\.skypack\.dev|esm\.run|cdn\.jsdelivr\.net\/npm|unpkg\.com)\/reveal\.js(?:@[^/]*)?\/?(?:\+esm)?$/i.test(u) || u === 'reveal.js');
    if (coreRefs.length) { score += 4; reasons.push('references reveal core script: ' + coreRefs[0]); }
    if (links.some((u) => CORE_CSS.test(u))) { score += 2; reasons.push('references reveal.css'); }
    const inlinedCore = !coreRefs.length && /reveal\.js[\s\S]{0,200}?MIT licensed[\s\S]{0,200}?Hakim El Hattab/.test(file.text);
    if (inlinedCore) { score += 4; reasons.push('reveal.js core is inlined (banner found)'); }
    const name = file.path.split('/').pop().toLowerCase(); const depth = file.path.split('/').length - 1;
    if (/^index\.html?$/.test(name)) { score += 3; reasons.push('named index.html'); }
    else if (/^(?:slides?|presentation|deck|talk)\b.*\.html?$/.test(name) || /\.slides\.html$/.test(name)) { score += 2; reasons.push('deck-like file name'); }
    score -= depth * 0.5;
    if (/(?:^|\/)(?:node_modules|bower_components|test|tests|examples|__MACOSX)\//i.test(file.path)) { score -= 12; reasons.push('inside vendor/test/examples directory'); }
    if (/(?:^|\/)(?:plugin\/notes\/(?:notes|speaker-view)\.html|plugin\/markdown\/example\.html|plugin\/notes-server\/notes\.html)$/i.test(file.path)) { score -= 20; reasons.push('reveal.js plugin helper page'); }
    if (name === 'demo.html' && /reveal\.js\s+–\s+The HTML Presentation Framework|reveal\.js - The HTML Presentation Framework/.test(file.text)) { score -= 8; reasons.push('stock reveal.js demo.html'); }
    const stock = topSections === 2 && sections === 2 && /<section>\s*Slide 1\s*<\/section>\s*<section>\s*Slide 2\s*<\/section>/.test(file.text);
    if (stock) { score -= 6; reasons.push('untouched reveal.js starter index.html'); }
    score += Math.min(3, sections / 10);
    return { path: file.path, score: +score.toFixed(2), reasons, doc, inline, srcs, imports, required, links, coreRefs, sections, topSections, init, inlinedCore, hasRoot: !!root };
  }

  const inspected = htmlFiles.map(inspect).sort((a, b) => b.score - a.score || a.path.length - b.path.length);
  const best = inspected.find((c) => c.hasRoot && (c.init || c.coreRefs.length || c.inlinedCore));
  const entries = inspected.map(({ path, score, reasons }) => ({ path, score, reasons }));
  if (!best) return { kind: 'not-reveal', entries, hint: inspected.some((c) => c.hasRoot) ? 'has .reveal/.slides markup but no reveal.js script or init call' : null };

  const problems = []; const cdn = []; const found = []; const missing = [];
  const allRefs = [
    ...best.srcs.map((u) => ['script', u]), ...best.imports.map((u) => ['import', u]), ...best.links.map((u) => ['style', u]),
    ...[...best.inline.matchAll(/\bsrc\s*:\s*["']([^"']+\.js)["']/g)].map((m) => ['dependency', m[1]]),
    ...best.required.filter((u) => !best.srcs.includes(u) && !best.imports.includes(u)).map((u) => ['require', u]),
    ...[...best.doc.querySelectorAll('[data-markdown]')].map((el) => el.getAttribute('data-markdown')).filter(Boolean).map((u) => ['markdown', u]),
  ];
  for (const [kind, url] of allRefs) {
    if (isInert(url)) continue;
    if (isRemote(url)) {
      const m = url.match(/^(?:https?:)?\/\/([^/]+)\/(.*)$/); const host = m[1]; let rest = m[2]; let pkg = null, spec = null, path = null;
      let x;
      if ((x = rest.match(/^(?:npm\/)?((?:@[^/@]+\/)?[^/@]+)(?:@([^/]*))?(?:\/(.*))?$/)) && /jsdelivr|unpkg|esm\.sh|esm\.run|skypack/.test(host)) { pkg = x[1]; spec = x[2] ?? ''; path = x[3] ?? ''; }
      else if ((x = rest.match(/^ajax\/libs\/([^/]+)\/([^/]+)\/(.*)$/))) { pkg = x[1]; spec = x[2]; path = x[3]; }
      cdn.push({ kind, url, host, pkg, spec, path });
      if (pkg === 'reveal.js' && path && path.startsWith('/')) problems.push({ code: 'cdn-double-slash', detail: url });
    } else {
      const target = resolve(best.path, url);
      if (byPath.has(target)) found.push({ kind, url, path: target });
      else missing.push({ kind, url, path: target, caseMismatch: lower.get(target.toLowerCase()) || null });
    }
  }
  // --- version ---
  const evidence = []; let exact = null;
  const semver = (text) => { const m = text && text.match(/[`"'](\d+\.\d+\.\d+)[`"']/); return m ? m[1] : null; };
  const coreLocal = found.find((r) => CORE.test(r.url));
  if (coreLocal && byPath.get(coreLocal.path).text) {
    const text = byPath.get(coreLocal.path).text;
    const v = (text.match(/\bVERSION\s*=\s*['"](\d+\.\d+\.\d+)['"]/) || [])[1] || semver(text);   // every 3.9-6.0 core build holds exactly one semver literal
    if (v) { exact = v; evidence.push(`VERSION literal in ${coreLocal.path}: ${v}`); }
  }
  if (!exact && best.inlinedCore) { const at = best.inline.search(/reveal\.js[\s\S]{0,200}?MIT licensed/); const v = at >= 0 ? semver(best.inline.slice(at, at + 400000)) : null; if (v) { exact = v; evidence.push('VERSION literal in inlined core: ' + v); } }
  for (const f of files) if (/(?:^|\/)package\.json$/.test(f.path) && f.text && /"name"\s*:\s*"reveal\.js"/.test(f.text)) { const v = (f.text.match(/"version"\s*:\s*"([^"]+)"/) || [])[1]; if (v) { evidence.push(`${f.path}: ${v}`); exact ??= v; } }
  const coreCdn = cdn.find((c) => c.pkg === 'reveal.js' && (c.kind === 'script' || c.kind === 'import' || c.kind === 'require'));
  let major = exact ? Number(exact.split('.')[0]) : null;
  if (coreCdn) { const m = (coreCdn.spec || '').match(/(\d+)(?:\.(\d+)\.(\d+))?/); evidence.push(`CDN spec "${coreCdn.spec || '(none = latest)'}" on ${coreCdn.host}`); if (m) { major ??= Number(m[1]); if (m[2] !== undefined) exact ??= m[0]; } }
  const refPaths = allRefs.map(([, u]) => u);
  const has = (re) => refPaths.some((u) => re.test(u));
  const layout = has(/(?:^|\/)dist\/plugin\/[\w-]+(?:\.min)?\.m?js|(?:^|\/)reveal\.mjs|\/plugin\/(?:markdown|highlight|notes|math|zoom|search)(?:\.min)?\.js/) ? 'v6'
    : has(/(?:^|\/)plugin\/[\w-]+\/[\w-]+(?:\.esm)?(?:\.min)?\.js/) && has(/(?:^|\/)(?:dist\/)?reveal(?:\.esm)?(?:\.min)?\.js|reveal(?:\.min)?\.css/) && !has(/(?:^|\/)js\/reveal(?:\.min)?\.js|(?:^|\/)css\/reveal(?:\.min)?\.css/) ? 'v4-v5'
    : has(/(?:^|\/)js\/reveal(?:\.min)?\.js|(?:^|\/)css\/reveal(?:\.min)?\.css|lib\/js\/head\.min\.js/) ? 'v3'
    : has(/(?:^|\/)dist\/reveal(?:\.min)?\.js/) ? 'v4+' : 'unknown';
  if (major === null) { major = layout === 'v6' ? 6 : layout === 'v3' ? 3 : null; if (major) evidence.push('path layout ' + layout); }
  // --- features ---
  const inline = best.inline;
  // the deck's own init script: the last inline script that calls Reveal.initialize / new Reveal and is not a library bundle
  const initScript = [...best.doc.querySelectorAll('script:not([src])')].map((s) => s.textContent).filter((t) => t.length < 60000 && /\bReveal\s*\.\s*initialize\s*\(|\bnew\s+Reveal\s*\(/.test(t)).pop() || inline;
  const features = {
    plugins: [...new Set([...initScript.matchAll(PLUGIN_GLOBALS)].map((m) => m[0]))],
    dependenciesLoader: /\bdependencies\s*:\s*\[\s*\{/.test(inline),
    esm: best.doc.querySelector('script[type="module"]') !== null && best.imports.length > 0,
    amd: /\brequire\s*\(\s*(?:\{[\s\S]*?\}\s*,\s*)?\[/.test(inline) && best.srcs.some((u) => /require(?:\.min)?\.js/.test(u)),
    externalMarkdown: allRefs.filter(([k]) => k === 'markdown').map(([, u]) => u),
    inlineMarkdown: best.doc.querySelectorAll('section[data-markdown=""], section[data-markdown]:not([data-markdown*="."])').length,
    math: /RevealMath\.KaTeX/.test(inline) ? 'katex' : /RevealMath\.MathJax3/.test(inline) ? 'mathjax3' : /RevealMath\.MathJax4/.test(inline) ? 'mathjax4' : /\bRevealMath\b/.test(inline) ? 'mathjax2' : /math\s*:\s*\{[\s\S]{0,200}mathjax/i.test(inline) ? 'mathjax2' : null,
    hash: /\bhash\s*:\s*true/.test(inline), history: /\bhistory\s*:\s*true/.test(inline),
    view: (inline.match(/\bview\s*:\s*["'](\w+)["']/) || [])[1] || null,
    notes: best.doc.querySelector('aside.notes, [data-notes]') !== null || /^\s*Notes?:/im.test(best.doc.querySelector('[data-markdown] textarea, [data-markdown] script')?.textContent || ''),
    lazyMedia: best.doc.querySelectorAll('[data-src]').length,
    backgrounds: best.doc.querySelectorAll('[data-background-image],[data-background-video],[data-background-iframe],[data-background]').length,
    iframes: best.doc.querySelectorAll('iframe, [data-background-iframe], [data-preview-link]').length,
    sections: best.sections, topLevelSections: best.topSections,
  };
  const gen = best.doc.querySelector('meta[name="generator"]')?.getAttribute('content') || '';
  const generator = /quarto/i.test(gen) ? 'quarto ' + gen.replace(/^quarto-?/i, '') : /pandoc/i.test(gen) ? 'pandoc' : /asciidoctor/i.test(gen) ? gen : /org[ -]?mode|org-re-reveal|org-reveal/i.test(gen + best.doc.documentElement.outerHTML.slice(0, 3000)) ? 'org-reveal' :
    best.doc.querySelector('body.jp-Notebook, .jp-Cell, div.cell.border-box-sizing') ? 'jupyter nbconvert' : best.doc.querySelector('.sl-block') ? 'slides.com' :
    best.doc.querySelector('.slides > section[data-markdown] > textarea[data-template]') && best.topSections === 1 && /highlightOnLoad|livereload|queryOptions|defaultOptions/.test(inline) ? 'reveal-md' : null;
  // --- problems ---
  const revealCdn = cdn.filter((c) => c.pkg === 'reveal.js');
  const localCore = !!coreLocal;
  const runtime = best.inlinedCore ? 'inline' : localCore ? (revealCdn.length ? 'mixed' : 'local') : revealCdn.length || coreCdn ? 'cdn' : 'missing';
  for (const el of best.doc.querySelectorAll('script[src^="data:text/plain"], link[href^="data:text/plain"]')) { problems.push({ code: 'embedded-resource-is-error-page', detail: decodeURIComponent((el.getAttribute('src') || el.getAttribute('href')).slice(0, 120)) }); break; }
  for (const m of missing) problems.push({ code: m.caseMismatch ? 'file-case-mismatch' : 'missing-local-file', detail: `${m.kind} ${m.url}` + (m.caseMismatch ? ` (archive has ${m.caseMismatch})` : '') });
  if (major === 6 && allRefs.some(([, u]) => /(?:^|\/)plugin\/(?:markdown|highlight|notes|math|zoom|search)\/\1?[\w.-]*\.js/.test(u) && !/dist\/plugin\//.test(u))) problems.push({ code: 'v4-plugin-paths-on-v6', detail: 'plugin/<name>/<name>.js does not exist in reveal.js 6 (moved to dist/plugin/<name>.js)' });
  for (const c of revealCdn) {
    const unpinned = c.spec === '' || c.spec === 'latest';
    const oldPluginPath = /^plugin\/[\w-]+\/[\w.-]+\.(?:js|css)$/.test(c.path) || /^dist\/reveal\.esm\.js$/.test(c.path) || /^(?:js|css|lib)\//.test(c.path);
    if (unpinned && oldPluginPath) problems.push({ code: /unpkg|esm\.sh/.test(c.host) ? 'unpinned-cdn-old-path-404' : 'unpinned-cdn-version-mix', detail: c.url });
    else if (unpinned) problems.push({ code: 'unpinned-cdn', detail: c.url });
  }
  if (features.externalMarkdown.length) problems.push({ code: 'external-markdown-needs-http', detail: features.externalMarkdown.join(', ') });
  if (features.esm) problems.push({ code: 'es-modules-need-http', detail: best.imports.join(', ') });
  if (features.math && !/katex\s*:\s*\{[\s\S]{0,200}?local\s*:|mathjax\s*:\s*["']/.test(inline)) problems.push({ code: 'math-plugin-loads-cdn', detail: features.math });
  for (const u of [...best.links, ...[...best.doc.querySelectorAll('style')].flatMap((s) => [...s.textContent.matchAll(/@import\s+(?:url\()?["']?([^"')\s;]+)/g)].map((m) => m[1]))]) if (/fonts\.googleapis\.com|fonts\.gstatic\.com/.test(u)) problems.push({ code: 'google-fonts', detail: u });
  const dedupe = [...new Map(problems.map((p) => [p.code + '|' + p.detail, p])).values()];
  return { kind: 'reveal', entry: best.path, entries, version: { major, exact, evidence }, layout, runtime, cdn, localRefs: { found: found.length, missing }, features, generator, problems: dedupe };
}
if (typeof window !== 'undefined') window.detectRevealDeck = detectRevealDeck;
