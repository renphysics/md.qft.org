// Live-edit agent injected into the sandboxed deck document (research prototype B1).
// Talks to the embedding page with plain-object postMessage: {qftLive:1, kind, ...}.
(() => {
  const send = (kind, detail) => parent.postMessage({ qftLive: 1, kind, ...detail }, '*');
  // --- compat shim (see reveal-compat-shim.js) ---
  for (const name of ['replaceState', 'pushState']) {
    const original = History.prototype[name];
    History.prototype[name] = function (state, title, url) {
      try { return original.call(this, state, title, url); }
      catch (error) { try { const at = typeof url === 'string' ? url.indexOf('#') : -1; return original.call(this, state, title, at >= 0 ? url.slice(at) : '#'); } catch (_) {} }
    };
  }
  window.open = () => ({ closed: false, focus() {}, postMessage() {}, document: { write() {} } });
  Element.prototype.requestFullscreen = () => Promise.resolve();
  for (const n of ['localStorage', 'sessionStorage']) { try { void window[n].length; } catch { const m = new Map(); Object.defineProperty(window, n, { value: { getItem: (k) => m.get(k) ?? null, setItem: (k, v) => m.set(k, String(v)), removeItem: (k) => m.delete(k), clear: () => m.clear(), key: (i) => [...m.keys()][i] ?? null, get length() { return m.size; } } }); } }

  const t0 = performance.now();
  let sources = null;            // last applied array of top-level section sources (keyed strategy)
  const raf2 = () => new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
  // reveal events bubble from .reveal to document: no reference to the Reveal object is needed to observe them
  document.addEventListener('ready', () => { raf2().then(() => send('ready', { ms: performance.now() - t0, state: window.Reveal?.getState?.() })); });
  for (const type of ['slidechanged', 'fragmentshown', 'fragmenthidden']) document.addEventListener(type, () => send('state', { state: window.Reveal?.getState?.() }));

  async function runPlugins(R, scopes) {
    const md = R.getPlugin && R.getPlugin('markdown');
    if (md && R.getSlidesElement().querySelector('[data-markdown]:not([data-markdown-parsed])')) { await md.processSlides(R.getSlidesElement()); await md.convertSlides(); }
    const hl = R.getPlugin && R.getPlugin('highlight');
    if (hl) for (const el of scopes()) { if (el.querySelector('pre code:not(.hljs)')) hl.init({ getConfig: () => R.getConfig(), getRevealElement: () => el, on() {}, off() {} }); }
  }
  const tag = (html, key) => html.replace(/^(\s*<section\b)/i, `$1 data-qft-src="${key}"`);

  async function swapFull({ slidesHtml }) {
    const R = window.Reveal; const state = R.getState(); const slides = R.getSlidesElement();
    slides.innerHTML = slidesHtml;
    await runPlugins(R, () => [slides]);
    R.sync(); R.slide(state.indexh, state.indexv, state.indexf);
    sources = null;
    return R.getState();
  }
  // Keyed update: replace only the top-level source sections whose text changed (common prefix/suffix diff).
  async function swapKeyed({ sections }) {
    const R = window.Reveal; const state = R.getState(); const slides = R.getSlidesElement();
    const top = R.getCurrentSlide()?.closest('.slides > section'); const currentKey = top?.getAttribute('data-qft-src') || null;
    if (!sources) { // first keyed call: establish keys with one full swap
      slides.innerHTML = sections.map((s, i) => tag(s, 'k' + i)).join('\n');
      sources = sections.map((s, i) => ({ key: 'k' + i, html: s })); sources.next = sections.length;
      await runPlugins(R, () => [slides]);
    } else {
      let start = 0; while (start < sources.length && start < sections.length && sources[start].html === sections[start]) start++;
      let endOld = sources.length, endNew = sections.length;
      while (endOld > start && endNew > start && sources[endOld - 1].html === sections[endNew - 1]) { endOld--; endNew--; }
      const removed = sources.slice(start, endOld);
      const anchorKey = endOld < sources.length ? sources[endOld].key : null;
      for (const r of removed) slides.querySelectorAll(`:scope > [data-qft-src="${r.key}"]`).forEach((el) => el.remove());
      const anchor = anchorKey ? slides.querySelector(`:scope > [data-qft-src="${anchorKey}"]`) : null;
      const added = sections.slice(start, endNew).map((html) => ({ key: 'k' + (sources.next++), html }));
      const template = document.createElement('template'); template.innerHTML = added.map((a) => tag(a.html, a.key)).join('\n');
      slides.insertBefore(template.content, anchor);
      const next = sources.next; sources = [...sources.slice(0, start), ...added, ...sources.slice(endOld)]; sources.next = next;
      await runPlugins(R, () => added.flatMap((a) => [...slides.querySelectorAll(`:scope > [data-qft-src="${a.key}"]`)]));
      var changed = { removed: removed.length, added: added.length };
    }
    R.sync();
    // follow the slide the viewer was on (by source key) rather than its numeric index
    const same = currentKey ? slides.querySelector(`:scope > [data-qft-src="${currentKey}"]`) : null;
    const h = same ? [...slides.children].filter((el) => el.matches('section')).indexOf(same) : state.indexh;
    R.slide(h, state.indexv, state.indexf);
    return { ...R.getState(), changed, followedKey: !!same };
  }
  window.addEventListener('message', async (event) => {
    const m = event.data; if (!m || m.qftLive !== 1 || event.source !== parent) return;
    const start = performance.now();
    try {
      let state;
      if (m.kind === 'swap-full') state = await swapFull(m);
      else if (m.kind === 'swap-keyed') state = await swapKeyed(m);
      else if (m.kind === 'css') { document.querySelector('style[data-qft-user]').textContent = m.css; window.Reveal.layout(); state = window.Reveal.getState(); }
      else if (m.kind === 'get-state') { send('reply', { id: m.id, state: window.Reveal.getState(), slideCount: window.Reveal.getTotalSlides(), text: window.Reveal.getCurrentSlide()?.innerText.slice(0, 80) }); return; }
      else return;
      const applied = performance.now() - start;
      await raf2();
      send('reply', { id: m.id, state, applied, painted: performance.now() - start, slideCount: window.Reveal.getTotalSlides(), text: window.Reveal.getCurrentSlide()?.innerText.slice(0, 80) });
    } catch (error) { send('reply', { id: m.id, error: String(error && error.stack || error).slice(0, 400) }); }
  });
})();
