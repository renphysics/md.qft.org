// Prototype: intercept the global Reveal object the moment a UMD build assigns it, so a host can
// merge init-time overrides (e.g. view:'print', hash:false, postMessageEvents:true) without parsing or editing deck code.
(() => {
  const overrides = window.__qftRevealOverrides || {};
  let value;
  const wrap = (R) => {
    if (!R || typeof R.initialize !== 'function' || R.__qftWrapped) return R;
    const initialize = R.initialize;
    R.initialize = function (options) {
      window.__qftRevealInit = { original: { ...(options || {}), plugins: undefined, dependencies: undefined } };
      return initialize.call(this, { ...(options || {}), ...overrides });
    };
    R.__qftWrapped = true;
    return R;
  };
  Object.defineProperty(window, 'Reveal', { configurable: true, enumerable: true, get() { return value; }, set(v) { value = wrap(v); } });
})();
