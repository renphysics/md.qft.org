// Service worker for a dedicated "player" origin: serves unpacked ZIP files from Cache Storage under /vfs/<id>/...
// Research prototype B1. No network fallback for /vfs/ paths; adds a CSP that blocks all external network access.
const CSP = "default-src 'self' 'unsafe-inline' 'unsafe-eval' data: blob:; connect-src 'self'; form-action 'none'; base-uri 'self'";
self.addEventListener('install', (e) => e.waitUntil(self.skipWaiting()));
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin || !url.pathname.startsWith('/vfs/')) return;
  event.respondWith((async () => {
    const id = url.pathname.split('/')[2];
    const cache = await caches.open('vfs-' + id);
    let path = url.pathname; if (path.endsWith('/')) path += 'index.html';
    const hit = await cache.match(new Request(url.origin + path), { ignoreSearch: true, ignoreVary: true });
    if (!hit) return new Response('Not in package: ' + path, { status: 404, headers: { 'content-type': 'text/plain' } });
    const headers = new Headers(hit.headers);
    headers.set('Content-Security-Policy', CSP); headers.set('Referrer-Policy', 'no-referrer'); headers.set('Cache-Control', 'no-store'); headers.set('X-Content-Type-Options', 'nosniff');
    return new Response(hit.body, { status: 200, headers });
  })());
});
