
### 1.5 Upload matrix: what the built site does with what an AI hands back [E4, E9, E14]

Each case ran in a fresh browser context; the "outcome" is the toast or dialog text verbatim.

| # | Fixture (in `proto/A2/fixtures/`) | What it is | Outcome |
| --- | --- | --- | --- |
| 1 | `reveal-standard.zip` | Standard Reveal.js 6.0.2 project: `index.html` + `dist/` (core, 14 themes, 6 plugins under `dist/plugin/`) + `assets/`; 27 entries, 2.26 MB | "This is a website build ZIP. Follow tools/slidev/README.md and use the QFT Slidev packaging tool to bundle its scripts, fonts, and assets for local playback." Nothing opens. (`presentation-package.ts:325-329`) |
| 2 | `reveal-standard-folder.zip` | Same inside `my-deck/` | Same message |
| 3 | `reveal-standard-readme.zip` | Same plus one `README.md` | **Silently opens README.md** as a document titled "README" in Document mode with the toast "Lesson opened. Check lesson helps you spot missing images, equations, or demo dependencies." The deck is ignored; its html/js/css land in "Lesson files" as inert text |
| 4 | `reveal-standard-two-md.zip` | Same plus `README.md` and `slides.md` | "A ZIP bundle must contain one Markdown document, or a QFT document manifest." (`document-bundle.ts:310`) |
| 5 | `reveal-npm-package.zip` | Whole npm package (css/, js/, dist/) + index.html; 111 entries, 3.2 MB | Same as 4 (two README.md) |
| 6 | `reveal-cdn-single.zip` | One `index.html` using jsDelivr URLs | Same as 4 |
| 7 | `reveal-cdn-single.html` | The same file, not zipped (the most common chat-AI answer) | "Choose Markdown (.md), plain text (.txt), a lesson ZIP, or a prepared Slidev presentation ZIP." (`markdown-workspace.ts:1387`; the picker's `accept` also hides `.html`, `MarkdownWorkspace.astro:87`) |
| 8 | `slidev-source.zip` | `slides.md` + `package.json` (@slidev/cli) + `components/Counter.vue` | "This ZIP contains Slidev source, not a playable presentation. Ask the AI to build it with the QFT Slidev packaging tool, following tools/slidev/README.md, and include the compiled presentation." (`presentation-package.ts:322-324`) |
| 9 | `slidev-source-no-pkg.zip` | `slides.md` + a `.vue` file | Same as 8 |
| 10 | `slidev-md-only.zip` | Only a Slidev `slides.md` | "Lesson opened. ..." - opened as a Markdown **document** titled "slides" |
| 11 | `slidev-slides.md` | The same file, not zipped | "Opened as a new document. Your original file is unchanged." Document mode |
| 12 | `slidev-dist.zip` | Ordinary `slidev build` output, 106 entries, 1.2 MB | Same message as 1 |
| 13 | `slidev-dist-relative.zip` | `slidev build --base ./` | Same message as 1 |
| 14 | `lesson-with-svg.zip` | Valid v2 lesson plus `images/diagram.svg` | "This lesson contains an unsupported file: images/diagram.svg. Use Markdown, HTML, CSS, JavaScript, JSON, text, or PNG/JPEG/WebP/GIF images." Whole import fails (`document-bundle.ts:306-308`) |
| 15 | `lesson-with-py.zip` | Valid v2 lesson plus `scripts/make_plot.py` | Same with `scripts/make_plot.py` |
| 16 | `lesson-no-manifest.zip` | `slides.md` + image + demo, no `qft.json` | Opens as "slides" in **Document** mode (no `mode` without manifest) |
| 17 | `lesson-missing-projectid.zip` | v2 manifest without `projectId` | "This lesson project needs a valid projectId." |
| 18 | `lesson-cdn-demo.zip` | Demo HTML loads Chart.js from a CDN | Opens with no diagnostics. Run demo: "Demo error: Uncaught ReferenceError: Chart is not defined". Check lesson: "Demo “demos/chart.html”: linked scripts and stylesheets cannot load. Put the needed JavaScript and CSS directly inside the HTML file." |
| 19 | `lesson-ok.zip` | Minimal valid lesson | Slides mode, "1 / 2" |
| 20 | `shared/slidev-starter/lesson.zip` | Portable Slidev package | Dialog "Quantum interference — Slidev", "Slidev · 14 files · 1.6 MB" |
| 21 | `lesson-fake-png.zip` | `.png` whose bytes are SVG | "“diagram.png” is not a supported image. Choose a PNG, JPEG, WebP, or GIF file." Whole import fails |
| 22 | `lesson-nested-with-stray.zip` | `lesson/qft.json` + a stray root file | Manifest ignored; opens "slides" in Document mode, identity lost |
| 23 | `lesson-many-files.zip` | 162 entries | "This ZIP bundle could not be opened. Invalid or duplicate archive path." (the 150-entry limit reported as a path error, `document-bundle.ts:277`) |
| 24 | `placeholder-id-A.zip` then `-B.zip` | Two unrelated lessons that both kept `"projectId": "REPLACE-WITH-A-NEW-UUID"` from the prompt | Second import opens "Review this lesson update." - "This ZIP is a revision of “Thermodynamics” in your workspace." The placeholder satisfies the id pattern `^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$` (`lesson-project.ts:16`) |
| 25 | `reveal-cdn-single.html` through Interactive demo -> "Open HTML file" | CDN deck as a demo | Inserted; Run demo: "Demo error: Uncaught ReferenceError: Reveal is not defined" (`script[src]` is stripped) |
| 26 | `reveal-inlined-single.html` (1.8 MB, everything inlined) through the same path | Self-contained deck as a demo | "Choose a self-contained HTML demo smaller than 100 KB." (`markdown-workspace.ts:1782`); reveal.js alone is 118,912 bytes |

Net result: **no form of standard Reveal.js output and no form of Slidev source plays today**. The only playable inputs are the site's own Markdown dialect and a package produced by `tools/slidev/pack.mjs`. Three cases (3, 10, 11) are worse than a refusal: they report success ("Lesson opened") while showing something else.

## 2. Markdown-to-reveal.js slide mode versus standard Reveal.js authoring

### 2.1 How the mode is built [C]

- Parsing: one markdown-it instance with `html: false` (`src/lib/render-markdown.ts:114-123`), KaTeX (`@mdit/plugin-katex`, four delimiter styles), footnotes, task lists; highlight.js core with exactly seven languages - javascript, typescript, python, json, bash, latex, css (`render-markdown.ts:18-20`).
- Slides: a top-level `hr` token whose source line matches `/^ {0,3}---[ \t]*$/` starts a new slide (`render-markdown.ts:320-328`); `***`, `- - -`, `----` stay horizontal rules. Each slide becomes a flat `<section class="qft-slide" data-slide-index="n"><div class="qft-slide-content">…</div></section>` (`render-markdown.ts:352-358`, `src/lib/slides.ts:31`). No attribute, class or nested section can be authored.
- Only a leading YAML block is blanked (`withoutFrontmatter`, `render-markdown.ts:367-374`).
- Preview player (`src/scripts/slide-preview.ts:42-80`): `new Reveal(canvas, {...})` with **no `plugins`** and

  ```
  embedded:true, controls:false, progress:false, slideNumber:false, hash:false, history:false,
  keyboard:{27:noop,70:noop,66:noop,190:noop}, overview:false, help:false, pause:false,
  jumpToSlide:false, center:false, margin:0, minScale:0.05, maxScale:2, transition:'none',
  backgroundTransition:'none', autoAnimate:false, autoSlide:0, touch:true, mouseWheel:false,
  view:null, scrollActivationWidth:0, width:1280, height:720|960
  ```
- Standalone HTML export (`src/lib/export-slides.ts:48-56`) embeds the raw reveal.js 6.0.2 runtime, again without plugins, with `controls:true, progress:true, slideNumber:'c/t', hash:true, transition:'none', embedded:false, pdfSeparateFragments:false, pdfMaxPagesPerSlide:1, view:null, scrollActivationWidth:0`. The probe deck exported to 603,351 bytes; CSP `default-src 'none'; script-src 'nonce-…'; style-src 'unsafe-inline'; img-src data:; font-src data:; frame-src 'self' blob:; connect-src 'none'; …`.
- Themes: three CSS-variable themes on the wrapper, `paper`, `midnight`, `serif` ("Academic") (`src/styles/slides.css:2-38`, `slides.ts:3`); two sizes, 1280x720 and 1280x960 (`slides.ts:19-21`).

### 2.2 Feature matrix

Probe deck: `fixtures/reveal-conventions.md` (8 slides written with the conventions documented at https://revealjs.com/markdown/ [D]), imported as `lesson-reveal-conventions.zip`. "App" = workspace preview and Present overlay. "Export" = the downloaded standalone HTML opened from `file://`.

| Standard Reveal.js feature | App | Export | Evidence |
| --- | --- | --- | --- |
| Horizontal slides | **Supported** (own `---` rule, needs blank lines around it) | Supported | [E1] 8 top-level sections; [C] `render-markdown.ts:320-328` |
| Vertical slides (`--`, nested `<section>`) | **Not supported** | Not supported | [E1] `--` printed as text inside slide 2; the only nested `<section>` is markdown-it's `<section class="footnotes">` |
| Fragments | **Not supported** | Not supported | [E1] 0 `.fragment` elements; `<!-- .element: class="fragment" -->` printed literally (`shots/A2-probe-slide-03.png`) |
| Speaker notes (`Note:`, `<aside class="notes">`, S key) | **Not supported** | Not supported | [E1] "Note: These are my speaker notes…" is visible slide text; 0 `aside.notes`; [E2][E3b] S opens nothing |
| Auto-animate | **Not supported** | Not supported | [C] `autoAnimate:false`; `data-auto-animate` cannot be authored |
| Slide backgrounds (colour, image, video, iframe) | **Not supported** | Not supported | [E1] `<!-- .slide: data-background="#ff0000" … -->` printed literally; no `data-*` on any section |
| Transitions | **Not supported** (`'none'`) | Not supported by authoring; `?transition=zoom` in the URL changes it | [C] config; [E3] class `zoom` after the query |
| Per-slide attributes (`<!-- .slide: -->`) | **Not supported** | Not supported | [E1] |
| Per-element attributes (`<!-- .element: -->`) | **Not supported** | Not supported | [E1] |
| Themes | **Partial**: 3 site themes; none of Reveal's 14 (`node_modules/reveal.js/dist/theme/`) | Same | [E3b] `data-slide-theme` paper/midnight/serif; backgrounds rgb(255,254,251) / rgb(23,28,41) / rgb(250,247,238) |
| Custom CSS | **Not supported** | Not supported | [E1] `<style>` printed as text; project `.css` files are preserved but never loaded (`lesson-format-v2.md:91`) |
| Custom JS in the slide | **Not supported** | Not supported | [E1] `<script>` printed as text, `window.__probeScriptRan` false |
| Custom JS via `interactive` fence | **Partial** (site-specific): sandboxed iframe card, <=100,000 chars each, <=20 per deck, explicit "Run demo" | Same, offline | [C] `interactive-demos.ts:9-10`; [E6] |
| Plugin: Markdown | **Partial/different**: site's markdown-it, not `RevealMarkdown`; no HTML, no attribute comments | Same | [C] |
| Plugin: Highlight | **Partial**: highlight.js at render time, 7 languages, no line numbers | Same | [E1] 7 `hljs-*` spans, `data-line-numbers` null |
| Code line highlighting and step-through (` ```js [1-2\|3] `) | **Not supported** (suffix silently ignored) | Not supported | [E1] no line table |
| Plugin: Math | **Supported differently**: KaTeX 0.19.1 at render time, `$…$`, `$$…$$`, `\(…\)`, `\[…\]`; no MathJax | Same, fonts embedded | [E1] 2 `.katex` nodes |
| Plugin: Notes / Search / Zoom | **Not supported** | Not supported | [E2][E3b] S, Ctrl+Shift+F, Alt+click do nothing |
| Third-party plugins | **Not supported** (no plugin hook) | Not supported | [C] no `plugins` option anywhere |
| Images | **Partial**: PNG, JPEG, WebP, GIF only; SVG rejected; remote images blocked until opted in | Embedded as data URIs | [E1] local image rendered, "Remote image · enable in Settings" |
| Video / audio / iframe embeds | **Not supported** | Not supported | [E1] 0 `video`, 0 `iframe`; tags printed as text |
| `r-fit-text`, `r-stack`, `r-stretch` (and `r-hstack`, `r-vstack`, `r-frame`) | **Not supported** (reveal.css is loaded but no class can be applied) | Not supported | [E1] 0 elements with these classes |
| Lightbox (`data-preview-image/-video/-link`, Reveal 5.2+ [D https://revealjs.com/lightbox/]) | **Not supported** | Not supported | [E1] |
| Overview (O / Esc) | **Not supported** (disabled) | **Supported** | [E2] no `overview` class; [E3] `overview:true` after O and after Esc |
| Scroll view (Reveal 5.0+ [D https://revealjs.com/scroll-view/]) | **Not supported**; `?view=scroll` on the site URL breaks the preview | Only via `?view=scroll` (8 scroll pages) | [E3] |
| PDF export | **Partial/different**: own print copy, one slide per page, through the browser print dialog; refuses on overflow | Own "Save PDF" button; Reveal's `?print-pdf` also works (8 `.pdf-page`) | [E8b] `interactive-physics` example -> 5 pages, MediaBox 960x540 pt; quantum example refused (2.5) |
| Keyboard navigation | **Supported**: arrows, Space, N/P, H/J/K/L, Home/End, PageUp/PageDown | Supported | [E3] each key moved 1/8 -> 2/8 or 8/8 -> 7/8 |
| Fullscreen | **Supported** by the Present overlay (F key disabled) | Button and F key | [E2] `fs:true` in Present; [E3b] |
| Pause/blackout (B, .) | Not supported | Supported | [E2][E3] |
| Jump to slide (G), help (?) | Not supported | Supported | [E3][E3b] |
| Controls, progress bar, slide number | Replaced by the site's own counter and arrows | Reveal's own | [E1] `display:none`; [E3] "1/8" |
| Hash deep links | Not supported (`hash:false`) | Supported (`#/1`) | [E3] |
| Touch swipe | Enabled in config, not tested | Enabled | [C] `touch:true` [I] |
| Auto-slide, presenter timer, multiplex | Not supported | Not supported | [C] |

Count over the 25 features named in the task (vertical slides … lightbox): in the app **1 is supported by different means** (math), **6 are partial** (themes, custom JS only as isolated demos, highlight, markdown, media limited to raster images, PDF) and **18 are not supported**. The standalone export additionally exposes overview, and scroll view and Reveal's print view through URL parameters.

### 2.3 What the Markdown mode has that stock Reveal.js lacks [C][E]

Live split editing with 180 ms debounced preview (`markdown-workspace.ts:293`); per-slide overflow detection (`slide-preview.ts:201-213`); sandboxed demo cards with Run/Stop/Restart, pause on inactive slides, canvas snapshots for PDF; math rendered without a runtime plugin; a static checker and a "copy report for AI" loop; project ZIP round trip with identity; one-file offline export; no network at any point.

### 2.4 Foreign slide dialects render as text and pass the checker [E]

- Reveal.js conventions: see `shots/A2-probe-slide-03.png` and `-06.png`. "Check lesson" on that deck reports "8 slides · 0 demos · 0 errors · 1 warning" - the single warning is the remote image [E13].
- Slidev `slides.md` switched to Slides mode [E8]: 3 slides; the per-slide frontmatter `---\nlayout: two-cols\n---` becomes an `<h2>` reading "layout: two-cols" (setext heading); `<v-click>`, `::right::`, `<Counter :count="10" />` and the presenter-note comment print literally. "Check lesson": "The format check passed. Your lesson is ready for a rehearsal."
- The site describes the mode as "a simple Markdown slide format, powered by reveal.js" (`src/pages/guide.astro:143`) and "This Reveal.js format" (`src/lib/site-faq.ts:36`). A user or an AI reading that can reasonably expect Reveal.js syntax to work. [I]

### 2.5 Defects found while probing

1. **The site URL's query string reconfigures or breaks the embedded deck.** reveal.js merges `location.search` into its config last (`node_modules/reveal.js/js/reveal.js:144-156`, `js/utils/util.ts:208-232`) and the site passes nothing to stop it. [E3] on `http://127.0.0.1:4410/`: `?controls=true&progress=true&slideNumber=true` shows Reveal's controls in the workspace; `?view=scroll` gives "Slides could not be loaded. Switch to Document and back to try again."; `?print-pdf` throws `TypeError: Cannot read properties of null (reading 'appendChild')`, adds `reveal-print print-pdf` to `<html>` and blanks the slide (`shots/A2-site-query-_print_pdf.png`); `?embedded=false` turns `<body>` into the Reveal viewport.
2. **Save PDF is refused for the site's own example.** `?example=quantum-slides` -> Save PDF -> "Slides 3, 5 contain too much content for the selected slide size. Split the content across slides or choose 4:3 before saving the PDF." [E8b]. Cause: the print check also tests every `pre, .katex-display, table` for `scrollHeight > clientHeight + 3` (`export-slides.ts:274-276`, same logic in the exported file `:111-115`). Display equations with fractions measure 101 vs 97 px (slide 3) and 93 vs 88 px (slide 5) while the slide itself has 131 px and 87 px of free space (`shots/A2-quantum-slide-3.png`) [E8c]. The live preview shows no overflow notice for those slides.
3. **Footnote sections count as slides in some Reveal code paths.** markdown-it emits `<section class="footnotes">` inside a slide; Reveal's `.slides section` selector includes it. [E1] 9 background elements for 8 slides; [E3] the export in `?view=scroll` shows slide number "10 / 9". Invisible in the app (controls are hidden); visible only through the scroll-view query.
4. **Checker false green** for foreign dialects (2.4).
5. **Placeholder id is a valid id** (1.5 row 24).
6. **Documentation versus behaviour.** `public/lesson-format-v2.md:56` says "SVG and PDF are not imported as pictures" and "keep its generation source in the project when useful"; in a v2 project any such file aborts the import (rows 14, 15). The 833-word prompt never lists the allowed file types or says that other files are fatal.

## 3. Distance from the lesson format to standard Reveal.js and Slidev projects

### 3.1 Structural comparison

| Aspect | QFT lesson (`qft.json` v2) | Standard Reveal.js project | Slidev project |
| --- | --- | --- | --- |
| Entry / manifest | `qft.json` (required for Slides mode and identity) + one Markdown file | `index.html`; no manifest | `slides.md` headmatter + `package.json` |
| Slide source | Markdown, `---` separators, no HTML | HTML `<section>` elements; optionally Markdown inside `<section data-markdown>` or an external `.md` loaded over HTTP [D https://revealjs.com/markdown/] | Markdown + Vue templates + UnoCSS classes, `---` separators with per-slide frontmatter, layouts, `<v-click>`, components |
| Runtime | Site renderer -> embedded Reveal core without plugins | `dist/reveal.js` + plugins + the author's own scripts; opens from `file://` ("Basic setup", [D https://revealjs.com/installation/]) | A Vite-built Vue 3 application; the source cannot run without compiling |
| Styling | 3 themes | 14 themes + arbitrary CSS; 8 of 14 themes `@import` Google Fonts, black/white embed fonts as data URIs (575 KB each) [C `dist/theme/*.css`] | Theme packages, UnoCSS, `<style>` |
| Assets | PNG/JPEG/WebP/GIF, <=8 MiB each, <=50, <=24 MiB | Anything: SVG, video, audio, fonts | Anything, via `public/` or imports |
| Interactivity | Isolated demo iframes, self-contained, <=100,000 chars, explicit Run | Any script in page scope, any library | Vue components, npm dependencies |
| Size | <=150 entries, <=30 MiB, text <=2 MiB per file and <=6 MiB total | Measured: `dist/` without `.d.ts`/`.mjs` = 25 files, 3.57 MB; npm package = 111 files, 6.1 MB | Source ~3-20 files; `node_modules` 573 MB; `dist` 106 files, 2.1 MB |
| Build step | None | None | Required |
| Edit -> see | Immediate | Reload | Dev-server HMR; on the site: none |

Reveal.js version drift matters for any importer [D https://revealjs.com/upgrading/, npm registry]: 6.0.0 (2026-03-11) moved plugins from `plugin/<name>/<name>.js` to `dist/plugin/<name>.js` and renamed `.esm.js` to `.mjs`; latest is 6.0.2 (2026-09-10); 5.2.1 is 2025-03-28. [E] today: `https://unpkg.com/reveal.js/plugin/notes/notes.js` -> 404 (resolves to 6.0.2); `https://cdn.jsdelivr.net/npm/reveal.js/plugin/notes/notes.js` -> 200 but served from `x-jsd-version: 5.2.1` while `…/dist/reveal.js` is 6.0.2 (mixed majors); `…/reveal.js@6/plugin/notes/notes.js` -> 404. AI models trained before 2026 write the 4.x/5.x paths. (Agent B1 has the full CDN matrix.)

### 3.2 Auto-converting a standard deck INTO the lesson format: possible, very lossy [I, grounded in 2.2]

What maps: section order (vertical stacks flattened), headings, paragraphs, lists, tables, links, code blocks (language only), raster `<img>`, TeX delimiters left in text. What is lost, by construction of the target format: fragments (everything appears at once), speaker notes (must be dropped or they become visible text), backgrounds, transitions, auto-animate, vertical navigation, layout helpers, columns/grids/absolute positioning, every theme and custom style, SVG/video/audio/iframes, code line steps, and **all page-scope JavaScript** - which is the "interactions" of goal 3. Interactive widgets could be moved into `demos/*.html` only when they are self-contained in under 100,000 characters; common libraries do not fit inline (reveal.js itself is 118,912 bytes; the highlight plugin 920,644). Conclusion: conversion yields a text outline of the deck, not the deck.

### 3.3 Wrapping a standard deck for the EXISTING player: works after five mechanical rewrites [E5]

`proto/A2/scripts/wrap-reveal.mjs` (about 70 lines of string and Map operations, no bundler; 0.31-0.32 s per run including Node start-up) takes `reveal-standard.zip` and:

- T1 inlines 4 stylesheets as `<style>` (CSS `url()` -> `data:`),
- T2 inlines 6 scripts,
- T3 rewrites asset attributes including `data-background-image` to `data:` URIs (2 assets),
- T4 removes `hash: true` / `history: true` from the init call,
- T5 converts inline `on*` attributes into `addEventListener` calls (1 handler),

then writes `qft-presentation.json` with `engine: "slidev"` (the only value the validator accepts, `presentation-package.ts:258`). Output: `presentation.html` 1,795,514 bytes, ZIP 836,822 bytes.

| Variant | Player status | Message shown |
| --- | --- | --- |
| All five rewrites | "Playing locally" | none |
| Without T4 (`hash: true`, as in Reveal's own `index.html` template) | "Playback needs attention" | "Failed to execute 'replaceState' on 'History': A history state object with URL '' cannot be created in a document with origin 'null' and URL 'blob:null/…'." |
| Without T5 (`onclick` kept) | Plays; the button stays "Count: 0" | console only: inline event handler blocked by CSP |
| Without T3 (`<img src="assets/pixel.png">`) | "Playback needs attention" | "This presentation references an asset outside its HTML. Rebuild the portable package with its pictures, fonts, and media included." |
| CDN single file | "Playback needs attention" | "This presentation has separate JavaScript files. Create a portable ZIP with the Slidev packaging tool before opening it." |
| Plus `RevealMath.KaTeX` | "Playback needs attention" | "This presentation requested an unsupported resource (style-src-elem). Rebuild it with the portable Slidev packaging tool." (the plugin loads `https://cdn.jsdelivr.net/npm/katex@latest/dist/katex.min.css`) |
| Plus `RevealMath.MathJax3` or default `RevealMath` (MathJax 2) | "Playback needs attention" | Same with `script-src-elem` (`…/mathjax@3/es5/tex-mml-chtml.js`, `…/mathjax@2/MathJax.js?config=TeX-AMS_HTML-full`) |

Inside the fully wrapped deck these all worked (`out/e5-wrapped-reveal.json`, `out/e5d-math-backgrounds.json`): 11 slides counted; plugins `markdown, highlight, notes, search, zoom` registered; vertical navigation (1.0 -> 1.1); fragments; auto-animate (target `margin-top: 200px` reached); background colour `rgb(42, 157, 143)`; `data:` image background; highlighted code with a 3-row line-number table and a second highlight step; a Markdown slide with an `.element` fragment and `Note:` turned into `aside.notes`; `r-fit-text` (computed 560 px); `r-stack`; the converted button counted to 2; overview, pause, jump-to-slide, help overlay, search box. Import took 214-275 ms and start 468-644 ms [E10].

Two ordinary keys kill the deck because the player treats any uncaught error as fatal (`presentation-runtime.ts:127-131`, `:237-245`) [E5b]:
- **S** (speaker view): "Blocked opening 'about:blank' in a new window because the request was made in a sandboxed frame whose 'allow-popups' permission is not set." -> "Uncaught TypeError: Cannot set properties of null (setting 'marked')".
- **F** (fullscreen): "Permissions policy violation: fullscreen is not allowed in this document." -> "Disallowed by permissions policy" (the frame is created with `fullscreen 'none'`, `presentation-runtime.ts:260`).

What a wrapped deck still loses [I]: the speaker window, in-frame fullscreen (the host's Present button replaces it), URL deep links, external iframes and remote media (`frame-src 'none'`, `connect-src 'none'`), external Markdown (`data-markdown="file.md"` uses XHR) unless the importer inlines it, anything needing `eval` or WebAssembly (no `'unsafe-eval'` / `'wasm-unsafe-eval'` in the frame policy), and Reveal's math plugin unless the importer substitutes a local KaTeX.

The decisive property for goal 4: **in Reveal.js the source is the runtime**. Editing `index.html`, a CSS file or a script and re-running the 0.3 s inlining step gives the edited presentation; no compiler is involved. [E][I]

### 3.4 Slidev

- Into the lesson format: only the Markdown text between frontmatter blocks survives; layouts, slots, components, UnoCSS/HTML (escaped by `html: false`), click animations, code steps and presenter notes are lost; `/public` absolute image paths are rejected by `projectFilePath` (`lesson-project.ts:30-44`). The naive import already shows the result (2.4). [E][C]
- Into the player: needs a real build. The repo's answer is `tools/slidev/pack.mjs` (297 lines: esbuild bundles the module graph to one IIFE, parse5 inlines CSS and assets, `portable-runtime.js` shims storage/BroadcastChannel). The browser compiles nothing (`tools/slidev/vite.config.ts:3-4`). In-browser compilation is a separate research question (other agents).

## 4. Reusable assets for the new goal

| Asset | Where (lines) | What it does today | Generalises to arbitrary Reveal.js/Slidev projects? | What must be rewritten |
| --- | --- | --- | --- | --- |
| Project model | `src/lib/lesson-project.ts` (131) | `LessonProject {version:2, id, document, files[{path, content}], imagePaths[]}`; `safeProjectPath`, `projectFilePath` (relative resolution with traversal and URL rejection), `relativeProjectPath`; limits 150 entries, 2 MB per text file, 6 MB text | Path safety and resolution: yes, as is | Text whitelist `md, markdown, txt, json, html, htm, css, js` + README/LICENSE/NOTICE (`:24-27`) excludes `svg, vue, ts, yaml, scss, woff2, mp4`…; `document` must be Markdown (`:64`); binary files exist only as "images". Needs engine + entry file, generic binary assets, larger limits (a Reveal `dist/` is 25 files / 3.57 MB of mostly text, close to the 6 MB cap) |
| ZIP import/export | `src/lib/document-bundle.ts` (340) | fflate `unzipSync` with a filter enforcing limits; single-root-folder detection; manifest v1/v2; image reference rewriting that respects code and math; `zipSync` export | The skeleton and the root-folder heuristic: yes | Fatal on unknown types (`:306-308`); one-Markdown-file assumption (`:309-312`); 150-entry and 30 MB caps. The stricter central-directory audit in `presentation-package.ts:97-201` (CRC, overlap, ZIP64, symlinks, ratio) is the better base for untrusted archives |
| Storage | `src/lib/draft-store.ts` (327), `src/lib/presentation-store.ts` (189) | Drafts: one IndexedDB store, whole project inside the draft record, optimistic revision check in one transaction, conflict copies, BroadcastChannel. Presentations: separate database with the original ZIP Blob + metadata, no per-file state | Revision/conflict logic: yes | Two unrelated stores; packages are immutable blobs. Every autosave re-validates and rewrites the full record and compares projects with `JSON.stringify` (`markdown-workspace.ts:80-86`). Measured cost is small at today's cap: +70 ms per save for a 22 MB project (575-591 ms vs 504-518 ms cycle), storage constant at 20.6 MB [E12]. A file-level store is needed only if limits rise |
| "Lesson files" editor | `markdown-workspace.ts:1568-1603`, `TeacherWorkflow.astro:68-79` | Modal dialog, `<select>` of text files, one 300 px `<textarea>`, Save applies all edits atomically with stale-edit guards | The guards and the atomic apply: yes | No tree, no add/rename/delete, no binary handling, no syntax highlighting, modal (preview hidden while editing). CodeMirror is already bundled and `@codemirror/lang-html`, `lang-css`, `lang-javascript` are already installed and shipped as dependencies of `lang-markdown` (HTML grammar found in the 921 KB workspace chunk), so a real editor costs little weight; Vue would need `@codemirror/lang-vue` |
| Revision review | `src/lib/lesson-revision.ts` (63), `markdown-workspace.ts:1480-1566` | Path-level added/changed/removed with full before/after text; images compared by bytes; settings as a pseudo-file; update keeps a recovery draft; guards against concurrent edits | Almost entirely engine-agnostic | `portableLessonSource` is Markdown-image specific; no line diff (a bounded one exists: `cleanupDiff`, `src/lib/cleanup-review.ts:89-126`, 80,000 chars / 1,000 lines); needs an identity for projects without a manifest; not wired to Slidev packages at all |
| Static checker | `src/lib/lesson-check.ts` (136) | Re-renders the deck; regex checks on demo HTML for linked scripts/styles, frames, inline events, fetch/XHR/WebSocket/Worker/import, linked images, storage; formatted report for pasting to an AI | The idea and the report format: yes. These are exactly the checks "will this HTML run in the opaque sandbox" | Regex on text -> DOM parse in an inert template (as `preparePresentationDocument` already does); resolve every `src/href/url()` against the ZIP file map; classify CDN URLs (known and replaceable vs unknown); detect `hash: true`, external Markdown, Google Fonts, `eval`. Add runtime findings (sandbox errors, CSP violations) to the report. Detect foreign dialects |
| Demo sandbox | `public/demo-sandbox.html` (34), `src/scripts/interactive-demo-runtime.ts` (354) | Opaque iframe (`sandbox="allow-scripts"`), `document.write` of a prepared document <=160,000 chars, nonce + inline-only CSP, virtualised timers for pause/resume, canvas snapshot relay, error relay | Too small for a deck (reveal.js alone exceeds the 100,000-char source cap) | Keep for small demos. Port its pause/resume and snapshot ideas to the deck player |
| Presentation sandbox | `public/presentation-sandbox.html`, `src/lib/presentation-runtime.ts` (331) | Opaque runner -> `blob:` child, CSP, in-memory storage shim, error relay, 20 s timeout, <=26 M chars, Start/Stop/Restart, standalone export shell | **Yes - it already runs a full Reveal.js deck** [E5] | Engine check and 20+ "Slidev" strings (9 in the runtime, 13 in the library UI); fatal-on-first-error policy; `fullscreen 'none'` and no popups; no History shim; `script-src-attr 'none'` plus attribute stripping; assets must be `data:` (base64 +33%); no state bridge (current slide is lost on reload); math/CDN substitution |
| Slidev packager | `tools/slidev/pack.mjs` (297) | Node-side esbuild + parse5 inliner with licence collection | Its HTML/CSS inlining logic is the model for a browser-side Reveal importer | Node-only (fs, esbuild); for Reveal no bundler is needed |
| Exports | `document-bundle.ts:162-212`, `export-slides.ts`, `presentation-runtime.ts:324-331` | Project ZIP; one-file offline deck (reveal runtime + KaTeX fonts + demo runtime); one-file player for packages; print-to-PDF | ZIP writer and the "player shell around an opaque frame" export: yes | For a wrapped Reveal deck the inlined HTML is already a standalone file. PDF from inside an opaque sandbox is unsolved (`window.print` needs `allow-modals`) [I] |
| AI hand-off | `src/lib/ai-lesson.ts`, `src/lib/slidev-prompt.ts`, `TeacherWorkflow.astro` | Brief form -> prompt; starter ZIP; report loop; projectId-based revision | Brief form, starter idea, report loop: yes | Prompt bodies (74% and 72% format-specific) become short for standard Reveal.js, which models already know [I] |

App-shell constraints an in-browser pipeline must respect [E11]: the page CSP (`src/layouts/BaseLayout.astro:20-32`, delivered as `<meta>`) is `script-src 'self'` -> `eval`/`new Function` blocked, **WebAssembly blocked** in the page and in `blob:` workers ("…because 'unsafe-eval' is not an allowed source…"), `import(blobUrl)` blocked; allowed: `blob:` workers (`worker-src 'self' blob:`), `fetch` to any https host (`connect-src 'self' https: blob:`; jsDelivr returned 200 from page and worker), IndexedDB, OPFS (`navigator.storage.getDirectory()` ok), `frame-src 'self'` only. `crossOriginIsolated` is false and `SharedArrayBuffer` undefined. Because the policy is a meta tag in the site's own layout, adding `'wasm-unsafe-eval'` or `blob:` is a source change, not a hosting change.

## 5. Friction and failure points

### 5.1 Teacher with only a chat AI (no terminal)

1. **Asking for "Reveal.js slides" produces something the site cannot open.** A chat answer is normally one `index.html` with CDN links, sometimes a ZIP of it. Rows 1-7 and 25-26 of table 1.5: refused or mis-opened in every form. [E]
2. To succeed the teacher must discover "Create with AI", choose "Markdown", and paste an 833-word contract; the AI must then honour a format it has never seen. Observed and code-derived failure modes:
   - No ZIP capability: the site has no multi-file paste import. The workable fallback is single-file: paste the Markdown (Paste dialog), switch to Slides by hand (pasted text opens in Document mode with the toast "Your text is ready. Try Clean up or choose a PDF style."), and keep demos inline. A pasted `interactive src="demos/…"` fence yields "Import the lesson ZIP to load this separate demo file. A Markdown file alone does not include its demo code." [E9] The prompt recommends separate files and mentions inline fences only in its last INTERACTIVE DEMOS sentence.
   - Any extra file type (SVG diagram, `.py` plot script, `.csv`, `.ipynb`) aborts the import (rows 14-15). Chat AIs without image generation tend to produce SVG. [E][I]
   - Wrong image bytes abort the import (row 21). [E]
   - Kept placeholder id -> false "revision" of an unrelated lesson (row 24). [E]
   - Missing manifest or extra root file -> Document mode, no identity (rows 16, 22). [E]
   - Library-based demos (Chart.js, Plotly, D3, three.js) fail at Run; the 100,000-char cap rules out inlining them. Only hand-written canvas/DOM code works. [E][C]
   - `onclick=` handlers are stripped silently; only "Check lesson" mentions it. [C `interactive-demo-runtime.ts:207-210`]
   - Reveal/Marp/Slidev syntax from habit renders as text and passes the check (2.4). [E]
3. **Slidev is unreachable** unless the chat product can run npm. What the vendors document today:
   - Claude: "Code execution and file creation is available to all Claude users (Free, Pro, Max, Ultra, Team, and Enterprise)"; for individual plans "Network access is enabled, allowing Claude to install packages from approved sources"; approved package managers include npm (registry.npmjs.org); "The maximum file size is 30MB per file for both uploads and downloads." [D https://support.claude.com/en/articles/12111783-create-and-edit-files-with-claude]. Whether a 128 MB / 573 MB Slidev install fits that sandbox's time and disk limits was not tested. [U]
   - ChatGPT: a January 2026 write-up reports that its container runs Bash and Node.js and that "`pip install package` and `npm install package` both work now via a custom proxy mechanism" while general outbound requests stay blocked [S https://simonwillison.net/2026/Jan/26/chatgpt-containers/]. A user report dated 2026-08-02 says the internal npm registry returned HTTP 503 on July 24-25 and HTTP 404 on August 2, with no staff reply [S https://community.openai.com/t/chatgpt-container-internal-npm-registry-changed-from-http-503-to-http-404-npm-installs-remain-unavailable/1388749]. Current state unknown. [U]
   - Gemini: the Canvas help page documents export to Docs, Slides, PDF and Colab; it does not mention multi-file projects or ZIP download [D https://support.google.com/gemini/answer/16047321]. [U] for actual capability.
4. Every error on the Slidev side sends the teacher to "tools/slidev/README.md", a repository path with no link, and calls any website ZIP a Slidev problem. [E]
5. Demo interaction during class needs a "Run demo" click per demo, again after every edit and in every export. [E6][C]

### 5.2 User with a coding agent (terminal available)

1. Reveal.js: the agent can build a perfect standard project (`npm i reveal.js`, copy `dist/`), and the site still refuses it (rows 1-5). The agent succeeds only by abandoning Reveal.js for the site's Markdown dialect.
2. Slidev: works when the agent follows the starter exactly. Measured here (T1, 4 CPUs, Node 22.23.5, npm 10.9.9, empty npm cache): `npm ci` 10.8 s, 128 MB of tarballs, 573 MB `node_modules`, 751 lockfile packages; `npm run build` 3.7 s (rebuild 4.2 s); `node pack.mjs` 0.94 s -> `lesson.zip` 1,674,953 bytes with a 3,523,631-byte `presentation.html`. So the machine cost of one revision is about 5 s; the human cost is the download/upload/restart cycle and the loss of the current slide.
3. Where agents go wrong: starting from an ordinary Slidev project instead of the starter. [E] Running the repo's own packager on the default-config build in `shared/slidev-ordinary/dist` (and on `dist-relative`) fails at once: "Slidev packaging failed: External asset cannot be packaged: https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@200;400;600&family=Fira+Code:wght@200;400;600&display=swap. Bundle it during the Slidev build." So the site's advice for row 12 ("use the QFT Slidev packaging tool to bundle its scripts, fonts, and assets") does not work on a default build; the headmatter must first be changed to the portable profile (`fonts.provider: none`, `routerMode: memory`, …) and the deck rebuilt. Other packager stops [C `tools/slidev/pack.mjs:81, 104, 122, 164, 193`]: "The build still contains CSS @import. Bundle styles in Vite before packaging.", "Unbundled module …", "The built presentation contains <iframe>…", "Inline HTML event handlers are not supported." Delivering `dist/` or source is refused (rows 8, 12). Libraries that need workers, `eval`, or runtime fetch pass the build and fail in the player [C `tools/slidev/README.md:67-80`].
4. The agent cannot run the acceptance test the prompt demands ("Open the packaged presentation in md.qft.org, visit every slide…", `slidev-prompt.ts:37`) without driving a browser against the live site.
5. No revision support for packages: duplicates in the library, no diff, no identity (B7).

### 5.3 Both

- Two products behind one "Open file": drafts in the workspace versus packages in a modal library with a separate database; a Markdown lesson opened from the library's own picker is refused with "This is a Markdown lesson ZIP. Close this panel and use Open file in the workspace to edit it." (`presentation-library.ts:71`).
- Goal 4 is met only by Path A, and there only through a modal textarea.
- Goal 3 ("interactions") is met by Path A only inside isolated demo cards, and by Path B only for pre-built packages.

## 6. Improvement ideas

Effort: S <= 2 days, M <= 2 weeks, L <= 6 weeks, XL more. Ordered by value for the owner's goal.

| # | Idea | Effort | Impact | Why (evidence) |
| --- | --- | --- | --- | --- |
| 1 | **Native Reveal.js project import and playback.** Accept a standard ZIP or a single HTML file; in the browser: unzip -> find the entry -> rewrite local references (and known CDN URLs, see 2) -> inject a small compat shim (History no-op, `window.open`/fullscreen stubs) -> run in the existing opaque runner with a non-fatal error policy and an engine-neutral manifest/UI | L | Very high | E5: the existing player already runs a full 6.0.2 deck after five mechanical rewrites; import 0.2-0.3 s, start ~0.5 s. Today every standard deck is refused (1.5) |
| 2 | **Vendor Reveal.js and resolve CDN references locally.** Ship pinned copies (6.0.2 `dist/` is 3.57 MB; core + one theme + markdown/highlight/notes ~1.2 MB) and map `cdn.jsdelivr.net/npm/reveal.js…`, `unpkg.com/reveal.js…`, `cdnjs…/reveal.js/…` including the 4.x/5.x `plugin/<n>/<n>.js` layout; substitute a local KaTeX for `RevealMath` | M | Very high | The typical chat answer is a CDN single file; the math plugin is CDN-only and fatal (3.3); v6 path drift breaks unpinned URLs (3.1). The site already ships KaTeX 0.19.1 and reveal.js |
| 3 | **Edit-and-replay loop for Reveal projects.** File tree + CodeMirror (HTML/CSS/JS grammars already shipped) beside the player; on save re-inline and reload the frame; restore position through a postMessage bridge (`Reveal.getState()/setState()`) | M (after 1) | Very high | Source equals runtime in Reveal.js (3.3); this is goal 4 with no compiler |
| 4 | **Stop false successes and wrong-engine messages.** Detect Reveal decks (`class="reveal"`, `Reveal.initialize`), Slidev source (headmatter keys, `<v-click>`, `.vue`) and generic sites; never open a lone README/`slides.md` as a "lesson"; replace "tools/slidev/README.md" with a link and a next step | S | High | Rows 1, 3, 10, 11, 12 |
| 5 | **Make the checker dialect-aware and runtime-aware.** Warn on `<!-- .slide:`, `<!-- .element:`, `Note:`, `--`, raw HTML, Slidev frontmatter/components; append sandbox errors and CSP violations to the copyable report | S-M | High | E8/E13 false green; the report loop is the site's best AI-facing idea |
| 6 | **Teach the Markdown mode the Reveal.js Markdown conventions** (allowlisted): `Note:`, `<!-- .slide: … -->`, `<!-- .element: class="fragment" -->`, vertical `--`, code line steps; enable fragments, transitions, backgrounds from project images, overview, pause | M | High for Path A | Removes most of the 108-word SLIDE SYNTAX section and matches what "powered by reveal.js" promises (2.4). Does not deliver arbitrary HTML/JS decks |
| 7 | **Tolerant lesson import.** Skip unknown files with a listed warning instead of aborting; preserve them as opaque blobs; accept SVG as an image (sanitised or `<img>`-only); report the 150-entry limit truthfully | S (skip + warn) / M (preserve) | Medium-high | Rows 14, 15, 21, 23; doc mismatch (2.5 item 6) |
| 8 | **Prompt fixes.** Insert a real UUID generated at copy time instead of a valid-looking placeholder, or reject the placeholder; list allowed file types and state that others are dropped; offer a "single message, no ZIP" variant with inline demos; add a "Reveal.js" option whose prompt is a few lines once idea 1 exists | S | Medium-high | Row 24; 5.1 item 2; prompt is 74% format teaching (1.4) |
| 9 | **Multi-file paste import** for chat tools without files: accept one pasted message containing fenced blocks labelled with paths and build the project | S-M | Medium | 5.1 item 2 first bullet |
| 10 | **Non-fatal player policy and host-provided affordances.** Log errors instead of stopping; provide presenter notes and fullscreen from the host; allow inline handlers inside the opaque frame or convert them | S-M | High (prerequisite of 1) | S and F keys kill a deck (3.3) |
| 11 | **Line diff and per-file accept in revision review; extend review and identity to packages** (reuse `cleanupDiff`) | S-M | Medium | Textareas only (A7); packages duplicate (B7) |
| 12 | **One project model and store** for Markdown lessons, Reveal projects and Slidev packages: manifest with `engine`, per-file records including binaries, shared revision/recovery logic | L | High (structural) | Section 4 rows 1-3; two databases today |
| 13 | **Slidev: publish the packager** (`npx …` one-liner that works on any Slidev project, applying the portable profile itself) and return structured errors | M | Medium | 5.2 items 2-3; removes "copy these four files" |
| 14 | **Slidev source in the browser** (compile Vue/Markdown/UnoCSS client-side) | XL | High for goal 4 on Slidev | Requires at least `'wasm-unsafe-eval'` or pure-JS compilers and a module loader inside the sandbox (E11). Feasibility belongs to the prototype agents |
| 15 | **Fix the two Reveal integration defects**: ignore the page query string for the embedded deck; relax the `.katex-display` overflow test | S | Medium | 2.5 items 1-2 |
| 16 | **Auto-start and persistence for demos** (optional autoplay when the slide becomes active in Present; keep running demos across unrelated edits) | S-M | Medium | 5.1 item 5 |

## 7. Open questions

1. Should the Markdown dialect stay as a third format, or converge on Reveal's Markdown conventions so one mental model serves both?
2. Is downloading public library files (Reveal plugins, KaTeX, fonts) at import time compatible with "nothing is sent to a server"? No user content leaves the browser, but requests are made; vendoring avoids the question at a cost of roughly 1-4 MB of static files.
3. Which runtime errors should stop a third-party deck? Today all do.
4. How should a project without a manifest get a stable identity for revision review - a sidecar file added on export, a content hash, or the file name?
5. Is a presenter view required? The sandbox forbids pop-ups; the host could render notes itself.
6. PDF for arbitrary decks: print from an exported standalone file, or build a host-side print view?
7. Do current chat products reliably emit ZIPs and v6-style paths? (Corpus work by other agents.)
8. Storage quotas for video-heavy decks if the 30/60 MB caps are raised.
9. The app-shell CSP forbids WebAssembly and `eval`; is the owner willing to add `'wasm-unsafe-eval'` if an in-browser compiler needs it?

## 8. Appendix

### 8.1 Limits in code

| Limit | Value | Source |
| --- | --- | --- |
| Markdown source | 400,000 chars; 200 slides | `render-markdown.ts:22-23` |
| Lesson ZIP | 30 MiB, 150 entries, text file 2 MiB, manifest 32 KiB, image 8 MiB | `document-bundle.ts:12-14`, `:277-288` |
| Project text | 2 MiB per file, 6 MiB total, 150 entries | `lesson-project.ts:13-15` |
| Images | 8 MiB each, 24 MiB total, 50 | `image-assets.ts:11-13` |
| Demos | 20 per document, 100,000 chars each, 160,000 prepared | `interactive-demos.ts:9-10`, `interactive-demo-runtime.ts:235` |
| Presentation package | ZIP 60 MiB, expanded 120 MiB, HTML 24 MiB, file 40 MiB, 1,000 entries, source preview 2 MiB per file / 8 MiB | `presentation-package.ts:5-14` |
| Player | 26 M chars prepared, 20 s load timeout | `presentation-runtime.ts:60`, `:216`, `:272` |

### 8.2 Sizes measured

- Built site chunks: workspace 921,451 B; `dist.*.js` 374,954 B; export-slides 197,853 B; reveal (lazy) 118,470 B; presentation library 28,503 B; presentation-package 9,178 B; document-bundle 8,523 B; slide-preview 8,810 B.
- reveal.js 6.0.2: `dist/reveal.js` 118,912 B; `reveal.css` 53,963 B; plugins highlight 920,644 B, notes 67,789 B, markdown 49,498 B, math 4,015 B, search 2,870 B, zoom 2,877 B; themes 5-6 KB (remote fonts), 46 KB (beige, league, moon, solarized), 575 KB (black, white and their contrast variants).
- Exported Markdown deck (8 slides): 603,351 B. Wrapped standard deck: 1,795,514 B.

### 8.3 Timings

- Slidev starter, cold npm cache: `npm ci` 10.83 s; build 3.68 s; pack 0.94 s; rebuild 4.23 s (`out/slidev-timing.txt`).
- Player: wrapped Reveal import 214-275 ms, start 468-644 ms; portable Slidev import 349-367 ms, start 441-486 ms (3 runs each).
- Autosave cycle: 504-518 ms (tiny lesson) vs 572-591 ms (22 MB lesson); 500 ms of each is the debounce (`markdown-workspace.ts:302`).

### 8.4 Housekeeping

The static server on port 4410 and all browsers were stopped at the end of the session. The 573 MB timing install was deleted; logs remain in `out/`.
