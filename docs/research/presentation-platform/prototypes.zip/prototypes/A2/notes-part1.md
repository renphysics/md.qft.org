# A2 - Audit of the site's slide-authoring and AI hand-off features against the owner's goal

Agent A2, 2026-11-24. Repo: /home/user/md.qft.org at commit 974fa5e ("Add portable Slidev presentations with offline interactive playback (#1)"). Nothing in the repo was modified.

Owner's goal (the yardstick): (1) user asks an AI for Reveal.js or Slidev slides, (2) uploads the ZIP, processed locally, (3) the site shows the presentation with interactions, (4) the user edits source files in the browser and sees the edited presentation.

## 0. Method, labels, reproduction

Labels used on every claim:
- **[E]** verified-empirically: run here against the production build in `/home/user/md.qft.org/dist`, served read-only by `proto/A2/scripts/serve.mjs` on `http://127.0.0.1:4410`, driven by Playwright + headless Chromium 158 (viewport 1440x900 unless stated).
- **[C]** verified-primary-source, code: `file:line` in the repo (or in `node_modules/reveal.js` 6.0.2).
- **[D]** verified-primary-source, docs/registry: URL given.
- **[S]** secondary-source (blog/forum): URL given.
- **[I]** inferred. **[U]** uncertain.

Everything lives under `SCRATCH/research/` (called `$R` below):
- Scripts: `$R/proto/A2/scripts/` (run as `node scripts/<name> fixtures $R/shots` from `$R/proto/A2`; `lib.cjs` holds the Playwright helpers; `A2_BASE` overrides the URL).
- Fixtures (40 files): `$R/proto/A2/fixtures/` built by `make-fixtures.mjs`, `make-fixtures2.mjs`, `make-math-fixture.mjs`, `make-big-lesson.mjs`, `wrap-reveal.mjs`.
- Raw outputs: `$R/proto/A2/out/` (`e1-feature-probe.json`, `e2-keys.json`, `e3-export.json`, `e3b.log`, `e4-upload-matrix.json`, `e5-wrapped-reveal.json`, `e5d-math-backgrounds.json`, `e6-journey.log`, `e8.log`, `e8b.log`, `e9.log`, `e11.log`, `slidev-timing.txt`, the two prompts as copied by the UI: `ui-prompt-markdown.txt`, `ui-prompt-slidev.txt`, the UI's starter ZIPs, `export-probe-slides.html`, `interactive-physics.pdf`).
- Screenshots: `$R/shots/A2-*.png` (35 files).

Experiment index:

| Id | Script | What it establishes |
| --- | --- | --- |
| E1/E2 | `e1-feature-probe.cjs` | Which Reveal.js authoring conventions survive the Markdown slide mode; keys in preview and Present |
| E3 | `e3-export-html.cjs`, `e3b-export-keys.cjs` | Features of the standalone HTML export; navigation keys; URL-query override of the embedded deck; themes; 390 px viewport |
| E4 | `e4-upload-matrix.cjs` | What each kind of AI-returned file does when opened (20 cases, exact messages) |
| E5 | `wrap-reveal.mjs`, `e5-wrapped-reveal.cjs`, `e5b-debug-keys.cjs`, `e5d-math-and-backgrounds.cjs` | A standard Reveal.js 6.0.2 deck inlined into one HTML and played in the EXISTING portable player |
| E6 | `e6-journey.cjs` | The whole Create-with-AI journey through the UI, both formats, including Lesson files editing and revision review |
| E8 | `e8-slidev-md-and-pdf.cjs`, `e8b-pdf-overflow.cjs`, `e8c-overflow-detail.cjs` | Slidev Markdown opened in the editor; slide-PDF path; overflow false positive |
| E9 | `e9-misc.cjs` | Placeholder projectId collision, odd ZIP layouts, paste-only path, duplicate Slidev imports |
| E10 | `e10-start-latency.cjs` | Import and start latency of packages in the player |
| E11 | `e11-csp-capabilities.cjs`, `e11b-eval.cjs` | What the app shell CSP and the sandbox CSP allow (wasm, eval, workers, fetch) |
| E12 | `e12-autosave-cost.cjs` | Autosave cost of a 22 MB lesson project |
| E13/E14 | `e13-check-probe.cjs`, `e14-html-as-demo.cjs` | Check lesson on a foreign-dialect deck; Reveal HTML through the demo path |
| T1 | shell, see section 5.3 | Cold `npm ci` + `slidev build` + `pack.mjs` timings for the Slidev starter |

Files read completely: `src/lib/slides.ts`, `src/scripts/slide-preview.ts`, `src/lib/export-slides.ts`, `src/styles/slides.css`, `src/lib/lesson-project.ts`, `src/lib/document-bundle.ts`, `src/lib/lesson-check.ts`, `src/lib/lesson-revision.ts`, `src/lib/ai-lesson.ts`, `src/lib/slidev-prompt.ts`, `src/lib/interactive-demos.ts`, `src/scripts/interactive-demo-runtime.ts`, `public/demo-sandbox.html`, `src/components/TeacherWorkflow.astro`, `public/lesson-format-v2.md`, `public/lesson.schema.json`, `src/pages/guide.astro`, `src/lib/site-faq.ts`, `src/lib/examples.ts`, plus `src/lib/render-markdown.ts`, `src/lib/presentation-package.ts`, `src/lib/presentation-runtime.ts`, `src/lib/presentation-store.ts`, `src/lib/draft-store.ts`, `src/lib/image-assets.ts`, `src/lib/export-document.ts`, `src/lib/cleanup-review.ts`, `src/scripts/presentation-library.ts`, `src/scripts/markdown-workspace.ts` (2,175 lines; the lesson/AI parts line by line), the three Astro components, `tools/slidev/*` (README, pack.mjs, slides.md, portable-runtime.js, vite.config.ts, package.json), README.md, docs/ARCHITECTURE.md, docs/VERIFICATION.md, and the tests `slides`, `ai-lesson`, `slidev-prompt`, `lesson-check`, `lesson-revision`, `lesson-project`, `lesson-demos`, `demo-sandbox`.

## 1. The current "Create with AI" journey

### 1.1 Entry point and UI [C][E]

- Sidebar button "Create with AI" (`src/components/MarkdownWorkspace.astro:17`) opens one modal dialog (`src/components/TeacherWorkflow.astro:5-41`).
- First field: `Presentation format` select with exactly two options (`TeacherWorkflow.astro:11`): "Markdown — edit directly in this workspace" (value `qft`) and "Slidev — build interactive Vue slides with Codex" (value `slidev`). **There is no "Reveal.js" option**; the Reveal.js path of the site is the Markdown lesson.
- Other fields: topic (textarea, max 3,000 chars), audience (default "Undergraduate students"), class length (default 45 min), and under a disclosure: language (default English), mathematics (4 choices, default "Match the audience"), demos (optional).
- Buttons: "Copy AI instructions" (`copyAIInstructions`, `src/scripts/markdown-workspace.ts:1411-1425`), "Starter ZIP" (`starterLesson(true)`, `:1427-1454`), "Open AI lesson" (opens the normal file picker), "Try the starter in the workspace", link "Format guide for AI & developers" -> `/lesson-format-v2.md`.
- The dialog states "No account or API key needed. You choose the AI assistant." The site never calls a model (`src/lib/ai-lesson.ts:36` comment; no network code in either prompt module).
- The three-step aside names "Codex or another assistant" (`TeacherWorkflow.astro:33`). Screenshots: `$R/shots/A2-ai-dialog-markdown.png`, `A2-ai-dialog-slidev.png`.

### 1.2 Path A - Markdown lesson (the site's Reveal.js path)

| # | User does | AI must produce | Site validates | Where it fails (exact strings from E4/E6/E9) |
| --- | --- | --- | --- | --- |
| A1 | Opens the dialog, types a topic, clicks "Copy AI instructions" | - | Clipboard write; on failure the prompt is shown selected in a textarea (`markdown-workspace.ts:1406-1409`) | - |
| A2 | Optionally clicks "Starter ZIP" | - | Generated client-side (`createStarterLesson`, `ai-lesson.ts:198-263`): 5 entries, 9,067 bytes: `qft.json`, `slides.md` (7 slides, 184 words), `demos/explore.html` (4,829 chars sine-wave canvas demo), `LICENSE`, `README.md` [E] | - |
| A3 | Pastes the 833-word prompt into a chat/agent, attaches chapter + starter | A ZIP with `qft.json` (format `qft-markdown`, version 2, fresh `projectId`), `slides.md`, `images/*.{png,jpg,webp,gif}`, `demos/*.html` (each self-contained, <=100,000 chars, no CDN, no `onclick`), `README.md` | nothing (off-site) | AI that cannot emit a ZIP: the prompt's only fallback is "create the files in the working directory and give me their download links" (`ai-lesson.ts:58`). There is no multi-file paste import on the site (section 5.1). |
| A4 | "Open AI lesson" / "Open file" / drag-drop the ZIP | - | `openFile` (`markdown-workspace.ts:1372-1393`): first `inspectPresentationArchive` (is it a Slidev package?), then `importWorkspaceBundle` (`src/lib/document-bundle.ts:266-340`): ZIP <=30 MB, <=150 entries, safe unique paths, expanded <=30 MB, text file <=2 MB, `qft.json` <=32 KB, image <=8 MB; manifest fields; UTF-8 (fatal decode); Markdown <=400,000 chars; image magic bytes (`src/lib/image-assets.ts:53-60`); project limits (`src/lib/lesson-project.ts:60-97`) | See table 1.5. Typical: "This lesson contains an unsupported file: images/diagram.svg. Use Markdown, HTML, CSS, JavaScript, JSON, text, or PNG/JPEG/WebP/GIF images." / "This lesson project needs a valid projectId." / "A ZIP bundle must contain one Markdown document, or a QFT document manifest." |
| A5 | Sees the deck in Slides mode (`mode: "slides"` in manifest) with live diagnostics | - | Live render errors only: KaTeX failures and invalid/missing demo fences (`render-markdown.ts:193-198`, `interactive-demos.ts:180-198`). NOT checked on import: missing images, CDN-dependent demos, crowded slides | A ZIP without manifest opens in Document mode, not Slides [E]. Foreign syntax (Reveal/Slidev/Marp) shows as literal text with no error (section 2.4) |
| A6 | Clicks "Check lesson" (visible in Slides mode or for any project) | - | `checkLesson` (`src/lib/lesson-check.ts:33-125`), static only: source limit, empty lesson, render errors, image without alt text, remote image, missing image, demo with linked code / frames / inline events / network / linked images / storage, >1 demo per slide, >180 words per slide; max 100 issues | Starter: "The format check passed. Your lesson is ready for a rehearsal." [E]. A deck full of Reveal.js or Slidev syntax also passes (E8, E13) |
| A7 | "Copy report for AI", pastes it back, receives a revised ZIP, opens it | Same `projectId`, same paths | `projectId` match against stored drafts (`markdown-workspace.ts:1380-1382`) -> "Review this lesson update." dialog (`:1480-1505`, `src/lib/lesson-revision.ts`); "Update lesson" first stores a recovery draft "(before update)" (`:1533-1560`) | Two read-only textareas, no line diff (`TeacherWorkflow.astro:59-62`). A kept placeholder id collides across unrelated lessons (E9) |
| A8 | On each demo slide clicks "Run demo" | - | Runtime: opaque-origin iframe, CSP, `script[src]`/`link`/`iframe` removed, `on*` attributes removed (`src/scripts/interactive-demo-runtime.ts:198-229`) | CDN demo: "Demo error: Uncaught ReferenceError: Chart is not defined" [E]. Inline `onclick` buttons silently dead |
| A9 | Edits: Markdown in CodeMirror; demo HTML via "Edit demo" or "Lesson files" (modal with `<select>` + 300 px `<textarea>`) | - | `validateLessonProject`, stale-edit guards (`markdown-workspace.ts:1588-1603`) | Works: edited demo heading appeared after Save + Run demo [E6]. A running demo is reset to idle by any edit |
| A10 | "Present" (fullscreen overlay), then Download -> Project ZIP / Standalone HTML / Save PDF | - | PDF: per-slide overflow check before `window.print()` (`src/lib/export-slides.ts:270-280`) | The site's own "Quantum phase" example is refused: "Slides 3, 5 contain too much content for the selected slide size..." although both fit (section 2.5) |

Happy-path cost: about 8 actions on the site plus 4 in the AI tool. Each AI revision loop costs about 6 more (download Project ZIP, attach, download result, open, review, update). Measured [E6]: import of the starter is instant; "Lesson files" lists 4 editable files ("4 editable files · 0 images. Images stay in the project; use Insert image to add more.").

### 1.3 Path B - Slidev

| # | User does | AI must produce | Site validates | Where it fails |
| --- | --- | --- | --- | --- |
| B1 | Selects "Slidev" in the dialog; help text becomes "Your coding assistant builds the Slidev package. Open it here to present; revise its source and rebuild for changes." (`markdown-workspace.ts:1715-1721`) | - | - | The path presumes a coding agent with a terminal |
| B2 | "Copy AI instructions" (446 words) and "Starter ZIP" | - | Starter = the checked-in `public/slidev/interactive-physics.zip`, 1,674,968 bytes, 14 entries: `qft-presentation.json`, `presentation.html` (3.4 MB), `README.txt`, `THIRD_PARTY_NOTICES.txt` (1.2 MB), `source/` (slides.md, components/QuantumInterference.vue, pack.mjs, pack.test.mjs, portable-runtime.js, vite.config.ts, package.json, package-lock.json 355 KB, README.md, LICENSE) [E6] | - |
| B3 | Gives prompt + starter to a coding agent | In `source/`: edit `slides.md` and Vue components keeping the portable headmatter (`routerMode: memory`, `fonts.provider: none`, monaco/presenter/pwa/record off; `tools/slidev/slides.md:1-31`), then `npm ci`, `npm run build`, `node pack.mjs --dist .build --source . --out lesson.zip --title "..."` (`src/lib/slidev-prompt.ts:30-34`) | - | Needs Node >= 22.12 (`tools/slidev/package.json` engines), the npm registry (751 lockfile packages; 128 MB tarballs, 573 MB `node_modules`; T1), and a terminal. A chat-only AI cannot comply |
| B4 | "Open file" with `lesson.zip` | - | `inspectPresentationArchive` (`src/lib/presentation-package.ts:308-380`): ZIP <=60 MB, central-directory audit (no ZIP64/encryption/symlinks, methods 0/8, <=1,000 entries, <=40 MB per file, <=120 MB expanded, expansion ratio, overlap), exactly one `qft-presentation.json`, `format: qft-presentation`, `version: 1`, `engine: slidev` (`:258`), entry HTML present, <=24 MB, contains `<html` and `<body`, declared source present, CRC of every entry | Source-only: "This ZIP contains Slidev source, not a playable presentation. Ask the AI to build it with the QFT Slidev packaging tool, following tools/slidev/README.md, and include the compiled presentation." Ordinary `slidev build` dist: "This is a website build ZIP. Follow tools/slidev/README.md and use the QFT Slidev packaging tool to bundle its scripts, fonts, and assets for local playback." A lone `slides.md` (with or without ZIP) is silently opened as a Markdown **document** [E4] |
| B5 | Dialog "Slidev presentations" opens; "Start presentation" | - | `preparePresentationDocument` (`src/lib/presentation-runtime.ts:158-218`): rejects `script[src]`, `link[rel~=stylesheet]`, `iframe/object/embed`, import maps, any `src/href/poster/background/data` that is not `data:` or `#`; strips `on*`, `meta`, `base`, `link`, `title`. Runtime: opaque sandbox + CSP; any uncaught error, unhandled rejection or CSP violation stops playback (`:127-134`, `:237-245`); 20 s load timeout (`:270-272`) | Started in 427 ms [E6]; 441-486 ms over 3 runs [E10] |
| B6 | "Source files" tab | - | Read-only textarea per file (`src/scripts/presentation-library.ts:311-320`), "Copy source" | Note shown: "Source is preserved exactly as imported. Revise it with your editor or AI assistant, rebuild the presentation, then open the new ZIP. The compiled slides do not change when source files are edited elsewhere." Goal 4 is not met |
| B7 | Revision: back to the agent, rebuild, re-upload | Updated source and rebuilt HTML | none: no project identity | Every upload is stored as a new library row; the same ZIP twice gives two identical rows [E9]. No review, no diff, no recovery copy |

### 1.4 The generated prompts (verbatim) and their size [E][C]

Measured with the dialog defaults and the topic "Wave packets and the uncertainty principle"; the clipboard text equals `generateLessonPrompt()` / `generateSlidevPrompt()` output byte for byte (`out/ui-prompt-*.txt` vs `out/prompt-*.txt`).

| Prompt | Words | Characters | Lines | ~Tokens (chars/4) |
| --- | --- | --- | --- | --- |
| Markdown lesson (`src/lib/ai-lesson.ts:37-111`) | **833** | 5,613 | 72 | ~1,400 |
| Slidev (`src/lib/slidev-prompt.ts:4-38`) | **446** | 3,267 | 30 | ~820 |

Words per section - Markdown: intro 14, LESSON BRIEF 37, TEACHING GOALS 163, DELIVERABLE 138, SLIDE SYNTAX 108, INTERACTIVE DEMOS 241, COMPATIBILITY CHECK BEFORE DELIVERY 132. Slidev: intro 13, LESSON BRIEF 33, TEACHING AND DESIGN 81, USE THE WORKING STARTER 57, PORTABLE PLAYBACK REQUIREMENTS 113, BUILD AND DELIVER 87, VERIFY 62.

So 619 of 833 words (74%: DELIVERABLE + SLIDE SYNTAX + INTERACTIVE DEMOS + COMPATIBILITY CHECK) of the Markdown prompt and 319 of 446 (72%: STARTER + PORTABLE PLAYBACK + BUILD AND DELIVER + VERIFY) of the Slidev prompt teach the AI a site-specific format or build recipe rather than the lesson. The documents the prompts point to add 1,744 words (`public/lesson-format-v2.md`) and 973 words (`tools/slidev/README.md`). The check report that is pasted back is 69-72 words when clean (`formatLessonReport`, `lesson-check.ts:128-136`).

Markdown lesson prompt:

