// Wrap a standard multi-file Reveal.js project (index.html + dist/ + assets) as a qft-presentation ZIP
// by inlining every local stylesheet, script and asset. Pure string/Map logic so the same steps could
// run in the browser on an unzipped file map (no bundler, no build).  Usage:
//   node wrap-reveal.mjs <in.zip> <out.zip> [--keep-hash] [--keep-inline-handlers] [--keep-attr-assets]
import { createRequire } from 'node:module';
import { readFileSync, writeFileSync } from 'node:fs';
const require = createRequire('/home/user/md.qft.org/package.json');
const { unzipSync, zipSync, strToU8, strFromU8 } = require('fflate');
const [input, output, ...flags] = process.argv.slice(2);
const files = unzipSync(new Uint8Array(readFileSync(input)));
const entry = Object.keys(files).find((path) => /(^|\/)index\.html$/.test(path));
const root = entry.slice(0, -'index.html'.length);
const mime = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp', svg: 'image/svg+xml', woff2: 'font/woff2', woff: 'font/woff', ttf: 'font/ttf', mp4: 'video/mp4', webm: 'video/webm', mp3: 'audio/mpeg' };
const resolvePath = (reference, base) => {
  if (/^(?:[a-z][a-z0-9+.-]*:|\/\/|#)/i.test(reference)) return undefined;
  const parts = base.split('/').slice(0, -1);
  for (const part of reference.split(/[?#]/)[0].split('/')) { if (part === '..') parts.pop(); else if (part && part !== '.') parts.push(decodeURIComponent(part)); }
  return parts.join('/');
};
const stats = { stylesheets: 0, scripts: 0, assets: 0, missing: [], remote: [] };
const dataUrl = (reference, base) => {
  const path = resolvePath(reference, base);
  if (!path) { if (/^(?:https?:)?\/\//i.test(reference)) stats.remote.push(reference); return reference; }
  if (!files[path]) { stats.missing.push(path); return reference; }
  stats.assets += 1;
  return `data:${mime[path.split('.').pop().toLowerCase()] ?? 'application/octet-stream'};base64,${Buffer.from(files[path]).toString('base64')}`;
};
const inlineCss = (css, base) => css
  .replace(/@import\s+(?:url\()?["']?([^"')\s;]+)["']?\)?[^;]*;/g, (match, reference) => { const path = resolvePath(reference, base); if (!path || !files[path]) { stats.remote.push(reference); return ''; } return inlineCss(strFromU8(files[path]), path); })
  .replace(/url\(\s*["']?([^"')]+)["']?\s*\)/g, (match, reference) => /^data:/i.test(reference) ? match : `url("${dataUrl(reference, base)}")`);
let html = strFromU8(files[entry]);
if (!flags.includes('--keep-inline-handlers')) {
  // Convert inline on* handlers into addEventListener registrations (CSP: script-src-attr 'none').
  let serial = 0; const handlers = [];
  html = html.replace(/<([a-z][a-z0-9-]*)\b([^>]*?)\s(on[a-z]+)=(["'])([\s\S]*?)\4([^>]*)>/gi, (match, tag, before, name, quote, code, after) => {
    const id = `qft-h${++serial}`; handlers.push([id, name.slice(2), code]);
    return `<${tag}${before} data-qft-handler="${id}"${after}>`;
  });
  if (handlers.length) html = html.replace(/<\/body>/i, `<script>${handlers.map(([id, type, code]) => `document.querySelector('[data-qft-handler="${id}"]').addEventListener(${JSON.stringify(type)},function(event){${code}});`).join('')}</script></body>`);
  stats.handlers = handlers.length;
}
html = html.replace(/<link\b[^>]*rel=["']?stylesheet["']?[^>]*>/gi, (tag) => {
  const href = tag.match(/href=["']([^"']+)["']/i)?.[1];
  const path = href && resolvePath(href, entry);
  if (!path || !files[path]) { if (href) stats.remote.push(href); return tag; }
  stats.stylesheets += 1;
  return `<style>${inlineCss(strFromU8(files[path]), path)}</style>`;
});
html = html.replace(/<script\b([^>]*)\bsrc=["']([^"']+)["']([^>]*)>\s*<\/script>/gi, (tag, before, src, after) => {
  const path = resolvePath(src, entry);
  if (!path || !files[path]) { stats.remote.push(src); return tag; }
  stats.scripts += 1;
  return `<script${/type=["']module["']/.test(before + after) ? ' type="module"' : ''}>${strFromU8(files[path]).replace(/<\/script/gi, '<\\/script')}</script>`;
});
if (!flags.includes('--keep-attr-assets')) html = html.replace(/\b(src|poster|data-src|data-background-image|data-background-video|data-background|data-preview-image|data-preview-video)=(["'])([^"']+)\2/gi,
  (match, name, quote, value) => /^(?:data:|#|https?:|\/\/)/i.test(value) || !/\.[a-z0-9]{2,5}(?:[?#].*)?$/i.test(value) ? match : `${name}=${quote}${dataUrl(value, entry)}${quote}`);
if (!flags.includes('--keep-hash')) html = html.replace(/\bhash\s*:\s*true\s*,?/g, '').replace(/\bhistory\s*:\s*true\s*,?/g, '');
const title = html.match(/<title>([^<]*)<\/title>/i)?.[1]?.trim() || 'Reveal.js presentation';
const out = { 'qft-presentation.json': strToU8(JSON.stringify({ format: 'qft-presentation', version: 1, engine: 'slidev', title, entry: 'presentation.html', aspectRatio: '16:9', generator: 'a2-reveal-wrap-probe' }, null, 2)), 'presentation.html': strToU8(html) };
for (const [path, bytes] of Object.entries(files)) if (/\.(?:html|md|css)$/.test(path) && !/(^|\/)dist\//.test(path)) out[`source/${path.slice(root.length)}`] = bytes;
writeFileSync(output, zipSync(out, { level: 6 }));
console.log(JSON.stringify({ output: output.split('/').pop(), htmlBytes: Buffer.byteLength(html), zipBytes: readFileSync(output).length, ...stats, flags }));
