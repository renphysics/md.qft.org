// E8: (a) Slidev slides.md opened in the Markdown editor; (b) slide PDF page count; (c) help overlay; (d) footnote section quirk.
const { launch, openApp, openFile, state } = require('./lib.cjs');
const { join, resolve } = require('node:path');
const { writeFileSync } = require('node:fs');
const fixtures = resolve(process.argv[2]);
const shots = process.argv[3];
const out = resolve(fixtures, '../out');
(async () => {
  const browser = await launch();
  { // (a)
    const { context, page } = await openApp(browser);
    await openFile(page, join(fixtures, 'slidev-slides.md'), 1500);
    await page.screenshot({ path: join(shots, 'A2-slidev-md-document-mode.png') });
    await page.locator('[data-content-mode="slides"]').click();
    await page.waitForTimeout(1500);
    const info = await page.evaluate(() => ({ pos: document.querySelector('[data-slide-position]').textContent, slides: [...document.querySelectorAll('.qft-slide-deck .slides > section')].map((s, i) => `${i + 1}: ${s.innerText.replace(/\s+/g, ' ').slice(0, 200)}`), headings: [...document.querySelectorAll('.qft-slide-deck h1, .qft-slide-deck h2')].map((h) => `${h.tagName}:${h.textContent}`) }));
    console.log('SLIDEV MD IN SLIDES MODE', JSON.stringify(info, null, 1));
    await page.screenshot({ path: join(shots, 'A2-slidev-md-slides-mode-1.png') });
    await page.locator('[data-slide-next]').click(); await page.waitForTimeout(300);
    await page.screenshot({ path: join(shots, 'A2-slidev-md-slides-mode-2.png') });
    await page.locator('[data-lesson-check]').click(); await page.waitForTimeout(300);
    console.log('SLIDEV MD CHECK LESSON', JSON.stringify(await page.evaluate(() => ({ result: document.querySelector('[data-lesson-check-result]').textContent, items: [...document.querySelectorAll('[data-lesson-check-list] li')].map((li) => li.textContent) }))));
    await context.close();
  }
  { // (b) slide PDF through the site's own print path
    const { context, page } = await openApp(browser);
    await page.addInitScript(() => {});
    await openFile(page, join(fixtures, 'lesson-reveal-conventions.zip'), 2500);
    await page.evaluate(() => { window.__printCalls = 0; window.print = () => { window.__printCalls += 1; }; });
    await page.locator('[data-pdf]').click(); await page.waitForTimeout(400);
    console.log('SLIDE PDF DIALOG', JSON.stringify(await page.evaluate(() => ({ count: document.querySelector('[data-slide-pdf-count]')?.textContent, ratio: document.querySelector('[data-slide-pdf-ratio]')?.textContent, warning: document.querySelector('[data-slide-pdf-warning]')?.hidden ? null : document.querySelector('[data-slide-pdf-warning]')?.textContent, description: document.querySelector('[data-slide-pdf-description]')?.textContent }))));
    await page.locator('[data-slide-print]').click(); await page.waitForTimeout(1500);
    const s = await state(page);
    console.log('AFTER SAVE PDF', JSON.stringify({ printCalls: await page.evaluate(() => window.__printCalls), toast: s.toast, printing: await page.evaluate(() => document.body.dataset.qftPrinting || null) }));
    await context.close();
    // a deck that fits: the built-in quantum example
    const second = await openApp(browser, { url: 'http://127.0.0.1:4410/?example=quantum-slides' });
    await second.page.waitForTimeout(2000);
    await second.page.evaluate(() => { window.__printCalls = 0; window.print = () => { window.__printCalls += 1; }; });
    await second.page.locator('[data-pdf]').click(); await second.page.waitForTimeout(400);
    await second.page.locator('[data-slide-print]').click(); await second.page.waitForTimeout(2000);
    const printing = await second.page.evaluate(() => ({ calls: window.__printCalls, flag: document.body.dataset.qftPrinting || null, copies: document.querySelectorAll('.qft-print-slides .slides > section').length }));
    console.log('QUANTUM EXAMPLE PRINT', JSON.stringify(printing), JSON.stringify((await state(second.page)).toast));
    if (printing.flag) {
      await second.page.emulateMedia({ media: 'print' });
      const pdf = await second.page.pdf({ preferCSSPageSize: true, printBackground: true });
      writeFileSync(join(out, 'quantum-slides.pdf'), pdf);
      const text = pdf.toString('latin1');
      console.log('PDF bytes', pdf.length, 'pages', (text.match(/\/Type\s*\/Page[^s]/g) || []).length, 'mediabox', text.match(/\/MediaBox\s*\[[^\]]+\]/)?.[0]);
    }
    await second.context.close();
  }
  await browser.close();
})();
