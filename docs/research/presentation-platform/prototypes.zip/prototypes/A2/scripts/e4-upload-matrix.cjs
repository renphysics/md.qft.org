// E4: what the built site does with each kind of ZIP/file an AI may hand back.
const { launch, openApp, state, openFile } = require('./lib.cjs');
const { join } = require('node:path');
const { writeFileSync } = require('node:fs');
const fixtures = process.argv[2];
const shared = 'SCRATCH/research/shared';
const cases = [
  ['reveal-standard.zip'], ['reveal-standard-folder.zip'], ['reveal-standard-readme.zip'], ['reveal-standard-two-md.zip'], ['reveal-npm-package.zip'],
  ['reveal-cdn-single.zip'], ['reveal-cdn-single.html'],
  ['slidev-source.zip'], ['slidev-source-no-pkg.zip'], ['slidev-md-only.zip'], ['slidev-slides.md'], ['slidev-dist.zip'], ['slidev-dist-relative.zip'],
  ['lesson-with-svg.zip'], ['lesson-with-py.zip'], ['lesson-no-manifest.zip'], ['lesson-missing-projectid.zip'], ['lesson-cdn-demo.zip'], ['lesson-ok.zip'],
  [join(shared, 'slidev-starter/lesson.zip'), 'slidev-starter/lesson.zip (portable package)'],
];
(async () => {
  const browser = await launch();
  const results = [];
  for (const [file, label] of cases) {
    const { context, page, logs } = await openApp(browser);
    const path = file.startsWith('/') ? file : join(fixtures, file);
    let error = null;
    try { await openFile(page, path, 2500); } catch (e) { error = String(e).slice(0, 300); }
    const result = { file: label || file, error, ...(await state(page)), logs: logs.slice(0, 4) };
    results.push(result);
    console.log('\n=== ' + result.file);
    console.log(JSON.stringify({ toast: result.toast, dialogs: result.dialogs, presNotice: result.presNotice, presTitle: result.presTitle, presSubtitle: result.presSubtitle, title: result.title, mode: result.mode, slidePosition: result.slidePosition, diagnostics: result.diagnostics, lessonFilesVisible: result.lessonFilesVisible, source: result.source, error, logs: result.logs }, null, 1));
    await context.close();
  }
  writeFileSync(join(fixtures, '../out/e4-upload-matrix.json'), JSON.stringify(results, null, 2));
  await browser.close();
})();
