const { launch, openApp, openFile, state } = require('./lib.cjs');
const { join, resolve } = require('node:path');
const fixtures = resolve(process.argv[2]);
(async () => {
  const browser = await launch();
  for (const file of ['lesson-ok.zip', 'lesson-big.zip']) {
    const { context, page } = await openApp(browser);
    const usage = async () => page.evaluate(async () => Math.round((await navigator.storage.estimate()).usage / 1024));
    const u0 = await usage();
    const t0 = Date.now();
    await openFile(page, join(fixtures, file), 200);
    await page.waitForFunction(() => /Lesson opened|could not|exceed|too large/.test(document.querySelector('[data-toast]')?.textContent || ''), null, { timeout: 60000 });
    const importMs = Date.now() - t0;
    const s = await state(page);
    await page.waitForTimeout(1500);
    const u1 = await usage();
    const saves = [];
    for (let i = 0; i < 5; i++) {
      await page.locator('[data-editor] .cm-content').click();
      await page.keyboard.press('End'); await page.keyboard.type('x');
      const t = Date.now();
      await page.waitForFunction(() => document.querySelector('[data-save-label]').textContent === 'Saving in this browser…', null, { timeout: 5000 }).catch(() => {});
      await page.waitForFunction(() => document.querySelector('[data-save-label]').textContent === 'Saved in this browser', null, { timeout: 60000 });
      saves.push(Date.now() - t);
    }
    await page.waitForTimeout(500);
    console.log(file, JSON.stringify({ toast: s.toast, importMs, usageKB: { before: u0, afterImport: u1, afterFiveEdits: await usage() }, saveCycleMs: saves }));
    await context.close();
  }
  await browser.close();
})();
