// E11: what the app shell and the two sandboxes allow (capabilities an in-browser build pipeline would need).
const { launch, openApp, openFile } = require('./lib.cjs');
const { join, resolve } = require('node:path');
const fixtures = resolve(process.argv[2]);
const probe = async () => {
  const out = {};
  const attempt = async (name, fn) => { try { out[name] = await fn(); } catch (error) { out[name] = 'BLOCKED: ' + String(error?.message || error).slice(0, 170); } };
  await attempt('wasm', async () => { await WebAssembly.instantiate(new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0])); return 'ok'; });
  await attempt('eval', async () => (0, eval)('1+1'));
  await attempt('newFunction', async () => new Function('return 2')());
  await attempt('blobWorker', () => new Promise((resolve, reject) => { const w = new Worker(URL.createObjectURL(new Blob(['postMessage(1)'], { type: 'text/javascript' }))); w.onmessage = () => resolve('ok'); w.onerror = (e) => reject(new Error('worker error ' + (e.message || ''))); setTimeout(() => reject(new Error('timeout')), 2500); }));
  await attempt('fetchSelf', async () => (await fetch(location.origin === 'null' ? 'http://127.0.0.1:4410/robots.txt' : '/robots.txt')).status);
  await attempt('fetchCdn', async () => (await fetch('https://cdn.jsdelivr.net/npm/reveal.js@6.0.2/package.json')).status);
  await attempt('indexedDB', () => new Promise((resolve, reject) => { const r = indexedDB.open('a2-probe'); r.onsuccess = () => { r.result.close(); resolve('ok'); }; r.onerror = () => reject(r.error); }));
  await attempt('localStorage', async () => { localStorage.setItem('a2', '1'); return 'ok(' + localStorage.constructor?.name + ')'; });
  await attempt('opfs', async () => { await navigator.storage.getDirectory(); return 'ok'; });
  await attempt('serviceWorkerApi', async () => ('serviceWorker' in navigator) ? 'api present' : 'absent');
  await attempt('blobModuleImport', async () => { const u = URL.createObjectURL(new Blob(['export default 7'], { type: 'text/javascript' })); return (await import(u)).default; });
  await attempt('dynamicInlineScript', () => new Promise((resolve) => { const s = document.createElement('script'); s.textContent = 'window.__dyn = 5'; document.head.append(s); resolve(window.__dyn === 5 ? 'ok' : 'BLOCKED (inline script without nonce)'); }));
  await attempt('windowOpen', async () => { const w = window.open('about:blank'); return w ? 'opened' : 'null'; });
  out.origin = self.origin; out.crossOriginIsolated = self.crossOriginIsolated; out.sab = typeof SharedArrayBuffer;
  return out;
};
(async () => {
  const browser = await launch();
  const { context, page } = await openApp(browser);
  console.log('APP SHELL', JSON.stringify(await page.evaluate(probe), null, 1));
  // presentation sandbox (blob child) via the wrapped reveal deck
  await openFile(page, join(fixtures, 'reveal-wrapped.zip'), 2000);
  await page.locator('[data-pres-start-button]').click();
  await page.waitForFunction(() => /Playing|attention/.test(document.querySelector('[data-pres-player-status]')?.textContent || ''), null, { timeout: 30000 });
  await page.waitForTimeout(800);
  const runner = page.frames().find((f) => f.url().includes('presentation-sandbox'));
  const deck = page.frames().find((f) => f.url().startsWith('blob:'));
  // run only non-fatal probes inside the deck frame (CSP violations there would stop playback)
  console.log('PRESENTATION RUNNER FRAME csp', JSON.stringify(await runner.evaluate(() => [...document.querySelectorAll('meta[http-equiv]')].map((m) => m.content))));
  console.log('DECK FRAME csp', JSON.stringify(await deck.evaluate(() => ({ csp: [...document.querySelectorAll('meta[http-equiv]')].map((m) => m.content), origin: self.origin, storage: (() => { try { return localStorage.constructor.name + ':' + typeof localStorage.setItem; } catch (e) { return 'throws ' + e.name; } })(), fullscreenEnabled: document.fullscreenEnabled, crossOriginIsolated: self.crossOriginIsolated }))));
  await context.close();
  await browser.close();
})();
