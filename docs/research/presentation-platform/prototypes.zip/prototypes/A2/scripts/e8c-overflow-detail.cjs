const { launch, openApp } = require('./lib.cjs');
const { join } = require('node:path');
const shots = process.argv[2];
(async () => {
  const browser = await launch();
  const { context, page } = await openApp(browser, { url: 'http://127.0.0.1:4410/?example=quantum-slides' });
  await page.waitForTimeout(2500);
  for (let slide = 1; slide <= 5; slide++) {
    await page.evaluate(() => document.fonts.ready);
    await page.waitForTimeout(500);
    const info = await page.evaluate(() => {
      const section = document.querySelector('.qft-slide-deck .slides > section.present');
      const content = section.querySelector('.qft-slide-content');
      const metric = (el) => ({ el: (el.className.split(' ')[0] || el.tagName), sh: el.scrollHeight, ch: el.clientHeight, sw: el.scrollWidth, cw: el.clientWidth });
      const last = content.lastElementChild.getBoundingClientRect(); const box = content.getBoundingClientRect();
      return { content: metric(content), flagged: [...content.querySelectorAll('pre,.katex-display,table')].map(metric), previewNotice: !document.querySelector('[data-slide-overflow]').hidden, lastChildBottomVsBox: Math.round(box.bottom - last.bottom), katexFonts: [...document.fonts].filter((f) => f.status === 'loaded' && /KaTeX/.test(f.family)).length };
    });
    console.log('slide', slide, JSON.stringify(info));
    if (slide === 3 || slide === 5) await page.locator('[data-slide-stage]').screenshot({ path: join(shots, `A2-quantum-slide-${slide}.png`) });
    await page.locator('[data-slide-next]').click().catch(() => {});
  }
  await browser.close();
})();
