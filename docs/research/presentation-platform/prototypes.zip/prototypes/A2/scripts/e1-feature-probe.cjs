// E1/E2: which standard Reveal.js authoring features survive the site's Markdown slide mode.
const { launch, openApp, state, openFile } = require('./lib.cjs');
const { join } = require('node:path');
const { writeFileSync } = require('node:fs');
const fixtures = process.argv[2];
const shots = process.argv[3];
(async () => {
  const browser = await launch();
  const { context, page, logs } = await openApp(browser);
  await openFile(page, join(fixtures, 'lesson-reveal-conventions.zip'), 3000);
  console.log('state', JSON.stringify(await state(page), null, 1));
  const dom = await page.evaluate(() => {
    const deck = document.querySelector('.qft-slide-deck');
    const reveal = deck.querySelector('.reveal');
    const slides = [...deck.querySelectorAll('.slides > section')];
    const q = (selector) => deck.querySelectorAll(selector).length;
    return {
      topLevelSections: slides.length,
      nestedSections: q('.slides > section section'),
      revealClasses: reveal.className,
      slidesHtmlBytes: deck.querySelector('.slides').innerHTML.length,
      fragmentElements: q('.fragment'),
      asideNotes: q('aside.notes'),
      slideDataAttributes: slides.map((s) => [...s.attributes].map((a) => a.name).filter((n) => n.startsWith('data-') && !['data-slide-index', 'data-index-h', 'data-index-v'].includes(n))),
      backgrounds: [...reveal.querySelectorAll('.backgrounds .slide-background')].map((b) => b.getAttribute('style') || '').filter(Boolean).length,
      backgroundElements: reveal.querySelectorAll('.backgrounds .slide-background').length,
      rFitText: q('.r-fit-text'), rStack: q('.r-stack'), rStretch: q('.r-stretch'),
      video: q('video'), iframe: q('iframe'), img: q('img'), style: q('style'), script: q('script'),
      codeBlocks: [...deck.querySelectorAll('pre code')].map((c) => ({ cls: c.className, lineNumbers: c.getAttribute('data-line-numbers'), hljsSpans: c.querySelectorAll('span[class^="hljs"]').length, tableRows: c.querySelectorAll('tr').length })),
      previewAttrs: q('[data-preview-link],[data-preview-image]'),
      katex: q('.katex'), tables: q('table'), footnotes: q('.footnotes'),
      controls: !!reveal.querySelector('.controls') && getComputedStyle(reveal.querySelector('.controls')).display,
      progress: !!reveal.querySelector('.progress') && getComputedStyle(reveal.querySelector('.progress')).display,
      slideNumber: !!reveal.querySelector('.slide-number') && getComputedStyle(reveal.querySelector('.slide-number')).display,
      speakerNotesEl: !!reveal.querySelector('.speaker-notes'),
      probeScriptRan: window.__probeScriptRan === true,
      perSlideText: slides.map((s, i) => `${i + 1}: ${s.innerText.replace(/\s+/g, ' ').slice(0, 230)}`),
      slide4Html: slides[3]?.innerHTML.slice(0, 700),
      slide3Html: slides[2]?.innerHTML.slice(0, 900),
      slide6Html: slides[5]?.innerHTML.slice(0, 1600),
    };
  });
  console.log(JSON.stringify(dom, null, 1));
  writeFileSync(join(fixtures, '../out/e1-feature-probe.json'), JSON.stringify(dom, null, 2));
  // Screenshots of the preview for a few slides
  const next = page.locator('[data-slide-next]');
  for (let i = 1; i <= 9; i++) {
    await page.locator('[data-slide-stage]').screenshot({ path: join(shots, `A2-probe-slide-${String(i).padStart(2, '0')}.png`) });
    if (await next.isEnabled()) await next.click(); else break;
    await page.waitForTimeout(250);
  }
  // Keyboard features: embedded preview first, then Present overlay
  const keyProbe = async (label) => {
    const out = {};
    const read = () => page.evaluate(() => {
      const reveal = document.querySelector('.qft-slide-deck .reveal');
      return { cls: reveal.className.replace(/\s+/g, ' '), pos: document.querySelector('[data-slide-position]')?.textContent, overlay: !!document.querySelector('.qft-slide-presentation'), fs: !!document.fullscreenElement,
        help: !!document.querySelector('.r-overlay-help, .overlay-help, .r-overlay'), jump: !!document.querySelector('.jump-to-slide'), pausedOverlay: !!reveal.querySelector('.pause-overlay') && getComputedStyle(reveal.querySelector('.pause-overlay')).visibility };
    });
    await page.locator('.qft-slide-deck .reveal').focus();
    out.start = await read();
    for (const key of ['ArrowRight', 'ArrowDown', 'Space', 'n', 'PageDown', 'ArrowLeft', 'Home', 'End', 'o', 'Escape', 'f', 'b', '.', 'g', '?', 's', 'z']) {
      const pagesBefore = context.pages().length;
      await page.locator('.qft-slide-deck .reveal').focus().catch(() => {});
      await page.keyboard.press(key);
      await page.waitForTimeout(250);
      const after = await read();
      out[key] = { pos: after.pos, overview: /\boverview\b/.test(after.cls), paused: /\bpaused\b/.test(after.cls), help: after.help, jump: after.jump, overlay: after.overlay, fs: after.fs, newWindows: context.pages().length - pagesBefore };
      if (label === 'present' && !after.overlay) { out[key].note = 'left Present'; await page.locator('[data-slide-present]').click(); await page.waitForTimeout(400); }
    }
    console.log(`\nKEYS (${label})`); for (const [k, v] of Object.entries(out)) console.log(' ', k.padEnd(11), JSON.stringify(v));
    return out;
  };
  const embedded = await keyProbe('embedded');
  await page.locator('[data-slide-present]').click();
  await page.waitForTimeout(600);
  await page.screenshot({ path: join(shots, 'A2-probe-present.png') });
  const presenting = await keyProbe('present');
  writeFileSync(join(fixtures, '../out/e2-keys.json'), JSON.stringify({ embedded, presenting }, null, 2));
  console.log('logs', logs.slice(0, 10));
  await browser.close();
})();
