const { launch, openApp, openFile } = require('./lib.cjs');
const { join, resolve } = require('node:path');
const fixtures = resolve(process.argv[2]);
(async () => {
  const browser = await launch();
  const { page } = await openApp(browser);
  await openFile(page, join(fixtures, 'lesson-reveal-conventions.zip'), 2500);
  await page.locator('[data-lesson-check]').click(); await page.waitForTimeout(300);
  console.log(await page.evaluate(() => document.querySelector('[data-lesson-report]').value));
  await browser.close();
})();
