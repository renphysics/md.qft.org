const { launch, openApp, openFile } = require('./lib.cjs');
const { join, resolve } = require('node:path');
const fixtures = resolve(process.argv[2]);
const shared = 'SCRATCH/research/shared';
(async () => {
  const browser = await launch();
  for (const [label, file] of [['wrapped reveal (1.8 MB html)', join(fixtures, 'reveal-wrapped.zip')], ['portable slidev (3.4 MB html)', join(shared, 'slidev-starter/lesson.zip')]]) {
    const times = [];
    for (let run = 0; run < 3; run++) {
      const { context, page } = await openApp(browser);
      const t0 = Date.now();
      await page.setInputFiles('[data-file-input]', file);
      await page.waitForSelector('[data-pres-dialog][open] [data-pres-start-button]', { timeout: 20000 });
      const t1 = Date.now();
      await page.locator('[data-pres-start-button]').click();
      await page.waitForFunction(() => /Playing|attention/.test(document.querySelector('[data-pres-player-status]')?.textContent || ''), null, { timeout: 30000 });
      times.push({ importMs: t1 - t0, startMs: Date.now() - t1, status: await page.evaluate(() => document.querySelector('[data-pres-player-status]').textContent) });
      await context.close();
    }
    console.log(label, JSON.stringify(times));
  }
  await browser.close();
})();
