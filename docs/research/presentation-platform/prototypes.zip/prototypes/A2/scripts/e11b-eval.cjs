const { launch, openApp } = require('./lib.cjs');
(async () => {
  const browser = await launch();
  const { context, page, logs } = await openApp(browser);
  const result = await page.evaluate(() => new Promise((resolve) => setTimeout(async () => {
    const out = {};
    try { out.eval = String((0, eval)('1+1')); } catch (e) { out.eval = 'BLOCKED: ' + e.message.slice(0, 140); }
    try { out.newFunction = String(new Function('return 2')()); } catch (e) { out.newFunction = 'BLOCKED: ' + e.message.slice(0, 140); }
    out.workerWasm = await new Promise((done) => {
      const code = 'WebAssembly.instantiate(new Uint8Array([0,97,115,109,1,0,0,0])).then(()=>postMessage("wasm ok"),e=>postMessage("BLOCKED: "+String(e.message).slice(0,150)))';
      const w = new Worker(URL.createObjectURL(new Blob([code], { type: 'text/javascript' })));
      w.onmessage = (e) => done(e.data); w.onerror = (e) => done('worker error ' + e.message); setTimeout(() => done('timeout'), 3000);
    });
    out.workerFetchCdn = await new Promise((done) => {
      const code = 'fetch("https://cdn.jsdelivr.net/npm/reveal.js@6.0.2/package.json").then(r=>postMessage("status "+r.status),e=>postMessage("BLOCKED: "+String(e.message).slice(0,120)))';
      const w = new Worker(URL.createObjectURL(new Blob([code], { type: 'text/javascript' })));
      w.onmessage = (e) => done(e.data); w.onerror = (e) => done('worker error ' + e.message); setTimeout(() => done('timeout'), 8000);
    });
    resolve(out);
  }, 0)));
  console.log(JSON.stringify(result, null, 1), logs.slice(0, 3).map((l) => l.slice(0, 200)));
  await browser.close();
})();
