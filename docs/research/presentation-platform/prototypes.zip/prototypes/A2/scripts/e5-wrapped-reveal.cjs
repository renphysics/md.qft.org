// E5: does a standard Reveal.js deck, inlined into one HTML, run in the EXISTING portable player?
const { launch, openApp, state, openFile } = require('./lib.cjs');
const { join, resolve } = require('node:path');
const { writeFileSync } = require('node:fs');
const fixtures = resolve(process.argv[2]);
const shots = process.argv[3];
const out = resolve(fixtures, '../out');
async function play(browser, file, interact) {
  const { context, page, logs } = await openApp(browser);
  await openFile(page, join(fixtures, file), 2500);
  const before = await state(page);
  const result = { file, opened: before.presTitle, subtitle: before.presSubtitle, toast: before.toast, notice: before.presNotice };
  if (before.presTitle) {
    await page.locator('[data-pres-start-button]').click();
    await page.waitForFunction(() => !/Opening/.test(document.querySelector('[data-pres-player-status]')?.textContent || 'Opening'), null, { timeout: 30000 }).catch(() => {});
    await page.waitForTimeout(1500);
    const after = await state(page);
    result.status = await page.evaluate(() => document.querySelector('[data-pres-player-status]')?.textContent);
    result.noticeAfterStart = after.presNotice;
    const deckFrame = page.frames().find((frame) => frame.url().startsWith('blob:'));
    result.frames = page.frames().map((frame) => frame.url().slice(0, 60));
    if (deckFrame && interact) result.features = await interact(page, deckFrame, context).catch((error) => ({ error: String(error).slice(0, 400) }));
    result.statusEnd = await page.evaluate(() => document.querySelector('[data-pres-player-status]')?.textContent);
    result.noticeEnd = (await state(page)).presNotice;
    await page.screenshot({ path: join(shots, `A2-wrapped-${file.replace(/\.zip$/, '')}.png`) });
  }
  result.logs = logs.slice(0, 6);
  await context.close();
  return result;
}
const features = async (page, frame, context) => {
  const r = {};
  try {
  const read = () => frame.evaluate(() => {
    const reveal = document.querySelector('.reveal');
    const ind = Reveal.getIndices();
    return { h: ind.h, v: ind.v, f: ind.f, cls: reveal.className.replace(/\s+/g, ' '), total: Reveal.getTotalSlides(), plugins: Object.keys(Reveal.getPlugins()), slideNumber: reveal.querySelector('.slide-number')?.textContent.replace(/\s+/g, ''), hash: location.hash, origin: self.origin, url: location.href.slice(0, 30) };
  });
  r.ready = await read();
  await frame.locator('.reveal').click({ position: { x: 200, y: 200 } });
  const press = async (key, label = key) => { await page.keyboard.press(key); await page.waitForTimeout(350); const s = await read(); r[label] = `${s.h}.${s.v}${s.f !== undefined ? ' f' + s.f : ''}${/overview/.test(s.cls) ? ' overview' : ''}${/paused/.test(s.cls) ? ' paused' : ''}`; return s; };
  await press('ArrowRight', '1 right -> vertical stack');
  await press('ArrowDown', '2 down -> vertical child');
  await press('ArrowRight', '3 right -> fragments slide');
  await press('ArrowRight', '4 right -> fragment 1');
  await press('ArrowRight', '5 right -> fragment 2');
  await press('ArrowRight', '6 right -> auto-animate A');
  await press('ArrowRight', '7 right -> auto-animate B');
  r.autoAnimate = await frame.evaluate(() => ({ styleSheets: document.querySelectorAll('style[data-auto-animate], head style').length, running: document.querySelector('.slides').getAttribute('data-auto-animate'), h2Top: getComputedStyle(document.querySelector('section.present h2')).marginTop }));
  await press('ArrowRight', '8 right -> background colour');
  r.background = await frame.evaluate(() => getComputedStyle(document.querySelector('.backgrounds .slide-background.present')).backgroundColor);
  await press('ArrowRight', '9 right -> image background');
  r.imageBackground = await frame.evaluate(() => getComputedStyle(document.querySelector('.backgrounds .slide-background.present .slide-background-content')).backgroundImage.slice(0, 40));
  await press('ArrowRight', '10 right -> code');
  r.code = await frame.evaluate(() => { const code = document.querySelector('section.present pre code'); return { hljs: code.classList.contains('hljs'), spans: code.querySelectorAll('span[class^="hljs-"]').length, lineNumberRows: code.querySelectorAll('tr').length, codeBlocks: document.querySelectorAll('section.present pre code').length }; });
  await press('ArrowRight', '11 right -> code step 2');
  await press('ArrowRight', '12 right -> markdown slide');
  r.markdown = await frame.evaluate(() => { const s = document.querySelector('section.present'); return { h2: s.querySelector('h2')?.textContent, fragments: s.querySelectorAll('.fragment').length, notes: s.querySelector('aside.notes')?.textContent?.trim(), dataMarkdownParsed: s.getAttribute('data-markdown-parsed') }; });
  await press('ArrowRight', '13 right -> md fragment');
  await press('ArrowRight', '14 right -> helpers slide');
  r.fitText = await frame.evaluate(() => getComputedStyle(document.querySelector('section.present .r-fit-text')).fontSize);
  await press('ArrowRight', '15 right -> r-stack A'); await press('ArrowRight', '16 right -> r-stack B');
  await frame.locator('section.present button').click(); await frame.locator('section.present button').click();
  r.buttonAfterTwoClicks = await frame.evaluate(() => document.querySelector('section.present button').textContent);
  await press('o', 'overview on'); await press('o', 'overview off');
  await press('b', 'pause on'); await press('b', 'pause off');
  await page.keyboard.press('Control+Shift+F'); await page.waitForTimeout(300);
  r.searchBox = await frame.evaluate(() => !!document.querySelector('.searchbox') && getComputedStyle(document.querySelector('.searchbox')).display);
  await page.keyboard.press('Escape');
  await page.keyboard.press('Home'); await page.waitForTimeout(300);
  r.end = await read();
  r.zoomPlugin = await frame.evaluate(() => typeof Reveal.getPlugin('zoom'));
  r.fullscreenEnabledInFrame = await frame.evaluate(() => document.fullscreenEnabled);
  const pages = context.pages().length;
  await page.keyboard.press('s'); await page.waitForTimeout(800);
  r.speakerWindowOpened = context.pages().length - pages;
  r.statusAfterS = await page.evaluate(() => document.querySelector('[data-pres-player-status]')?.textContent);
  r.noticeAfterS = await page.evaluate(() => { const n = document.querySelector('[data-pres-notice]'); return n && !n.hidden ? n.textContent : null; });
  } catch (error) { r.error = String(error).slice(0, 300); }
  return r;
};
(async () => {
  const browser = await launch();
  const results = [];
  for (const [file, interact] of [['reveal-wrapped.zip', features], ['reveal-wrapped-keep-hash.zip', null], ['reveal-wrapped-keep-handlers.zip', async (page, frame) => { for (let i = 0; i < 14; i++) await frame.evaluate(() => Reveal.next()); await frame.locator('section.present button').click(); await page.waitForTimeout(500); return { button: await frame.evaluate(() => document.querySelector('section.present button').textContent).catch((e) => String(e).slice(0, 120)) }; }], ['reveal-wrapped-keep-attr-assets.zip', async (page, frame) => { for (let i = 0; i < 9; i++) { await frame.evaluate(() => Reveal.next()).catch(() => {}); await page.waitForTimeout(150); } return {}; }], ['reveal-wrapped-cdn.zip', null]]) {
    const result = await play(browser, file, interact);
    results.push(result);
    console.log('\n=== ' + file + '\n' + JSON.stringify(result, null, 1));
  }
  writeFileSync(join(out, 'e5-wrapped-reveal.json'), JSON.stringify(results, null, 2));
  await browser.close();
})();
