const { chromium } = require('playwright');
const BASE = process.env.A2_BASE || 'http://127.0.0.1:4410/';
async function launch() { return chromium.launch(); }
async function openApp(browser, { url = BASE, viewport = { width: 1440, height: 900 }, acceptDownloads = true } = {}) {
  const context = await browser.newContext({ viewport, acceptDownloads });
  const page = await context.newPage();
  const logs = [];
  page.on('console', (message) => { if (['error', 'warning'].includes(message.type())) logs.push(`[${message.type()}] ${message.text().slice(0, 300)}`); });
  page.on('pageerror', (error) => logs.push(`[pageerror] ${String(error).slice(0, 300)}`));
  await page.goto(url, { waitUntil: 'load' });
  await page.waitForSelector('[data-editor] .cm-content', { timeout: 20000 });
  await page.waitForFunction(() => document.querySelector('[data-save-label]')?.textContent !== 'Getting ready', null, { timeout: 20000 });
  return { context, page, logs };
}
async function state(page) {
  return page.evaluate(() => {
    const text = (selector) => document.querySelector(selector)?.textContent?.trim().replace(/\s+/g, ' ') ?? null;
    const workspace = document.querySelector('qft-markdown-workspace');
    const toast = document.querySelector('[data-toast]');
    const dialogs = [...document.querySelectorAll('dialog[open]')].map((dialog) => ({
      heading: dialog.querySelector('h2')?.textContent?.trim(),
      notice: dialog.querySelector('[data-dialog-notice]')?.textContent?.trim(),
    }));
    const presNotice = document.querySelector('[data-pres-notice]');
    return {
      title: text('[data-document-title]'),
      mode: workspace?.dataset.contentMode,
      docs: text('[data-doc-count]'),
      toast: toast && !toast.hidden ? toast.textContent.trim() : null,
      dialogs,
      presNotice: presNotice && !presNotice.hidden ? presNotice.textContent.trim() : null,
      presTitle: document.querySelector('[data-pres-dialog]')?.open ? text('[data-pres-title]') : null,
      presSubtitle: document.querySelector('[data-pres-dialog]')?.open ? text('[data-pres-subtitle]') : null,
      slidePosition: text('[data-slide-position]'),
      diagnostics: document.querySelector('[data-diagnostics]')?.hidden === false ? [...document.querySelectorAll('[data-error-list] button')].map((b) => b.textContent) : [],
      source: document.querySelector('[data-editor] .cm-content')?.innerText.slice(0, 240),
      lessonFilesVisible: document.querySelector('[data-lesson-files]')?.hidden === false,
      checkLessonVisible: document.querySelector('[data-lesson-check]')?.hidden === false,
    };
  });
}
async function openFile(page, path, wait = 1500) {
  await page.setInputFiles('[data-file-input]', path);
  await page.waitForTimeout(wait);
}
module.exports = { launch, openApp, state, openFile, BASE };
