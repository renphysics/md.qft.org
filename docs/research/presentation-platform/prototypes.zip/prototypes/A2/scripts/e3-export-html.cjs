// E3: features of the standalone HTML export of a Markdown deck (stock Reveal instance, no plugins).
// Also forward-key behaviour in the embedded preview, and URL query overrides.
const { launch, openApp, state, openFile, BASE } = require('./lib.cjs');
const { join } = require('node:path');
const { writeFileSync, statSync, readFileSync } = require('node:fs');
const fixtures = process.argv[2];
const shots = process.argv[3];
const out = require('node:path').resolve(fixtures, '../out');
(async () => {
  const browser = await launch();
  const { context, page } = await openApp(browser);
  await openFile(page, join(fixtures, 'lesson-reveal-conventions.zip'), 2500);
  // forward keys from the first slide
  const pos = () => page.evaluate(() => document.querySelector('[data-slide-position]')?.textContent);
  const forward = {};
  for (const key of ['ArrowRight', 'ArrowDown', 'Space', 'n', 'PageDown', 'l', 'j', 'ArrowUp', 'p', 'h', 'k', 'Backspace']) {
    await page.locator('.qft-slide-deck .reveal').focus();
    await page.keyboard.press('Home'); await page.waitForTimeout(120);
    if (['ArrowUp', 'p', 'h', 'k', 'Backspace'].includes(key)) { await page.keyboard.press('End'); await page.waitForTimeout(120); }
    const before = await pos();
    await page.keyboard.press(key); await page.waitForTimeout(200);
    forward[key] = `${before} -> ${await pos()}`;
  }
  console.log('embedded navigation keys', JSON.stringify(forward));
  // Export standalone HTML
  await page.locator('[data-export-toggle]').click();
  const [download] = await Promise.all([page.waitForEvent('download', { timeout: 60000 }), page.locator('[data-export-html]').click()]);
  const htmlPath = join(out, 'export-probe-slides.html');
  await download.saveAs(htmlPath);
  const html = readFileSync(htmlPath, 'utf8');
  console.log('export size bytes', statSync(htmlPath).size, 'suggested', download.suggestedFilename());
  console.log('export CSP', html.match(/<meta http-equiv="Content-Security-Policy" content="([^"]+)"/)?.[1]);
  console.log('contains RevealMarkdown/Highlight/Notes plugin?', /RevealMarkdown|RevealHighlight|RevealNotes/.test(html));
  // Project ZIP too
  await page.locator('[data-export-toggle]').click();
  const [zip] = await Promise.all([page.waitForEvent('download', { timeout: 60000 }), page.locator('[data-export-md]').click()]);
  await zip.saveAs(join(out, 'export-probe-project.zip'));
  console.log('project zip', zip.suggestedFilename(), statSync(join(out, 'export-probe-project.zip')).size);
  await context.close();

  const probe = async (query, label) => {
    const ctx = await browser.newContext({ viewport: { width: 1280, height: 800 } });
    const p = await ctx.newPage();
    const errors = [];
    p.on('console', (m) => { if (m.type() === 'error') errors.push(m.text().slice(0, 200)); });
    p.on('pageerror', (e) => errors.push(String(e).slice(0, 200)));
    await p.goto('file://' + htmlPath + query);
    await p.waitForTimeout(1200);
    const read = () => p.evaluate(() => {
      const reveal = document.querySelector('.reveal');
      const show = (selector) => { const el = reveal.querySelector(selector); return el ? getComputedStyle(el).display !== 'none' : false; };
      return { cls: reveal.className.replace(/\s+/g, ' '), hash: location.hash, slideNumber: reveal.querySelector('.slide-number')?.textContent, controls: show('.controls'), progress: show('.progress'),
        help: !!document.querySelector('.r-overlay-help, .r-overlay'), jump: !!document.querySelector('.jump-to-slide'), pdfPages: document.querySelectorAll('.pdf-page').length, scrollPages: document.querySelectorAll('.scroll-page').length,
        revealGlobal: typeof Reveal, bodyClass: document.documentElement.className + ' | ' + document.body.className };
    });
    const result = { label, start: await read() };
    if (!query) {
      await p.locator('.reveal').click({ position: { x: 640, y: 400 } }).catch(() => {});
      for (const key of ['ArrowRight', 'o', 'Escape', 'b', 'b', 'g', 'Escape', '?', 'Escape', 'f', 's']) {
        const pages = ctx.pages().length;
        await p.keyboard.press(key); await p.waitForTimeout(300);
        const r = await read();
        result[`${key}#${Object.keys(result).length}`] = { hash: r.hash, n: r.slideNumber, overview: /\boverview\b/.test(r.cls), paused: /\bpaused\b/.test(r.cls), help: r.help, jump: r.jump, fs: await p.evaluate(() => !!document.fullscreenElement), newWindows: ctx.pages().length - pages };
      }
      await p.screenshot({ path: join(shots, 'A2-export-html.png') });
    }
    result.errors = errors.slice(0, 5);
    console.log('\nEXPORT ' + label); for (const [k, v] of Object.entries(result)) console.log(' ', k.padEnd(14), JSON.stringify(v));
    await ctx.close();
    return result;
  };
  const results = [await probe('', 'plain'), await probe('?print-pdf', '?print-pdf'), await probe('?view=scroll', '?view=scroll'), await probe('?transition=zoom&controls=false', '?transition=zoom&controls=false')];
  writeFileSync(join(out, 'e3-export.json'), JSON.stringify({ forward, results }, null, 2));

  // URL query overriding the embedded preview configuration on the site itself
  for (const query of ['?controls=true&progress=true&slideNumber=true&overview=true&help=true', '?view=scroll', '?print-pdf', '?embedded=false']) {
    const { context: c2, page: p2, logs } = await openApp(browser, { url: BASE + query });
    await openFile(p2, join(fixtures, 'lesson-ok.zip'), 2500);
    const r = await p2.evaluate(() => {
      const reveal = document.querySelector('.qft-slide-deck .reveal');
      if (!reveal) return { missing: true, host: document.querySelector('[data-slide-host]')?.textContent?.slice(0, 200) };
      const show = (selector) => { const el = reveal.querySelector(selector); return el ? getComputedStyle(el).display !== 'none' : false; };
      return { cls: reveal.className.replace(/\s+/g, ' '), controls: show('.controls'), progress: show('.progress'), slideNumber: show('.slide-number'), htmlClass: document.documentElement.className, bodyClass: document.body.className, pdfPages: document.querySelectorAll('.pdf-page').length, scrollPages: document.querySelectorAll('.scroll-page').length, pos: document.querySelector('[data-slide-position]')?.textContent, location: location.search };
    });
    await p2.screenshot({ path: join(shots, `A2-site-query-${query.replace(/[^a-z]+/gi, '_').slice(0, 30)}.png`) });
    console.log('\nSITE QUERY', query, JSON.stringify(r), logs.slice(0, 3));
    await c2.close();
  }
  await browser.close();
})();
