const { launch, openApp, openFile } = require('./lib.cjs');
const { join, resolve } = require('node:path');
const fixtures = resolve(process.argv[2]);
(async () => {
  const browser = await launch();
  const start = async () => {
    const { context, page, logs } = await openApp(browser);
    await openFile(page, join(fixtures, 'reveal-wrapped.zip'), 2000);
    await page.locator('[data-pres-start-button]').click();
    await page.waitForFunction(() => /Playing|attention/.test(document.querySelector('[data-pres-player-status]')?.textContent || ''), null, { timeout: 30000 });
    await page.waitForTimeout(800);
    const frame = page.frames().find((f) => f.url().startsWith('blob:'));
    await frame.locator('.reveal').click({ position: { x: 200, y: 200 } });
    return { context, page, logs, frame };
  };
  const status = (page) => page.evaluate(() => `${document.querySelector('[data-pres-player-status]')?.textContent} | ${document.querySelector('[data-pres-notice]')?.hidden ? '' : document.querySelector('[data-pres-notice]')?.textContent}`);
  for (const keys of [['Control+Shift+F'], ['Control+Shift+F', 'Escape'], ['Escape'], ['Home'], ['s'], ['f'], ['Shift+?'], ['g'], ['Alt+z'], ['z'], ['q'], ['.'], ['v'], ['Enter'], ['Tab'], ['c'], ['t'], ['a'], ['m']]) {
    const { context, page, logs, frame } = await start();
    const pages = context.pages().length;
    for (const key of keys) { await page.keyboard.press(key); await page.waitForTimeout(500); }
    let inner = 'detached';
    try { inner = await frame.evaluate(() => JSON.stringify({ i: Reveal.getIndices(), paused: Reveal.isPaused(), overview: Reveal.isOverview(), help: !!document.querySelector('.r-overlay-help'), jump: !!document.querySelector('.jump-to-slide'), search: document.querySelector('.searchbox') ? getComputedStyle(document.querySelector('.searchbox')).display : null, fs: !!document.fullscreenElement, fsEnabled: document.fullscreenEnabled })); } catch {}
    console.log(keys.join(' , ').padEnd(26), '=>', await status(page), '| inner', inner, '| popups', context.pages().length - pages, logs.slice(0, 2).map((l) => l.slice(0, 150)));
    await context.close();
  }
  await browser.close();
})();
