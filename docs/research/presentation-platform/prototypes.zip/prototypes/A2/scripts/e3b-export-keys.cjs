const { launch, openApp, openFile } = require('./lib.cjs');
const { join, resolve } = require('node:path');
const fixtures = resolve(process.argv[2]);
const out = resolve(fixtures, '../out');
(async () => {
  const browser = await launch();
  // exported HTML: keys that were masked by the pause state in the first probe
  for (const key of ['f', 's', 'Shift+?', 'Escape', 'z', 'Alt+Click']) {
    const ctx = await browser.newContext({ viewport: { width: 1280, height: 800 } });
    const p = await ctx.newPage();
    const errors = []; p.on('pageerror', (e) => errors.push(String(e).slice(0, 160)));
    await p.goto('file://' + join(out, 'export-probe-slides.html'));
    await p.waitForTimeout(800);
    await p.locator('.reveal').click({ position: { x: 640, y: 500 } });
    const pages = ctx.pages().length;
    if (key === 'Alt+Click') await p.locator('.reveal h1').first().click({ modifiers: ['Alt'] }); else await p.keyboard.press(key);
    await p.waitForTimeout(500);
    const r = await p.evaluate(() => ({ fs: !!document.fullscreenElement, overview: document.querySelector('.reveal').classList.contains('overview'), help: !!document.querySelector('.r-overlay-help'), paused: document.querySelector('.reveal').classList.contains('paused'), zoomed: document.body.style.transform || document.body.style.zoom || '' }));
    console.log('export key', key.padEnd(10), JSON.stringify(r), 'popups', ctx.pages().length - pages, errors);
    await ctx.close();
  }
  // toolbar of the export
  {
    const ctx = await browser.newContext({ viewport: { width: 1280, height: 800 } });
    const p = await ctx.newPage();
    await p.goto('file://' + join(out, 'export-probe-slides.html'));
    await p.waitForTimeout(600);
    console.log('export toolbar', JSON.stringify(await p.evaluate(() => [...document.querySelectorAll('.export-toolbar button, .export-toolbar summary')].map((b) => b.textContent.trim()))));
    await ctx.close();
  }
  // mobile width + themes on the site
  const { context, page } = await openApp(browser, { viewport: { width: 390, height: 800 } });
  await openFile(page, join(fixtures, 'lesson-ok.zip'), 2500);
  await page.locator('[data-view-mode="preview"]').click().catch(() => {});
  await page.waitForTimeout(600);
  console.log('mobile 390px', JSON.stringify(await page.evaluate(() => ({ view: document.querySelector('qft-markdown-workspace').dataset.view, revealCls: document.querySelector('.qft-slide-deck .reveal')?.className, scrollView: !!document.querySelector('.reveal-scroll'), pos: document.querySelector('[data-slide-position]')?.textContent, bodyOverflowX: document.documentElement.scrollWidth - document.documentElement.clientWidth }))));
  await context.close();
  const desk = await openApp(browser);
  await openFile(desk.page, join(fixtures, 'lesson-ok.zip'), 2500);
  const themes = {};
  for (const theme of ['paper', 'midnight', 'serif']) {
    await desk.page.locator('select[data-slide-theme]').selectOption(theme); await desk.page.waitForTimeout(300);
    themes[theme] = await desk.page.evaluate(() => { const deck = document.querySelector('.qft-slide-deck'); const s = getComputedStyle(deck.querySelector('.qft-slide-content')); return { attr: deck.dataset.slideTheme, bg: getComputedStyle(deck).backgroundColor, color: s.color, font: s.fontFamily.slice(0, 40) }; });
  }
  console.log('themes', JSON.stringify(themes));
  console.log('theme options', JSON.stringify(await desk.page.evaluate(() => [...document.querySelector('select[data-slide-theme]').options].map((o) => o.textContent))), 'ratio options', JSON.stringify(await desk.page.evaluate(() => [...document.querySelector('select[data-slide-ratio]').options].map((o) => o.textContent))));
  await browser.close();
})();
