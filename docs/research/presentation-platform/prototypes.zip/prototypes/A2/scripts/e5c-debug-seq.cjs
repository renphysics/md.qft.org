const { launch, openApp, openFile } = require('./lib.cjs');
const { join, resolve } = require('node:path');
const fixtures = resolve(process.argv[2]);
(async () => {
  const browser = await launch();
  const { context, page, logs } = await openApp(browser);
  await openFile(page, join(fixtures, 'reveal-wrapped.zip'), 2000);
  await page.locator('[data-pres-start-button]').click();
  await page.waitForFunction(() => /Playing|attention/.test(document.querySelector('[data-pres-player-status]')?.textContent || ''), null, { timeout: 30000 });
  await page.waitForTimeout(800);
  const frame = page.frames().find((f) => f.url().startsWith('blob:'));
  await frame.locator('.reveal').click({ position: { x: 200, y: 200 } });
  const alive = async (label) => { const ok = await frame.evaluate(() => `${JSON.stringify(Reveal.getIndices())} active=${document.activeElement?.tagName}.${document.activeElement?.className}`).catch(() => 'DETACHED'); console.log(label.padEnd(24), ok, logs.slice(-1).map((l) => l.slice(0, 90))); };
  await frame.evaluate(() => Reveal.slide(9, 0, 1)); await alive('at helpers slide');
  await frame.locator('section.present button').click(); await alive('button click');
  for (const key of ['o', 'o', 'b', 'b', 'Control+Shift+F']) { await page.keyboard.press(key); await page.waitForTimeout(350); await alive(key); }
  for (const key of ['Escape', 'Home']) { await page.keyboard.press(key); await page.waitForTimeout(600); await alive(key); }
  await browser.close();
})();
