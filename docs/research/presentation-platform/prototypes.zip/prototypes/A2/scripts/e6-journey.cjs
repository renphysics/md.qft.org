// E6/E7: walk the Create-with-AI journey on the built site (Markdown lesson path + Slidev path).
const { launch, openApp, openFile, state } = require('./lib.cjs');
const { join, resolve } = require('node:path');
const { writeFileSync, statSync, readFileSync } = require('node:fs');
const fixtures = resolve(process.argv[2]);
const shots = process.argv[3];
const out = resolve(fixtures, '../out');
const log = (label, value) => console.log(`\n## ${label}\n${typeof value === 'string' ? value : JSON.stringify(value, null, 1)}`);
(async () => {
  const browser = await launch();
  const { context, page, logs } = await openApp(browser);
  await context.grantPermissions(['clipboard-read', 'clipboard-write']);
  // --- Step 1: Create with AI dialog (Markdown)
  await page.locator('[data-create-ai]').click();
  await page.waitForTimeout(300);
  log('dialog fields', await page.evaluate(() => [...document.querySelectorAll('[data-ai-form] label')].map((label) => label.textContent.trim().replace(/\s+/g, ' ').slice(0, 90))));
  await page.screenshot({ path: join(shots, 'A2-ai-dialog-markdown.png') });
  await page.locator('[data-ai-topic]').fill('Wave packets and the uncertainty principle');
  await page.locator('[data-ai-form] button[type=submit]').click();
  await page.waitForTimeout(400);
  const clip = await page.evaluate(() => navigator.clipboard.readText());
  log('copy status', await page.evaluate(() => document.querySelector('[data-ai-status]').textContent));
  log('clipboard words (markdown prompt)', String(clip.trim().split(/\s+/).length) + ' words, ' + clip.length + ' chars; first line: ' + clip.split('\n')[0]);
  writeFileSync(join(out, 'ui-prompt-markdown.txt'), clip);
  // starter ZIP download
  const [starter] = await Promise.all([page.waitForEvent('download'), page.locator('[data-ai-starter]').click()]);
  const starterPath = join(out, 'ui-starter-markdown.zip');
  await starter.saveAs(starterPath);
  log('starter ZIP', `${starter.suggestedFilename()} ${statSync(starterPath).size} bytes | status: ${await page.evaluate(() => document.querySelector('[data-ai-status]').textContent)}`);
  // --- switch to Slidev
  await page.locator('[data-ai-format]').selectOption('slidev');
  await page.waitForTimeout(200);
  log('slidev help texts', await page.evaluate(() => ({ formatHelp: document.querySelector('[data-ai-format-help]').textContent, workflowHelp: document.querySelector('[data-ai-workflow-help]').textContent, status: document.querySelector('[data-ai-status]').textContent, steps: [...document.querySelectorAll('.ai-lesson-steps li')].map((li) => li.textContent.trim().replace(/\s+/g, ' ')) })));
  await page.locator('[data-ai-form] button[type=submit]').click();
  await page.waitForTimeout(400);
  const clip2 = await page.evaluate(() => navigator.clipboard.readText());
  log('clipboard words (slidev prompt)', String(clip2.trim().split(/\s+/).length) + ' words, ' + clip2.length + ' chars');
  writeFileSync(join(out, 'ui-prompt-slidev.txt'), clip2);
  await page.screenshot({ path: join(shots, 'A2-ai-dialog-slidev.png') });
  const [slidevStarter] = await Promise.all([page.waitForEvent('download'), page.locator('[data-ai-starter]').click()]);
  const slidevStarterPath = join(out, 'ui-starter-slidev.zip');
  await slidevStarter.saveAs(slidevStarterPath);
  log('slidev starter ZIP', `${slidevStarter.suggestedFilename()} ${statSync(slidevStarterPath).size} bytes`);
  await page.locator('[data-ai-close]').click();
  // --- Step 3: open the starter the "AI" returned (unchanged) and check it
  await openFile(page, starterPath, 2500);
  log('after opening starter', await state(page));
  await page.locator('[data-lesson-check]').click();
  await page.waitForTimeout(300);
  log('check lesson', await page.evaluate(() => ({ summary: document.querySelector('[data-lesson-check-summary]').textContent, result: document.querySelector('[data-lesson-check-result]').textContent, items: [...document.querySelectorAll('[data-lesson-check-list] li')].map((li) => li.textContent), report: document.querySelector('[data-lesson-report]').value })));
  await page.screenshot({ path: join(shots, 'A2-check-lesson.png') });
  await page.locator('.lesson-check-dialog [data-lesson-check-close]').last().click();
  // run the demo: go to slide 5 and press Run demo
  for (let i = 0; i < 4; i++) { await page.locator('[data-slide-next]').click(); await page.waitForTimeout(150); }
  await page.locator('.qft-slide.present [data-demo-run]').click();
  await page.waitForTimeout(2000);
  log('demo running', await page.evaluate(() => ({ status: document.querySelector('.qft-slide.present [data-demo-status]').textContent, state: document.querySelector('.qft-slide.present .qft-demo').dataset.demoState, frames: window.frames.length })));
  const demoFrame = page.frames().find((f) => f.url().includes('demo-sandbox'));
  log('demo frame', demoFrame ? await demoFrame.evaluate(() => ({ origin: self.origin, h1: document.querySelector('h1')?.textContent, csp: document.querySelector('meta[http-equiv]')?.content.slice(0, 120) })) : 'no frame');
  await page.screenshot({ path: join(shots, 'A2-starter-demo-running.png') });
  // --- Step 4: edit source in the browser: Lesson files -> change the demo heading -> save -> run again
  await page.locator('[data-lesson-files]').click();
  await page.waitForTimeout(300);
  log('lesson files dialog', await page.evaluate(() => ({ files: [...document.querySelector('[data-lesson-file]').options].map((o) => o.value), note: document.querySelector('[data-lesson-file-note]').textContent, editorTag: document.querySelector('[data-lesson-file-source]').tagName, rows: document.querySelector('[data-lesson-file-source]').getBoundingClientRect().height })));
  await page.screenshot({ path: join(shots, 'A2-lesson-files.png') });
  await page.locator('[data-lesson-file]').selectOption('demos/explore.html');
  const html = await page.locator('[data-lesson-file-source]').inputValue();
  await page.locator('[data-lesson-file-source]').fill(html.replace('<h1>Explore y = A sin(kx)</h1>', '<h1>EDITED IN THE BROWSER</h1>'));
  await page.locator('[data-lesson-files-form] button[type=submit]').click();
  await page.waitForTimeout(800);
  log('after saving lesson files', (await state(page)).toast);
  log('demo card state after edit (was running)', await page.evaluate(() => ({ state: document.querySelector('.qft-slide.present .qft-demo')?.dataset.demoState, status: document.querySelector('.qft-slide.present [data-demo-status]')?.textContent, pos: document.querySelector('[data-slide-position]').textContent })));
  await page.locator('.qft-slide.present [data-demo-run]').click();
  await page.waitForTimeout(1500);
  const demoFrame2 = page.frames().find((f) => f.url().includes('demo-sandbox'));
  log('demo after edit', demoFrame2 ? await demoFrame2.evaluate(() => document.querySelector('h1')?.textContent) : 'no frame');
  // Edit demo dialog
  await page.locator('.qft-slide.present [data-demo-edit]').click();
  await page.waitForTimeout(300);
  log('edit demo dialog', await page.evaluate(() => ({ description: document.querySelector('[data-demo-edit-description]').textContent, sourceChars: document.querySelector('[data-demo-edit-source]').value.length, tag: document.querySelector('[data-demo-edit-source]').tagName })));
  await page.screenshot({ path: join(shots, 'A2-edit-demo.png') });
  await page.locator('.demo-edit-dialog [data-demo-edit-close]').first().click();
  // --- Step 5: export Project ZIP, list contents
  await page.locator('[data-export-toggle]').click();
  log('export menu', await page.evaluate(() => [...document.querySelectorAll('[data-export-menu] button')].filter((b) => !b.hidden).map((b) => b.textContent.trim().replace(/\s+/g, ' '))));
  const [project] = await Promise.all([page.waitForEvent('download'), page.locator('[data-export-md]').click()]);
  await project.saveAs(join(out, 'ui-project.zip'));
  const { unzipSync, strFromU8 } = require('/home/user/md.qft.org/node_modules/fflate');
  const entries = unzipSync(new Uint8Array(readFileSync(join(out, 'ui-project.zip'))));
  log('project zip entries', Object.fromEntries(Object.entries(entries).map(([k, v]) => [k, v.length])));
  log('project zip qft.json', strFromU8(entries['qft.json']));
  // --- Step 6: revision flow
  await openFile(page, join(fixtures, 'lesson-ok.zip'), 2000);
  await openFile(page, join(fixtures, 'lesson-ok-revised.zip'), 2000);
  await page.locator('.lesson-change-details summary').click().catch(() => {});
  await page.waitForTimeout(300);
  log('revision review', await page.evaluate(() => ({ open: document.querySelector('[data-lesson-update-dialog]').open, description: document.querySelector('[data-lesson-update-description]').textContent, summary: document.querySelector('[data-lesson-update-summary]').innerText, options: [...document.querySelector('[data-lesson-change-file]').options].map((o) => o.textContent), before: document.querySelector('[data-lesson-before]').value.slice(0, 200), after: document.querySelector('[data-lesson-after]').value.slice(0, 200), beforeTag: document.querySelector('[data-lesson-before]').tagName })));
  await page.screenshot({ path: join(shots, 'A2-revision-review.png') });
  await page.locator('[data-lesson-update-apply]').click();
  await page.waitForTimeout(1200);
  log('after update', await state(page));
  log('documents list', await page.evaluate(() => [...document.querySelectorAll('[data-documents] [data-document-id]')].map((d) => d.textContent.trim().replace(/\s+/g, ' ').slice(0, 60))));
  log('console', logs.slice(0, 8));
  await context.close();

  // --- CDN demo failure mode
  {
    const { context: c, page: p, logs: l } = await openApp(browser);
    await openFile(p, join(fixtures, 'lesson-cdn-demo.zip'), 2000);
    await p.locator('[data-slide-next]').click(); await p.waitForTimeout(300);
    await p.locator('.qft-slide.present [data-demo-run]').click();
    await p.waitForTimeout(2500);
    log('CDN demo: run result', await p.evaluate(() => ({ status: document.querySelector('.qft-slide.present [data-demo-status]').textContent, state: document.querySelector('.qft-slide.present .qft-demo').dataset.demoState })));
    await p.locator('[data-lesson-check]').click(); await p.waitForTimeout(300);
    log('CDN demo: check lesson', await p.evaluate(() => ({ result: document.querySelector('[data-lesson-check-result]').textContent, items: [...document.querySelectorAll('[data-lesson-check-list] li')].map((li) => li.textContent) })));
    log('CDN demo console', l.slice(0, 4));
    await c.close();
  }
  // --- Slidev path: open portable package, source tab
  {
    const { context: c, page: p } = await openApp(browser);
    await openFile(p, slidevStarterPath, 2500);
    await p.locator('[data-pres-view="source"]').click(); await p.waitForTimeout(300);
    log('slidev source tab', await p.evaluate(() => ({ files: [...document.querySelector('[data-pres-file]').options].map((o) => o.textContent), readOnly: document.querySelector('[data-pres-source-text]').readOnly, info: document.querySelector('[data-pres-file-info]').textContent, note: document.querySelector('.presentation-source-note').textContent, storage: document.querySelector('[data-pres-storage]').textContent })));
    await p.screenshot({ path: join(shots, 'A2-slidev-source-tab.png') });
    await p.locator('[data-pres-view="preview"]').click();
    const t0 = Date.now();
    await p.locator('[data-pres-start-button]').click();
    await p.waitForFunction(() => /Playing|attention/.test(document.querySelector('[data-pres-player-status]')?.textContent || ''), null, { timeout: 30000 });
    log('slidev start', `${await p.evaluate(() => document.querySelector('[data-pres-player-status]').textContent)} after ${Date.now() - t0} ms`);
    await p.waitForTimeout(800);
    await p.screenshot({ path: join(shots, 'A2-slidev-playing.png') });
    await c.close();
  }
  await browser.close();
})();
