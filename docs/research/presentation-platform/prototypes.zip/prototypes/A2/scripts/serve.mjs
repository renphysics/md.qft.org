// Minimal static server (no writes): node serve.mjs <root> <port>
import { createServer } from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { resolve, extname, join, sep } from 'node:path';
const root = resolve(process.argv[2]);
const port = Number(process.argv[3]);
const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.woff2': 'font/woff2', '.woff': 'font/woff', '.ttf': 'font/ttf', '.zip': 'application/zip', '.md': 'text/markdown; charset=utf-8', '.txt': 'text/plain; charset=utf-8', '.xml': 'application/xml', '.map': 'application/json', '.ico': 'image/x-icon', '.mp4': 'video/mp4', '.webm': 'video/webm' };
createServer(async (request, response) => {
  try {
    let path = decodeURIComponent(new URL(request.url, 'http://x').pathname);
    let file = resolve(join(root, path));
    if (file !== root && !file.startsWith(root + sep)) { response.writeHead(403).end(); return; }
    let info = await stat(file).catch(() => undefined);
    if (info?.isDirectory()) { file = join(file, 'index.html'); info = await stat(file).catch(() => undefined); }
    if (!info) { response.writeHead(404, { 'content-type': 'text/plain' }).end('Not found'); return; }
    response.writeHead(200, { 'content-type': types[extname(file).toLowerCase()] ?? 'application/octet-stream', 'cache-control': 'no-store' });
    response.end(await readFile(file));
  } catch (error) { response.writeHead(500).end(String(error)); }
}).listen(port, '127.0.0.1', () => console.log(`serving ${root} on http://127.0.0.1:${port}`));
