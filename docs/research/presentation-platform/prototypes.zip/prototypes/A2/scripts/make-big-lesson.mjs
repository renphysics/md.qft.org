import { createRequire } from 'node:module';
import { writeFileSync } from 'node:fs';
import { randomFillSync } from 'node:crypto';
const require = createRequire('/home/user/md.qft.org/package.json');
const { zipSync, strToU8 } = require('fflate');
const out = process.argv[2];
const files = { 'qft.json': strToU8(JSON.stringify({ format: 'qft-markdown', version: 2, projectId: 'a2-big', document: 'slides.md', title: 'Big lesson', mode: 'slides', images: [] })) };
let md = '# Big lesson\n';
for (let i = 0; i < 5; i++) {
  const bytes = new Uint8Array(4 * 1024 * 1024); randomFillSync(bytes); bytes.set([137, 80, 78, 71, 13, 10, 26, 10]);
  files[`images/big-${i}.png`] = bytes; md += `\n---\n\n![Image ${i}](images/big-${i}.png)\n`;
}
for (let i = 0; i < 20; i++) files[`demos/demo-${i}.html`] = strToU8('<p>demo</p>' + 'x'.repeat(90_000));
files['slides.md'] = strToU8(md);
writeFileSync(`${out}/lesson-big.zip`, zipSync(files, { level: 0 }));
console.log('ok', Object.keys(files).length);
