const { launch, openApp, openFile, state } = require('./lib.cjs');
const { join, resolve } = require('node:path');
const fixtures = resolve(process.argv[2]);
const shared = 'SCRATCH/research/shared';
const brief = (s) => JSON.stringify({ toast: s.toast, dialogs: s.dialogs, title: s.title, mode: s.mode, docs: s.docs, diagnostics: s.diagnostics });
(async () => {
  const browser = await launch();
  { // 1. placeholder projectId collision
    const { context, page } = await openApp(browser);
    await openFile(page, join(fixtures, 'placeholder-id-A.zip'), 1800);
    console.log('placeholder A', brief(await state(page)));
    await openFile(page, join(fixtures, 'placeholder-id-B.zip'), 1800);
    console.log('placeholder B', brief(await state(page)), JSON.stringify(await page.evaluate(() => ({ description: document.querySelector('[data-lesson-update-description]')?.textContent, summary: document.querySelector('[data-lesson-update-summary]')?.innerText }))));
    await context.close();
  }
  for (const file of ['lesson-fake-png.zip', 'lesson-nested-with-stray.zip', 'lesson-many-files.zip']) {
    const { context, page } = await openApp(browser);
    await openFile(page, join(fixtures, file), 1800);
    console.log(file, brief(await state(page)));
    await context.close();
  }
  { // 4. paste-only path
    const { context, page } = await openApp(browser);
    await page.locator('[data-paste]').click();
    await page.locator('[data-paste-source]').fill('# Pasted lesson\n\nText.\n\n---\n\n## Demo by file\n\n```interactive src="demos/explore.html" title="Explore"\n```\n\n---\n\n## Inline demo\n\n```interactive title="Counter"\n<button id="b">Count: 0</button>\n<script>let n=0;document.getElementById("b").addEventListener("click",()=>{document.getElementById("b").textContent="Count: "+(++n)})</script>\n```\n');
    await page.locator('[data-paste-form] button[type=submit]').click();
    await page.waitForTimeout(800);
    const s1 = await state(page);
    console.log('paste -> state', brief(s1), 'lessonFiles', s1.lessonFilesVisible);
    await page.locator('[data-content-mode="slides"]').click(); await page.waitForTimeout(1200);
    const s2 = await state(page);
    console.log('paste -> slides', brief(s2), s2.slidePosition);
    await page.locator('[data-slide-next]').click(); await page.locator('[data-slide-next]').click(); await page.waitForTimeout(300);
    await page.locator('.qft-slide.present [data-demo-run]').click(); await page.waitForTimeout(1500);
    const frame = page.frames().find((f) => f.url().includes('demo-sandbox'));
    await frame.locator('#b').click();
    console.log('pasted inline demo button', await frame.evaluate(() => document.getElementById('b').textContent));
    // export menu labels for a non-project slides draft
    await page.locator('[data-export-toggle]').click();
    console.log('export menu (pasted slides)', JSON.stringify(await page.evaluate(() => [...document.querySelectorAll('[data-export-menu] button')].filter((b) => !b.hidden).map((b) => b.textContent.trim().replace(/\s+/g, ' ')))));
    await context.close();
  }
  { // 6. same Slidev package twice
    const { context, page } = await openApp(browser);
    await openFile(page, join(shared, 'slidev-starter/lesson.zip'), 2500);
    await page.locator('[data-pres-close]').click(); await page.waitForTimeout(300);
    await openFile(page, join(shared, 'slidev-starter/lesson.zip'), 2500);
    await page.locator('[data-pres-back]').click(); await page.waitForTimeout(600);
    console.log('library after opening the same ZIP twice', JSON.stringify(await page.evaluate(() => ({ count: document.querySelector('[data-pres-count]').textContent, rows: [...document.querySelectorAll('.presentation-saved-row')].map((r) => r.textContent.trim().replace(/\s+/g, ' ').slice(0, 80)) }))));
    await context.close();
  }
  await browser.close();
})();
