const { launch, openApp, state } = require('./lib.cjs');
const { join, resolve } = require('node:path');
const { writeFileSync, readFileSync } = require('node:fs');
const fixtures = resolve(process.argv[2]);
(async () => {
  const browser = await launch();
  // a self-contained reveal deck (inlined) as HTML file: too large for the demo path?
  const { unzipSync, strFromU8 } = require('/home/user/md.qft.org/node_modules/fflate');
  const wrapped = strFromU8(unzipSync(new Uint8Array(readFileSync(join(fixtures, 'reveal-wrapped.zip'))))['presentation.html']);
  writeFileSync(join(fixtures, 'reveal-inlined-single.html'), wrapped);
  for (const file of ['reveal-cdn-single.html', 'reveal-inlined-single.html']) {
    const { context, page, logs } = await openApp(browser);
    await page.locator('[data-insert-demo]').click(); await page.waitForTimeout(200);
    await page.locator('[data-demo-custom] summary').click();
    await page.setInputFiles('[data-demo-file-input]', join(fixtures, file));
    await page.waitForTimeout(700);
    const afterPick = await state(page);
    const filled = await page.evaluate(() => document.querySelector('[data-demo-html]').value.length);
    let run = null;
    if (filled) {
      await page.locator('[data-demo-form] button[type=submit]').click(); await page.waitForTimeout(1500);
      const s = await state(page);
      await page.locator('.qft-slide.present [data-demo-run]').click().catch(() => {}); await page.waitForTimeout(2500);
      run = await page.evaluate(() => ({ status: document.querySelector('.qft-slide.present [data-demo-status]')?.textContent, state: document.querySelector('.qft-slide.present .qft-demo')?.dataset.demoState }));
      run.toast = s.toast; run.mode = s.mode;
    }
    console.log(file, readFileSync(join(fixtures, file)).length, 'bytes ->', JSON.stringify({ pickToast: afterPick.toast, dialogNotice: afterPick.dialogs, filled, run, logs: logs.slice(0, 2).map((l) => l.slice(0, 120)) }));
    await context.close();
  }
  await browser.close();
})();
