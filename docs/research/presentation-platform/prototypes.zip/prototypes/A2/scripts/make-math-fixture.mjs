import { createRequire } from 'node:module';
import { readFileSync, writeFileSync } from 'node:fs';
const require = createRequire('/home/user/md.qft.org/package.json');
const { unzipSync, zipSync, strToU8, strFromU8 } = require('fflate');
const dir = process.argv[2];
const files = unzipSync(new Uint8Array(readFileSync(`${dir}/reveal-standard.zip`)));
for (const [name, plugin] of [['katex', 'RevealMath.KaTeX'], ['mathjax3', 'RevealMath.MathJax3'], ['default', 'RevealMath']]) {
  let html = strFromU8(files['index.html']);
  html = html.replace('<section><h1>Standard deck</h1>', '<section><h2>Math</h2><p>Inline $e^{i\\pi}+1=0$</p>\\[ \\int_0^1 x^2\\,dx = \\tfrac13 \\]</section>\n<section><h1>Standard deck</h1>');
  html = html.replace('<script src="dist/plugin/zoom.js"></script>', '<script src="dist/plugin/zoom.js"></script><script src="dist/plugin/math.js"></script>');
  html = html.replace('RevealZoom]', `RevealZoom, ${plugin}]`);
  const out = { ...files, 'index.html': strToU8(html) };
  writeFileSync(`${dir}/reveal-standard-math-${name}.zip`, zipSync(out, { level: 6 }));
}
console.log('ok');
