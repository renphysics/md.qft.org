const { launch, openApp, state } = require('./lib.cjs');
const { join, resolve } = require('node:path');
const { writeFileSync } = require('node:fs');
const shots = process.argv[2];
const out = resolve(__dirname, '../out');
(async () => {
  const browser = await launch();
  for (const example of ['quantum-slides', 'interactive-physics']) {
    const { context, page } = await openApp(browser, { url: `http://127.0.0.1:4410/?example=${example}` });
    await page.waitForTimeout(2500);
    await page.evaluate(() => document.fonts.ready);
    const live = await page.evaluate(() => ({
      fonts: [...document.fonts].filter((f) => f.status === 'loaded').map((f) => f.family).filter((v, i, a) => a.indexOf(v) === i).slice(0, 12),
      overflowNotice: !document.querySelector('[data-slide-overflow]').hidden,
      slides: [...document.querySelectorAll('.qft-slide-deck .slides > section')].map((section, index) => {
        const content = section.querySelector('.qft-slide-content');
        const metric = (el) => ({ tag: el.className.split(' ')[0] || el.tagName, sh: el.scrollHeight, ch: el.clientHeight, sw: el.scrollWidth, cw: el.clientWidth });
        return { slide: index + 1, content: metric(content), inner: [...content.querySelectorAll('pre,.katex-display,table')].map(metric).filter((m) => m.sh > m.ch + 3 || m.sw > m.cw + 3) };
      }),
    }));
    console.log(example, JSON.stringify(live, null, 0));
    // Run the site's print path with window.print stubbed, then render the print copy to PDF if it was accepted
    await page.evaluate(() => { window.__printCalls = 0; window.print = () => { window.__printCalls += 1; }; });
    await page.locator('[data-pdf]').click(); await page.waitForTimeout(400);
    await page.locator('[data-slide-print]').click(); await page.waitForTimeout(2500);
    const printing = await page.evaluate(() => ({ calls: window.__printCalls, flag: document.body.dataset.qftPrinting || null, copies: document.querySelectorAll('.qft-print-slides .slides > section').length }));
    console.log(example, 'print', JSON.stringify(printing), JSON.stringify((await state(page)).toast));
    if (printing.flag) {
      await page.emulateMedia({ media: 'print' });
      const pdf = await page.pdf({ preferCSSPageSize: true, printBackground: true });
      writeFileSync(join(out, `${example}.pdf`), pdf);
      const text = pdf.toString('latin1');
      console.log(example, 'PDF bytes', pdf.length, 'pages', (text.match(/\/Type\s*\/Page[^s]/g) || []).length, text.match(/\/MediaBox\s*\[[^\]]+\]/)?.[0]);
    }
    await page.screenshot({ path: join(shots, `A2-example-${example}.png`) });
    await context.close();
  }
  await browser.close();
})();
