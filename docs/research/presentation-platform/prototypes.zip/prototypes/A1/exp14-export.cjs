// EXP14: the standalone HTML export, opened from file://, running the same hostile battery.
const fs = require('node:fs'); const path = require('node:path'); const { pathToFileURL } = require('node:url');
const { chromium } = require('playwright'); const L = require('./lib.cjs');
const html = fs.readFileSync(path.join(__dirname, 'hostile-battery.html'), 'utf8').replaceAll('__EVIL__', 4401).replaceAll('__SITE__', 4400).replaceAll('__TCP__', 4402).replaceAll('__UDP__', 4403).replaceAll('__LANIP__', '192.0.2.2')
  .replace("await t('fetch', ", "await t('fetch_file_url', () => fetch('file:///etc/hostname').then((r) => r.text()).then((x) => 'READ ' + x.length));\n  await t('img_file_url', () => new Promise((resolve) => { const i = new Image(); i.onload = () => resolve('LOADED'); i.onerror = () => resolve('error event'); i.src = 'file:///usr/share/pixmaps/debian-logo.png'; }));\n  await t('fetch', ");
(async () => {
  const site = await L.startSite(4400); const evil = await L.startEvil(4401); const udp = await L.startUdp(4403);
  const browser = await chromium.launch({ channel: 'chromium' });
  const out = {};
  try {
    const context = await browser.newContext({ acceptDownloads: true }); const page = await context.newPage();
    await L.openWorkspace(page, 'http://127.0.0.1:4400/');
    await L.openFile(page, L.makePackage(html, { manifest: { title: 'Export probe' } }), 'hostile.zip');
    await page.locator('[data-pres-start-button]').waitFor({ state: 'visible', timeout: 15000 });
    const [download] = await Promise.all([page.waitForEvent('download'), page.locator('[data-pres-html]').click()]);
    const file = path.join(__dirname, 'out', 'export-hostile.html'); await download.saveAs(file);
    out.exportBytes = fs.statSync(file).size;
    out.exportCsp = [...fs.readFileSync(file, 'utf8').matchAll(/http-equiv="Content-Security-Policy" content="([^"]*)"/g)].map((m) => m[1]).slice(0, 2);
    await context.close();
    const offline = await browser.newContext(); const p2 = await offline.newPage();
    const dialogs = []; p2.on('dialog', async (d) => { dialogs.push(d.message()); await d.dismiss(); });
    await p2.goto(pathToFileURL(file).href);
    out.topOrigin = await p2.evaluate(() => `${location.protocol} origin=${self.origin} secure=${isSecureContext}`);
    await p2.getByRole('button', { name: 'Start presentation', exact: true }).click();
    const frame = await L.until(() => p2.frames().find((f) => f.url().startsWith('blob:')), 'app frame', 15000);
    await L.until(() => frame.evaluate(() => window.__r && window.__r.done), 'battery', 120000, 500);
    const r = await frame.evaluate(() => window.__r);
    const keys = ['origin', 'fetch_file_url', 'img_file_url', 'fetch', 'img_detached', 'webrtc_stun', 'top_document', 'parent_document', 'top_location_assign', 'window_open', 'localStorage_shim', 'indexedDB_open_qft-markdown', 'document_cookie', 'alert', 'fullscreen', 'eval', 'inline_script_with_copied_nonce (eval-equivalent)', 'worker_blob', 'iframe_blob', 'wasm'];
    out.probe = Object.fromEntries(keys.map((k) => [k, r[k]]));
    out.frames = p2.frames().map((f) => f.url().slice(0, 40)); out.status = await p2.locator('#status').textContent();
    out.evil = evil.log.map((e) => `${e.method} ${e.url}`); out.stunDatagrams = udp.log.length; out.dialogs = dialogs;
  } finally { await browser.close(); await Promise.all([site.close(), evil.close(), udp.close()]); fs.writeFileSync(path.join(__dirname, 'logs', 'exp14-export.json'), JSON.stringify(out, null, 2)); }
  console.log(JSON.stringify(out, null, 1));
})().catch((e) => { console.error(e); process.exit(1); });
