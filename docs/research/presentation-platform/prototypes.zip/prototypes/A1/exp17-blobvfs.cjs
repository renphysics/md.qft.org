// EXP17: extension-point feasibility. Same frame topology as the player (page -> sandboxed runner
// -> sandboxed blob: child, two different opaque origins). Can the CHILD load files through blob:
// URLs that the RUNNER created (a "virtual file system" with no service worker and no inlining)?
const fs = require('node:fs'); const path = require('node:path');
const { chromium } = require('playwright'); const L = require('./lib.cjs');
const csp = "default-src 'none'; script-src 'unsafe-inline' blob:; style-src 'unsafe-inline' blob:; img-src data: blob:; font-src data: blob:; media-src data: blob:; connect-src blob:; frame-src blob:; worker-src blob:";
const png = 'iVBORw0KGgoAAAANSUhEUgAAAAIAAAACCAYAAABytg0kAAAAFElEQVR42mP8z8Dwn4EIwDiqEF8IAHvRAv4X2z5JAAAAAElFTkSuQmCC';
const runner = `<!doctype html><html><head><meta http-equiv="Content-Security-Policy" content="${csp}"></head><body><script>
(() => {
  const url = (text, type) => URL.createObjectURL(new Blob([text], { type }));
  const bytes = Uint8Array.from(atob('${png}'), (c) => c.charCodeAt(0));
  const files = {
    img: URL.createObjectURL(new Blob([bytes], { type: 'image/png' })),
    css: url('#styled{color:rgb(1,2,3)}', 'text/css'),
    classic: url('window.__classic = "classic script ran";', 'text/javascript'),
    json: url('{"answer":42}', 'application/json'),
  };
  files.dep = url('export const dep = "dependency module";', 'text/javascript');
  files.mod = url('import { dep } from ' + JSON.stringify(files.dep) + '; window.__module = "module ran with " + dep;', 'text/javascript');
  files.lazy = url('export default "lazy chunk";', 'text/javascript');
  files.worker = url('postMessage("worker ran")', 'text/javascript');
  const child = '<!doctype html><html><head><link rel="stylesheet" href="' + files.css + '"></head><body><p id="styled">x</p><img id="i" src="' + files.img + '">'
    + '<script src="' + files.classic + '"></scr' + 'ipt><script type="module" src="' + files.mod + '"></scr' + 'ipt>'
    + '<script>addEventListener("load", async () => { const R = { origin: self.origin };'
    + 'R.img = document.getElementById("i").naturalWidth ? "loaded " + document.getElementById("i").naturalWidth + "px" : "FAILED";'
    + 'R.css = getComputedStyle(document.getElementById("styled")).color;'
    + 'R.classic = window.__classic || "FAILED";'
    + 'await new Promise((r) => setTimeout(r, 300)); R.module = window.__module || "FAILED";'
    + 'try { R.fetch = JSON.stringify(await (await fetch(' + JSON.stringify(files.json) + ')).json()); } catch (e) { R.fetch = "FAILED " + e.message; }'
    + 'try { R.dynamicImport = (await import(' + JSON.stringify(files.lazy) + ')).default; } catch (e) { R.dynamicImport = "FAILED " + e.message; }'
    + 'R.worker = await new Promise((resolve) => { try { const w = new Worker(' + JSON.stringify(files.worker) + '); w.onmessage = (e) => resolve(e.data); w.onerror = () => resolve("FAILED error event"); setTimeout(() => resolve("FAILED timeout"), 1500); } catch (e) { resolve("FAILED " + e.message); } });'
    + 'try { const own = URL.createObjectURL(new Blob(["own"])); R.ownBlobFetch = await (await fetch(own)).text(); } catch (e) { R.ownBlobFetch = "FAILED " + e.message; }'
    + 'parent.postMessage({ a1: R }, "*"); });</scr' + 'ipt></body></html>';
  addEventListener('message', (event) => { if (event.data && event.data.a1) parent.postMessage({ a1: event.data.a1, runnerOrigin: self.origin }, '*'); });
  const frame = document.createElement('iframe'); frame.setAttribute('sandbox', 'allow-scripts'); frame.style.cssText = 'width:300px;height:100px';
  frame.src = url(child, 'text/html'); document.body.append(frame);
})();
</script></body></html>`;
const host = `<!doctype html><html><body><script>
addEventListener('message', (event) => { if (event.data && event.data.a1) window.__r = event.data; });
const f = document.createElement('iframe'); f.setAttribute('sandbox', 'allow-scripts'); f.src = '/__a1/runner.html'; document.body.append(f);
</script></body></html>`;
(async () => {
  const site = await L.startSite(4400, { '/__a1/runner.html': { type: 'text/html', body: runner }, '/__a1/vfs-host.html': { type: 'text/html', body: host } });
  const out = {};
  try {
    for (const channel of ['chromium', undefined]) {
      const browser = await chromium.launch(channel ? { channel } : {});
      const page = await browser.newPage(); const consoleErrors = []; page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(m.text().slice(0, 180)); });
      await page.goto('http://127.0.0.1:4400/__a1/vfs-host.html');
      const r = await L.until(() => page.evaluate(() => window.__r), 'result', 15000).catch((e) => ({ error: e.message }));
      out[channel ? 'full Chromium' : 'headless shell'] = { ...r, consoleErrors: consoleErrors.slice(0, 6) };
      await browser.close();
    }
  } finally { await site.close(); fs.writeFileSync(path.join(__dirname, 'logs', 'exp17-blobvfs.json'), JSON.stringify(out, null, 2)); }
  console.log(JSON.stringify(out, null, 1));
})().catch((e) => { console.error(e); process.exit(1); });
