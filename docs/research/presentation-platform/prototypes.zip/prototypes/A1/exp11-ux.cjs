// EXP11: UX defects around the player and the library.
const fs = require('node:fs'); const path = require('node:path');
const { chromium } = require('playwright'); const L = require('./lib.cjs');
const base = 'http://127.0.0.1:4400/';
const page1 = (bodyHtml, script = '') => `<!doctype html><html lang="en"><head><style>body{font:18px system-ui;padding:30px}</style></head><body>${bodyHtml}<script>${script}</script></body></html>`;
const simple = page1('<h1>Simple deck</h1>');
const lateError = page1('<h1>Deck that fails after four seconds</h1>', `setTimeout(()=>{throw new Error('late failure while presenting')},4000)`);
const example = fs.readFileSync('/home/user/md.qft.org/dist/slidev/interactive-physics.zip');
const shots = path.join(__dirname, 'shots');

(async () => {
  const site = await L.startSite(4400); const browser = await chromium.launch({ channel: 'chromium' });
  const out = {};
  const fresh = async () => { const context = await browser.newContext({ viewport: { width: 1300, height: 900 } }); const page = await context.newPage(); await L.openWorkspace(page, base); return { context, page }; };
  const waitDeck = (page) => page.locator('[data-pres-start-button]').waitFor({ state: 'visible', timeout: 20000 });
  const libraryRows = async (page) => { await page.locator('[data-pres-back]').click(); await L.sleep(500); return page.evaluate(() => ({ count: document.querySelector('[data-pres-count]').textContent, rows: [...document.querySelectorAll('.presentation-saved-open')].map((el) => el.textContent.trim().replace(/\s+/g, ' ')) })); };
  try {
    { // (a) the same ZIP opened twice, and the built-in example opened twice
      const { context, page } = await fresh();
      const zip = L.makePackage(simple, { manifest: { title: 'Same deck' } });
      await L.openFile(page, zip, 'same.zip'); await waitDeck(page); await L.until(async () => /Saved/.test((await L.dialogState(page)).storage), 'saved');
      await page.locator('[data-pres-close]').click(); await L.sleep(600);
      await L.openFile(page, zip, 'same.zip'); await waitDeck(page); await L.until(async () => /Saved/.test((await L.dialogState(page)).storage), 'saved');
      out.sameZipTwice = await libraryRows(page);
      await page.locator('[data-pres-example]').click(); await waitDeck(page); await L.until(async () => /Saved/.test((await L.dialogState(page)).storage), 'saved');
      await page.locator('[data-pres-back]').click(); await L.sleep(300);
      await page.locator('[data-pres-example]').click(); await waitDeck(page); await L.until(async () => /Saved/.test((await L.dialogState(page)).storage), 'saved');
      out.exampleTwice = await libraryRows(page);
      out.storageAfter = await page.evaluate(async () => { const e = await navigator.storage.estimate(); return `${(e.usage / 1048576).toFixed(1)} MiB used`; });
      await context.close();
    }
    { // (k) the documented deep link stores another copy on every visit
      const { context, page } = await fresh();
      for (let i = 0; i < 2; i++) { await page.goto(`${base}?presentation=slidev-example`); await waitDeck(page); await L.until(async () => /Saved/.test((await L.dialogState(page)).storage), 'saved'); }
      out.deepLinkTwice = await libraryRows(page);
      await context.close();
    }
    { // (b) a failure while in host fullscreen: what does the presenter see?
      const { context, page } = await fresh();
      await L.openFile(page, L.makePackage(lateError, { manifest: { title: 'Late failure' } }), 'late.zip'); await waitDeck(page);
      await page.locator('[data-pres-present]').click();
      await L.until(async () => (await L.dialogState(page)).status === 'Playing locally', 'ready', 15000);
      out.fullscreenWhilePlaying = await page.evaluate(() => document.fullscreenElement?.className ?? null);
      await L.until(async () => (await L.dialogState(page)).status === 'Playback needs attention', 'error', 15000);
      await L.sleep(400);
      out.failureInFullscreen = await page.evaluate(() => {
        const stage = document.querySelector('[data-pres-stage]'); const notice = document.querySelector('[data-pres-notice]'); const status = document.querySelector('[data-pres-player-status]');
        const visibleIn = (el) => stage.contains(el);
        return { stillFullscreen: document.fullscreenElement === stage, noticeText: notice.textContent, noticeInsideFullscreenElement: visibleIn(notice), statusInsideFullscreenElement: visibleIn(status), stageText: stage.innerText.replace(/\s+/g, ' ').trim().slice(0, 200) };
      });
      await page.screenshot({ path: path.join(shots, 'exp11-error-in-fullscreen.png') });
      await context.close();
    }
    { // (c) start, then the tab goes to the background before the handshake
      const { context, page } = await fresh();
      await L.openFile(page, example, 'example.zip'); await waitDeck(page);
      const other = await context.newPage();
      await page.bringToFront();
      // Click Start and hide the tab at once.
      await page.locator('[data-pres-start-button]').click();
      await other.bringToFront();
      const visibility = await page.evaluate(() => document.visibilityState);
      const timeline = []; let last = ''; const t0 = Date.now();
      while (Date.now() - t0 < 24000) { const s = await L.dialogState(page); const key = `${s.status}|${s.notice}`; if (key !== last) { last = key; timeline.push(`${Date.now() - t0}ms ${s.status}${s.notice ? ' | ' + s.notice : ''}`); } await L.sleep(250); }
      out.backgroundTab = { visibilityAfterSwitch: visibility, timeline };
      await context.close();
    }
    { // (d) Escape with focus on the dialog chrome while a deck is running
      const { context, page } = await fresh();
      await L.openFile(page, example, 'example.zip'); await waitDeck(page);
      await page.locator('[data-pres-start-button]').click();
      await L.until(async () => (await L.dialogState(page)).status === 'Playing locally', 'ready', 20000);
      await page.locator('[data-pres-view="preview"]').focus();
      await page.keyboard.press('Escape'); await L.sleep(500);
      const s = await L.dialogState(page);
      out.escapeOnChrome = { dialogOpen: s.dialogOpen, frames: s.frames };
      await context.close();
    }
    { // (e)+(f) library file picker with a non-presentation ZIP; source viewer facts
      const { context, page } = await fresh();
      await page.locator('[data-open-presentations]').click(); await page.locator('[data-pres-library]').waitFor({ state: 'visible' });
      await page.locator('[data-pres-input]').setInputFiles({ name: 'reveal-with-readme.zip', mimeType: 'application/zip', buffer: L.makeZip({ 'index.html': '<html><body>x</body></html>', 'js/app.js': '1', 'README.md': '# readme' }) });
      await L.sleep(1200);
      out.libraryPickerNonPresentation = (await L.dialogState(page)).notice;
      await page.locator('[data-pres-input]').setInputFiles({ name: 'example.zip', mimeType: 'application/zip', buffer: example }); await waitDeck(page);
      await page.locator('[data-pres-view="source"]').click();
      out.sourceViewer = await page.evaluate(() => {
        const select = document.querySelector('[data-pres-file]'); const area = document.querySelector('[data-pres-source-text]');
        const options = [...select.options].map((o) => o.textContent);
        select.value = 'presentation.html'; select.dispatchEvent(new Event('change'));
        return { files: options.length, firstFiles: options.slice(0, 4), readonly: area.readOnly, tag: area.tagName, entryShownAs: area.value.slice(0, 90), note: document.querySelector('.presentation-source-note').textContent.trim() };
      });
      await page.locator('[data-pres-source-text]').click(); await page.keyboard.type('EDIT');
      out.sourceViewer.afterTyping = await page.evaluate(() => document.querySelector('[data-pres-source-text]').value.includes('EDIT'));
      await page.screenshot({ path: path.join(shots, 'exp11-source-tab.png') });
      await context.close();
    }
  } finally { await browser.close(); await site.close(); fs.writeFileSync(path.join(__dirname, 'logs', 'exp11-ux.json'), JSON.stringify(out, null, 2)); }
  console.log(JSON.stringify(out, null, 1));
})().catch((e) => { console.error(e); process.exit(1); });
