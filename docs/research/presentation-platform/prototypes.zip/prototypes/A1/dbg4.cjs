const { chromium } = require('playwright'); const L = require('./lib.cjs');
const page1 = (b) => `<!doctype html><html lang="en"><head></head><body>${b}</body></html>`;
(async () => {
  const site = await L.startSite(4400); const browser = await chromium.launch({ channel: process.argv[2] === 'shell' ? undefined : 'chromium' });
  try {
    const page = await (await browser.newContext({ viewport: { width: 1300, height: 900 } })).newPage();
    page.on('console', (m) => { if (m.type() === 'error') console.log('console:', m.text().slice(0, 200)); });
    page.on('pageerror', (e) => console.log('pageerror:', e.message));
    await L.openWorkspace(page, 'http://127.0.0.1:4400/');
    const zip = L.makePackage(page1('<h1>Simple deck</h1>'), { manifest: { title: 'Same deck' } });
    await L.openFile(page, zip, 'same.zip');
    await page.locator('[data-pres-start-button]').waitFor({ state: 'visible', timeout: 20000 });
    await L.until(async () => /Saved/.test((await L.dialogState(page)).storage), 'saved');
    console.log('1st:', JSON.stringify(await L.dialogState(page)).slice(0, 330));
    await page.locator('[data-pres-close]').click(); await L.sleep(500);
    console.log('closed:', JSON.stringify(await L.dialogState(page)).slice(0, 330));
    await L.openFile(page, zip, 'same.zip'); await L.sleep(2500);
    const s = await L.dialogState(page);
    console.log('2nd:', JSON.stringify(s).slice(0, 400));
    console.log('toast:', await page.locator('[data-toast]').evaluate((el) => (el.hidden ? null : el.textContent)));
    console.log('active element:', await page.evaluate(() => document.activeElement?.outerHTML.slice(0, 120)));
  } finally { await browser.close(); await site.close(); }
})().catch((e) => { console.error(e); process.exit(1); });
