// EXP1b: additional capability-map edge cases (same method as EXP1).
const fs = require('node:fs'); const path = require('node:path');
const { chromium } = require('playwright'); const L = require('./lib.cjs');
const ok = '<!doctype html><html lang="en"><head></head><body><h1>ok</h1></body></html>';
const { zipSync, strToU8 } = require('/home/user/md.qft.org/node_modules/fflate');
// A ZIP whose file name is Latin-1 "résumé.md" WITHOUT the UTF-8 flag (as older Windows tools write it).
function legacyNameZip() {
  const buffer = Buffer.from(zipSync({ 'qft-presentation.json': strToU8(JSON.stringify(L.baseManifest)), 'presentation.html': strToU8(ok), 'source/rXsumX.md': strToU8('# x') }, { level: 0 }));
  let patched = 0;
  for (let i = 0; i < buffer.length - 9; i++) if (buffer.toString('latin1', i, i + 9) === 'rXsumX.md') { buffer[i + 1] = 0xe9; buffer[i + 5] = 0xe9; patched++; }
  return buffer;
}
const cases = [
  { id: 'markdown-zip-with-slides.md-and-a-.vue-file', buffer: L.makeZip({ 'slides.md': '# My notes\n\n---\n\n# Two\n', 'snippets/Example.vue': '<template><p>code sample</p></template>' }) },
  { id: 'manifest-source-is-html', buffer: L.makePackage(ok, { manifest: { source: 'source/index.html' }, files: { 'source/index.html': ok } }) },
  { id: 'manifest-extra-property-(schema-forbids)', buffer: L.makePackage(ok, { manifest: { theme: 'dark', engineVersion: '53.1.0' } }), start: true },
  { id: 'manifest-aspectRatio-16:10', buffer: L.makePackage(ok, { manifest: { aspectRatio: '16:10' } }) },
  { id: 'manifest-title-201-chars', buffer: L.makePackage(ok, { manifest: { title: 'x'.repeat(201) } }) },
  { id: 'backslash-path-in-package', buffer: L.makePackage(ok, { files: { 'source\\slides.md': '# x' } }) },
  { id: 'legacy-non-utf8-filename-in-package', buffer: legacyNameZip() },
  { id: 'two-manifests', buffer: L.makeZip({ 'a/qft-presentation.json': JSON.stringify(L.baseManifest), 'a/presentation.html': ok, 'b/qft-presentation.json': JSON.stringify(L.baseManifest), 'b/presentation.html': ok }) },
  { id: 'qft.json-and-index.html+js (lesson wins)', buffer: L.makeZip({ 'qft.json': '{}', 'index.html': ok, 'app.js': '1' }) },
  { id: 'html-entry-in-utf16', buffer: L.makePackage(Buffer.from('﻿' + ok, 'utf16le')) },
  { id: 'empty-zip', buffer: L.makeZip({}) },
];
(async () => {
  const site = await L.startSite(4400); const browser = await chromium.launch(); const results = [];
  try {
    for (const item of cases) {
      const context = await browser.newContext({ viewport: { width: 1440, height: 1000 } }); const page = await context.newPage();
      await L.openWorkspace(page, 'http://127.0.0.1:4400/');
      await L.openFile(page, item.buffer, 'case.zip');
      await L.until(async () => { const s = await L.dialogState(page); const toast = await page.locator('[data-toast]').evaluate((el) => (el.hidden ? '' : el.textContent.trim())); return (s.dialogOpen && s.deckHidden === false) || toast; }, 'settle', 10000).catch(() => {});
      await L.sleep(500);
      const s = await L.dialogState(page); const toast = await page.locator('[data-toast]').evaluate((el) => (el.hidden ? null : el.textContent.trim()));
      let started = null;
      if (item.start && s.deckHidden === false) { await page.locator('[data-pres-start-button]').click(); await L.sleep(1200); const a = await L.dialogState(page); started = `${a.status}${a.notice ? ' | ' + a.notice : ''}`; }
      const r = { id: item.id, deckShown: s.dialogOpen && s.deckHidden === false, toast, started }; results.push(r);
      console.log(`${item.id}\n    deckShown=${r.deckShown} toast=${JSON.stringify(toast)}${started ? ' START -> ' + started : ''}`);
      await context.close();
    }
  } finally { await browser.close(); await site.close(); fs.writeFileSync(path.join(__dirname, 'logs', 'exp1b-capability-extra.json'), JSON.stringify(results, null, 2)); }
})().catch((e) => { console.error(e); process.exit(1); });
