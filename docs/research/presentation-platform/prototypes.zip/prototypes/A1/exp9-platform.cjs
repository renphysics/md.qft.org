// EXP9: platform facts that bound the extension points.
//  A. Under the editor's real CSP (dist/index.html): can WebAssembly run in the page, in a blob
//     worker, in a same-origin network worker? Can a service worker be registered?
//  B. Can a same-origin service worker serve a virtual file system into a sandboxed
//     (opaque-origin) iframe? Compared with allow-same-origin and with no sandbox.
const fs = require('node:fs'); const path = require('node:path');
const { chromium } = require('playwright'); const L = require('./lib.cjs');

const wasmBytes = '[0,97,115,109,1,0,0,0]';
const workerJs = `self.onmessage = async () => { try { await WebAssembly.instantiate(new Uint8Array(${wasmBytes})); postMessage('wasm OK in network worker'); } catch (e) { postMessage('wasm BLOCKED in network worker: ' + e.message.slice(0, 90)); } };`;
const swJs = `
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (event) => event.waitUntil(self.clients.claim()));
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);
  if (!url.pathname.startsWith('/__a1/vfs/')) return;
  const name = url.pathname.slice('/__a1/vfs/'.length);
  if (name === 'index.html') event.respondWith(new Response('<!doctype html><html><body><p>served by service worker</p><script src="app.js"></scr' + 'ipt><script>var storage;try{localStorage.setItem("x","1");storage="storage-ok"}catch(e){storage="storage-blocked"};parent.postMessage({kind:"vfs",label:location.search.slice(1),origin:self.origin,app:window.__app||"app.js NOT served",storage:storage,controller:!!(navigator.serviceWorker&&navigator.serviceWorker.controller)},"*")</scr' + 'ipt></body></html>', { headers: { 'content-type': 'text/html' } }));
  else if (name === 'app.js') event.respondWith(new Response('window.__app="app.js served by service worker"', { headers: { 'content-type': 'text/javascript' } }));
});`;
const hostHtml = `<!doctype html><html><head><meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob: https:; font-src 'self' data:; connect-src 'self' https: blob:; worker-src 'self' blob:; frame-src 'self'; object-src 'none'; base-uri 'self'; form-action 'none'"></head><body><script>
(async () => {
  const R = window.__r = { frames: {} };
  try {
    const registration = await navigator.serviceWorker.register('/__a1/sw.js', { scope: '/__a1/' });
    await navigator.serviceWorker.ready;
    if (!navigator.serviceWorker.controller) await new Promise((resolve) => navigator.serviceWorker.addEventListener('controllerchange', resolve, { once: true }));
    R.sw = 'registered, scope ' + registration.scope + ', controlling=' + !!navigator.serviceWorker.controller;
  } catch (e) { R.sw = 'FAILED ' + e.name + ': ' + e.message; R.done = true; return; }
  addEventListener('message', (event) => { if (event.data && event.data.kind === 'vfs') R.frames[event.data.label] = event.data; });
  const variants = { 'no-sandbox': null, 'sandbox-allow-scripts': 'allow-scripts', 'sandbox-allow-scripts-allow-same-origin': 'allow-scripts allow-same-origin' };
  for (const [label, sandbox] of Object.entries(variants)) {
    const frame = document.createElement('iframe');
    if (sandbox !== null) frame.setAttribute('sandbox', sandbox);
    frame.src = '/__a1/vfs/index.html?' + label;
    const loaded = new Promise((resolve) => { frame.onload = () => resolve('load'); setTimeout(() => resolve('timeout'), 4000); });
    document.body.append(frame);
    const how = await loaded; await new Promise((r) => setTimeout(r, 500));
    if (!R.frames[label]) R.frames[label] = { result: 'no message from frame (' + how + ')' };
  }
  R.done = true;
})();
</script></body></html>`;

(async () => {
  const site = await L.startSite(4400, {
    '/__a1/worker.js': { type: 'text/javascript', body: workerJs },
    '/__a1/sw.js': { type: 'text/javascript', body: swJs, headers: { 'service-worker-allowed': '/' } },
    '/__a1/host.html': { type: 'text/html', body: hostHtml },
  });
  const out = {};
  try {
    for (const channel of ['chromium']) {
      const browser = await chromium.launch({ channel });
      const context = await browser.newContext();
      const page = await context.newPage();
      const consoleErrors = []; page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(m.text().slice(0, 200)); });
      // --- A: the real editor page and its CSP -------------------------------------------------
      await L.openWorkspace(page, 'http://127.0.0.1:4400/');
      out.editor = await page.evaluate(async (bytes) => {
        const R = {};
        try { await WebAssembly.instantiate(new Uint8Array(bytes)); R.wasmMain = 'OK'; } catch (e) { R.wasmMain = 'BLOCKED: ' + e.message.slice(0, 140); }
        R.wasmBlobWorker = await new Promise((resolve) => {
          try {
            const w = new Worker(URL.createObjectURL(new Blob([`(async()=>{try{await WebAssembly.instantiate(new Uint8Array([${bytes}]));postMessage('wasm OK in blob worker')}catch(e){postMessage('wasm BLOCKED in blob worker: '+e.message.slice(0,90))}})()`], { type: 'text/javascript' })));
            w.onmessage = (e) => resolve(e.data); w.onerror = (e) => resolve('worker error: ' + e.message); setTimeout(() => resolve('timeout'), 3000);
          } catch (e) { resolve('THROW ' + e.message); }
        });
        R.wasmNetworkWorker = await new Promise((resolve) => {
          try { const w = new Worker('/__a1/worker.js'); w.onmessage = (e) => resolve(e.data); w.onerror = (e) => resolve('worker error: ' + e.message); w.postMessage(1); setTimeout(() => resolve('timeout'), 3000); }
          catch (e) { resolve('THROW ' + e.message); }
        });
        try { const reg = await navigator.serviceWorker.register('/__a1/sw.js', { scope: '/__a1/' }); R.serviceWorkerRegister = 'OK scope=' + reg.scope; await reg.unregister(); } catch (e) { R.serviceWorkerRegister = 'FAILED ' + e.name + ': ' + e.message.slice(0, 120); }
        try { new Function('return 1')(); R.evalMain = 'OK'; } catch (e) { R.evalMain = 'BLOCKED'; }
        R.crossOriginIsolated = crossOriginIsolated; R.sharedArrayBuffer = typeof SharedArrayBuffer;
        return R;
      }, [0, 97, 115, 109, 1, 0, 0, 0]);
      out.editorConsole = consoleErrors.splice(0).slice(0, 4);
      // --- B: service worker VFS into frames -------------------------------------------------------
      const page2 = await context.newPage();
      page2.on('console', (m) => console.log('  [host.html console]', m.type(), m.text().slice(0, 200)));
      page2.on('pageerror', (e) => console.log('  [host.html pageerror]', e.message.slice(0, 200)));
      await page2.goto('http://127.0.0.1:4400/__a1/host.html');
      await L.until(() => page2.evaluate(() => window.__r && window.__r.done), 'host done', 20000).catch(async (e) => { console.log('  host.html state:', JSON.stringify(await page2.evaluate(() => window.__r))); });
      out.serviceWorkerVfs = await page2.evaluate(() => window.__r);
      await browser.close();
    }
  } finally { await site.close(); fs.writeFileSync(path.join(__dirname, 'logs', 'exp9-platform.json'), JSON.stringify(out, null, 2)); }
  console.log(JSON.stringify(out, null, 1));
})().catch((e) => { console.error(e); process.exit(1); });
