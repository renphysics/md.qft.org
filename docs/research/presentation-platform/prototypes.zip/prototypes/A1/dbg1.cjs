const fs = require('node:fs'); const path = require('node:path');
const { chromium } = require('playwright'); const L = require('./lib.cjs');
const html = fs.readFileSync(path.join(__dirname, 'hostile-battery.html'), 'utf8').replaceAll('__EVIL__', 4401).replaceAll('__SITE__', 4400).replaceAll('__TCP__', 4402).replaceAll('__UDP__', 4403).replaceAll('__LANIP__', '192.0.2.2');
(async () => {
  const site = await L.startSite(4400); const browser = await chromium.launch();
  try {
    const page = await (await browser.newContext()).newPage();
    page.on('console', (m) => console.log('console', m.type(), m.text().slice(0, 300)));
    await L.openWorkspace(page, 'http://127.0.0.1:4400/');
    await L.openFile(page, L.makePackage(html), 'hostile.zip');
    await page.locator('[data-pres-start-button]').waitFor({ state: 'visible', timeout: 15000 });
    await page.locator('[data-pres-start-button]').click();
    for (let i = 0; i < 6; i++) { await L.sleep(500); console.log(JSON.stringify(await L.dialogState(page)).slice(0, 500)); console.log(page.frames().map((f) => f.url().slice(0, 80))); }
  } finally { await browser.close(); await site.close(); }
})();
