// EXP1: capability map. Feed many kinds of input through the real "Open file" control
// of the production build and record exactly what the UI says.
const fs = require('node:fs');
const path = require('node:path');
const { chromium } = require('playwright');
const L = require('./lib.cjs');

const SITE = 4400;
const base = `http://127.0.0.1:${SITE}/`;
const here = __dirname;
const SHARED = path.resolve(here, '../../shared');
const reveal = '/home/user/md.qft.org/node_modules/reveal.js/dist';
const read = (file) => new Uint8Array(fs.readFileSync(file));

const revealIndex = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Reveal multi-file</title>
<link rel="stylesheet" href="dist/reset.css">
<link rel="stylesheet" href="dist/reveal.css">
<link rel="stylesheet" href="dist/theme/black.css">
</head>
<body>
<div class="reveal"><div class="slides">
<section><h1>Slide 1</h1><p class="fragment">Fragment</p></section>
<section><h2>Slide 2</h2><img src="assets/logo.svg" alt="logo"><button id="b">Click</button> <span id="count">0</span></section>
</div></div>
<script src="dist/reveal.js"></script>
<script src="dist/plugin/notes.js"></script>
<script>Reveal.initialize({ hash: true, plugins: [RevealNotes] });</script>
</body></html>`;
const revealFiles = {
  'index.html': revealIndex,
  'dist/reset.css': read(`${reveal}/reset.css`), 'dist/reveal.css': read(`${reveal}/reveal.css`),
  'dist/theme/black.css': read(`${reveal}/theme/black.css`), 'dist/reveal.js': read(`${reveal}/reveal.js`),
  'dist/plugin/notes.js': read(`${reveal}/plugin/notes.js`),
  'assets/logo.svg': '<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64"><circle cx="32" cy="32" r="30" fill="tomato"/></svg>',
};
const revealCdn = `<!doctype html><html><head><meta charset="utf-8"><title>CDN deck</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/reveal.js@6.0.2/dist/reveal.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/reveal.js@6.0.2/dist/theme/black.css"></head>
<body><div class="reveal"><div class="slides"><section>One</section><section>Two</section></div></div>
<script src="https://cdn.jsdelivr.net/npm/reveal.js@6.0.2/dist/reveal.js"></script><script>Reveal.initialize();</script></body></html>`;

const slidevDist = L.zipDirectory(`${SHARED}/slidev-ordinary/dist`);
const slidevSource = {
  'slides.md': fs.readFileSync(`${SHARED}/slidev-ordinary/slides.md`, 'utf8'),
  'package.json': fs.readFileSync(`${SHARED}/slidev-ordinary/package.json`, 'utf8'),
  ...L.zipDirectory(`${SHARED}/slidev-ordinary/components`, 'components/'),
};
const example = fs.readFileSync('/home/user/md.qft.org/dist/slidev/interactive-physics.zip');
const selfContained = '<!doctype html><html lang="en"><head><style>body{font:20px system-ui;padding:40px}</style></head><body><h1 id="h">Self-contained</h1><button id="b">+1</button> <output id="o">0</output><script>let n=0;document.getElementById("b").addEventListener("click",()=>{document.getElementById("o").textContent=++n});</script></body></html>';

const big = path.join(here, 'out', 'over-60MiB.zip');
if (!fs.existsSync(big)) { const fd = fs.openSync(big, 'w'); fs.ftruncateSync(fd, 60 * 1024 * 1024 + 1); fs.closeSync(fd); }
const manyEntries = Object.fromEntries(Array.from({ length: 1001 }, (_, i) => [`f/${i}.txt`, 'x']));

const cases = [
  { id: 'example-slidev-portable', name: 'interactive-physics.zip', buffer: example, start: true },
  { id: 'reveal-multifile', name: 'reveal-deck.zip', buffer: L.makeZip(revealFiles) },
  { id: 'reveal-multifile-in-folder', name: 'reveal-deck.zip', buffer: L.makeZip(Object.fromEntries(Object.entries(revealFiles).map(([k, v]) => [`my-deck/${k}`, v]))) },
  { id: 'reveal-multifile+README.md', name: 'reveal-deck.zip', buffer: L.makeZip({ ...revealFiles, 'README.md': '# My Reveal deck\n\nOpen index.html in a browser.\n' }) },
  { id: 'reveal-multifile+2md', name: 'reveal-deck.zip', buffer: L.makeZip({ ...revealFiles, 'README.md': '# My Reveal deck\n', 'slides/extra.md': '## External markdown slide\n' }) },
  { id: 'reveal-single-html-cdn-zip', name: 'reveal-cdn.zip', buffer: L.makeZip({ 'index.html': revealCdn }) },
  { id: 'reveal-single-html-cdn-bare-html', name: 'index.html', buffer: Buffer.from(revealCdn), mime: 'text/html' },
  { id: 'slidev-dist', name: 'slidev-dist.zip', buffer: L.makeZip(slidevDist) },
  { id: 'slidev-dist-in-dist-folder', name: 'slidev-dist.zip', buffer: L.makeZip(Object.fromEntries(Object.entries(slidevDist).map(([k, v]) => [`dist/${k}`, v]))) },
  { id: 'slidev-source-only', name: 'slidev-src.zip', buffer: L.makeZip(slidevSource) },
  { id: 'slidev-source+dist', name: 'slidev-both.zip', buffer: L.makeZip({ ...slidevSource, ...Object.fromEntries(Object.entries(slidevDist).map(([k, v]) => [`dist/${k}`, v])) }) },
  { id: 'slidev-slides.md-only', name: 'slides.zip', buffer: L.makeZip({ 'slides.md': slidevSource['slides.md'] }) },
  { id: 'qft-presentation-selfcontained-html', name: 'self.zip', buffer: L.makePackage(selfContained), start: true },
  { id: 'qft-presentation-engine-reveal', name: 'engine.zip', buffer: L.makePackage(selfContained, { manifest: { engine: 'reveal' } }) },
  { id: 'qft-presentation-version-2', name: 'v2.zip', buffer: L.makePackage(selfContained, { manifest: { version: 2 } }) },
  { id: 'qft-presentation-multifile-entry(script src)', name: 'multi.zip', buffer: L.makePackage(revealIndex, { files: Object.fromEntries(Object.entries(revealFiles).filter(([k]) => k !== 'index.html')) }), start: true },
  { id: 'qft-presentation-cdn-entry', name: 'cdn.zip', buffer: L.makePackage(revealCdn), start: true },
  { id: 'qft-presentation-external-img', name: 'img.zip', buffer: L.makePackage('<!doctype html><html><body><img src="assets/logo.svg"><p>x</p></body></html>', { files: { 'assets/logo.svg': revealFiles['assets/logo.svg'] } }), start: true },
  { id: 'qft-presentation-iframe', name: 'iframe.zip', buffer: L.makePackage('<!doctype html><html><body><iframe src="https://www.youtube.com/embed/x"></iframe></body></html>'), start: true },
  { id: 'qft-presentation-entry-missing', name: 'missing.zip', buffer: L.makePackage(selfContained, { manifest: { entry: 'index.html' } }) },
  { id: 'qft-presentation-fragment-entry(no html/body tags)', name: 'fragment.zip', buffer: L.makePackage('<div>Just a fragment</div><script>1</script>') },
  { id: 'qft-presentation-file-outside-folder', name: 'outside.zip', buffer: L.makeZip({ 'deck/qft-presentation.json': JSON.stringify(L.baseManifest), 'deck/presentation.html': selfContained, 'notes.txt': 'outside' }) },
  { id: 'qft-presentation-percent-in-filename', name: 'percent.zip', buffer: L.makePackage(selfContained, { files: { 'source/100%.md': '# x' } }) },
  { id: 'not-a-zip-renamed', name: 'fake.zip', buffer: Buffer.from('this is not a zip archive at all, just text') },
  { id: 'zip-1001-entries-no-manifest', name: 'many.zip', buffer: L.makeZip(manyEntries, 0) },
  { id: 'zip-over-60MiB', name: 'over-60MiB.zip', path: big },
  { id: 'markdown-plus-image-zip', name: 'notes.zip', buffer: L.makeZip({ 'notes.md': '# Notes\n\n![p](p.png)\n', 'p.png': Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64') }) },
];

(async () => {
  const site = await L.startSite(SITE);
  const browser = await chromium.launch();
  const results = [];
  try {
    for (const item of cases) {
      const context = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
      const page = await context.newPage();
      const consoleErrors = [];
      page.on('console', (message) => { if (message.type() === 'error') consoleErrors.push(message.text().slice(0, 300)); });
      page.on('pageerror', (error) => consoleErrors.push(`pageerror: ${error.message}`.slice(0, 300)));
      await L.openWorkspace(page, base);
      const before = await page.evaluate(() => document.querySelectorAll('[data-documents] [data-id], [data-documents] li').length);
      const t0 = Date.now();
      if (item.path) await page.locator('[data-file-input]').setInputFiles(item.path);
      else await L.openFile(page, item.buffer, item.name, item.mime);
      // Settle: either the presentation dialog shows a deck, or a toast appears, or a new document opens.
      await L.until(async () => {
        const s = await L.dialogState(page);
        const toast = await page.locator('[data-toast]').evaluate((el) => (el.hidden ? '' : el.textContent.trim()));
        return (s.dialogOpen && s.deckHidden === false) || toast || (s.dialogOpen && s.notice);
      }, 'settle', 12000).catch(() => {});
      await L.sleep(700);
      const afterImport = await L.dialogState(page);
      const toast = await page.locator('[data-toast]').evaluate((el) => (el.hidden ? null : el.textContent.trim()));
      const editorText = await page.locator('.cm-content').first().innerText().then((text) => text.slice(0, 120)).catch(() => null);
      const importMs = Date.now() - t0;
      let afterStart = null;
      let startMs = null;
      if (item.start && afterImport.dialogOpen && afterImport.deckHidden === false) {
        const t1 = Date.now();
        await page.locator('[data-pres-start-button]').click();
        await L.until(async () => {
          const s = await L.dialogState(page);
          return s.status === 'Playing locally' || s.status === 'Playback needs attention';
        }, 'start result', 26000).catch(() => {});
        startMs = Date.now() - t1;
        await L.sleep(400);
        afterStart = await L.dialogState(page);
      }
      const saved = await page.evaluate(async () => {
        const dbs = await indexedDB.databases();
        return dbs.map((db) => db.name);
      });
      results.push({ id: item.id, file: item.name, bytes: item.buffer ? item.buffer.length : fs.statSync(item.path).size, importMs, toast, editorText, afterImport, startMs, afterStart, databases: saved, consoleErrors });
      const r = results.at(-1);
      console.log(`\n### ${item.id} (${r.bytes} bytes)`);
      console.log(`  dialogOpen=${afterImport.dialogOpen} deckShown=${afterImport.deckHidden === false} title=${JSON.stringify(afterImport.title)}`);
      console.log(`  toast=${JSON.stringify(toast)}`);
      console.log(`  notice=${JSON.stringify(afterImport.notice)} storage=${JSON.stringify(afterImport.storage)}`);
      if (!afterImport.dialogOpen) console.log(`  editor starts with=${JSON.stringify(editorText)}`);
      if (afterStart) console.log(`  START -> status=${JSON.stringify(afterStart.status)} notice=${JSON.stringify(afterStart.notice)} frames=${afterStart.frames} (${startMs} ms)`);
      if (consoleErrors.length) console.log(`  console errors: ${JSON.stringify(consoleErrors.slice(0, 4))}`);
      await context.close();
    }
  } finally {
    await browser.close();
    await site.close();
    fs.writeFileSync(path.join(here, 'logs', 'exp1-capability.json'), JSON.stringify(results, null, 2));
  }
})().catch((error) => { console.error(error); process.exit(1); });
