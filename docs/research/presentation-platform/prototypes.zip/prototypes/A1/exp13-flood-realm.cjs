// EXP13: (a) can a package obtain a fresh JavaScript realm (which would defeat any bootstrap-level
// removal of APIs such as RTCPeerConnection)? (b) can it degrade the host by flooding postMessage?
const fs = require('node:fs'); const path = require('node:path');
const { chromium } = require('playwright'); const L = require('./lib.cjs');
const page1 = (script) => `<!doctype html><html lang="en"><head></head><body><h1>probe</h1><script>${script}</script></body></html>`;
const realm = page1(`
  window.addEventListener('securitypolicyviolation',e=>{(window.__v=window.__v||[]).push(e.effectiveDirective);e.stopImmediatePropagation()},true);
  window.__r = {};
  // Pretend the host bootstrap had removed the API from this realm.
  const original = window.RTCPeerConnection; delete window.RTCPeerConnection; window.__r.removedHere = typeof window.RTCPeerConnection;
  const f = document.createElement('iframe'); document.body.append(f);   // initial about:blank, no navigation
  try { window.__r.blankFrameWindow = String(f.contentWindow); window.__r.freshRealmRTC = typeof f.contentWindow.RTCPeerConnection; window.__r.sameOriginAccess = !!f.contentDocument; window.__r.freshEval = (() => { try { return f.contentWindow.eval('1+1'); } catch (e) { return 'eval blocked: ' + e.name; } })(); }
  catch (e) { window.__r.freshRealm = 'THROW ' + e.name + ': ' + e.message.slice(0, 100); }
  window.__r.done = true;`);
const floodPage = (mode) => page1(`
  const MODE = ${JSON.stringify(mode)};
  const token = (document.scripts[0].textContent.match(/\\)\\("([a-f0-9]{36})"\\)/)||[])[1];
  window.addEventListener('load',()=>setTimeout(()=>{ window.__flooding = true; let sent = 0;
    setInterval(()=>{ const end = performance.now() + 8; while (performance.now() < end) { if (MODE !== 'relay') { top.postMessage({ junk: sent }, '*'); sent++; } if (MODE !== 'top') { parent.postMessage({ qftPresentation: 1, token, kind: 'escape' }, '*'); sent++; } } window.__sent = sent; }, 0);
  },1200));`);
const withTimeout = (promise, ms) => Promise.race([promise.then((value) => ({ ok: true, value }), (error) => ({ ok: false, value: `failed: ${String(error.message).split('\n')[0]}` })), new Promise((resolve) => setTimeout(() => resolve({ ok: false, value: `no answer within ${ms} ms` }), ms))]);
(async () => {
  const site = await L.startSite(4400); const browser = await chromium.launch({ channel: 'chromium' });
  const out = {};
  try {
    { const page = await (await browser.newContext()).newPage(); await L.openWorkspace(page, 'http://127.0.0.1:4400/');
      await L.openFile(page, L.makePackage(realm), 'realm.zip'); await page.locator('[data-pres-start-button]').click();
      const frame = await L.until(() => L.appFrame(page), 'frame', 15000); await L.until(() => frame.evaluate(() => window.__r && window.__r.done), 'done', 15000);
      out.freshRealm = await frame.evaluate(() => ({ ...window.__r, violations: window.__v || [] })); await page.close(); }
    for (const mode of ['top', 'relay']) { const page = await (await browser.newContext()).newPage(); await L.openWorkspace(page, 'http://127.0.0.1:4400/');
      await L.openFile(page, L.makePackage(floodPage(mode)), 'flood.zip'); await page.locator('[data-pres-start-button]').click();
      await L.until(async () => (await L.dialogState(page)).status === 'Playing locally', 'ready', 15000);
      const baseline = await page.evaluate(() => new Promise((resolve) => { const s = performance.now(); requestAnimationFrame(() => resolve(Math.round(performance.now() - s))); }));
      await L.sleep(4000);
      const frame = L.appFrame(page);
      const f = out['flood_' + mode] = { target: mode === 'top' ? 'top.postMessage(junk) straight to the editor window' : 'valid escape messages through the runner relay', baselineFrameMs: baseline };
      const sent = await withTimeout(frame.evaluate(() => window.__sent), 5000); f.messagesSentIn2_8s = sent.value;
      const raf = await withTimeout(page.evaluate(() => new Promise((resolve) => { const s = performance.now(); let n = 0; const tick = () => { if (++n === 30) resolve(Math.round((performance.now() - s) / 30)); else requestAnimationFrame(tick); }; requestAnimationFrame(tick); })), 15000);
      f.hostAverageFrameMsUnderFlood = raf.value;
      const heap = await withTimeout(page.evaluate(() => performance.memory ? Math.round(performance.memory.usedJSHeapSize / 1048576) : null), 5000); f.hostHeapMiB = heap.value;
      const s = Date.now(); const clicked = await withTimeout(page.locator('[data-pres-stop]').click({ timeout: 10000 }).then(() => 'clicked'), 11000);
      f.stop = clicked.ok ? `clicked after ${Date.now() - s} ms` : clicked.value;
      const state = await withTimeout(L.dialogState(page), 5000); f.after = state.ok ? { status: state.value.status, frames: state.value.frames } : state.value;
      await Promise.race([page.close(), L.sleep(3000)]); }
  } finally { await Promise.race([browser.close(), L.sleep(5000)]); await site.close(); fs.writeFileSync(path.join(__dirname, 'logs', 'exp13-flood-realm.json'), JSON.stringify(out, null, 2)); }
  console.log(JSON.stringify(out, null, 1));
})().catch((e) => { console.error(e); process.exit(1); });
