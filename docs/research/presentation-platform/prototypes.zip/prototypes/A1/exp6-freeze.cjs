// EXP6: can a package freeze the host? Runs an infinite loop inside the player and measures whether
// the editor stays responsive and whether Stop works, with Chromium's default process model and with
// sandboxed-iframe process isolation switched off (approximating engines/platforms without it).
const fs = require('node:fs'); const path = require('node:path');
const { chromium } = require('playwright'); const L = require('./lib.cjs');
const base = 'http://127.0.0.1:4400/';
const page1 = (script) => `<!doctype html><html lang="en"><head></head><body><h1>freeze probe</h1><script>${script}</script></body></html>`;
const loopAfterReady = page1(`window.addEventListener('load',()=>setTimeout(()=>{window.__looping=true;for(;;){}} ,1200));`);
const loopAtLoad = page1(`for(;;){}`);

const withTimeout = (promise, ms) => Promise.race([promise.then((value) => ({ ok: true, value })), new Promise((resolve) => setTimeout(() => resolve({ ok: false, value: `no answer within ${ms} ms` }), ms))]);

async function targets(browser) {
  const session = await browser.newBrowserCDPSession();
  const { targetInfos } = await session.send('Target.getTargets');
  let processes = null;
  try { processes = (await session.send('SystemInfo.getProcessInfo')).processInfo.map((p) => p.type); } catch { /* optional */ }
  await session.detach();
  return { targets: targetInfos.map((t) => `${t.type} ${t.url.slice(0, 60)}`), processes };
}

async function scenario(label, args, html, mode, channel) {
  const browser = await chromium.launch({ args, ...(channel ? { channel } : {}) });
  const out = { label, args, mode, channel: channel || 'default (chrome-headless-shell)', version: browser.version() };
  try {
    const context = await browser.newContext({ viewport: { width: 1300, height: 900 } });
    const page = await context.newPage();
    await L.openWorkspace(page, base);
    await L.openFile(page, L.makePackage(html), 'freeze.zip');
    await page.locator('[data-pres-start-button]').waitFor({ state: 'visible', timeout: 15000 });
    const t0 = Date.now();
    await page.locator('[data-pres-start-button]').click();
    if (mode === 'after-ready') {
      await L.until(async () => (await L.dialogState(page)).status === 'Playing locally', 'ready', 10000);
      out.processModelWhilePlaying = await targets(browser);
      await L.sleep(2000); // the loop starts 1.2 s after load
      const ping = await withTimeout(page.evaluate(() => 1 + 1), 4000);
      out.hostEvaluateDuringLoop = ping.ok ? `answered ${ping.value}` : ping.value;
      // Is the editor's own UI thread alive? Measure a requestAnimationFrame round trip.
      const raf = await withTimeout(page.evaluate(() => new Promise((resolve) => { const s = performance.now(); requestAnimationFrame(() => resolve(Math.round(performance.now() - s))); })), 4000);
      out.hostAnimationFrame = raf.ok ? `${raf.value} ms` : raf.value;
      const s = Date.now();
      const clicked = await withTimeout(page.locator('[data-pres-stop]').click({ timeout: 6000 }).then(() => 'clicked'), 7000);
      out.stopClick = clicked.ok ? `clicked after ${Date.now() - s} ms` : clicked.value;
      const state = await withTimeout(L.dialogState(page), 4000);
      out.afterStop = state.ok ? { status: state.value.status, frames: state.value.frames } : state.value;
      // Typing in the editor behind the dialog is not possible while the modal is open; close it and type.
      const closed = await withTimeout(page.locator('[data-pres-close]').click({ timeout: 4000 }).then(() => 'closed'), 5000);
      out.closeDialog = closed.ok ? closed.value : closed.value;
      out.processModelAfterStop = await targets(browser).catch((e) => String(e.message));
    } else {
      // Loop during parsing: the handshake can never happen. Wait for the host's own timeout.
      const ping = await withTimeout(page.evaluate(() => 1 + 1), 4000);
      out.hostEvaluateDuringLoop = ping.ok ? `answered ${ping.value}` : ping.value;
      const result = await withTimeout(L.until(async () => (await L.dialogState(page)).status === 'Playback needs attention', 'timeout state', 30000, 250), 31000);
      out.msUntilError = result.ok ? Date.now() - t0 : result.value;
      const state = await withTimeout(L.dialogState(page), 4000);
      out.afterTimeout = state.ok ? { status: state.value.status, notice: state.value.notice, frames: state.value.frames } : state.value;
    }
    await context.close().catch(() => {});
  } catch (error) { out.error = String(error.message).split('\n')[0]; }
  finally { await Promise.race([browser.close(), L.sleep(5000)]); }
  console.log(JSON.stringify(out, null, 1));
  return out;
}

(async () => {
  const site = await L.startSite(4400);
  const results = [];
  try {
    const which = process.argv[2] || 'all';
    if (which === 'all' || which === 'shell') {
      results.push(await scenario('headless shell, default flags', [], loopAfterReady, 'after-ready'));
      results.push(await scenario('headless shell, --site-per-process', ['--site-per-process'], loopAfterReady, 'after-ready'));
    }
    if (which === 'all' || which === 'chrome') {
      results.push(await scenario('full Chromium (new headless), default flags', [], loopAfterReady, 'after-ready', 'chromium'));
      results.push(await scenario('full Chromium (new headless), IsolateSandboxedIframes disabled', ['--disable-features=IsolateSandboxedIframes'], loopAfterReady, 'after-ready', 'chromium'));
      results.push(await scenario('full Chromium (new headless), default flags', [], loopAtLoad, 'at-load', 'chromium'));
    }
  } finally {
    await site.close();
    fs.writeFileSync(path.join(__dirname, 'logs', `exp6-freeze-${process.argv[2] || 'all'}.json`), JSON.stringify(results, null, 2));
  }
})().catch((e) => { console.error(e); process.exit(1); });
