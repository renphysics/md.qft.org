const fs = require('node:fs'); const path = require('node:path');
const { chromium } = require('playwright'); const L = require('./lib.cjs');
(async () => {
  const site = await L.startSite(4400); const browser = await chromium.launch({ channel: 'chromium' });
  try {
    const src = fs.readFileSync(path.join(__dirname, 'exp7-reveal.cjs'), 'utf8');
    // reuse the deck builder
    const mod = { exports: {} };
    const body = src.slice(0, src.indexOf('async function open(')) + '\nmodule.exports = { deck };';
    new Function('require', 'module', '__dirname', body)(require, mod, __dirname);
    const html = mod.exports.deck();
    const page = await (await browser.newContext({ viewport: { width: 1300, height: 900 } })).newPage();
    page.on('console', (m) => { if (m.type() === 'error') console.log('console:', m.text().slice(0, 200)); });
    await L.openWorkspace(page, 'http://127.0.0.1:4400/');
    await L.openFile(page, L.makePackage(html), 'r.zip');
    await page.locator('[data-pres-start-button]').click();
    await L.until(async () => (await L.dialogState(page)).status === 'Playing locally', 'ready', 20000);
    const frame = L.appFrame(page);
    await frame.locator('body').press('ArrowRight'); await frame.locator('body').press('ArrowRight'); await L.sleep(1200);
    console.log(await frame.evaluate(() => { const b = document.getElementById('plus').getBoundingClientRect(); const top = document.elementFromPoint(b.x + b.width / 2, b.y + b.height / 2); const i = Reveal.getIndices(); return { indices: i, rect: [b.x, b.y, b.width, b.height].map(Math.round), viewport: [innerWidth, innerHeight], hit: top && (top.id || top.className || top.tagName), slidesStyle: document.querySelector('.slides').getAttribute('style'), revealRect: JSON.stringify(document.querySelector('.reveal').getBoundingClientRect()), bodyClass: document.body.className, htmlClass: document.documentElement.className, pe: getComputedStyle(document.getElementById('plus')).pointerEvents, secPe: getComputedStyle(document.getElementById('two')).pointerEvents, slidesPe: getComputedStyle(document.querySelector('.slides')).pointerEvents, present: document.getElementById('two').className }; }));
    await page.screenshot({ path: path.join(__dirname, 'shots', 'dbg3-reveal.png') });
  } finally { await browser.close(); await site.close(); }
})().catch((e) => { console.error(e); process.exit(1); });
