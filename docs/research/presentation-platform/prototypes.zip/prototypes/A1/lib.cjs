// Shared helpers for the A1 audit experiments. Nothing here writes into the repo.
const http = require('node:http');
const net = require('node:net');
const dgram = require('node:dgram');
const fs = require('node:fs');
const path = require('node:path');
const { zipSync, strToU8 } = require('/home/user/md.qft.org/node_modules/fflate');

const DIST = '/home/user/md.qft.org/dist';
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png',
  '.woff2': 'font/woff2', '.woff': 'font/woff', '.ttf': 'font/ttf', '.zip': 'application/zip', '.md': 'text/markdown; charset=utf-8',
  '.txt': 'text/plain; charset=utf-8', '.xml': 'application/xml', '.wasm': 'application/wasm',
};

/** Static server for the production build. Logs every request. `extra` maps a path to {type, body}. */
function startSite(port, extra = {}) {
  const log = [];
  const server = http.createServer((req, res) => {
    const url = new URL(req.url, 'http://x');
    log.push({ t: Date.now(), method: req.method, url: req.url, dest: req.headers['sec-fetch-dest'], site: req.headers['sec-fetch-site'], referer: req.headers.referer });
    if (extra[url.pathname]) {
      const item = extra[url.pathname];
      res.writeHead(200, { 'content-type': item.type, ...(item.headers || {}) });
      res.end(item.body);
      return;
    }
    let file = path.join(DIST, decodeURIComponent(url.pathname));
    if (!file.startsWith(DIST)) { res.writeHead(403); res.end(); return; }
    if (fs.existsSync(file) && fs.statSync(file).isDirectory()) file = path.join(file, 'index.html');
    if (!fs.existsSync(file)) { res.writeHead(404, { 'content-type': 'text/html' }); res.end(fs.readFileSync(path.join(DIST, '404.html'))); return; }
    res.writeHead(200, { 'content-type': MIME[path.extname(file)] || 'application/octet-stream', 'cache-control': 'no-store' });
    fs.createReadStream(file).pipe(res);
  });
  return new Promise((resolve) => server.listen(port, '0.0.0.0', () => resolve({ server, log, close: () => new Promise((r) => { server.closeAllConnections?.(); server.close(() => r()); }) })));
}

/** "Attacker" HTTP origin: logs anything that reaches it. */
function startEvil(port) {
  const log = [];
  const server = http.createServer((req, res) => {
    log.push({ t: Date.now(), method: req.method, url: req.url, origin: req.headers.origin, dest: req.headers['sec-fetch-dest'] });
    res.writeHead(200, { 'content-type': req.url.includes('.css') ? 'text/css' : req.url.includes('.js') ? 'text/javascript' : 'text/plain', 'access-control-allow-origin': '*', 'cache-control': 'no-store' });
    res.end(req.url.includes('.js') ? 'window.__externalScriptRan=true;' : req.url.includes('.css') ? 'body{outline:3px solid red}' : 'ok');
  });
  server.on('upgrade', (req, socket) => { log.push({ t: Date.now(), method: 'UPGRADE', url: req.url }); socket.destroy(); });
  return new Promise((resolve) => server.listen(port, '0.0.0.0', () => resolve({ server, log, close: () => new Promise((r) => { server.closeAllConnections?.(); server.close(() => r()); }) })));
}

/** Raw TCP listener: records connections (e.g. link rel=preconnect) and the first bytes. */
function startTcp(port) {
  const log = [];
  const server = net.createServer((socket) => {
    const entry = { t: Date.now(), remote: socket.remoteAddress, first: '' };
    log.push(entry);
    socket.on('data', (chunk) => { if (entry.first.length < 200) entry.first += chunk.toString('latin1').slice(0, 200); });
    socket.on('error', () => {});
    setTimeout(() => socket.destroy(), 1500);
  });
  return new Promise((resolve) => server.listen(port, '0.0.0.0', () => resolve({ server, log, close: () => new Promise((r) => server.close(() => r())) })));
}

/** UDP listener: records datagrams (e.g. STUN binding requests from WebRTC). */
function startUdp(port) {
  const log = [];
  const socket = dgram.createSocket('udp4');
  socket.on('message', (message, remote) => { log.push({ t: Date.now(), from: `${remote.address}:${remote.port}`, bytes: message.length, hex: message.subarray(0, 24).toString('hex') }); });
  return new Promise((resolve) => socket.bind(port, '0.0.0.0', () => resolve({ socket, log, close: () => new Promise((r) => socket.close(() => r())) })));
}

const baseManifest = { format: 'qft-presentation', version: 1, engine: 'slidev', title: 'A1 probe', entry: 'presentation.html' };

/** Build a qft-presentation ZIP around caller-supplied HTML. */
function makePackage(html, { manifest = {}, files = {}, level = 6 } = {}) {
  const entries = {
    'qft-presentation.json': strToU8(JSON.stringify({ ...baseManifest, ...manifest })),
    'presentation.html': typeof html === 'string' ? strToU8(html) : html,
  };
  for (const [name, value] of Object.entries(files)) entries[name] = typeof value === 'string' ? strToU8(value) : value;
  return Buffer.from(zipSync(entries, { level }));
}

/** Arbitrary ZIP from a {path: string|Uint8Array} map. */
function makeZip(files, level = 6) {
  return Buffer.from(zipSync(Object.fromEntries(Object.entries(files).map(([name, value]) => [name, typeof value === 'string' ? strToU8(value) : value])), { level }));
}

/** ZIP an on-disk directory (optionally under a prefix inside the archive). */
function zipDirectory(root, prefix = '', filter = () => true) {
  const files = {};
  const walk = (dir, rel) => {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const abs = path.join(dir, entry.name);
      const name = rel ? `${rel}/${entry.name}` : entry.name;
      if (!filter(name, entry)) continue;
      if (entry.isDirectory()) walk(abs, name);
      else if (entry.isFile()) files[prefix + name] = new Uint8Array(fs.readFileSync(abs));
    }
  };
  walk(root, '');
  return files;
}

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function until(check, label, timeout = 15000, step = 100) {
  const deadline = Date.now() + timeout;
  let last;
  while (Date.now() < deadline) {
    try { const value = await check(); if (value) return value; } catch (error) { last = error; }
    await sleep(step);
  }
  throw new Error(`Timed out: ${label}${last ? ` (${last.message})` : ''}`);
}

/** Open the workspace and wait for the editor. */
async function openWorkspace(page, base) {
  await page.goto(base, { waitUntil: 'load' });
  await page.locator('.cm-editor').waitFor({ timeout: 30000 });
}

/** Hand a file to the workspace's Open file input (same path as the user's Open file button). */
async function openFile(page, buffer, name = 'probe.zip', mimeType = 'application/zip') {
  await page.locator('[data-file-input]').setInputFiles({ name, mimeType, buffer });
}

/** Read the visible state of the presentation dialog. */
async function dialogState(page) {
  return page.evaluate(() => {
    const q = (selector) => document.querySelector(selector);
    const text = (selector) => q(selector)?.textContent?.trim() ?? null;
    const hidden = (selector) => { const el = q(selector); return el ? el.hidden : null; };
    return {
      dialogOpen: q('[data-pres-dialog]')?.open ?? null,
      title: text('[data-pres-title]'), subtitle: text('[data-pres-subtitle]'),
      notice: hidden('[data-pres-notice]') ? null : text('[data-pres-notice]'),
      status: text('[data-pres-player-status]'), storage: text('[data-pres-storage]'),
      deckHidden: hidden('[data-pres-deck]'), libraryHidden: hidden('[data-pres-library]'),
      startOverlayHidden: hidden('[data-pres-start]'), stopHidden: hidden('[data-pres-stop]'), restartHidden: hidden('[data-pres-restart]'),
      frames: document.querySelectorAll('[data-pres-host] iframe').length,
      count: text('[data-pres-count]'),
      toast: [...document.querySelectorAll('[data-toast],[role="status"],[role="alert"],.toast,.notice')].map((el) => el.textContent.trim()).filter(Boolean).slice(0, 8),
    };
  });
}

/** The innermost (blob:) application frame, if it exists. */
function appFrame(page) {
  return page.frames().find((frame) => frame.url().startsWith('blob:')) ?? null;
}
function runnerFrame(page) {
  return page.frames().find((frame) => /presentation-sandbox\.html/.test(frame.url())) ?? null;
}

module.exports = { startSite, startEvil, startTcp, startUdp, makePackage, makeZip, zipDirectory, sleep, until, openWorkspace, openFile, dialogState, appFrame, runnerFrame, DIST, baseManifest };
