// EXP7c: locate the cause of the lost keyboard focus in full Chromium and try the smallest repair
// from the outside (what a patched player would do after the ready handshake).
const fs = require('node:fs'); const path = require('node:path');
const { chromium } = require('playwright'); const L = require('./lib.cjs');
const zip = fs.readFileSync(path.join(__dirname, 'pkgs', 'reveal-inlined.zip'));
const focusInfo = () => ({ hasFocus: document.hasFocus(), active: document.activeElement ? document.activeElement.tagName.toLowerCase() : null });
(async () => {
  const site = await L.startSite(4400); const browser = await chromium.launch({ channel: 'chromium' });
  const out = {};
  try {
    const page = await (await browser.newContext({ viewport: { width: 1300, height: 900 } })).newPage();
    const consoleMessages = []; page.on('console', (m) => consoleMessages.push(`${m.type()}: ${m.text().slice(0, 140)} @ ${m.location().url.slice(0, 60)}`));
    await L.openWorkspace(page, 'http://127.0.0.1:4400/');
    await L.openFile(page, zip, 'deck.zip');
    await page.locator('[data-pres-start-button]').click();
    await L.until(async () => (await L.dialogState(page)).status === 'Playing locally', 'ready', 25000);
    await L.sleep(800);
    const frame = L.appFrame(page); const runner = L.runnerFrame(page);
    const state = async () => ({ top: await page.evaluate(focusInfo), runner: await runner.evaluate(focusInfo), deck: await frame.evaluate(focusInfo), slide: await frame.evaluate(() => { const i = Reveal.getIndices(); return `${i.h}/${i.v} f=${i.f}`; }) });
    out.afterStart = await state();
    out.violationSource = consoleMessages.filter((m) => /focus-without/.test(m));
    // Step 1: the top document re-focuses the outer iframe without blur (what player.focus() does today).
    await page.evaluate(() => document.querySelector('[data-pres-host] iframe').focus({ preventScroll: true }));
    await L.sleep(200); out.afterRefocusOnly = await state();
    // Step 2: blur first so the focus call is a real focus change.
    await page.evaluate(() => { const f = document.querySelector('[data-pres-host] iframe'); f.blur(); f.focus({ preventScroll: true }); });
    await L.sleep(200); out.afterBlurThenFocus = await state();
    // Step 3: ask the runner (existing protocol message) to focus its child now that it owns focus.
    const token = await frame.evaluate(() => (document.scripts[0].textContent.match(/\)\("([a-f0-9]{36})"\)/) || [])[1]);
    await page.evaluate((token) => document.querySelector('[data-pres-host] iframe').contentWindow.postMessage({ type: 'qft-presentation-focus', token }, '*'), token);
    await L.sleep(300); out.afterRunnerFocusMessage = await state();
    await page.keyboard.press('ArrowRight'); await L.sleep(500);
    out.afterArrowRight = await state();
    out.console = consoleMessages.filter((m) => /focus/.test(m));
  } finally { await browser.close(); await site.close(); fs.writeFileSync(path.join(__dirname, 'logs', 'exp7c-focusfix.json'), JSON.stringify(out, null, 2)); }
  console.log(JSON.stringify(out, null, 1));
})().catch((e) => { console.error(e); process.exit(1); });
