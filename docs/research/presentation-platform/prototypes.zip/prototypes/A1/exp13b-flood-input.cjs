// EXP13b: under a postMessage flood, does a real pointer click on Stop still work?
const fs = require('node:fs'); const path = require('node:path');
const { chromium } = require('playwright'); const L = require('./lib.cjs');
const page1 = (script) => `<!doctype html><html lang="en"><head></head><body><h1>flood</h1><script>${script}</script></body></html>`;
const flood = page1(`window.addEventListener('load',()=>setTimeout(()=>{ setInterval(()=>{ const end = performance.now() + 8; while (performance.now() < end) top.postMessage({ junk: 1 }, '*'); }, 0); },2500));`);
const withTimeout = (promise, ms) => Promise.race([promise.then((value) => ({ ok: true, value }), (error) => ({ ok: false, value: `failed: ${String(error.message).split('\n')[0]}` })), new Promise((resolve) => setTimeout(() => resolve({ ok: false, value: `no answer within ${ms} ms` }), ms))]);
(async () => {
  const site = await L.startSite(4400); const browser = await chromium.launch({ channel: 'chromium' });
  const out = {};
  try {
    const page = await (await browser.newContext({ viewport: { width: 1300, height: 900 } })).newPage(); await L.openWorkspace(page, 'http://127.0.0.1:4400/');
    await L.openFile(page, L.makePackage(flood), 'flood.zip'); await page.locator('[data-pres-start-button]').click();
    await L.until(async () => (await L.dialogState(page)).status === 'Playing locally', 'ready', 15000);
    const box = await page.locator('[data-pres-stop]').boundingBox();           // measured before the flood begins
    // A host-side heartbeat that records how late each 100 ms timer fires.
    await page.evaluate(() => { window.__beat = []; let last = performance.now(); setInterval(() => { const now = performance.now(); window.__beat.push(Math.round(now - last - 100)); last = now; }, 100); });
    await L.sleep(6000);                                                       // flood has been running ~3.5 s
    const t0 = Date.now();
    await withTimeout(page.mouse.click(box.x + box.width / 2, box.y + box.height / 2), 15000).then((r) => { out.rawClickDispatch = r.ok ? `dispatched in ${Date.now() - t0} ms` : r.value; });
    const state = await withTimeout(L.until(async () => (await L.dialogState(page)).frames === 0, 'frame removed', 40000, 500), 45000);
    out.frameRemovedAfterClick = state.ok ? `${Date.now() - t0} ms after the click` : state.value;
    const beat = await withTimeout(page.evaluate(() => window.__beat), 20000);
    if (beat.ok) { const during = beat.value.slice(25); out.timerLatenessMs = { samples: beat.value.length, maxLate: Math.max(...beat.value), medianLateDuringFlood: during.sort((a, b) => a - b)[Math.floor(during.length / 2)] }; } else out.timerLatenessMs = beat.value;
    const final = await withTimeout(L.dialogState(page), 10000); out.final = final.ok ? { status: final.value.status, frames: final.value.frames } : final.value;
  } finally { await Promise.race([browser.close(), L.sleep(5000)]); await site.close(); fs.writeFileSync(path.join(__dirname, 'logs', 'exp13b-flood-input.json'), JSON.stringify(out, null, 2)); }
  console.log(JSON.stringify(out, null, 1));
})().catch((e) => { console.error(e); process.exit(1); });
