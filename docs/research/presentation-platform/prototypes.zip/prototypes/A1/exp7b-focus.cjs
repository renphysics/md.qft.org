// EXP7b: after pressing Start, does the keyboard reach the deck without an extra click?
const fs = require('node:fs'); const path = require('node:path');
const { chromium } = require('playwright'); const L = require('./lib.cjs');
const revealZip = fs.readFileSync(path.join(__dirname, 'pkgs', 'reveal-inlined.zip'));
const slidevZip = fs.readFileSync('/home/user/md.qft.org/dist/slidev/interactive-physics.zip');
const focusInfo = () => ({ hasFocus: document.hasFocus(), active: document.activeElement ? `${document.activeElement.tagName.toLowerCase()}${document.activeElement.id ? '#' + document.activeElement.id : ''}` : null });

async function run(browser, label, zip, position, viaPresent) {
  const context = await browser.newContext({ viewport: { width: 1300, height: 900 } });
  const page = await context.newPage();
  const consoleMessages = []; page.on('console', (m) => { if (m.type() === 'error' || m.type() === 'warning') consoleMessages.push(m.text().slice(0, 160)); });
  await L.openWorkspace(page, 'http://127.0.0.1:4400/');
  await L.openFile(page, zip, 'deck.zip');
  await page.locator('[data-pres-start-button]').waitFor({ state: 'visible', timeout: 15000 });
  await page.locator(viaPresent ? '[data-pres-present]' : '[data-pres-start-button]').click();   // a real, trusted click
  await L.until(async () => (await L.dialogState(page)).status === 'Playing locally', 'ready', 25000);
  await L.sleep(1200);
  const frame = L.appFrame(page); const runner = L.runnerFrame(page);
  const out = { label, viaPresent };
  out.focusAfterStart = { top: await page.evaluate(focusInfo), runner: await runner.evaluate(focusInfo), deck: await frame.evaluate(focusInfo) };
  out.before = await frame.evaluate(position);
  await page.keyboard.press('ArrowRight'); await L.sleep(700);
  out.afterArrowRightWithoutClicking = await frame.evaluate(position);
  // Now click in the middle of the deck like a user would, then press the key again.
  const box = await page.locator('[data-pres-host] iframe').boundingBox();
  await page.mouse.click(box.x + box.width / 2, box.y + box.height * 0.8); await L.sleep(300);
  out.focusAfterClick = { top: await page.evaluate(focusInfo), runner: await runner.evaluate(focusInfo), deck: await frame.evaluate(focusInfo) };
  await page.keyboard.press('ArrowRight'); await L.sleep(700);
  out.afterArrowRightAfterClick = await frame.evaluate(position);
  out.console = consoleMessages;
  console.log(JSON.stringify(out, null, 1));
  await context.close();
  return out;
}

(async () => {
  const site = await L.startSite(4400);
  const results = [];
  try {
    for (const channel of ['chromium', undefined]) {
      const browser = await chromium.launch(channel ? { channel } : {});
      const tag = channel ? 'full Chromium' : 'headless shell';
      results.push(await run(browser, `${tag} / Reveal`, revealZip, () => { const i = Reveal.getIndices(); return `${i.h}/${i.v} f=${i.f}`; }, false));
      results.push(await run(browser, `${tag} / Slidev example`, slidevZip, () => document.querySelector('.slidev-page:not([style*="display: none"]) h1')?.textContent.trim().slice(0, 30) ?? document.title, false));
      results.push(await run(browser, `${tag} / Reveal via Present`, revealZip, () => { const i = Reveal.getIndices(); return `${i.h}/${i.v} f=${i.f}`; }, true));
      await browser.close();
    }
  } finally { await site.close(); fs.writeFileSync(path.join(__dirname, 'logs', 'exp7b-focus.json'), JSON.stringify(results, null, 2)); }
})().catch((e) => { console.error(e); process.exit(1); });
