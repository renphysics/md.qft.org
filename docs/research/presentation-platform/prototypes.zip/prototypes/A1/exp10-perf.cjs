// EXP10: size limits and timing. Self-contained decks padded with an inert JS string.
const fs = require('node:fs'); const path = require('node:path'); const crypto = require('node:crypto');
const { chromium } = require('playwright'); const L = require('./lib.cjs');
const MiB = 1024 * 1024;
function deck(bytes) {
  const head = '<!doctype html><html lang="en"><head><style>body{font:20px system-ui;padding:40px}</style></head><body><h1 id="h">Padded deck</h1><script>window.__pad="';
  const tail = '";document.getElementById("h").textContent="Padded deck "+window.__pad.length;</script></body></html>';
  // base64 of random bytes: incompressible, like embedded fonts/images.
  const need = bytes - head.length - tail.length;
  const pad = crypto.randomBytes(Math.ceil(need * 3 / 4)).toString('base64').replace(/[+/=]/g, 'A').slice(0, need);
  return head + pad + tail;
}
(async () => {
  const site = await L.startSite(4400); const browser = await chromium.launch({ channel: 'chromium' });
  const results = [];
  try {
    for (const size of [1 * MiB, 8 * MiB, 20 * MiB, 24 * MiB, 24 * MiB + 1]) {
      const html = deck(size);
      const zipPath = path.join(__dirname, 'out', `padded-${size}.zip`);
      const t = Date.now(); fs.writeFileSync(zipPath, L.makePackage(html, { level: 1 }));
      const context = await browser.newContext({ viewport: { width: 1300, height: 900 }, acceptDownloads: true });
      const page = await context.newPage();
      await L.openWorkspace(page, 'http://127.0.0.1:4400/');
      const r = { htmlBytes: Buffer.byteLength(html), zipBytes: fs.statSync(zipPath).size };
      const t0 = Date.now();
      await page.locator('[data-file-input]').setInputFiles(zipPath);
      const shown = await L.until(async () => { const s = await L.dialogState(page); const toast = await page.locator('[data-toast]').evaluate((el) => (el.hidden ? '' : el.textContent.trim())); return (s.dialogOpen && s.deckHidden === false) ? 'deck' : toast; }, 'import', 60000, 50);
      r.importMs = Date.now() - t0; r.importResult = shown;
      if (shown === 'deck') {
        await L.until(async () => /Saved in this browser|Not saved/.test((await L.dialogState(page)).storage), 'saved', 60000, 50);
        r.savedMs = Date.now() - t0; r.storage = (await L.dialogState(page)).storage;
        const t1 = Date.now();
        await page.locator('[data-pres-start-button]').click();
        await L.until(async () => { const s = await L.dialogState(page); return s.status === 'Playing locally' || s.status === 'Playback needs attention'; }, 'start', 40000, 50);
        r.startMs = Date.now() - t1; const s = await L.dialogState(page); r.status = s.status; r.notice = s.notice;
        const t2 = Date.now();
        const [download] = await Promise.all([page.waitForEvent('download', { timeout: 60000 }), page.locator('[data-pres-html]').click()]);
        const exported = path.join(__dirname, 'out', `export-${size}.html`); await download.saveAs(exported);
        r.exportMs = Date.now() - t2; r.exportBytes = fs.statSync(exported).size; fs.rmSync(exported);
        // Reopen from the library (re-validates the whole archive).
        await page.locator('[data-pres-back]').click(); await page.locator('.presentation-saved-open').first().waitFor({ timeout: 10000 });
        const t3 = Date.now(); await page.locator('.presentation-saved-open').first().click();
        await L.until(async () => (await L.dialogState(page)).deckHidden === false, 'reopen', 60000, 50); r.reopenMs = Date.now() - t3;
        r.estimate = await page.evaluate(async () => { const e = await navigator.storage.estimate(); return { usageMiB: +(e.usage / 1048576).toFixed(1), quotaMiB: Math.round(e.quota / 1048576) }; });
      }
      results.push(r); console.log(JSON.stringify(r));
      await context.close(); fs.rmSync(zipPath);
    }
  } finally { await browser.close(); await site.close(); fs.writeFileSync(path.join(__dirname, 'logs', 'exp10-perf.json'), JSON.stringify(results, null, 2)); }
})().catch((e) => { console.error(e); process.exit(1); });
