// EXP15b: is there any declarative switch that stops <link rel=prerender> from fetching?
// Top-level test pages on the local server (no sandbox), full Chromium, one CSP variant each.
const fs = require('node:fs'); const path = require('node:path'); const http = require('node:http');
const { chromium } = require('playwright'); const L = require('./lib.cjs');
const body = (name, meta) => `<!doctype html><html><head>${meta ? `<meta http-equiv="Content-Security-Policy" content="${meta}">` : ''}</head><body><script>
const l = document.createElement('link'); l.rel = 'prerender'; l.href = 'http://localhost:4401/${name}'; document.head.append(l);
document.addEventListener('securitypolicyviolation', (e) => { (window.__v = window.__v || []).push(e.effectiveDirective); });
</script></body></html>`;
const strict = "default-src 'none'; script-src 'unsafe-inline'; connect-src 'none'";
const variants = {
  'no-csp': { meta: '' },
  'meta-default-src-none': { meta: strict },
  'meta-plus-prefetch-src-none': { meta: `${strict}; prefetch-src 'none'` },
  'meta-plus-navigate-to-none': { meta: `${strict}; navigate-to 'none'` },
  'meta-plus-child-src-frame-src-none': { meta: `${strict}; child-src 'none'; frame-src 'none'` },
  'header-default-src-none': { header: { 'content-security-policy': strict } },
  'header-csp-sandbox-allow-scripts': { header: { 'content-security-policy': `${strict}; sandbox allow-scripts` } },
  'header-supports-loading-mode-absent+document-policy': { header: { 'content-security-policy': strict, 'permissions-policy': 'speculation-rules=()' } },
};
(async () => {
  const routes = {}; for (const [name, v] of Object.entries(variants)) routes[`/__a1/pr-${name}.html`] = { type: 'text/html', body: body(name, v.meta), headers: v.header || {} };
  const site = await L.startSite(4400, routes);
  const log = []; const evil = http.createServer((req, res) => { log.push(req.url); res.writeHead(200, { 'content-type': 'text/html' }); res.end('x'); });
  await new Promise((r) => evil.listen(4401, '0.0.0.0', r));
  const out = {};
  try {
    const browser = await chromium.launch({ channel: 'chromium' });
    for (const name of Object.keys(variants)) {
      const page = await (await browser.newContext()).newPage(); const errors = []; page.on('console', (m) => { if (m.type() === 'error' || m.type() === 'warning') errors.push(m.text().slice(0, 120)); });
      const before = log.length; await page.goto(`http://127.0.0.1:4400/__a1/pr-${name}.html`); await L.sleep(2500);
      out[name] = { attackerReceived: log.slice(before), violations: await page.evaluate(() => window.__v || []), console: errors.slice(0, 3) };
      console.log(name.padEnd(52), JSON.stringify(out[name])); await page.close();
    }
    await browser.close();
  } finally { await site.close(); evil.closeAllConnections?.(); await new Promise((r) => evil.close(r)); fs.writeFileSync(path.join(__dirname, 'logs', 'exp15b-prerender-mitigation.json'), JSON.stringify(out, null, 2)); }
})().catch((e) => { console.error(e); process.exit(1); });
