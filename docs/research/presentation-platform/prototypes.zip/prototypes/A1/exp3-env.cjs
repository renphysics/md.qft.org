// EXP3: environment facts inside the player: secure-context status per frame level (http and https),
// fragment navigation inside a blob:null document, preconnect control, and the CSP `webrtc` directive.
const fs = require('node:fs'); const path = require('node:path'); const https = require('node:https');
const { chromium } = require('playwright'); const L = require('./lib.cjs');

const probe = `<!doctype html><html lang="en"><head><style>body{font:16px system-ui;padding:24px} #far{margin-top:3000px}</style></head><body>
<h1 id="top">env probe</h1><a id="link" href="#far">jump to #far</a><p id="far">far target</p>
<script>
(async () => {
  const R = window.__r = {};
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const t = async (name, fn) => { try { R[name] = await fn(); } catch (e) { R[name] = 'THROW ' + e.name + ': ' + String(e.message).slice(0, 150); } };
  await t('isSecureContext', () => isSecureContext);
  await t('crypto.randomUUID', () => typeof crypto.randomUUID === 'function' ? 'function -> ' + crypto.randomUUID().length + ' chars' : typeof crypto.randomUUID);
  await t('crypto.subtle', () => typeof crypto.subtle);
  await t('crypto.getRandomValues', () => typeof crypto.getRandomValues);
  await t('navigator.clipboard', () => typeof navigator.clipboard);
  await t('navigator.mediaDevices', () => typeof navigator.mediaDevices);
  await t('navigator.storage', () => typeof navigator.storage);
  await t('navigator.locks', () => typeof navigator.locks);
  await t('navigator.serviceWorker', () => typeof navigator.serviceWorker);
  await t('caches', () => typeof caches);
  await t('SharedArrayBuffer', () => typeof SharedArrayBuffer);
  await t('WebGL', () => { const c = document.createElement('canvas'); return !!(c.getContext('webgl2') || c.getContext('webgl')); });
  await t('OffscreenCanvas', () => typeof OffscreenCanvas);
  await t('AudioContext', () => typeof AudioContext);
  await t('document.fullscreenEnabled', () => document.fullscreenEnabled);
  await t('WebGPU navigator.gpu', () => typeof navigator.gpu);
  // Fragment navigation, as used by in-deck links and hash routers.
  await t('anchor_click_#far', async () => { const before = scrollY; document.getElementById('link').click(); await sleep(250); return 'hash=' + JSON.stringify(location.hash) + ' scrollY ' + before + ' -> ' + scrollY; });
  await t('location.hash_set', async () => { location.hash = '#top'; await sleep(250); return 'hash=' + JSON.stringify(location.hash) + ' scrollY=' + scrollY; });
  await t('location.href_set_fragment', async () => { location.href = '#far'; await sleep(250); return 'hash=' + JSON.stringify(location.hash) + ' scrollY=' + scrollY; });
  await t('location.replace_fragment', async () => { location.replace('#top'); await sleep(250); return 'hash=' + JSON.stringify(location.hash) + ' scrollY=' + scrollY; });
  await t('history.replaceState_fragment', () => { history.replaceState(null, '', '#/3'); return 'hash=' + JSON.stringify(location.hash); });
  await t('history.pushState_fragment', () => { const b = history.length; history.pushState(null, '', '#/4'); return 'hash=' + JSON.stringify(location.hash) + ' length ' + b + ' -> ' + history.length; });
  await t('hashchange_event_on_back', async () => { let fired = 0; addEventListener('hashchange', () => fired++); addEventListener('popstate', () => fired += 10); history.back(); await sleep(400); return 'events=' + fired + ' hash=' + JSON.stringify(location.hash); });
  await t('scrollIntoView', async () => { document.getElementById('far').scrollIntoView(); await sleep(100); return 'scrollY=' + scrollY; });
  R.done = true;
})();
</script></body></html>`;

async function run(label, base, launchContext) {
  const { context } = launchContext;
  const page = await context.newPage();
  const consoleErrors = [];
  page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(m.text().slice(0, 200)); });
  await L.openWorkspace(page, base);
  const topInfo = await page.evaluate(() => ({ isSecureContext, historyLength: history.length }));
  await L.openFile(page, L.makePackage(probe), 'env.zip');
  await page.locator('[data-pres-start-button]').waitFor({ state: 'visible', timeout: 15000 });
  await page.locator('[data-pres-start-button]').click();
  const frame = await L.until(() => L.appFrame(page), 'app frame', 15000);
  await L.until(() => frame.evaluate(() => window.__r && window.__r.done), 'probe done', 30000, 300);
  const runner = L.runnerFrame(page);
  const result = { label, top: topInfo, runner: await runner.evaluate(() => ({ isSecureContext, origin: self.origin, randomUUID: typeof crypto.randomUUID, subtle: typeof crypto.subtle })), app: await frame.evaluate(() => window.__r), hostHistoryAfter: await page.evaluate(() => history.length), hostState: await L.dialogState(page), consoleErrors };
  console.log(`\n=== ${label} ===`);
  console.log('top:', JSON.stringify(result.top), '| runner:', JSON.stringify(result.runner), '| host history.length after:', result.hostHistoryAfter, '| status:', result.hostState.status, '| notice:', result.hostState.notice);
  for (const [k, v] of Object.entries(result.app)) console.log('  ' + k.padEnd(34), v);
  if (consoleErrors.length) console.log('  console errors:', consoleErrors);
  await page.close();
  return result;
}

(async () => {
  const site = await L.startSite(4400);
  // A throwaway self-signed certificate (regenerated when missing).
  if (!fs.existsSync(path.join(__dirname, 'out/key.pem'))) require('node:child_process').execFileSync('openssl', ['req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-keyout', path.join(__dirname, 'out/key.pem'), '-out', path.join(__dirname, 'out/cert.pem'), '-days', '2', '-subj', '/CN=localhost', '-addext', 'subjectAltName=DNS:localhost,IP:127.0.0.1'], { stdio: 'ignore' });
  // HTTPS copy of the same build (self-signed) to check secure-context behavior as deployed.
  const tls = https.createServer({ key: fs.readFileSync(path.join(__dirname, 'out/key.pem')), cert: fs.readFileSync(path.join(__dirname, 'out/cert.pem')) }, (req, res) => {
    const url = new URL(req.url, 'https://x'); let file = path.join(L.DIST, decodeURIComponent(url.pathname));
    if (fs.existsSync(file) && fs.statSync(file).isDirectory()) file = path.join(file, 'index.html');
    if (!fs.existsSync(file)) { res.writeHead(404); res.end(); return; }
    const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.svg': 'image/svg+xml', '.woff2': 'font/woff2', '.zip': 'application/zip' };
    res.writeHead(200, { 'content-type': types[path.extname(file)] || 'application/octet-stream' }); fs.createReadStream(file).pipe(res);
  });
  await new Promise((r) => tls.listen(4404, '0.0.0.0', r));
  const browser = await chromium.launch();
  const out = [];
  try {
    const httpContext = await browser.newContext({ viewport: { width: 1300, height: 900 } });
    out.push(await run('http://127.0.0.1:4400 (potentially trustworthy http)', 'http://127.0.0.1:4400/', { context: httpContext }));
    const httpsContext = await browser.newContext({ viewport: { width: 1300, height: 900 }, ignoreHTTPSErrors: true });
    out.push(await run('https://localhost:4404 (self-signed TLS)', 'https://localhost:4404/', { context: httpsContext }));
  } finally {
    await browser.close(); await site.close(); tls.closeAllConnections?.(); await new Promise((r) => tls.close(r));
    fs.writeFileSync(path.join(__dirname, 'logs', 'exp3-env.json'), JSON.stringify(out, null, 2));
  }
})().catch((e) => { console.error(e); process.exit(1); });
