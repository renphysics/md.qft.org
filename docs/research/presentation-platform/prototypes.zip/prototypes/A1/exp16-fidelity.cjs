// EXP16: how faithfully does preparePresentationDocument reproduce a deck's document structure?
const fs = require('node:fs'); const path = require('node:path');
const { chromium } = require('playwright'); const L = require('./lib.cjs');
const cases = {
  'body-attributes': `<!doctype html><html lang="fr" class="theme-dark" id="root" data-mode="x"><head><title>My deck title</title><meta name="viewport" content="width=1024"><script>window.__headRan = { bodyAtHeadScript: !!document.body, readyState: document.readyState };</script></head><body id="app" class="deck [&>p]:mt-2 wide" data-k="1" style="background:#123" onload="window.__onload=1"><p>content</p><script>window.__r = { htmlLang: document.documentElement.lang, htmlClass: document.documentElement.className, htmlId: document.documentElement.id, htmlDataMode: document.documentElement.dataset.mode ?? null, bodyId: document.body.id, bodyClass: document.body.className, bodyDataK: document.body.dataset.k ?? null, bodyStyle: document.body.getAttribute('style'), title: document.title, viewportMeta: document.querySelector('meta[name=viewport]')?.content, compatMode: document.compatMode, head: window.__headRan, headChildren: [...document.head.children].map((e) => e.tagName.toLowerCase()).join(','), firstBodyChildren: [...document.body.children].slice(0, 4).map((e) => e.tagName.toLowerCase()).join(',') }; window.addEventListener('load', () => { window.__r.onloadAttrRan = !!window.__onload; });</script></body></html>`,
  'body-tag-string-inside-head-script': `<!doctype html><html lang="en"><head><script>var speakerViewTemplate = '<html><body class="from-a-js-string" data-injected="1">';</script></head><body class="real-body"><p>content</p><script>window.__r = { bodyClass: document.body.className, bodyDataInjected: document.body.dataset.injected ?? null };</script></body></html>`,
  'no-doctype-quirks-deck': `<html><head></head><body><table height="100%"><tr><td>quirks layout</td></tr></table><script>window.__r = { compatMode: document.compatMode };</script></body></html>`,
};
(async () => {
  const site = await L.startSite(4400); const browser = await chromium.launch({ channel: 'chromium' }); const out = {};
  try {
    for (const [name, html] of Object.entries(cases)) {
      const page = await (await browser.newContext()).newPage(); await L.openWorkspace(page, 'http://127.0.0.1:4400/');
      await L.openFile(page, L.makePackage(html), 'f.zip'); await page.locator('[data-pres-start-button]').click();
      await L.until(async () => { const s = await L.dialogState(page); return s.status === 'Playing locally' || s.status === 'Playback needs attention'; }, 'start', 15000);
      await L.sleep(400);
      const frame = L.appFrame(page); const s = await L.dialogState(page);
      out[name] = frame ? await frame.evaluate(() => window.__r) : { host: s.status, notice: s.notice };
      console.log(name, JSON.stringify(out[name], null, 1)); await page.close();
    }
  } finally { await browser.close(); await site.close(); fs.writeFileSync(path.join(__dirname, 'logs', 'exp16-fidelity.json'), JSON.stringify(out, null, 2)); }
})().catch((e) => { console.error(e); process.exit(1); });
