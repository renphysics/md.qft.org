const { chromium } = require('playwright');
const fs = require('node:fs');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage();
  await page.goto('about:blank');
  for (const pid of fs.readdirSync('/proc').filter((n) => /^\d+$/.test(n))) {
    try {
      const cmd = fs.readFileSync(`/proc/${pid}/cmdline`, 'utf8').split('\0');
      if (/chrome/.test(cmd[0]) && !cmd.some((a) => a.startsWith('--type='))) { console.log(pid, cmd.join('\n   ')); break; }
    } catch {}
  }
  await browser.close();
})();
