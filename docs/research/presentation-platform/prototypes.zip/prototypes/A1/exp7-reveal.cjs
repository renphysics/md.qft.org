// EXP7: is the player really Slidev-specific? Wrap a hand-inlined, single-file Reveal.js 6.0.2 deck
// in a qft-presentation manifest (which must claim engine "slidev") and exercise ordinary Reveal
// interactions inside the player.
const fs = require('node:fs'); const path = require('node:path');
const { chromium } = require('playwright'); const L = require('./lib.cjs');
const dist = '/home/user/md.qft.org/node_modules/reveal.js/dist';
const read = (file) => fs.readFileSync(path.join(dist, file), 'utf8');
const js = (code) => code.replace(/<\/script/gi, '<\\/script');
const pixel = 'data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==';

function deck({ lazyImage = false, config = '{ hash: true }' } = {}) {
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Inlined Reveal deck</title>
<style>${read('reset.css')}</style>
<style>${read('reveal.css')}</style>
<style>${read('theme/black.css')}</style>
</head>
<body>
<div class="reveal"><div class="slides">
<section id="one"><h2>Slide one</h2><p class="fragment" id="frag">A fragment</p><p><a id="jump" href="#/2">Jump to slide three</a></p><aside class="notes">Speaker notes here.</aside></section>
<section id="two"><h2>Slide two</h2><button id="plus">+1</button> <output id="count">0</output><canvas id="cv" width="200" height="60"></canvas></section>
<section id="three"><h2>Slide three</h2>${lazyImage ? '<img id="lazy" alt="chart" data-src="images/chart.png">' : `<img alt="dot" src="${pixel}">`}</section>
</div></div>
<script>${js(read('reveal.js'))}</script>
<script>${js(read('plugin/notes.js'))}</script>
<script>
  let n = 0;
  document.getElementById('plus').addEventListener('click', () => { document.getElementById('count').textContent = String(++n); });
  const ctx = document.getElementById('cv').getContext('2d'); let x = 0;
  (function draw() { ctx.clearRect(0, 0, 200, 60); ctx.fillStyle = '#4af'; ctx.fillRect(x = (x + 2) % 200, 20, 20, 20); window.__frames = (window.__frames || 0) + 1; requestAnimationFrame(draw); })();
  Reveal.initialize(Object.assign({ plugins: [RevealNotes] }, ${config})).then(() => { window.__revealReady = true; });
</script>
</body>
</html>`;
}

async function open(page, html, manifest) {
  await L.openWorkspace(page, 'http://127.0.0.1:4400/');
  await L.openFile(page, L.makePackage(html, { manifest }), 'reveal-inlined.zip');
  await page.locator('[data-pres-start-button]').waitFor({ state: 'visible', timeout: 15000 });
  const t0 = Date.now();
  await page.locator('[data-pres-start-button]').click();
  await L.until(async () => { const s = await L.dialogState(page); return s.status === 'Playing locally' || s.status === 'Playback needs attention'; }, 'start', 25000);
  const ms = Date.now() - t0;
  // Full Chromium does not hand keyboard focus to the deck after Start (see EXP7b). Click a neutral
  // corner of the slide first, as a user has to.
  const box = await page.locator('[data-pres-host] iframe').boundingBox().catch(() => null);
  if (box) { await page.mouse.click(box.x + 30, box.y + 30); await L.sleep(300); }
  return ms;
}
const indices = (frame) => frame.evaluate(() => { const i = Reveal.getIndices(); return `${i.h}/${i.v}${i.f !== undefined ? ` f=${i.f}` : ''}`; });
const snapshot = async (page) => { const s = await L.dialogState(page); return { status: s.status, notice: s.notice, frames: s.frames }; };

(async () => {
  const site = await L.startSite(4400);
  const browser = await chromium.launch({ channel: 'chromium' });
  const out = { chromium: browser.version(), htmlBytes: Buffer.byteLength(deck()) };
  try {
    // --- A: clean deck --------------------------------------------------------------------
    {
      const context = await browser.newContext({ viewport: { width: 1300, height: 900 } });
      const page = await context.newPage();
      const consoleErrors = []; page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(m.text().slice(0, 200)); });
      const a = out.clean = {};
      a.startMs = await open(page, deck(), { title: 'Inlined Reveal deck' });
      a.afterStart = await snapshot(page);
      const frame = L.appFrame(page);
      a.revealVersion = await frame.evaluate(() => Reveal.VERSION);
      a.initial = await indices(frame);
      await frame.locator('body').press('ArrowRight'); a.afterRight1 = await indices(frame);
      await frame.locator('body').press('ArrowRight'); a.afterRight2 = await indices(frame);
      await frame.locator('#plus').click(); await frame.locator('#plus').click(); a.counter = await frame.locator('#count').textContent();
      a.canvasFrames = await frame.evaluate(() => window.__frames);
      a.hashAfterNav = await frame.evaluate(() => location.hash);
      a.hostHistoryLength = await page.evaluate(() => history.length);
      await frame.locator('body').press('ArrowLeft');
      a.backTo = await indices(frame);
      await frame.locator('#jump').click({ timeout: 3000 }).catch((e) => { a.jumpClickError = e.message.split('\n')[0]; });
      await L.sleep(400);
      a.afterInternalLinkClick = await indices(frame);
      await frame.locator('body').press('o'); await L.sleep(300);
      a.overviewActive = await frame.evaluate(() => Reveal.isOverview());
      await frame.locator('body').press('Escape'); await L.sleep(300);
      a.afterEscape = { overview: await frame.evaluate(() => Reveal.isOverview()), host: await snapshot(page) };
      await frame.locator('body').press('s'); await L.sleep(500);
      a.afterSpeakerKey = await snapshot(page);
      a.consoleBeforeF = consoleErrors.slice();
      if (a.afterSpeakerKey.frames) { await frame.locator('body').press('f').catch(() => {}); await L.sleep(900); }
      a.afterFullscreenKey = await snapshot(page);
      a.console = consoleErrors.slice(-4);
      await page.screenshot({ path: path.join(__dirname, 'shots', 'exp7-reveal-after-f.png') });
      await context.close();
    }
    // --- B: host "Present" (outer fullscreen) with the same deck ---------------------------------
    {
      const context = await browser.newContext({ viewport: { width: 1300, height: 900 } });
      const page = await context.newPage();
      const b = out.present = {};
      await open(page, deck(), { title: 'Inlined Reveal deck' });
      const frame = L.appFrame(page);
      await frame.locator('body').press('ArrowRight'); await frame.locator('body').press('ArrowRight');
      b.before = await indices(frame);
      await page.locator('[data-pres-present]').click(); await L.sleep(800);
      b.fullscreenElement = await page.evaluate(() => document.fullscreenElement?.getAttribute('class') || (document.querySelector('[data-pres-stage]').classList.contains('presentation-fallback-fullscreen') ? 'fallback-fullscreen class' : null));
      b.sameFrameStillRunning = L.appFrame(page) === frame; b.after = await indices(frame);
      b.frameViewport = await frame.evaluate(() => `${innerWidth}x${innerHeight}`);
      await page.screenshot({ path: path.join(__dirname, 'shots', 'exp7-reveal-present.png') });
      await context.close();
    }
    // --- C: lazy-loaded relative image (data-src) -----------------------------------------------
    {
      const context = await browser.newContext({ viewport: { width: 1300, height: 900 } });
      const page = await context.newPage();
      const c = out.lazyImage = {};
      c.startMs = await open(page, deck({ lazyImage: true }), { title: 'Reveal deck with data-src' });
      await L.sleep(1200);
      c.afterStart = await snapshot(page);
      await context.close();
    }
    // --- D: history: true (Reveal writes location.hash) -----------------------------------------
    {
      const context = await browser.newContext({ viewport: { width: 1300, height: 900 } });
      const page = await context.newPage();
      const consoleErrors = []; page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(m.text().slice(0, 160)); });
      const d = out.historyTrue = {};
      await open(page, deck({ config: '{ history: true }' }), { title: 'Reveal deck history:true' });
      const frame = L.appFrame(page);
      await frame.locator('body').press('ArrowRight'); await frame.locator('body').press('ArrowRight'); await L.sleep(500);
      d.indices = await indices(frame).catch((e) => e.message.split('\n')[0]); d.hash = await frame.evaluate(() => location.hash).catch(() => null);
      d.host = await snapshot(page); d.hostHistoryLength = await page.evaluate(() => history.length); d.console = consoleErrors.slice(0, 3);
      await context.close();
    }
  } finally {
    await browser.close(); await site.close();
    fs.writeFileSync(path.join(__dirname, 'logs', 'exp7-reveal.json'), JSON.stringify(out, null, 2));
    fs.writeFileSync(path.join(__dirname, 'pkgs', 'reveal-inlined.zip'), L.makePackage(deck(), { manifest: { title: 'Inlined Reveal deck' } }));
  }
  console.log(JSON.stringify(out, null, 1));
})().catch((e) => { console.error(e); process.exit(1); });
