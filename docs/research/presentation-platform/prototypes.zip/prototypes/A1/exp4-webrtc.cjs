// EXP4: (a) is link rel=preconnect observable at all in this harness (control), (b) does Chromium
// honor the CSP `webrtc 'block'` directive when delivered through <meta> (possible mitigation)?
const fs = require('node:fs'); const path = require('node:path');
const { chromium } = require('playwright'); const L = require('./lib.cjs');
const body = (extraCsp) => `<!doctype html><html><head>${extraCsp ? `<meta http-equiv="Content-Security-Policy" content="${extraCsp}">` : ''}</head><body><script>
(async () => {
  const R = window.__r = {};
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const violations = []; document.addEventListener('securitypolicyviolation', (e) => violations.push(e.effectiveDirective + ' <- ' + e.blockedURI));
  try {
    const l = document.createElement('link'); l.rel = 'preconnect'; l.href = 'http://localhost:4402'; document.head.append(l);
    const d = document.createElement('link'); d.rel = 'dns-prefetch'; d.href = 'http://a1-probe-dns.invalid'; document.head.append(d);
    await sleep(800); R.preconnect = 'inserted';
  } catch (e) { R.preconnect = 'THROW ' + e.message; }
  try {
    const pc = new RTCPeerConnection({ iceServers: [{ urls: ['stun:127.0.0.1:4403', 'stun:192.0.2.2:4403'] }] });
    const candidates = []; const errors = [];
    pc.onicecandidate = (e) => { if (e.candidate) candidates.push(e.candidate.type || e.candidate.candidate.split(' ')[7]); };
    pc.onicecandidateerror = (e) => errors.push(e.errorCode + ' ' + e.errorText);
    pc.createDataChannel('x');
    await pc.setLocalDescription(await pc.createOffer());
    await sleep(2500);
    R.webrtc = 'state=' + pc.iceGatheringState + ' candidates=' + JSON.stringify(candidates) + ' errors=' + JSON.stringify(errors.slice(0, 3));
    pc.close();
  } catch (e) { R.webrtc = 'THROW ' + e.name + ': ' + e.message; }
  R.violations = violations; R.done = true;
})();
</script></body></html>`;
(async () => {
  const strict = "default-src 'none'; script-src 'unsafe-inline'; connect-src 'none'";
  const site = await L.startSite(4400, {
    '/__a1/control.html': { type: 'text/html', body: body('') },
    '/__a1/csp-connect-none.html': { type: 'text/html', body: body(strict) },
    '/__a1/csp-webrtc-block.html': { type: 'text/html', body: body(`${strict}; webrtc 'block'`) },
    '/__a1/csp-webrtc-block-header.html': { type: 'text/html', body: body(''), headers: { 'content-security-policy': `${strict}; webrtc 'block'` } },
  });
  const tcp = await L.startTcp(4402); const udp = await L.startUdp(4403);
  const browser = await chromium.launch();
  const out = {};
  try {
    for (const name of ['control', 'csp-connect-none', 'csp-webrtc-block', 'csp-webrtc-block-header']) {
      const page = await (await browser.newContext()).newPage();
      const consoleErrors = []; page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(m.text().slice(0, 220)); });
      const tcpBefore = tcp.log.length; const udpBefore = udp.log.length;
      await page.goto(`http://127.0.0.1:4400/__a1/${name}.html`);
      await L.until(() => page.evaluate(() => window.__r && window.__r.done), 'done', 20000);
      await L.sleep(500);
      out[name] = { ...(await page.evaluate(() => window.__r)), tcpConnections: tcp.log.length - tcpBefore, stunDatagrams: udp.log.length - udpBefore, consoleErrors };
      console.log(name, JSON.stringify(out[name], null, 1));
      await page.close();
    }
  } finally { await browser.close(); await Promise.all([site.close(), tcp.close(), udp.close()]); fs.writeFileSync(path.join(__dirname, 'logs', 'exp4-webrtc.json'), JSON.stringify(out, null, 2)); }
})().catch((e) => { console.error(e); process.exit(1); });
