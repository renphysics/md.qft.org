// EXP2: one hostile qft-presentation package runs a battery of probes inside the player.
// Evidence is collected three ways: (1) what the probe saw, (2) what our "attacker" servers
// received, (3) what Playwright observed on the host page (dialogs, popups, navigations).
const fs = require('node:fs');
const path = require('node:path');
const { chromium } = require('playwright');
const L = require('./lib.cjs');

const PORT = { site: 4400, evil: 4401, tcp: 4402, udp: 4403 };
const base = `http://127.0.0.1:${PORT.site}/`;
const html = fs.readFileSync(path.join(__dirname, 'hostile-battery.html'), 'utf8')
  .replaceAll('__EVIL__', PORT.evil).replaceAll('__SITE__', PORT.site).replaceAll('__TCP__', PORT.tcp).replaceAll('__UDP__', PORT.udp).replaceAll('__LANIP__', '192.0.2.2');

(async () => {
  const site = await L.startSite(PORT.site);
  const evil = await L.startEvil(PORT.evil);
  const tcp = await L.startTcp(PORT.tcp);
  const udp = await L.startUdp(PORT.udp);
  const browser = await chromium.launch();
  const out = { chromium: browser.version() };
  try {
    const context = await browser.newContext({ viewport: { width: 1440, height: 1000 }, acceptDownloads: true });
    const page = await context.newPage();
    const host = { dialogs: [], popups: [], downloads: [], mainFrameNavigations: [], console: [], requests: [] };
    page.on('dialog', async (dialog) => { host.dialogs.push(`${dialog.type()}: ${dialog.message()}`); await dialog.dismiss().catch(() => {}); });
    context.on('page', (popup) => host.popups.push(popup.url()));
    page.on('download', (download) => host.downloads.push(download.suggestedFilename()));
    page.on('framenavigated', (frame) => { if (frame === page.mainFrame()) host.mainFrameNavigations.push(frame.url()); });
    page.on('console', (message) => { if (['error', 'warning'].includes(message.type())) host.console.push(`${message.type()}: ${message.text().slice(0, 260)}`); });
    page.on('request', (request) => { const url = request.url(); if (!url.startsWith(base) && !url.startsWith('blob:') && !url.startsWith('data:')) host.requests.push(`${request.method()} ${url.slice(0, 120)} [${request.resourceType()}]`); });
    await L.openWorkspace(page, base);
    // Give the editor something private to protect.
    await page.locator('.cm-content').first().click();
    await page.keyboard.type('# PRIVATE DRAFT\n\nsecret-token-12345');
    await L.sleep(1500);
    const siteLogBefore = site.log.length;
    await L.openFile(page, L.makePackage(html), 'hostile.zip');
    await page.locator('[data-pres-start-button]').waitFor({ state: 'visible', timeout: 15000 });
    await page.locator('[data-pres-start-button]').click();
    const frame = await L.until(() => L.appFrame(page), 'application frame', 15000);
    await L.until(() => frame.evaluate(() => window.__r && window.__r.done), 'battery to finish', 120000, 500);
    out.probe = await frame.evaluate(() => window.__r);
    out.frames = page.frames().map((f) => f.url().slice(0, 60));
    await L.sleep(1500);
    out.hostAfter = await L.dialogState(page);
    out.host = host;
    out.evilLog = evil.log.map((e) => `${e.method} ${e.url} dest=${e.dest}`);
    out.tcpLog = tcp.log.map((e) => `tcp from ${e.remote} first=${JSON.stringify(e.first.slice(0, 60))}`);
    out.udpLog = udp.log.map((e) => `udp ${e.bytes}B from ${e.from} hex=${e.hex}`);
    out.siteRequestsAfterImport = site.log.slice(siteLogBefore).map((e) => `${e.method} ${e.url} dest=${e.dest}`);
    out.draftStillThere = await page.evaluate(() => document.querySelector('.cm-content')?.textContent.includes('secret-token-12345'));
    await page.screenshot({ path: path.join(__dirname, 'shots', 'exp2-battery.png') });
    await context.close();
  } finally {
    await browser.close();
    await Promise.all([site.close(), evil.close(), tcp.close(), udp.close()]);
    fs.writeFileSync(path.join(__dirname, 'logs', 'exp2-battery.json'), JSON.stringify(out, null, 2));
  }
  console.log('Chromium', out.chromium);
  for (const [key, value] of Object.entries(out.probe || {})) if (key !== 'violations') console.log(`${key.padEnd(52)} ${typeof value === 'string' ? value : JSON.stringify(value)}`);
  console.log('\nCSP violations seen inside the package (muted from the host):');
  for (const item of out.probe?.violations || []) console.log('  ', item);
  console.log('\nHOST status after battery:', JSON.stringify({ status: out.hostAfter?.status, notice: out.hostAfter?.notice, frames: out.hostAfter?.frames }));
  console.log('HOST observations:', JSON.stringify(out.host, null, 1));
  console.log('EVIL http log:', out.evilLog);
  console.log('TCP log:', out.tcpLog);
  console.log('UDP log:', out.udpLog);
  console.log('Site requests after import:', out.siteRequestsAfterImport);
  console.log('Draft intact:', out.draftStillThere, '| frames:', out.frames);
})().catch((error) => { console.error(error); process.exit(1); });
