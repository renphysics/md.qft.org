// EXP7d: Reveal's own fullscreen shortcut (F) inside the player.
const fs = require('node:fs'); const path = require('node:path');
const { chromium } = require('playwright'); const L = require('./lib.cjs');
const zip = fs.readFileSync(path.join(__dirname, 'pkgs', 'reveal-inlined.zip'));
(async () => {
  const site = await L.startSite(4400); const browser = await chromium.launch({ channel: 'chromium' });
  const out = {};
  try {
    const page = await (await browser.newContext({ viewport: { width: 1300, height: 900 } })).newPage();
    const consoleMessages = []; page.on('console', (m) => { if (m.type() === 'error') consoleMessages.push(m.text().slice(0, 200)); });
    await L.openWorkspace(page, 'http://127.0.0.1:4400/');
    await L.openFile(page, zip, 'deck.zip');
    await page.locator('[data-pres-start-button]').click();
    await L.until(async () => (await L.dialogState(page)).status === 'Playing locally', 'ready', 25000);
    const box = await page.locator('[data-pres-host] iframe').boundingBox();
    await page.mouse.click(box.x + 30, box.y + 30); await L.sleep(300);
    await page.keyboard.press('f'); await L.sleep(1200);
    const s = await L.dialogState(page);
    out.afterF = { status: s.status, notice: s.notice, frames: s.frames, hostFullscreen: await page.evaluate(() => !!document.fullscreenElement) };
    out.console = consoleMessages;
  } finally { await browser.close(); await site.close(); fs.writeFileSync(path.join(__dirname, 'logs', 'exp7d-fkey.json'), JSON.stringify(out, null, 2)); }
  console.log(JSON.stringify(out, null, 1));
})().catch((e) => { console.error(e); process.exit(1); });
