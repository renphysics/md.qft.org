// EXP12: the ready handshake waits for two animation frames. What if the tab is hidden while loading?
const fs = require('node:fs'); const path = require('node:path');
const { chromium } = require('playwright'); const L = require('./lib.cjs');
const example = fs.readFileSync('/home/user/md.qft.org/dist/slidev/interactive-physics.zip');
(async () => {
  const site = await L.startSite(4400);
  // Drop the Playwright switches that keep background pages running at full speed.
  const browser = await chromium.launch({ channel: 'chromium', ignoreDefaultArgs: ['--disable-backgrounding-occluded-windows', '--disable-renderer-backgrounding', '--disable-background-timer-throttling'] });
  const out = {};
  try {
    const context = await browser.newContext({ viewport: { width: 1300, height: 900 } });
    const page = await context.newPage();
    await L.openWorkspace(page, 'http://127.0.0.1:4400/');
    await L.openFile(page, example, 'example.zip');
    await page.locator('[data-pres-start-button]').waitFor({ state: 'visible', timeout: 20000 });
    const cdp = await context.newCDPSession(page);
    const tryHide = async () => {
      const attempts = {};
      try { const { windowId } = await cdp.send('Browser.getWindowForTarget'); await cdp.send('Browser.setWindowBounds', { windowId, bounds: { windowState: 'minimized' } }); attempts.minimize = 'ok'; } catch (e) { attempts.minimize = e.message.split('\n')[0]; }
      await L.sleep(300); attempts.visibilityAfterMinimize = await page.evaluate(() => document.visibilityState);
      if (attempts.visibilityAfterMinimize !== 'hidden') {
        try { await cdp.send('Emulation.setPageVisibilityOverride', { visibility: 'hidden' }); attempts.override = 'ok'; } catch (e) { attempts.override = e.message.split('\n')[0]; }
        await L.sleep(200); attempts.visibilityAfterOverride = await page.evaluate(() => document.visibilityState);
      }
      return attempts;
    };
    // Start via a DOM click (no pointer needed once the window is minimized), then hide immediately.
    await page.evaluate(() => document.querySelector('[data-pres-start-button]').click());
    out.hide = await tryHide();
    out.rafWhileHidden = await Promise.race([page.evaluate(() => new Promise((resolve) => requestAnimationFrame(() => resolve('rAF fired')))), L.sleep(3000).then(() => 'no animation frame within 3 s')]);
    const timeline = []; let last = ''; const t0 = Date.now();
    while (Date.now() - t0 < 25000) { const s = await L.dialogState(page); const key = `${s.status}|${s.notice}`; if (key !== last) { last = key; timeline.push(`${Date.now() - t0}ms ${s.status}${s.notice ? ' | ' + s.notice : ''}`); } await L.sleep(300); }
    out.timeline = timeline;
  } finally { await browser.close(); await site.close(); fs.writeFileSync(path.join(__dirname, 'logs', 'exp12-hidden.json'), JSON.stringify(out, null, 2)); }
  console.log(JSON.stringify(out, null, 1));
})().catch((e) => { console.error(e); process.exit(1); });
