// EXP8: play an ORDINARY slidev-build dist (default router mode, default features) after it was
// converted by the repo's own packer (pack.mjs), with the Google Fonts <link> removed by hand.
const fs = require('node:fs'); const path = require('node:path');
const { chromium } = require('playwright'); const L = require('./lib.cjs');
const zip = fs.readFileSync(path.join(__dirname, 'out', process.argv[2] || 'ordinary-dist-nofonts.zip'));
(async () => {
  const site = await L.startSite(4400); const browser = await chromium.launch({ channel: 'chromium' });
  const out = {};
  try {
    const page = await (await browser.newContext({ viewport: { width: 1300, height: 900 } })).newPage();
    const consoleMessages = []; page.on('console', (m) => { if (m.type() === 'error') consoleMessages.push(m.text().slice(0, 220)); });
    await L.openWorkspace(page, 'http://127.0.0.1:4400/');
    await L.openFile(page, zip, 'ordinary.zip');
    await page.locator('[data-pres-start-button]').waitFor({ state: 'visible', timeout: 15000 });
    const t0 = Date.now();
    await page.locator('[data-pres-start-button]').click();
    const timeline = []; let last = '';
    const sample = async () => { const s = await L.dialogState(page); const key = `${s.status}|${s.notice}`; if (key !== last) { last = key; timeline.push(`${Date.now() - t0}ms ${s.status}${s.notice ? ' | ' + s.notice : ''}`); } return s; };
    await L.until(async () => { const s = await sample(); return s.status === 'Playing locally' || s.status === 'Playback needs attention'; }, 'start', 25000, 100).catch(() => {});
    await L.sleep(1500); await sample();
    out.timeline = timeline;
    const frame = L.appFrame(page);
    if (frame) {
      const view = () => ({ url: location.href.slice(0, 20) + '…' + location.hash, title: document.title, slideText: (document.querySelector('.slidev-page:not([style*="display: none"])')?.innerText || document.body.innerText).trim().slice(0, 80), layouts: document.querySelectorAll('.slidev-layout').length, is404: /404|not found/i.test(document.body.innerText.slice(0, 300)) });
      out.initial = await frame.evaluate(view);
      const box = await page.locator('[data-pres-host] iframe').boundingBox();
      await page.mouse.click(box.x + 40, box.y + 40); await L.sleep(300);
      for (let i = 0; i < 3; i++) { await page.keyboard.press('ArrowRight'); await L.sleep(700); await sample(); }
      out.afterThreeRights = L.appFrame(page) ? await frame.evaluate(view).catch((e) => e.message.split('\n')[0]) : 'frame gone';
      out.hostHistoryLength = await page.evaluate(() => history.length);
    }
    out.timeline = timeline; out.final = await sample().then((s) => ({ status: s.status, notice: s.notice, frames: s.frames }));
    out.console = consoleMessages.slice(0, 8);
    await page.screenshot({ path: path.join(__dirname, 'shots', 'exp8-packed-ordinary.png') });
  } finally { await browser.close(); await site.close(); fs.writeFileSync(path.join(__dirname, 'logs', 'exp8-packed-ordinary.json'), JSON.stringify(out, null, 2)); }
  console.log(JSON.stringify(out, null, 1));
})().catch((e) => { console.error(e); process.exit(1); });
