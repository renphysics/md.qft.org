// V1.9 F16 retest: query string affecting the embedded Reveal slide preview (slides mode).
const fs=require('node:fs'),path=require('node:path'); const {chromium}=require('playwright'); const L=require('./lib-a1-copy.cjs');
(async()=>{
 const site=await L.startSite(4660); const out={}; let browser;
 try{
  browser=await chromium.launch({channel:'chromium'});
  const grab=async(q)=>{const page=await (await browser.newContext()).newPage();const errs=[];page.on('pageerror',e=>errs.push(e.message.slice(0,90)));
    await page.goto('http://127.0.0.1:4660/?example=quantum-slides'+q,{waitUntil:'load'});
    await page.locator('.cm-editor').waitFor({timeout:30000}).catch(()=>{});
    await L.sleep(1500);
    await page.locator('[data-content-mode="slides"]').click().catch(()=>{});
    await L.sleep(2500);
    const r={pageerrors:errs,
      slideLoadError:await page.evaluate(()=>document.body.innerText.includes('could not be loaded')||document.body.innerText.includes('Switch to Document and back')),
      bodyMentionsPrintPdf:await page.evaluate(()=>!!document.querySelector('.reveal-print, .print-pdf')),
      revealClasses:await page.evaluate(()=>{const r=document.querySelector('.reveal');return r?r.className.slice(0,60):'no-reveal'}),
      previewSnippet:await page.evaluate(()=>{const s=document.querySelector('.reveal .slides section');return s?s.innerText.replace(/\s+/g,' ').slice(0,50):'no-slide'})};
    await page.close(); return r;};
  out.normal=await grab('');
  out.scroll=await grab('&view=scroll');
  out.printPdf=await grab('&print-pdf');
 } finally { if(browser)await browser.close(); await site.close(); fs.writeFileSync(path.join(__dirname,'logs','v-f16.json'),JSON.stringify(out,null,2)); }
 console.log(JSON.stringify(out,null,1));
})().catch(e=>{console.error(e);process.exit(1)});
