// V1.5 verify: self-contained Reveal 6.0.2, hash:true (first slide id-less) killed by SecurityError
// from replaceState; try/catch shim around replaceState/pushState makes it play. F and S kill a running deck.
const fs=require('node:fs'),path=require('node:path');
const {chromium}=require('playwright'); const L=require('./lib-a1-copy.cjs');
const R='SCRATCH/research/proto/B1/pkgs/v6.0.2/package/dist';
const revealCss=fs.readFileSync(path.join(R,'reveal.css'),'utf8');
const themeCss=fs.readFileSync(path.join(R,'theme/white.css'),'utf8').replace(/@import[^;]+;/g,''); // drop any font @import
const revealJs=fs.readFileSync(path.join(R,'reveal.js'),'utf8');
const deck=(hash,shim,extraInit='')=>`<!doctype html><html><head><meta charset="utf-8">
<style>${revealCss}</style><style>${themeCss}</style></head><body>
<div class="reveal"><div class="slides">
<section>First slide (no id)</section>
<section id="second">Second slide</section>
<section>Third</section>
</div></div>
${shim?`<script>(function(){const H=History.prototype;const rs=H.replaceState,ps=H.pushState;H.replaceState=function(){try{return rs.apply(this,arguments)}catch(e){return}};H.pushState=function(){try{return ps.apply(this,arguments)}catch(e){return}};})();<\/script>`:''}
<script>${revealJs}<\/script>
<script>Reveal.initialize({hash:${hash},respondToHashChanges:${hash}${extraInit}});<\/script>
</body></html>`;
(async()=>{
 const site=await L.startSite(4660); const out={}; let browser;
 const run=async(page,html,label)=>{
   await L.openFile(page,L.makePackage(html),label+'.zip');
   await page.locator('[data-pres-start-button]').waitFor({state:'visible',timeout:15000});
   await page.locator('[data-pres-start-button]').click();
   await L.sleep(3500);
   const s=await L.dialogState(page); const frame=L.appFrame(page);
   return {status:s.status,notice:s.notice,frameAlive:!!frame,hash:frame?await frame.evaluate(()=>location.hash).catch(()=>null):null};
 };
 try{
  browser=await chromium.launch({channel:'chromium'});
  // Case 1: hash:true, no shim
  let page=await (await browser.newContext()).newPage();
  await L.openWorkspace(page,'http://127.0.0.1:4660/');
  out.hashTrue_noShim=await run(page,deck(true,false),'h1'); await page.close();
  // Case 2: hash:true, WITH shim
  page=await (await browser.newContext()).newPage();
  await L.openWorkspace(page,'http://127.0.0.1:4660/');
  out.hashTrue_withShim=await run(page,deck(true,true),'h2'); await page.close();
  // Case 3: hash:false baseline (should play), then press F then S to show they kill it
  page=await (await browser.newContext()).newPage();
  await L.openWorkspace(page,'http://127.0.0.1:4660/');
  out.hashFalse_baseline=await run(page,deck(false,false),'h3');
  // deck should be playing; focus it then press F
  const frame=L.appFrame(page);
  if(frame){
   await page.evaluate(()=>{const f=document.querySelector('[data-pres-host] iframe');f.blur();f.focus({preventScroll:true})});
   const token=await frame.evaluate(()=>{const m=(document.scripts[0]?.textContent||'').match(/\)\("([a-f0-9]{36})"\)/);return m?m[1]:null});
   await page.evaluate(t=>document.querySelector('[data-pres-host] iframe').contentWindow.postMessage({type:'qft-presentation-focus',token:t},'*'),token);
   await L.sleep(200);
   await page.keyboard.press('f'); await L.sleep(1500);
   out.afterF={...await L.dialogState(page),frameAlive:!!L.appFrame(page)};
  }
  await page.close();
  // Case 4: hash:false baseline then press S (speaker view)
  page=await (await browser.newContext()).newPage();
  await L.openWorkspace(page,'http://127.0.0.1:4660/');
  const b4=await run(page,deck(false,false),'h4');
  const f4=L.appFrame(page);
  if(f4){
   await page.evaluate(()=>{const f=document.querySelector('[data-pres-host] iframe');f.blur();f.focus({preventScroll:true})});
   const token=await f4.evaluate(()=>{const m=(document.scripts[0]?.textContent||'').match(/\)\("([a-f0-9]{36})"\)/);return m?m[1]:null});
   await page.evaluate(t=>document.querySelector('[data-pres-host] iframe').contentWindow.postMessage({type:'qft-presentation-focus',token:t},'*'),token);
   await L.sleep(200);
   await page.keyboard.press('s'); await L.sleep(1500);
   out.afterS={...await L.dialogState(page),frameAlive:!!L.appFrame(page)};
  }
  out.sBaseline=b4;
  await page.close();
 } finally { if(browser)await browser.close(); await site.close(); fs.writeFileSync(path.join(__dirname,'logs','v-reveal-hash.json'),JSON.stringify(out,null,2)); }
 console.log(JSON.stringify(out,null,1));
})().catch(e=>{console.error(e);process.exit(1)});
