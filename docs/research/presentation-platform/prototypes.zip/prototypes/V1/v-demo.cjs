// Extra check: does the interactive-demo sandbox have the same prerender + webrtc channels?
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'); const {chromium}=require('playwright'); const L=require('./lib-a1-copy.cjs');
const UDP_IP='127.0.0.1',UDP_PORT=4663;
const demoHtml=`<div id="box">demo</div>
<script>
{const l=document.createElement('link');l.rel='prerender';l.href='http://localhost:4661/DEMO-prerender?d=1';document.head.append(l);}
try{const pc=new RTCPeerConnection({iceServers:[{urls:'stun:${UDP_IP}:${UDP_PORT}'}]});pc.createDataChannel('c');pc.createOffer().then(o=>pc.setLocalDescription(o));}catch(e){}
<\/script>`;
const md=`# Demo probe\n\n\`\`\`interactive title="probe"\n${demoHtml}\n\`\`\`\n`;
(async()=>{
 const site=await L.startSite(4660);
 const hl=[]; const evil=http.createServer((req,res)=>{hl.push(req.url.slice(0,40));res.writeHead(200);res.end('x');});
 await new Promise(r=>evil.listen(4661,'0.0.0.0',r));
 const udp=await L.startUdp(UDP_PORT);
 const out={}; let browser;
 try{
  browser=await chromium.launch({channel:'chromium'});
  const page=await (await browser.newContext()).newPage();
  const cons=[]; page.on('console',m=>cons.push(m.text().slice(0,100)));
  await L.openWorkspace(page,'http://127.0.0.1:4660/');
  await L.openFile(page,Buffer.from(md,'utf8'),'demo.md','text/markdown');
  await L.sleep(1500);
  // find the demo Run button in the preview
  const runBtn=page.locator('[data-demo-run]').first();
  out.runButtonCount=await page.locator('[data-demo-run]').count();
  if(out.runButtonCount>0){
   const before=hl.length,ub=udp.log.length;
   await runBtn.click();
   await L.sleep(4000);
   const df=page.frames().find(f=>f.url().startsWith('blob:')||/demo-sandbox/.test(f.url()));
   out.demoFrame=df?df.url().slice(0,40):null;
   out.httpReceived=hl.slice(before);
   out.stunDatagrams=udp.log.length-ub;
   out.demoStatus=await page.locator('[data-demo-status]').first().textContent().catch(()=>null);
  }
  // inspect the demo-sandbox CSP from dist
  out.demoSandboxCsp=fs.readFileSync('/home/user/md.qft.org/public/demo-sandbox.html','utf8').match(/Content-Security-Policy" content="([^"]*)"/)[1].slice(0,200);
 } finally { if(browser)await browser.close(); await site.close(); evil.closeAllConnections?.(); await new Promise(r=>evil.close(r)); await udp.close(); fs.writeFileSync(path.join(__dirname,'logs','v-demo.json'),JSON.stringify(out,null,2)); }
 console.log(JSON.stringify(out,null,1));
})().catch(e=>{console.error(e);process.exit(1)});
