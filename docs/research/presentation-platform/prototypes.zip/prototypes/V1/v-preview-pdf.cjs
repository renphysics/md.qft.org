// V1.9: (F16) ?view=scroll and ?print-pdf break the Markdown slide preview; (F17) Save PDF refused for quantum-slides.
const fs=require('node:fs'),path=require('node:path'); const {chromium}=require('playwright'); const L=require('./lib-a1-copy.cjs');
(async()=>{
 const site=await L.startSite(4660); const out={}; let browser;
 try{
  browser=await chromium.launch({channel:'chromium'});
  const grab=async(q)=>{const page=await (await browser.newContext()).newPage();const errs=[];page.on('pageerror',e=>errs.push(e.message.slice(0,80)));
    await page.goto('http://127.0.0.1:4660/'+q,{waitUntil:'load'});
    await page.locator('.cm-editor').waitFor({timeout:30000}).catch(()=>{});
    await L.sleep(2500);
    const previewText=await page.evaluate(()=>{const p=document.querySelector('[data-preview],.preview,[data-render-root],.markdown-preview,main');return (document.body.innerText||'').slice(0,0),(document.querySelector('.slides-could-not, [data-slide-error]')?.textContent)||''});
    const bodyHasError=await page.evaluate(()=>document.body.innerText.includes('could not be loaded')||document.body.innerText.includes('Switch to Document'));
    const htmlClass=await page.evaluate(()=>document.documentElement.className);
    const notice=await page.evaluate(()=>{const n=[...document.querySelectorAll('[role="status"],[role="alert"],.toast,[data-render-state]')].map(e=>e.textContent.trim()).filter(Boolean);return n.slice(0,4)});
    const r={pageerrors:errs,bodyMentionsLoadError:bodyHasError,htmlClass:htmlClass.slice(0,40),notice};
    await page.close(); return r;};
  out.scroll=await grab('?view=scroll');
  out.printPdf=await grab('?print-pdf');
  out.normal=await grab('');
  // F17: quantum-slides Save PDF
  const page=await (await browser.newContext()).newPage();
  const toasts=[]; 
  await page.goto('http://127.0.0.1:4660/?example=quantum-slides',{waitUntil:'load'});
  await page.locator('.cm-editor').waitFor({timeout:30000});
  await L.sleep(3000);
  // ensure slides mode preview
  await page.locator('[data-content-mode="slides"]').click().catch(()=>{});
  await L.sleep(1500);
  // open exports menu then Print/Save PDF
  await page.locator('[data-export-toggle],[data-export-menu-toggle],[data-exports-toggle]').first().click().catch(()=>{});
  await L.sleep(300);
  // trigger openPdf: the Print / Save PDF button
  await page.locator('[data-print]').first().click().catch(async()=>{await page.keyboard.press('Control+p')});
  await L.sleep(1000);
  // slide pdf dialog should be open; click Save PDF
  const dlgOpen=await page.evaluate(()=>!!document.querySelector('[data-slide-pdf-dialog]')?.open);
  out.slidePdfDialogOpen=dlgOpen;
  // capture notices after Save PDF
  const noticeBefore=await page.evaluate(()=>[...document.querySelectorAll('[role="status"],[role="alert"],.toast')].map(e=>e.textContent.trim()).filter(Boolean));
  await page.locator('[data-slide-print]').click().catch(()=>{});
  await L.sleep(2000);
  out.noticeAfterSavePdf=await page.evaluate(()=>[...document.querySelectorAll('[role="status"],[role="alert"],.toast,[data-slide-pdf-warning]')].map(e=>e.textContent.trim()).filter(Boolean).slice(0,6));
  out.bodyMentionsTooMuch=await page.evaluate(()=>document.body.innerText.includes('too much content'));
  await page.close();
 } finally { if(browser)await browser.close(); await site.close(); fs.writeFileSync(path.join(__dirname,'logs','v-preview-pdf.json'),JSON.stringify(out,null,2)); }
 console.log(JSON.stringify(out,null,1));
})().catch(e=>{console.error(e);process.exit(1)});
