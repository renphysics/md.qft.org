// V1.3 readable probes, every async source fully handled so bootstrap never fatals.
const fs=require('node:fs'),path=require('node:path');
const {chromium}=require('playwright'); const L=require('./lib-a1-copy.cjs');
const E='http://localhost:4661', UDP_IP='127.0.0.1', UDP_PORT=4663;
const html=`<!doctype html><html><body><h1>iso</h1><script>
window.__p={};const rec=(k,v)=>window.__p[k]=String(v).slice(0,70);
const S=(k,f)=>{try{rec(k,'VAL:'+f())}catch(e){rec(k,'BLOCKED:'+(e.name||e.message||e))}};
S('1_localStorage_native_isEditorStore',()=>{localStorage.setItem('probe','v');return 'len='+localStorage.length+' (shim if 1 & isolated)'});
S('3_cookie_read',()=>'cookie='+JSON.stringify(document.cookie));
S('5_top_dom_read',()=>top.document.body.innerHTML.length);
S('6_parent_dom_title',()=>parent.document.title);
S('7_window_open',()=>{const w=window.open('${E}/popup','_blank');return 'ret='+(w===null?'null':typeof w)});
S('12_history_pushState',()=>{history.pushState({},'','/x');return 'pushed len='+history.length});
S('13_history_replaceState',()=>{history.replaceState({},'','/y');return 'replaced'});
// indexedDB with full error handling
(()=>{try{const r=indexedDB.open('qft-markdown');r.onerror=e=>{e.stopPropagation&&e.stopPropagation();rec('2_indexedDB_qft','onerror:'+(r.error&&r.error.name))};r.onsuccess=()=>rec('2_indexedDB_qft','opened stores='+[...r.result.objectStoreNames].join('|'));r.onupgradeneeded=()=>rec('2_indexedDB_qft','upgradeneeded=newEmptyDB')}catch(e){rec('2_indexedDB_qft','throw:'+e.name)}})();
// alert/confirm are sync; sandbox without allow-modals makes them no-op (return undefined/false) - no error
S('8_alert',()=>{const r=alert('hi');return 'alert-returned='+r});
S('9_confirm',()=>'confirm='+confirm('ok'));
// escapes
S('ESCAPE_prerender',()=>{const l=document.createElement('link');l.rel='prerender';l.href='${E}/ESCAPE-prerender?x=1';document.head.append(l);return 'appended'});
(()=>{try{const pc=new RTCPeerConnection({iceServers:[{urls:'stun:${UDP_IP}:${UDP_PORT}'}]});pc.createDataChannel('c');pc.createOffer().then(o=>pc.setLocalDescription(o)).then(()=>rec('ESCAPE_webrtc','offer-set')).catch(e=>rec('ESCAPE_webrtc','rtcrej:'+e.name));}catch(e){rec('ESCAPE_webrtc','throw:'+e.name)}})();
setTimeout(()=>{window.__done=true},1800);
</script></body></html>`;
(async()=>{
 const site=await L.startSite(4660); const evil=await L.startEvil(4661); const udp=await L.startUdp(UDP_PORT);
 const out={}; let browser;
 try{
  browser=await chromium.launch({channel:'chromium'});
  const page=await (await browser.newContext()).newPage();
  const dialogs=[]; page.on('dialog',async d=>{dialogs.push(d.type());await d.dismiss()});
  const popups=[]; page.on('popup',p=>popups.push(p.url()));
  await L.openWorkspace(page,'http://127.0.0.1:4660/');
  await L.openFile(page,L.makePackage(html),'iso.zip');
  await page.locator('[data-pres-start-button]').waitFor({state:'visible',timeout:15000});
  await page.locator('[data-pres-start-button]').click();
  await L.sleep(3200);
  const frame=L.appFrame(page); const s=await L.dialogState(page);
  out.hostStatus=s.status; out.frameAlive=!!frame;
  out.probes=frame?await frame.evaluate(()=>window.__p).catch(()=>'err'):'no-frame';
  out.attackerHTTP=evil.log.map(e=>`${e.method} ${e.url}`); out.stunDatagrams=udp.log.length;
  out.dialogsSeenByHost=dialogs; out.popups=popups;
 } finally { if(browser)await browser.close(); await Promise.all([site.close(),evil.close(),udp.close()]); fs.writeFileSync(path.join(__dirname,'logs','v-isolation3.json'),JSON.stringify(out,null,2)); }
 console.log(JSON.stringify(out,null,1));
})().catch(e=>{console.error(e);process.exit(1)});
