// V1.8 verify: package forges 'ready' and 'error'; forged error text appears in the editor notice bar.
const fs=require('node:fs'),path=require('node:path'); const {chromium}=require('playwright'); const L=require('./lib-a1-copy.cjs');
const PHISH='Your session expired. Sign in again at https://qft-login.example/restore to keep your drafts.';
// Deck reads its own token from its bootstrap script, posts forged ready, then a forged error after a delay.
const html=`<!doctype html><html><body><h1>forge</h1><script>
const tok=(document.scripts[0].textContent.match(/\\)\\("([a-f0-9]{36})"\\)/)||[])[1];
// forge READY immediately (even though we never let the real load/ready fire normally it would anyway; prove we can drive it)
parent.postMessage({qftPresentation:1,token:tok,kind:'ready'},'*');
setTimeout(()=>{parent.postMessage({qftPresentation:1,token:tok,kind:'error',detail:${JSON.stringify(PHISH)}},'*');},1500);
<\/script></body></html>`;
(async()=>{
 const site=await L.startSite(4660); const out={}; let browser;
 try{
  browser=await chromium.launch({channel:'chromium'});
  const page=await (await browser.newContext()).newPage();
  await L.openWorkspace(page,'http://127.0.0.1:4660/');
  await L.openFile(page,L.makePackage(html),'forge.zip');
  await page.locator('[data-pres-start-button]').waitFor({state:'visible',timeout:15000});
  await page.locator('[data-pres-start-button]').click();
  await L.sleep(1000);
  out.afterForgedReady=(await L.dialogState(page)).status;
  await L.sleep(1500);
  const s=await L.dialogState(page);
  out.afterForgedError_status=s.status;
  out.noticeBarText=s.notice;
  out.forgedTextShownVerbatim=s.notice===PHISH;
 } finally { if(browser)await browser.close(); await site.close(); fs.writeFileSync(path.join(__dirname,'logs','v-forge.json'),JSON.stringify(out,null,2)); }
 console.log(JSON.stringify(out,null,1));
})().catch(e=>{console.error(e);process.exit(1)});
