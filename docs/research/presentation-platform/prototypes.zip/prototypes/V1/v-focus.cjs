// V1.4 verify: arrow keys don't reach deck after Start (full Chromium) for the SHIPPED slidev example;
// the 3-line repair (blur+focus outer iframe, then focus message) fixes it.
const fs=require('node:fs'),path=require('node:path');
const {chromium}=require('playwright'); const L=require('./lib-a1-copy.cjs');
const ZIP=fs.readFileSync('/home/user/md.qft.org/dist/slidev/interactive-physics.zip');
const fi=()=>({hasFocus:document.hasFocus(),active:document.activeElement?document.activeElement.tagName.toLowerCase():null});
(async()=>{
 const site=await L.startSite(4660); const out={}; let browser;
 try{
  browser=await chromium.launch({channel:'chromium'});
  const page=await (await browser.newContext({viewport:{width:1300,height:900}})).newPage();
  const cons=[]; page.on('console',m=>cons.push(m.text().slice(0,120)));
  await L.openWorkspace(page,'http://127.0.0.1:4660/');
  await L.openFile(page,ZIP,'slidev-example.zip');
  await page.locator('[data-pres-start-button]').waitFor({state:'visible',timeout:15000});
  await page.locator('[data-pres-start-button]').click();
  await L.until(async()=>(await L.dialogState(page)).status==='Playing locally','ready',25000);
  await L.sleep(1000);
  const frame=L.appFrame(page); const runner=L.runnerFrame(page);
  // read slidev slide index from the URL hash or nav state
  const slide=async()=>{try{return await frame.evaluate(()=>location.hash+' | path='+location.pathname)}catch(e){return 'err:'+e.message}};
  // A robust "did we advance" signal: slidev updates the visible slide; capture body text hash
  const snap=async()=>{try{return await frame.evaluate(()=>document.body.innerText.replace(/\s+/g,' ').slice(0,80))}catch(e){return 'err'}};
  out.afterStart={top:await page.evaluate(fi),runner:await runner.evaluate(fi),deck:await frame.evaluate(fi),slide:await slide(),snap:await snap()};
  // Try arrows WITHOUT clicking (the bug scenario)
  await page.keyboard.press('ArrowRight'); await L.sleep(400);
  await page.keyboard.press('ArrowRight'); await L.sleep(400);
  out.afterArrowsNoClick={deck:await frame.evaluate(fi),slide:await slide(),snap:await snap()};
  // Apply the 3-line repair from outside
  await page.evaluate(()=>{const f=document.querySelector('[data-pres-host] iframe');f.blur();f.focus({preventScroll:true});});
  await L.sleep(150);
  const token=await frame.evaluate(()=>{const s=document.scripts[0]&&document.scripts[0].textContent||'';const m=s.match(/\)\("([a-f0-9]{36})"\)/);return m?m[1]:null});
  await page.evaluate(t=>document.querySelector('[data-pres-host] iframe').contentWindow.postMessage({type:'qft-presentation-focus',token:t},'*'),token);
  await L.sleep(250);
  out.afterRepair={deck:await frame.evaluate(fi),runner:await runner.evaluate(fi)};
  await page.keyboard.press('ArrowRight'); await L.sleep(500);
  out.afterArrowPostRepair={deck:await frame.evaluate(fi),slide:await slide(),snap:await snap()};
  out.focusConsole=cons.filter(m=>/focus/i.test(m)).slice(0,5);
 } finally { if(browser)await browser.close(); await site.close(); fs.writeFileSync(path.join(__dirname,'logs','v-focus.json'),JSON.stringify(out,null,2)); }
 console.log(JSON.stringify(out,null,1));
})().catch(e=>{console.error(e);process.exit(1)});
