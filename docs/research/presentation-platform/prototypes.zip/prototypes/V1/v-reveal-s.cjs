const fs=require('node:fs'),path=require('node:path');
const {chromium}=require('playwright'); const L=require('./lib-a1-copy.cjs');
const R='SCRATCH/research/proto/B1/pkgs/v6.0.2/package/dist';
const revealCss=fs.readFileSync(path.join(R,'reveal.css'),'utf8');
const revealJs=fs.readFileSync(path.join(R,'reveal.js'),'utf8');
const notesJs=fs.readFileSync(path.join(R,'plugin/notes.js'),'utf8');
const html=`<!doctype html><html><head><meta charset="utf-8"><style>${revealCss}</style></head><body>
<div class="reveal"><div class="slides"><section id="a">One<aside class="notes">speaker note</aside></section><section id="b">Two</section></div></div>
<script>${revealJs}<\/script><script>${notesJs}<\/script>
<script>Reveal.initialize({hash:false,plugins:[RevealNotes]});<\/script></body></html>`;
(async()=>{
 const site=await L.startSite(4660); const out={}; let browser;
 try{
  browser=await chromium.launch({channel:'chromium'});
  const page=await (await browser.newContext()).newPage();
  await L.openWorkspace(page,'http://127.0.0.1:4660/');
  await L.openFile(page,L.makePackage(html),'notes.zip');
  await page.locator('[data-pres-start-button]').waitFor({state:'visible',timeout:15000});
  await page.locator('[data-pres-start-button]').click();
  await L.sleep(3000);
  out.baseline={...await L.dialogState(page),frameAlive:!!L.appFrame(page)};
  const frame=L.appFrame(page);
  if(frame){
   await page.evaluate(()=>{const f=document.querySelector('[data-pres-host] iframe');f.blur();f.focus({preventScroll:true})});
   const token=await frame.evaluate(()=>{const m=(document.scripts[0]?.textContent||'').match(/\)\("([a-f0-9]{36})"\)/);return m?m[1]:null});
   await page.evaluate(t=>document.querySelector('[data-pres-host] iframe').contentWindow.postMessage({type:'qft-presentation-focus',token:t},'*'),token);
   await L.sleep(200);
   await page.keyboard.press('s'); await L.sleep(1500);
   const s=await L.dialogState(page);
   out.afterS={status:s.status,notice:s.notice,frameAlive:!!L.appFrame(page)};
  }
 } finally { if(browser)await browser.close(); await site.close(); }
 console.log(JSON.stringify(out,null,1));
})().catch(e=>{console.error(e);process.exit(1)});
