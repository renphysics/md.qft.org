// F7b: which Firefox content process spins during the loop, and do top page and sandboxed deck share it?
const {execSync}=require('node:child_process'); const fs=require('node:fs'),path=require('node:path');
const FF=require('./ff.cjs'); const L=require('./lib.cjs');
const html=`<!doctype html><html><body><h1>freeze</h1><script>window.addEventListener('load',()=>setTimeout(()=>{for(;;){}},1500));</script></body></html>`;
const ps=()=>execSync("ps -eo pid,pcpu,args | grep -E 'firefox' | grep -v grep | sed -E 's#/tmp/[^ ]*/firefox/firefox#FF#' | awk '{a=$1\" \"$2; for(i=3;i<=NF;i++){ if($i ~ /^-?(isForBrowser|appDir|parentBuildID|prefsLen|prefMapSize|jsInitLen|greomni|appomni|childID|sandboxReporter|ipcHandle|initialChannelId|parentPid)$/){i++;continue} a=a\" \"$i}; print substr(a,1,160)}'").toString().trim().split('\n');
(async()=>{
 const site=await L.startSite(4740); const out={};
 for(const [label,prefs] of [['default',null],['isolation=1',{'fission.webContentIsolationStrategy':1,'fission.autostart':true}]]){
  const b=await FF.launch(prefs?{firefoxUserPrefs:prefs}:{}); const o={};
  try{
   const page=await (await b.newContext()).newPage();
   await L.openWorkspace(page,'http://127.0.0.1:4740/');
   o.idleProcs=ps();
   await L.openFile(page,L.makePackage(html),'f.zip');
   await page.locator('[data-pres-start-button]').waitFor({state:'visible',timeout:15000});
   await page.locator('[data-pres-start-button]').click();
   await L.until(async()=>(await L.dialogState(page)).status==='Playing locally','ready',10000);
   o.playingProcs=ps();
   await L.sleep(4000);
   o.loopProcs=ps();
  }catch(e){o.error=String(e.message).split('\n')[0]}
  finally{await Promise.race([b.close(),L.sleep(6000)]);}
  out[label]=o;
 }
 await site.close(); fs.writeFileSync(path.join(__dirname,'logs','f7d.json'),JSON.stringify(out,null,2)); console.log(JSON.stringify(out,null,1));
})();
