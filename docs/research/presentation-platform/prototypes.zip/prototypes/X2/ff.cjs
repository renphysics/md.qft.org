// Firefox launcher from the isolated Playwright copy (never the global one).
const W='SCRATCH/research/corpus/naive/n3-reveal-offline/_work';
process.env.PLAYWRIGHT_BROWSERS_PATH=W+'/browsers';
const pw=require(W+'/node_modules/playwright-core');
module.exports={firefox:pw.firefox,launch:(opts={})=>pw.firefox.launch(opts)};
