// F1b: does the proposed Chromium focus repair (blur+focus outer iframe, then focus message) keep keys working in Firefox?
const fs=require('node:fs'),path=require('node:path'); const FF=require('./ff.cjs'); const L=require('./lib.cjs');
(async()=>{ const site=await L.startSite(4740); const b=await FF.launch(); const out={};
 try{ const page=await (await b.newContext({viewport:{width:1300,height:900}})).newPage();
  await page.goto('http://127.0.0.1:4740/?presentation=slidev-example',{waitUntil:'load'});
  await page.locator('[data-pres-start-button]').waitFor({state:'visible',timeout:30000}); await page.locator('[data-pres-start-button]').click();
  await L.until(async()=>(await L.dialogState(page)).status==='Playing locally','ready',25000); await L.sleep(1000);
  const frame=L.appFrame(page); const snap=()=>frame.evaluate(()=>document.body.innerText.replace(/\s+/g,' ').slice(0,40));
  out.s0=await snap();
  await page.evaluate(()=>{const f=document.querySelector('[data-pres-host] iframe');f.blur();f.focus({preventScroll:true});}); await L.sleep(150);
  const token=await frame.evaluate(()=>{const m=(document.scripts[0]?.textContent||'').match(/\)\("([a-f0-9]{36})"\)/);return m?m[1]:null}); out.tokenFound=!!token;
  await page.evaluate(t=>document.querySelector('[data-pres-host] iframe').contentWindow.postMessage({type:'qft-presentation-focus',token:t},'*'),token); await L.sleep(300);
  out.deckFocus=await frame.evaluate(()=>({hasFocus:document.hasFocus(),active:document.activeElement?.tagName}));
  await page.keyboard.press('ArrowRight'); await L.sleep(600); out.s1=await snap(); out.status=(await L.dialogState(page)).status;
 }catch(e){out.err=String(e.message).split('\n')[0]} finally{await b.close();await site.close();fs.writeFileSync(path.join(__dirname,'logs','f1b.json'),JSON.stringify(out,null,2));}
 console.log(JSON.stringify(out)); })();
