// F2: Reveal.js in the current player, Firefox. (a) A1 reveal-inlined.zip play+nav; (b) hash:true id-less first slide, no shim / with shim;
// (c) fragment navigation inside the blob: deck document.
const fs=require('node:fs'),path=require('node:path');
const FF=require('./ff.cjs'); const L=require('./lib.cjs');
const R='SCRATCH/research/proto/B1/pkgs/v6.0.2/package/dist';
const revealCss=fs.readFileSync(path.join(R,'reveal.css'),'utf8');
const themeCss=fs.readFileSync(path.join(R,'theme/white.css'),'utf8').replace(/@import[^;]+;/g,'');
const revealJs=fs.readFileSync(path.join(R,'reveal.js'),'utf8');
const deck=(hash,shim)=>`<!doctype html><html><head><meta charset="utf-8"><style>${revealCss}</style><style>${themeCss}</style></head><body>
<div class="reveal"><div class="slides"><section>First slide (no id) <a id="lnk" href="#second">link</a></section><section id="second">Second slide</section><section>Third</section></div></div>
${shim?`<script>(function(){const H=History.prototype;const rs=H.replaceState,ps=H.pushState;H.replaceState=function(){try{return rs.apply(this,arguments)}catch(e){return}};H.pushState=function(){try{return ps.apply(this,arguments)}catch(e){return}};})();<\/script>`:''}
<script>${revealJs}<\/script><script>Reveal.initialize({hash:${hash},respondToHashChanges:${hash}});<\/script></body></html>`;
(async()=>{
 const site=await L.startSite(4740); const out={}; const b=await FF.launch(); out.version=b.version();
 const run=async(buf,label)=>{
  const ctx=await b.newContext({viewport:{width:1300,height:900}}); const page=await ctx.newPage(); const cons=[]; page.on('console',m=>{if(m.type()==='error')cons.push(m.text().slice(0,220))});
  await L.openWorkspace(page,'http://127.0.0.1:4740/'); await L.openFile(page,buf,label+'.zip');
  await page.locator('[data-pres-start-button]').waitFor({state:'visible',timeout:15000});
  const t0=Date.now(); await page.locator('[data-pres-start-button]').click();
  let readyMs=null; try{await L.until(async()=>(await L.dialogState(page)).status==='Playing locally','ready',8000);readyMs=Date.now()-t0}catch{}
  await L.sleep(1500); const s=await L.dialogState(page); const f=L.appFrame(page);
  const r={readyMs,status:s.status,notice:s.notice,frameAlive:!!f};
  const idx=async()=>f?f.evaluate(()=>window.Reveal?.getIndices?JSON.stringify(Reveal.getIndices())+' hash='+location.hash:'no Reveal').catch(e=>'err '+e.message):null;
  r.idx0=await idx();
  if(f&&s.status==='Playing locally'){
   await page.keyboard.press('ArrowRight'); await L.sleep(600); r.idxAfterArrowNoClick=await idx();
   const box=await page.locator('[data-pres-host] iframe').boundingBox(); await page.mouse.click(box.x+box.width*0.8,box.y+box.height*0.8); await L.sleep(300);
   await page.keyboard.press('ArrowRight'); await L.sleep(600); r.idxAfterClickArrow=await idx();
  }
  return {r,page,ctx,f,cons};
 };
 try{
  let x=await run(fs.readFileSync('SCRATCH/research/proto/A1/pkgs/reveal-inlined.zip'),'ri'); out.revealInlined={...x.r,console:x.cons.slice(0,4)}; await x.ctx.close();
  x=await run(L.makePackage(deck(true,false)),'h1'); out.hashTrue_noShim={...x.r,console:x.cons.slice(0,4)}; await x.ctx.close();
  x=await run(L.makePackage(deck(true,true)),'h2'); out.hashTrue_withShim={...x.r,console:x.cons.slice(0,4)}; await x.ctx.close();
  x=await run(L.makePackage(deck(false,false)),'h3'); out.hashFalse={...x.r};
  if(x.f){
   const fr=await x.f.evaluate(async()=>{const o={url:location.href.slice(0,40)};const w=()=>new Promise(r=>setTimeout(r,500));
    try{location.hash='#x';await w();o.afterLocationHash=location.hash||'(empty)'}catch(e){o.afterLocationHash='THREW '+e.name+': '+e.message.slice(0,140)}
    try{document.getElementById('lnk').click();await w();o.afterAnchorClick=location.hash||'(empty)'}catch(e){o.afterAnchorClick='THREW '+e.name}
    try{history.replaceState(null,'','#/2');o.replaceStateFragment='ok hash='+location.hash}catch(e){o.replaceStateFragment='THREW '+e.name+': '+e.message.slice(0,140)}
    try{history.pushState(null,'','other');o.pushStatePath='ok'}catch(e){o.pushStatePath='THREW '+e.name+': '+e.message.slice(0,160)}
    return o;}).catch(e=>'frame err '+e.message);
   await L.sleep(800); const s=await L.dialogState(x.page);
   out.fragmentNav={...fr,hostAfter:s.status,noticeAfter:s.notice,frameStillBlob:!!L.appFrame(x.page),frameUrls:x.page.frames().map(f=>f.url().slice(0,50)),console:x.cons.slice(0,4)};
  }
  await x.ctx.close();
 } finally { await b.close(); await site.close(); fs.writeFileSync(path.join(__dirname,'logs','f2.json'),JSON.stringify(out,null,2)); }
 console.log(JSON.stringify(out,null,1));
})();
