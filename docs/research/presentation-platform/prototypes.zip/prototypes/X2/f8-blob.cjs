// EXP17b: variant of EXP17. The runner TRANSFERS the files (Blob objects) to the child with
// postMessage, and the child's bootstrap creates the blob: URLs in its own opaque origin.
const fs = require('node:fs'); const path = require('node:path');
const FF = require('./ff.cjs'); const L = require('./lib.cjs');
const csp = "default-src 'none'; script-src 'unsafe-inline' blob:; style-src 'unsafe-inline' blob:; img-src data: blob:; font-src data: blob:; media-src data: blob:; connect-src blob:; frame-src blob:; worker-src blob:";
const png = 'iVBORw0KGgoAAAANSUhEUgAAAAIAAAACCAYAAABytg0kAAAAFElEQVR42mP8z8Dwn4EIwDiqEF8IAHvRAv4X2z5JAAAAAElFTkSuQmCC';
const childScript = `
addEventListener('message', async (event) => {
  if (event.source !== parent || !event.data || !event.data.files) return;
  const t0 = performance.now();
  const pu = event.data.parentUrls || {}; const P = {};
  P.img = await new Promise((resolve) => { const i = new Image(); i.onload = () => resolve('loaded'); i.onerror = () => resolve('FAILED'); i.src = pu.img; });
  P.classic = await new Promise((resolve) => { const sc = document.createElement('script'); sc.src = pu.classic; sc.onload = () => resolve(window.__classic ? 'ran' : 'loaded, did not run'); sc.onerror = () => resolve('FAILED'); document.head.append(sc); });
  try { await fetch(pu.json); P.fetch = 'ok'; } catch (e) { P.fetch = 'FAILED ' + e.message; }
  window.__classic = undefined;
  const files = event.data.files; const R = { origin: self.origin, received: Object.keys(files).join(',') }; R.parentCreatedUrls = P;
  const url = {}; for (const [name, blob] of Object.entries(files)) if (name !== 'mod') url[name] = URL.createObjectURL(blob);
  // Rewrite the import specifier inside the module to the child's own blob URL for its dependency.
  url.mod = URL.createObjectURL(new Blob([(await files.mod.text()).replace('__DEP__', url.dep)], { type: 'text/javascript' }));
  const load = (el) => new Promise((resolve) => { el.onload = () => resolve('loaded'); el.onerror = () => resolve('FAILED'); document.head.append(el); });
  const img = new Image(); R.img = await new Promise((resolve) => { img.onload = () => resolve('loaded ' + img.naturalWidth + 'px'); img.onerror = () => resolve('FAILED'); img.src = url.img; });
  const link = document.createElement('link'); link.rel = 'stylesheet'; link.href = url.css; R.cssLoad = await load(link); R.css = getComputedStyle(document.getElementById('styled')).color;
  const s = document.createElement('script'); s.src = url.classic; R.classicLoad = await load(s); R.classic = window.__classic || 'FAILED';
  const m = document.createElement('script'); m.type = 'module'; m.src = url.mod; R.moduleLoad = await load(m); R.module = window.__module || 'FAILED';
  try { R.fetch = JSON.stringify(await (await fetch(url.json)).json()); } catch (e) { R.fetch = 'FAILED ' + e.message; }
  try { R.dynamicImport = (await import(url.lazy)).default; } catch (e) { R.dynamicImport = 'FAILED ' + e.message; }
  R.worker = await new Promise((resolve) => { try { const w = new Worker(url.worker); w.onmessage = (e) => resolve(e.data); w.onerror = () => resolve('FAILED error event'); setTimeout(() => resolve('FAILED timeout'), 1500); } catch (e) { resolve('FAILED ' + e.message); } });
  const font = new FontFace('vfs', 'url(' + url.img + ')'); R.fontUrlRequestAllowed = await font.load().then(() => 'loaded', (e) => 'request made, decode failed as expected: ' + e.name);
  R.ms = Math.round(performance.now() - t0);
  parent.postMessage({ a1: R }, '*');
});
parent.postMessage({ a1ready: true }, '*');`;
const runner = `<!doctype html><html><head><meta http-equiv="Content-Security-Policy" content="${csp}"></head><body><script>
(() => {
  const blob = (text, type) => new Blob([text], { type });
  const files = {
    img: new Blob([Uint8Array.from(atob('${png}'), (c) => c.charCodeAt(0))], { type: 'image/png' }),
    css: blob('#styled{color:rgb(1,2,3)}', 'text/css'), classic: blob('window.__classic = "classic script ran";', 'text/javascript'),
    json: blob('{"answer":42}', 'application/json'), dep: blob('export const dep = "dependency module";', 'text/javascript'),
    mod: blob('import { dep } from "__DEP__"; window.__module = "module ran with " + dep;', 'text/javascript'),
    lazy: blob('export default "lazy chunk";', 'text/javascript'), worker: blob('postMessage("worker ran")', 'text/javascript'),
  };
  const child = '<!doctype html><html><head></head><body><p id="styled">x</p><script>' + ${JSON.stringify(childScript)} + '</scr' + 'ipt></body></html>';
  const frame = document.createElement('iframe'); frame.setAttribute('sandbox', 'allow-scripts');
  addEventListener('message', (event) => {
    if (event.source !== frame.contentWindow || !event.data) return;
    if (event.data.a1ready) frame.contentWindow.postMessage({ files, parentUrls: { img: URL.createObjectURL(files.img), classic: URL.createObjectURL(files.classic), json: URL.createObjectURL(files.json) } }, '*');
    if (event.data.a1) parent.postMessage({ a1: event.data.a1 }, '*');
  });
  frame.src = URL.createObjectURL(blob(child, 'text/html')); document.body.append(frame);
})();
</script></body></html>`;
const host = `<!doctype html><html><body><script>
addEventListener('message', (event) => { if (event.data && event.data.a1) window.__r = event.data.a1; });
const f = document.createElement('iframe'); f.setAttribute('sandbox', 'allow-scripts'); f.src = '/__a1/runner2.html'; document.body.append(f);
</script></body></html>`;
(async () => {
  const site = await L.startSite(4740, { '/__a1/runner2.html': { type: 'text/html', body: runner }, '/__a1/vfs-host2.html': { type: 'text/html', body: host } });
  const out = {};
  try {
    for (const channel of ['firefox']) {
      const browser = await FF.launch();
      const page = await browser.newPage(); const consoleErrors = []; page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(m.text().slice(0, 180)); });
      await page.goto('http://127.0.0.1:4740/__a1/vfs-host2.html');
      const r = await L.until(() => page.evaluate(() => window.__r), 'result', 15000).catch((e) => ({ error: e.message }));
      out['Firefox ' + browser.version()] = { ...r, consoleErrors: consoleErrors.slice(0, 6) };
      await browser.close();
    }
  } finally { await site.close(); fs.writeFileSync(path.join(__dirname, 'logs', 'f8-blob.json'), JSON.stringify(out, null, 2)); }
  console.log(JSON.stringify(out, null, 1));
})().catch((e) => { console.error(e); process.exit(1); });
