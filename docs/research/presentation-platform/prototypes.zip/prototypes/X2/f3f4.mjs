// F3: B7 inline-deck (copy) on n2-reveal-chat-nonet, played on the site in Firefox. F4: B2 converted Slidev build dist-history-abs.zip.
import { createRequire } from 'node:module'; import { readFileSync, writeFileSync } from 'node:fs';
import { inlineDeck } from './inline-deck.copy.mjs';
const require = createRequire(import.meta.url);
const FF = require('./ff.cjs'); const L = require('./lib.cjs');
const { unzipSync, zipSync, strToU8 } = createRequire('/home/user/md.qft.org/package.json')('fflate');
const S = 'SCRATCH/research/';
function loadZip(p) { let files = new Map(Object.entries(unzipSync(new Uint8Array(readFileSync(p)))).filter(([k]) => !k.endsWith('/')).map(([k, v]) => [k, Buffer.from(v)]));
  const keys = [...files.keys()]; const top = keys[0].split('/')[0];
  if (keys.length > 1 && keys.every((k) => k.startsWith(top + '/'))) files = new Map(keys.map((k) => [k.slice(top.length + 1), files.get(k)]));
  const entry = [...files.keys()].filter((k) => /(^|\/)index\.html?$/i.test(k)).sort((a, b) => a.length - b.length)[0]; return { files, entry }; }
const { files, entry } = loadZip(S + 'corpus/naive/n2-reveal-chat-nonet.zip');
const { html, report } = inlineDeck(files.get(entry).toString('utf8'), files, { historyShim: true });
const n2zip = Buffer.from(zipSync({ 'qft-presentation.json': strToU8(JSON.stringify({ format: 'qft-presentation', version: 1, engine: 'slidev', title: 'n2', entry: 'presentation.html' })), 'presentation.html': strToU8(html) }));
writeFileSync('out-n2.B7.zip', n2zip);
const out = { adapter: { unresolved: report.unresolved.length, coerced: [...new Set(report.coerced.map((c) => `${c.lib} ${c.requested}->${c.served}`))], bytes: report.bytes } };
const site = await L.startSite(4740); const b = await FF.launch(); out.version = b.version();
async function open(buf, name) {
  const ctx = await b.newContext({ viewport: { width: 1360, height: 860 } }); const page = await ctx.newPage(); const errs = [];
  page.on('console', (m) => { if (m.type() === 'error') errs.push(m.text().slice(0, 200)); });
  await ctx.route('**/*', (r) => { const u = r.request().url(); if (u.startsWith('http://127.0.0.1:4740') || u.startsWith('blob:') || u.startsWith('data:')) return r.continue(); errs.push('BLOCKED-EXTERNAL ' + u.slice(0, 100)); return r.abort(); });
  await L.openWorkspace(page, 'http://127.0.0.1:4740/'); await L.openFile(page, buf, name);
  await page.locator('[data-pres-start-button]').waitFor({ state: 'visible', timeout: 15000 });
  const t0 = Date.now(); await page.locator('[data-pres-start-button]').click();
  let readyMs = null; try { await L.until(async () => (await L.dialogState(page)).status === 'Playing locally', 'ready', 25000); readyMs = Date.now() - t0; } catch {}
  await L.sleep(1500); const s = await L.dialogState(page);
  return { ctx, page, errs, frame: L.appFrame(page), r: { readyMs, status: s.status, notice: s.notice } };
}
try {
  // F3
  let x = await open(n2zip, 'n2.zip'); out.F3 = x.r;
  if (x.frame) { const f = x.frame;
    out.F3.inside = await f.evaluate(() => ({ reveal: window.Reveal?.VERSION, total: Reveal?.getTotalSlides?.(), katex: document.querySelectorAll('.katex').length, ranges: document.querySelectorAll('input[type=range]').length }));
    const idx = () => f.evaluate(() => JSON.stringify(Reveal.getIndices()));
    const i0 = await idx(); await x.page.keyboard.press('ArrowRight'); await L.sleep(500); const i1 = await idx(); await x.page.keyboard.press('ArrowRight'); await L.sleep(500);
    out.F3.nav = `${i0} -> ${i1} -> ${await idx()} (no click)`;
    out.F3.slider = await f.evaluate(async () => { const el = document.querySelector('.slides section input[type=range]'); if (!el) return 'no slider'; const sec = el.closest('section'); const i = Reveal.getIndices(sec); Reveal.slide(i.h, i.v || 0); await new Promise((r) => setTimeout(r, 800));
      const t = () => sec.innerText.replace(/\s+/g, ' '); const a = t(); const min = +el.min || 0, max = +el.max || 100; el.value = String(+el.value === max ? min : max); el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); await new Promise((r) => setTimeout(r, 500)); const bb = t();
      const A = a.split(' '), B = bb.split(' '); const d = []; for (let k = 0; k < Math.max(A.length, B.length) && d.length < 6; k++) if (A[k] !== B[k]) d.push((A[k] || '') + '=>' + (B[k] || '')); return { changed: a !== bb, diff: d.join(' ; ') }; });
    out.F3.statusAfter = (await L.dialogState(x.page)).status; }
  out.F3.console = x.errs.slice(0, 5); await x.ctx.close();
  // F4
  x = await open(readFileSync(S + 'proto/B2/packer/out-conv/dist-history-abs.zip'), 'conv.zip'); out.F4 = x.r;
  if (x.frame) { const f = x.frame; const snap = () => f.evaluate(() => document.body.innerText.replace(/\s+/g, ' ').slice(0, 60)).catch((e) => 'err');
    const s0 = await snap(); await x.page.keyboard.press('ArrowRight'); await L.sleep(600); const s1 = await snap();
    out.F4.navNoClick = [s0, s1];
    await f.locator('body').press('ArrowRight').catch(() => {}); await L.sleep(450); await f.locator('body').press('ArrowRight').catch(() => {}); await L.sleep(450); await f.locator('body').press('ArrowRight').catch(() => {}); await L.sleep(600);
    out.F4.later = await snap();
    out.F4.interaction = await f.evaluate(async () => { const btn = [...document.querySelectorAll('button')].find((b) => /Opposite/.test(b.textContent)); if (!btn) return 'no component button found (buttons: ' + [...document.querySelectorAll('button')].map((b) => b.textContent.trim().slice(0, 15)).slice(0, 8).join('|') + ')';
      const read = () => document.querySelector('.intensity-value strong')?.textContent; const before = read(); btn.click(); await new Promise((r) => setTimeout(r, 200)); return `intensity ${before} -> ${read()}`; }).catch((e) => 'eval error ' + String(e).slice(0, 100));
    out.F4.statusAfter = (await L.dialogState(x.page)).status; }
  out.F4.console = x.errs.slice(0, 5); await x.ctx.close();
} catch (e) { out.fatal = String(e.message).split('\n')[0]; }
finally { await b.close(); await site.close(); writeFileSync('logs/f3f4.json', JSON.stringify(out, null, 2)); }
console.log(JSON.stringify(out, null, 1));
