// F1: shipped Slidev example in Firefox via the deep link; keyboard before/after click; repair.
const fs=require('node:fs'),path=require('node:path');
const FF=require('./ff.cjs'); const L=require('./lib.cjs');
const fi=()=>({hasFocus:document.hasFocus(),active:document.activeElement?document.activeElement.tagName.toLowerCase():null});
(async()=>{
 const site=await L.startSite(4740); const out={}; let browser;
 try{
  browser=await FF.launch(); out.version=browser.version();
  const page=await (await browser.newContext({viewport:{width:1300,height:900}})).newPage();
  const cons=[]; page.on('console',m=>cons.push(m.type()+': '+m.text().slice(0,160))); page.on('pageerror',e=>cons.push('pageerror '+String(e).slice(0,160)));
  await page.goto('http://127.0.0.1:4740/?presentation=slidev-example',{waitUntil:'load'});
  await page.locator('[data-pres-start-button]').waitFor({state:'visible',timeout:30000});
  out.beforeStart=await L.dialogState(page);
  const t0=Date.now();
  await page.locator('[data-pres-start-button]').click();
  try{ await L.until(async()=>(await L.dialogState(page)).status==='Playing locally','ready',25000); out.readyMs=Date.now()-t0; }catch(e){ out.readyError=e.message; }
  out.afterStartState=await L.dialogState(page);
  await L.sleep(1000);
  const frame=L.appFrame(page); const runner=L.runnerFrame(page);
  out.frames=page.frames().map(f=>f.url().slice(0,60));
  if(frame){
   const snap=async()=>{try{return await frame.evaluate(()=>document.body.innerText.replace(/\s+/g,' ').slice(0,70))}catch(e){return 'err '+e.message}};
   const slideNo=async()=>{try{return await frame.evaluate(()=>{const a=window.__slidev?.nav; return a? (a.currentPage?.value ?? a.currentPage ?? null) : null})}catch(e){return 'err'}};
   out.afterStart={top:await page.evaluate(fi),runner:runner?await runner.evaluate(fi).catch(e=>'err '+e.message):null,deck:await frame.evaluate(fi),page:await slideNo(),snap:await snap()};
   await page.keyboard.press('ArrowRight'); await L.sleep(500); await page.keyboard.press('ArrowRight'); await L.sleep(600);
   out.afterArrowsNoClick={deck:await frame.evaluate(fi),page:await slideNo(),snap:await snap()};
   // click inside the deck then arrow
   const box=await page.locator('[data-pres-host] iframe').boundingBox();
   await page.mouse.click(box.x+box.width*0.5,box.y+box.height*0.5); await L.sleep(400);
   const beforeClickArrow={page:await slideNo(),snap:await snap()};
   await page.keyboard.press('ArrowRight'); await L.sleep(700);
   out.afterClick={before:beforeClickArrow,after:{deck:await frame.evaluate(fi),page:await slideNo(),snap:await snap()}};
  }
  await page.screenshot({path:path.join(__dirname,'shots','f1.png')});
  out.console=cons.filter(m=>!/^debug/.test(m)).slice(0,12);
 } catch(e){ out.fatal=String(e.message).split('\n')[0]; }
 finally { if(browser)await browser.close(); await site.close(); fs.writeFileSync(path.join(__dirname,'logs','f1.json'),JSON.stringify(out,null,2)); }
 console.log(JSON.stringify(out,null,1));
})();
