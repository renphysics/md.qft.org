// F7: runaway deck (infinite loop 1.2 s after load) in Firefox; host rAF and Stop click. Variants: default prefs, fission on, fission off.
const fs=require('node:fs'),path=require('node:path');
const FF=require('./ff.cjs'); const L=require('./lib.cjs');
const html=`<!doctype html><html lang="en"><head></head><body><h1>freeze probe</h1><script>window.addEventListener('load',()=>setTimeout(()=>{window.__looping=true;for(;;){}},1200));</script></body></html>`;
const withTimeout=(p,ms)=>Promise.race([p.then(v=>({ok:true,value:v}),e=>({ok:false,value:'error '+String(e.message).split('\n')[0]})),new Promise(r=>setTimeout(()=>r({ok:false,value:`no answer within ${ms} ms`}),ms))]);
async function scenario(label,prefs){
 const out={label,prefs};
 const browser=await FF.launch(prefs?{firefoxUserPrefs:prefs}:{});
 try{
  const page=await (await browser.newContext({viewport:{width:1300,height:900}})).newPage();
  await L.openWorkspace(page,'http://127.0.0.1:4740/');
  await L.openFile(page,L.makePackage(html),'freeze.zip');
  await page.locator('[data-pres-start-button]').waitFor({state:'visible',timeout:15000});
  await page.locator('[data-pres-start-button]').click();
  await L.until(async()=>(await L.dialogState(page)).status==='Playing locally','ready',10000);
  out.fissionInfo=await page.evaluate(()=>({ua:navigator.userAgent}));
  await L.sleep(2500);
  const ping=await withTimeout(page.evaluate(()=>1+1),4000); out.hostEvaluate=ping.ok?'answered '+ping.value:ping.value;
  const raf=await withTimeout(page.evaluate(()=>new Promise(r=>{const s=performance.now();requestAnimationFrame(()=>r(Math.round(performance.now()-s)))})),4000);
  out.hostRaf=raf.ok?raf.value+' ms':raf.value;
  // 10 rAF ticks: measure average interval
  const raf10=await withTimeout(page.evaluate(()=>new Promise(r=>{let n=0;const s=performance.now();const f=()=>{if(++n===10)r(Math.round((performance.now()-s)/10));else requestAnimationFrame(f)};requestAnimationFrame(f)})),6000);
  out.hostRaf10avg=raf10.ok?raf10.value+' ms/frame':raf10.value;
  const s=Date.now(); const c=await withTimeout(page.locator('[data-pres-stop]').click({timeout:6000}).then(()=>'clicked'),7000);
  out.stopClick=c.ok?`clicked after ${Date.now()-s} ms`:c.value;
  await L.sleep(500);
  const st=await withTimeout(L.dialogState(page),4000); out.afterStop=st.ok?{status:st.value.status,frames:st.value.frames}:st.value;
  const r2=await withTimeout(page.evaluate(()=>new Promise(r=>{const s=performance.now();requestAnimationFrame(()=>r(Math.round(performance.now()-s)))})),4000);
  out.rafAfterStop=r2.ok?r2.value+' ms':r2.value;
 }catch(e){out.error=String(e.message).split('\n')[0];}
 finally{await Promise.race([browser.close(),L.sleep(6000)]);}
 console.log(JSON.stringify(out));
 return out;
}
(async()=>{
 const site=await L.startSite(4740); const res=[];
 try{
  res.push(await scenario('release-like: webContentIsolationStrategy=1, fission.autostart=true',{'fission.webContentIsolationStrategy':1,'fission.autostart':true}));
 } finally { await site.close(); fs.writeFileSync(path.join(__dirname,'logs','f7-isolated.json'),JSON.stringify(res,null,2)); }
})();
