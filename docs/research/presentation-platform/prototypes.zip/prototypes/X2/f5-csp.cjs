// F5: Worker-vs-meta-CSP rule in Firefox (copy of B2 csptest served from memory).
const fs=require('node:fs'),path=require('node:path');
const FF=require('./ff.cjs'); const L=require('./lib.cjs');
const C='SCRATCH/research/proto/B2/csptest';
const extra={'/csptest/index.html':{type:'text/html',body:fs.readFileSync(C+'/index.html')},'/csptest/main.js':{type:'text/javascript',body:fs.readFileSync(C+'/main.js')},'/csptest/probe-worker.js':{type:'text/javascript',body:fs.readFileSync(C+'/probe-worker.js')}};
(async()=>{
 const site=await L.startSite(4744,extra); const out={}; const b=await FF.launch(); out.version=b.version();
 try{
  const page=await b.newPage(); const cons=[]; page.on('console',m=>{if(/error|warn/.test(m.type()))cons.push(m.text().slice(0,200))});
  await page.goto('http://127.0.0.1:4744/csptest/index.html');
  out.r=await L.until(()=>page.evaluate(()=>window.__r&&window.__r.done&&window.__r),'done',20000).catch(e=>({err:e.message}));
  out.console=[...new Set(cons)].slice(0,8);
  // Same probe on the real editor page (site CSP) : main thread + same-origin worker is not available there, so only main thread
  const p2=await b.newPage(); await p2.goto('http://127.0.0.1:4744/',{waitUntil:'load'});
  out.sitePageCsp=await p2.evaluate(()=>[...document.querySelectorAll('meta[http-equiv]')].map(m=>m.content));
  out.siteMain=await p2.evaluate(()=>new Promise(res=>setTimeout(async()=>{const r={};try{await WebAssembly.compile(new Uint8Array([0,97,115,109,1,0,0,0]));r.wasm='allowed'}catch(e){r.wasm=e.name+': '+e.message.slice(0,120)}try{r.fn='allowed '+new Function('return 1')()}catch(e){r.fn=e.name}
   try{const src='const o={};(async()=>{try{await WebAssembly.compile(new Uint8Array([0,97,115,109,1,0,0,0]));o.wasm="allowed"}catch(e){o.wasm=e.name}try{o.fn="allowed "+new Function("return 1")()}catch(e){o.fn=e.name}postMessage(o)})()';const w=new Worker(URL.createObjectURL(new Blob([src],{type:'text/javascript'})));r.blobWorker=await new Promise(rs=>{w.onmessage=e=>rs(e.data);w.onerror=e=>rs('error '+e.message);setTimeout(()=>rs('timeout'),3000)})}catch(e){r.blobWorker=e.name+' '+e.message}
   res(r)},50)));
 } finally { await b.close(); await site.close(); fs.writeFileSync(path.join(__dirname,'logs','f5.json'),JSON.stringify(out,null,2)); }
 console.log(JSON.stringify(out,null,1));
})();
