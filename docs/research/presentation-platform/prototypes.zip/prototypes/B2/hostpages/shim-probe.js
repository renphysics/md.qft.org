// Injected (inline) into a sandboxed deck document before any module runs.
// 1. Records what origin-bound APIs do in an opaque origin (window.__probe).
// 2. Installs in-memory localStorage/sessionStorage so Slidev can boot.
(() => {
  const probe = window.__probe = {};
  const attempt = (name, fn) => { try { probe[name] = fn(); } catch (e) { probe[name] = e.name + ': ' + e.message; } };
  attempt('localStorage', () => { window.localStorage.getItem('x'); return 'ok'; });
  attempt('sessionStorage', () => { window.sessionStorage.getItem('x'); return 'ok'; });
  attempt('cookie', () => 'ok: ' + JSON.stringify(document.cookie));
  attempt('BroadcastChannel', () => { const c = new BroadcastChannel('x'); c.postMessage(1); c.close(); return 'ok'; });
  attempt('indexedDB', () => { const r = indexedDB.open('x'); r.onerror = () => { probe.indexedDB = 'open error: ' + r.error?.name + ': ' + r.error?.message; }; r.onsuccess = () => { probe.indexedDB = 'open ok'; }; return 'pending'; });
  attempt('history.replaceState(same url + #hash)', () => { history.replaceState(null, '', '#/probe'); const h = location.href; history.replaceState(null, '', '#'); return 'ok -> ' + h; });
  attempt('history.replaceState(/2)', () => { history.replaceState(null, '', '/2'); return 'ok -> ' + location.href; });
  attempt('caches', () => typeof caches);
  attempt('serviceWorker', () => typeof navigator.serviceWorker + (navigator.serviceWorker ? '' : ''));
  attempt('Worker(blob)', () => { const w = new Worker(URL.createObjectURL(new Blob(['postMessage(1)'], { type: 'text/javascript' }))); w.terminate(); return 'ok'; });
  attempt('wakeLock', () => typeof navigator.wakeLock);
  attempt('fullscreenEnabled', () => String(document.fullscreenEnabled));
  attempt('origin', () => window.origin + ' | baseURI ' + document.baseURI + ' | location ' + location.href);

  if (!window.__noShim) {
    const memory = () => {
      const m = new Map();
      return {
        get length() { return m.size; }, key: i => [...m.keys()][i] ?? null,
        getItem: k => m.get(String(k)) ?? null, setItem: (k, v) => { m.set(String(k), String(v)); },
        removeItem: k => { m.delete(String(k)); }, clear: () => m.clear(),
      };
    };
    for (const name of ['localStorage', 'sessionStorage']) {
      try { window[name].getItem('x'); } catch { Object.defineProperty(window, name, { configurable: true, value: memory() }); }
    }
  }
})();
