// Analyse the ES module graph of a Vite/Slidev dist: static vs dynamic edges, cycles, top-level await.
import { init, parse } from 'es-module-lexer';
import { readFile, readdir } from 'node:fs/promises';
import { join, relative, resolve, dirname, sep } from 'node:path';
await init;
const dist = resolve(process.argv[2]);
async function walk(d) { const o = []; for (const e of await readdir(d, { withFileTypes: true })) { const p = join(d, e.name); if (e.isDirectory()) o.push(...await walk(p)); else o.push(p); } return o; }
const files = (await walk(dist)).filter(f => /\.m?js$/.test(f));
const rel = p => relative(dist, p).split(sep).join('/');
const graph = new Map(); let dyn = 0, stat = 0, external = [], nonLiteralDyn = 0, importMeta = 0;
for (const f of files) {
  const code = await readFile(f, 'utf8');
  const [imports, , , hasModuleSyntax] = parse(code);
  const edges = { static: [], dynamic: [] };
  for (const i of imports) {
    if (i.d === -2) { importMeta++; continue; }
    if (i.n == null) { nonLiteralDyn++; continue; }
    if (!/^\.{0,2}\//.test(i.n)) { external.push(i.n); continue; }
    const target = rel(resolve(dirname(f), i.n));
    if (i.d === -1) { edges.static.push(target); stat++; } else { edges.dynamic.push(target); dyn++; }
  }
  graph.set(rel(f), edges);
}
// cycle detection on static edges
const state = new Map(); const cycles = [];
function dfs(n, stack) { state.set(n, 1); stack.push(n); for (const m of graph.get(n)?.static ?? []) { if (state.get(m) === 1) cycles.push(stack.slice(stack.indexOf(m)).concat(m).join(' -> ')); else if (!state.get(m)) dfs(m, stack); } stack.pop(); state.set(n, 2); }
for (const n of graph.keys()) if (!state.get(n)) dfs(n, []);
console.log(JSON.stringify({ dist: process.argv[2].split('/').pop(), jsFiles: files.length, staticEdges: stat, dynamicEdges: dyn, nonLiteralDynamicImports: nonLiteralDyn, importMetaUses: importMeta, bareOrExternalSpecifiers: [...new Set(external)], staticCycles: cycles }, null, 1));
