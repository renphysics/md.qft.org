#!/usr/bin/env node
// Prototype: make an ORDINARY `slidev build` output (default Vite profile, any routerMode,
// any base) playable in the md.qft.org opaque-origin sandbox, without rebuilding it.
// Pre-processes a copy of dist/ and then runs the (relaxed) repo packer.
//   node convert-dist.mjs <dist> <out.zip> [--no-router-patch] [--no-mapdeps-patch] [--no-css]
import { cp, rm, readFile, writeFile, readdir, mkdtemp } from 'node:fs/promises';
import { join, relative, resolve, sep } from 'node:path';
import { tmpdir } from 'node:os';
import { packageSlidev } from './pack-relaxed.mjs';

const [dist, out, ...flags] = process.argv.slice(2);
const opt = name => !flags.includes('--no-' + name);
const work = await mkdtemp(join(tmpdir(), 'b2-convert-'));
await cp(resolve(dist), work, { recursive: true });
const report = { dist, notes: [] };

async function walk(dir) {
  const result = [];
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    const path = join(dir, entry.name);
    if (entry.isDirectory()) result.push(...await walk(path)); else result.push(path);
  }
  return result;
}
const files = await walk(work);
const rel = path => relative(work, path).split(sep).join('/');

// --- detect -----------------------------------------------------------------
let html = await readFile(join(work, 'index.html'), 'utf8');
report.slidevVersion = html.match(/<meta property="slidev:version" content="([^"]+)"/)?.[1] ?? null;
const entrySrc = html.match(/<script type="module"[^>]* src="([^"]+)"/)?.[1] ?? '';
report.base = entrySrc.replace(/assets\/[^/]+$/, '') || '(unknown)';

// --- 1. Vite preload helper: no runtime <link> creation ------------------------
const mapDepsRe = /__vite__mapDeps=\(i,m=__vite__mapDeps,d=\(m\.f\|\|\(m\.f=\[[^\]]*\]\)\)\)=>i\.map\(i=>d\[i\]\)/g;
// --- 2. router: history/hash -> in-memory history -------------------------------
const routerRe = /history:([\w$]+)\(([`'"])([^`'"]*)\2\),routes:/g;
const memoryHistory = `window.__qftMemoryHistory=function(base){var q=[["",{}]],p=0,ls=[];function set(l,s){p++;if(p!==q.length)q.splice(p);q.push([l,s||{}])}function fire(to,from,i){for(var k=0;k<ls.length;k++)ls[k](to,from,i)}var h={location:"",state:{},base:base||"",createHref:function(l){return"#"+l},replace:function(to,st){q.splice(p--,1);set(to,st)},push:function(to,st){set(to,st)},listen:function(cb){ls.push(cb);return function(){var i=ls.indexOf(cb);if(i>-1)ls.splice(i,1)}},destroy:function(){ls=[];q=[["",{}]];p=0},go:function(d,should){if(should===void 0)should=true;var from=this.location,dir=d<0?"back":"forward";p=Math.max(0,Math.min(p+d,q.length-1));if(should)fire(this.location,from,{direction:dir,delta:d,type:"pop"})}};Object.defineProperty(h,"location",{enumerable:true,get:function(){return q[p][0]}});Object.defineProperty(h,"state",{enumerable:true,get:function(){return q[p][1]}});return h};`;

let routerPatched = 0, mapDepsPatched = 0;
for (const file of files.filter(f => /\.m?js$/.test(f))) {
  let code = await readFile(file, 'utf8');
  const before = code;
  if (opt('mapdeps-patch')) code = code.replace(mapDepsRe, () => { mapDepsPatched++; return '__vite__mapDeps=()=>[]'; });
  if (opt('router-patch')) code = code.replace(routerRe, (_, fn, quote, base) => { routerPatched++; report.routerCall = `${fn}(${quote}${base}${quote})`; return `history:window.__qftMemoryHistory(${quote}${base}${quote}),routes:`; });
  if (code !== before) await writeFile(file, code);
}
report.mapDepsPatched = mapDepsPatched; report.routerPatched = routerPatched;

// --- 2b. absolute non-root base (e.g. /sub/deck/): strip the prefix from CSS url() and JS/HTML strings
if (report.base.startsWith('/') && report.base !== '/') {
  let rewritten = 0;
  for (const file of files.filter(f => /\.(?:css|m?js)$/.test(f))) {
    const text = await readFile(file, 'utf8');
    if (!text.includes(report.base)) continue;
    await writeFile(file, text.replaceAll(report.base + 'assets/', '/assets/')); rewritten++;
  }
  report.baseRewrittenFiles = rewritten;
}
// --- 2c. URL-addressed assets inside JS -> data: URIs -------------------------------
if (opt('assets')) {
  const mime = { '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.webp': 'image/webp', '.svg': 'image/svg+xml', '.avif': 'image/avif', '.ico': 'image/x-icon', '.mp4': 'video/mp4', '.webm': 'video/webm', '.mp3': 'audio/mpeg', '.woff2': 'font/woff2', '.woff': 'font/woff', '.ttf': 'font/ttf' };
  const assets = new Map();
  for (const file of files) {
    const type = mime[file.slice(file.lastIndexOf('.')).toLowerCase()];
    if (type && !/\.(?:woff2?|ttf)$/.test(file)) assets.set(rel(file), `data:${type};base64,${(await readFile(file)).toString('base64')}`);
  }
  let viaNewUrl = 0, viaLiteral = 0;
  const prefix = report.base.startsWith('/') ? '/' : null; // 2b already normalised a sub-path base to "/"
  for (const file of files.filter(f => /\.m?js$/.test(f))) {
    let code = await readFile(file, 'utf8');
    const before = code;
    const dir = rel(file).split('/').slice(0, -1);
    code = code.replace(/new URL\(([`'"])([^`'"]+)\1,import\.meta\.url\)(\.href)?/g, (all, q, target, href) => {
      const parts = [...dir];
      for (const part of target.split('/')) { if (part === '..') parts.pop(); else if (part !== '.') parts.push(part); }
      const data = assets.get(parts.join('/'));
      if (!data) return all;
      viaNewUrl++;
      return href ? JSON.stringify(data) : `new URL(${JSON.stringify(data)})`;
    });
    if (prefix) for (const [path, data] of assets) {
      for (const q of ['`', '"', "'"]) {
        const literal = q + prefix + path + q;
        if (code.includes(literal)) { code = code.replaceAll(literal, JSON.stringify(data)); viaLiteral++; }
      }
    }
    if (code !== before) await writeFile(file, code);
  }
  report.assetsInlined = { candidates: assets.size, viaNewUrl, viaLiteral };
}
// --- 3. link every stylesheet up-front (the packer inlines them) -----------------
if (opt('css')) {
  const linked = new Set([...html.matchAll(/<link rel="stylesheet"[^>]* href="([^"]+)"/g)].map(m => m[1].replace(/^(?:\.\/|\/)/, '').replace(new RegExp('^' + report.base.replace(/^\/|^\.\//, '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&')), '')));
  const extra = files.filter(f => f.endsWith('.css')).map(rel).filter(p => !linked.has(p));
  report.extraCss = extra.length;
  html = html.replace('</head>', extra.map(p => `<link rel="stylesheet" href="./${p}">`).join('') + '</head>');
}
// make index.html references relative so the packer resolves them inside the work dir
if (report.base.startsWith('/') && report.base !== '/') html = html.replaceAll(`"${report.base}`, '"./');
if (opt('router-patch')) html = html.replace('<head>', `<head><script>${memoryHistory}</script>`);
if (opt('wakelock')) html = html.replace('<head>', '<head><script>try{delete Navigator.prototype.wakeLock}catch(e){}</script>');
await writeFile(join(work, 'index.html'), html);

// --- 4. bundle + inline with the repo packer --------------------------------------
try {
  const result = await packageSlidev({ dist: work, out, title: 'converted ' + dist.split('/').pop() });
  Object.assign(report, { ok: true, zipBytes: result.bytes, htmlBytes: result.htmlBytes });
} catch (error) { report.ok = false; report.error = error.message; }
await rm(work, { recursive: true, force: true });
console.log(JSON.stringify(report));
