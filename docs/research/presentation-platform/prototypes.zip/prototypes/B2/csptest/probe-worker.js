const out = {};
const wasmBytes = new Uint8Array([0,97,115,109,1,0,0,0]);
(async () => {
  try { await WebAssembly.compile(wasmBytes); out.wasm = 'allowed'; } catch (e) { out.wasm = e.name + ': ' + e.message.slice(0, 140); }
  try { out.newFunction = 'allowed -> ' + new Function('return 6*7')(); } catch (e) { out.newFunction = e.name + ': ' + e.message.slice(0, 140); }
  try { const r = await fetch('probe-worker.js'); out.fetchSelf = 'ok ' + r.status; } catch (e) { out.fetchSelf = e.name + ': ' + e.message.slice(0, 100); }
  try { const u = URL.createObjectURL(new Blob(['export default 42'], { type: 'text/javascript' })); const m = await import(u); out.importBlobModule = 'allowed -> ' + m.default; } catch (e) { out.importBlobModule = e.name + ': ' + e.message.slice(0, 140); }
  postMessage(out);
})();
