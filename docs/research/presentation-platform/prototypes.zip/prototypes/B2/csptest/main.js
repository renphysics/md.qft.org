window.__r = { done: false };
const wasmBytes = new Uint8Array([0,97,115,109,1,0,0,0]);
(async () => {
  const r = window.__r;
  try { await WebAssembly.compile(wasmBytes); r.mainWasm = 'allowed'; } catch (e) { r.mainWasm = e.name + ': ' + e.message.slice(0, 160); }
  try { r.mainNewFunction = 'allowed -> ' + new Function('return 6*7')(); } catch (e) { r.mainNewFunction = e.name + ': ' + e.message.slice(0, 160); }
  try { const u = URL.createObjectURL(new Blob(['export default 42'], { type: 'text/javascript' })); const m = await import(u); r.mainImportBlobModule = 'allowed -> ' + m.default; } catch (e) { r.mainImportBlobModule = e.name + ': ' + e.message.slice(0, 160); }
  const run = (w) => new Promise(res => { w.onmessage = e => res(e.data); w.onerror = e => res('worker error: ' + (e.message || 'load failed')); setTimeout(() => res('timeout'), 4000); });
  try { r.workerSelfUrl = await run(new Worker('probe-worker.js')); } catch (e) { r.workerSelfUrl = e.name + ': ' + e.message; }
  try { r.workerSelfUrlModule = await run(new Worker('probe-worker.js', { type: 'module' })); } catch (e) { r.workerSelfUrlModule = e.name + ': ' + e.message; }
  try { const src = await (await fetch('probe-worker.js')).text(); r.workerBlobUrl = await run(new Worker(URL.createObjectURL(new Blob([src.replace("fetch('probe-worker.js')", "fetch(location.origin==='null'?'x':'" + location.origin + "/probe-worker.js')")], { type: 'text/javascript' })))); } catch (e) { r.workerBlobUrl = e.name + ': ' + e.message; }
  r.done = true;
})();
