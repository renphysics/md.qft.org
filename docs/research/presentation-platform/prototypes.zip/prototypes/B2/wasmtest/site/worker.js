// Runs in a same-origin module Worker: the page's meta CSP does not apply here, so WebAssembly is allowed.
import * as esbuild from './esbuild/browser.min.js';
import { init as lexerInit, parse as parseImports } from './es-module-lexer.js';

const decoder = new TextDecoder();
const mime = { '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.webp': 'image/webp', '.svg': 'image/svg+xml', '.avif': 'image/avif', '.ico': 'image/x-icon', '.woff2': 'font/woff2' };
const ext = p => p.slice(p.lastIndexOf('.')).toLowerCase();
const dirname = p => p.includes('/') ? p.slice(0, p.lastIndexOf('/')) : '';
const join = (base, rel) => { const out = base ? base.split('/') : []; for (const s of rel.split('/')) { if (s === '..') out.pop(); else if (s && s !== '.') out.push(s); } return out.join('/'); };
const b64 = bytes => { let s = ''; for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000)); return btoa(s); };
const memoryHistory = `window.__qftMemoryHistory=function(base){var q=[["",{}]],p=0,ls=[];function set(l,s){p++;if(p!==q.length)q.splice(p);q.push([l,s||{}])}function fire(to,from,i){for(var k=0;k<ls.length;k++)ls[k](to,from,i)}var h={location:"",state:{},base:base||"",createHref:function(l){return"#"+l},replace:function(to,st){q.splice(p--,1);set(to,st)},push:function(to,st){set(to,st)},listen:function(cb){ls.push(cb);return function(){var i=ls.indexOf(cb);if(i>-1)ls.splice(i,1)}},destroy:function(){ls=[];q=[["",{}]];p=0},go:function(d,should){if(should===void 0)should=true;var from=this.location,dir=d<0?"back":"forward";p=Math.max(0,Math.min(p+d,q.length-1));if(should)fire(this.location,from,{direction:dir,delta:d,type:"pop"})}};Object.defineProperty(h,"location",{enumerable:true,get:function(){return q[p][0]}});Object.defineProperty(h,"state",{enumerable:true,get:function(){return q[p][1]}});return h};try{delete Navigator.prototype.wakeLock}catch(e){}`;

let ready;
async function init() {
  const t0 = performance.now();
  ready ??= Promise.all([esbuild.initialize({ wasmURL: new URL('./esbuild/esbuild.wasm', import.meta.url).href, worker: false }), lexerInit]);
  await ready;
  return { initMs: performance.now() - t0, esbuild: esbuild.version };
}

async function convert({ files }) {
  await init();
  const t0 = performance.now();
  const report = {};
  const text = p => decoder.decode(files[p]);
  let html = text('index.html');
  report.slidevVersion = html.match(/<meta property="slidev:version" content="([^"]+)"/)?.[1] ?? null;
  const entrySrc = html.match(/<script type="module"[^>]* src="([^"]+)"/)?.[1] ?? '';
  const base = entrySrc.replace(/assets\/[^/]+$/, '');
  const entry = entrySrc.slice(base.length);
  report.base = base;
  const strip = url => url.startsWith(base) && base !== './' ? url.slice(base.length) : url.replace(/^\.\//, '');
  const assetData = p => files[p] && mime[ext(p)] ? `data:${mime[ext(p)]};base64,${b64(files[p])}` : null;

  // 1-5: textual patches on the JS chunks
  const js = {};
  let mapDeps = 0, router = 0, assetsInlined = 0;
  for (const p of Object.keys(files).filter(p => /\.m?js$/.test(p))) {
    let code = text(p);
    code = code.replace(/__vite__mapDeps=\(i,m=__vite__mapDeps,d=\(m\.f\|\|\(m\.f=\[[^\]]*\]\)\)\)=>i\.map\(i=>d\[i\]\)/g, () => { mapDeps++; return '__vite__mapDeps=()=>[]'; });
    code = code.replace(/history:([\w$]+)\(([`'"])([^`'"]*)\2\),routes:/g, (_, fn, q, b) => { router++; return `history:window.__qftMemoryHistory(${q}${b}${q}),routes:`; });
    code = code.replace(/new URL\(([`'"])([^`'"]+)\1,import\.meta\.url\)(\.href)?/g, (all, q, target, href) => { const data = assetData(join(dirname(p), target)); if (!data) return all; assetsInlined++; return href ? JSON.stringify(data) : `new URL(${JSON.stringify(data)})`; });
    if (base.startsWith('/')) for (const a of Object.keys(files)) { if (!mime[ext(a)] || ext(a) === '.woff2') continue; for (const q of ['`', '"', "'"]) { const lit = q + base + a + q; if (code.includes(lit)) { code = code.replaceAll(lit, JSON.stringify(assetData(a))); assetsInlined++; } } }
    js[p] = code;
  }
  Object.assign(report, { mapDepsPatched: mapDeps, routerPatched: router, assetsInlined, jsChunks: Object.keys(js).length });

  // 6: bundle the ES module graph into one classic script (esbuild-wasm)
  const tb = performance.now();
  const built = await esbuild.build({
    entryPoints: ['vfs:' + entry], bundle: true, write: false, format: 'iife', platform: 'browser', target: 'es2022', minify: false, logLevel: 'silent',
    define: { 'import.meta.url': '"about:blank"' },
    plugins: [{ name: 'vfs', setup(build) {
      build.onResolve({ filter: /.*/ }, args => {
        if (args.kind === 'entry-point') return { path: args.path.slice(4), namespace: 'vfs' };
        const target = args.path.startsWith('/') ? strip(args.path) : join(dirname(args.importer), args.path);
        if (!(target in js)) return { errors: [{ text: `unresolved import ${args.path} from ${args.importer}` }] };
        return { path: target, namespace: 'vfs' };
      });
      build.onLoad({ filter: /.*/, namespace: 'vfs' }, args => {
        let code = js[args.path];
        // keep `import()` results recognisable as ES modules (Vue's async components unwrap `default` that way)
        const inserts = parseImports(code)[0].filter(i => i.d >= 0).flatMap(i => [{ at: i.ss, text: '(' }, { at: i.se, text: ').then(m=>{if(m[Symbol.toStringTag]!=="Module")Object.defineProperty(m,Symbol.toStringTag,{value:"Module"});return m})' }]).sort((a, b) => b.at - a.at);
        for (const ins of inserts) code = code.slice(0, ins.at) + ins.text + code.slice(ins.at);
        return { contents: code, loader: 'js' };
      });
    } }],
  });
  report.bundleMs = performance.now() - tb;
  const bundle = built.outputFiles[0].text;
  report.bundleBytes = bundle.length;

  // 7: all stylesheets up-front, assets as data: URIs (woff2 only)
  let css = '';
  const linked = [...html.matchAll(/<link rel="stylesheet"[^>]* href="([^"]+)"/g)].map(m => m[1]).filter(h => !/^https?:/.test(h)).map(strip);
  const cssFiles = [...new Set([...linked, ...Object.keys(files).filter(p => p.endsWith('.css'))])];
  for (const p of cssFiles) css += text(p).replace(/url\(\s*(?:"([^"]*)"|'([^']*)'|([^)]*))\s*\)/g, (all, a, b, c) => { const u = (a ?? b ?? c).trim(); if (/^data:|^#/.test(u)) return all; const target = u.startsWith('/') ? strip(u) : join(dirname(p), u.split(/[?#]/)[0]); return `url("${assetData(target) ?? 'data:,'}")`; }) + '\n';
  report.cssFiles = cssFiles.length; report.cssBytes = css.length;
  report.droppedExternal = [...html.matchAll(/<(?:link|script)[^>]*(?:href|src)="(https?:[^"]+)"/g)].map(m => m[1]);
  const title = html.match(/<title>([^<]*)<\/title>/)?.[1] ?? 'Slidev';
  const out = `<!doctype html><html lang="en"><head><meta charset="utf-8"><title>${title}</title><style>${css.replace(/<\/style/gi, '<\\/style')}</style></head><body><div id="app"></div><div id="mermaid-rendering-container"></div><script>${memoryHistory}</script><script>${bundle.replace(/<\/script/gi, '<\\/script')}</script></body></html>`;
  report.totalMs = performance.now() - t0;
  return { html: out, report };
}

self.onmessage = async e => {
  const { id, type, payload } = e.data;
  try { self.postMessage({ id, result: type === 'init' ? await init() : await convert(payload) }); }
  catch (error) { self.postMessage({ id, error: String(error?.message ?? error).slice(0, 600) + (error?.errors ? ' :: ' + error.errors.slice(0, 3).map(x => x.text).join(' | ') : '') }); }
};
