import { createPresentationPlayer } from './presentation-runtime.js';
const state = window.__app = { ready: false, playerStates: [], playerErrors: [] };
const worker = new Worker('./worker.js', { type: 'module' });
let seq = 0; const pending = new Map();
worker.onmessage = e => { const p = pending.get(e.data.id); if (!p) return; pending.delete(e.data.id); e.data.error ? p.reject(new Error(e.data.error)) : p.resolve(e.data.result); };
const call = (type, payload, transfer = []) => new Promise((resolve, reject) => { const id = ++seq; pending.set(id, { resolve, reject }); worker.postMessage({ id, type, payload }, transfer); });
window.__convertAndPlay = async function (name) {
  const t0 = performance.now();
  const manifest = await (await fetch(`dists/${name}/manifest.json`)).json();
  const files = {};
  await Promise.all(manifest.map(async p => { files[p] = new Uint8Array(await (await fetch(`dists/${name}/${p}`)).arrayBuffer()); }));
  const tLoad = performance.now() - t0;
  const result = await call('convert', { files });
  state.playerStates = []; state.playerErrors = []; state.player?.destroy();
  const t1 = performance.now();
  await new Promise(resolve => {
    state.player = createPresentationPlayer(document.getElementById('host'), result.html, { title: name, sandboxUrl: './presentation-sandbox.html', onState: s => { state.playerStates.push(s); if (s === 'ready' || s === 'error') resolve(); }, onError: m => state.playerErrors.push(m) });
    state.player.start(); setTimeout(resolve, 20000);
  });
  return { loadMs: tLoad, bootMs: performance.now() - t1, htmlBytes: result.html.length, report: result.report, playerStates: [...state.playerStates], playerErrors: [...state.playerErrors] };
};
state.init = await call('init', {});
state.ready = true;
