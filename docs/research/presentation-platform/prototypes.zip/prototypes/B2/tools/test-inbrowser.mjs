// Drive the in-browser compile prototype: compile -> play in sandbox -> probe -> edit -> recompile.
// Usage: node test-inbrowser.mjs <site dir> <port> <deck> [--shot]
import { spawn } from 'node:child_process';
import { resolve } from 'node:path';
import { writeFile, mkdir } from 'node:fs/promises';
import { chromium, probe, sleep, uniq } from './deck-probe.mjs';
const [site, port, deckName = 'ordinary', ...flags] = process.argv.slice(2);
const here = import.meta.dirname;
const server = spawn(process.execPath, [resolve(here, 'static-server.mjs'), port, JSON.stringify([{ prefix: '/', dir: resolve(site), spa: false }])], { stdio: ['ignore', 'pipe', 'inherit'] });
await new Promise(r => server.stdout.once('data', r));
const browser = await chromium.launch();
const out = {};
try {
  const context = await browser.newContext({ viewport: { width: 1280, height: 720 } });
  const external = [];
  await context.route(url => !/^(?:http:\/\/localhost|blob:|data:|about:)/.test(url.href), route => { external.push(route.request().url().slice(0, 120)); return route.abort(); });
  const page = await context.newPage();
  const consoleMsgs = []; page.on('console', m => { if (['error', 'warning'].includes(m.type())) consoleMsgs.push(`[${m.type()}] ${m.text().slice(0, 400)}`); });
  const pageErrors = []; page.on('pageerror', e => pageErrors.push(String(e.message).slice(0, 300)));
  const requests = []; page.on('requestfinished', r => requests.push(r.url()));
  await page.goto(`http://localhost:${port}/index.html`, { waitUntil: 'load' });
  await page.waitForFunction(() => window.__app?.ready, null, { timeout: 30000 });
  out.versions = await page.evaluate(() => window.__app.versions);
  const deck = () => page.frames().find(f => f.url().startsWith('blob:'));
  const run = async (mutate) => page.evaluate(async ({ deckName, mutate }) => {
    const files = await window.__loadFiles(deckName);
    if (mutate) for (const [path, [from, to]] of Object.entries(mutate)) files[path] = files[path].replace(from, to);
    return window.__compileAndPlay(files);
  }, { deckName, mutate });
  const press = async key => { await deck()?.locator('body').press(key).catch(() => {}); await sleep(400); };
  const detail = () => deck()?.evaluate(() => {
    const shown = [...document.querySelectorAll('.slidev-page')].filter(p => { let e = p; while (e && e !== document.body) { if (getComputedStyle(e).display === 'none') return false; e = e.parentElement; } return true; });
    const cur = shown.at(-1);
    const vis = el => { const s = getComputedStyle(el); return s.opacity !== '0' && s.visibility !== 'hidden' && s.display !== 'none'; };
    return cur ? {
      page: (cur.className.match(/slidev-page-\d+/) || [])[0], layout: cur.querySelector('.slidev-layout')?.className,
      h1: cur.querySelector('h1')?.textContent.trim(), katex: cur.querySelectorAll('.katex').length,
      codeBlocks: cur.querySelectorAll('pre.shiki, .slidev-code').length, shikiSpans: cur.querySelectorAll('pre .line span[style], pre .line span[class]').length,
      highlightedLines: cur.querySelectorAll('pre .line.highlighted').length, dishonored: cur.querySelectorAll('pre .line.dishonored').length,
      liVisible: [...cur.querySelectorAll('li')].map(li => vis(li) && !li.classList.contains('slidev-vclick-hidden')),
      vclickTargets: cur.querySelectorAll('.slidev-vclick-target').length, vclickHidden: cur.querySelectorAll('.slidev-vclick-hidden').length,
      h1Font: getComputedStyle(cur.querySelector('h1') || cur).fontSize, h1Color: getComputedStyle(cur.querySelector('h1') || cur).color,
      text: cur.innerText.replace(/\s+/g, ' ').slice(0, 140),
    } : null;
  }).catch(e => ({ evalError: String(e).slice(0, 200) }));

  // --- run 1: cold compile -------------------------------------------------
  out.run1 = await run(null);
  await sleep(800);
  out.slide1 = await detail();
  await press('ArrowRight'); out.slide2_click0 = await detail();
  await press('ArrowRight'); out.slide2_click1 = await detail();
  await press('ArrowRight'); out.slide2_click2 = await detail();
  await press('ArrowRight'); out.slide3 = await detail();
  out.interaction = await deck()?.evaluate(async () => {
    const btn = [...document.querySelectorAll('button')].find(b => /Opposite/.test(b.textContent));
    if (!btn) return 'no component button found';
    const read = () => document.querySelector('.intensity-value strong')?.textContent;
    const before = read(); btn.click(); await new Promise(r => setTimeout(r, 150));
    const box = document.querySelector('.interference-demo');
    return `intensity ${before} -> ${read()} | scoped css border-radius=${getComputedStyle(box).borderRadius} | data-v attr=${[...box.attributes].some(a => a.name.startsWith('data-v-'))}`;
  }).catch(e => 'eval error ' + String(e).slice(0, 150));
  await press('ArrowRight'); out.slide4_click0 = await detail();
  await press('ArrowRight'); out.slide4_click1 = await detail();
  await press('ArrowRight'); await press('ArrowRight'); out.slide5 = await detail();
  if (flags.includes('--shot')) { await mkdir(resolve(here, '../results'), { recursive: true }); await page.screenshot({ path: resolve(here, `../results/inbrowser-${deckName}-last.png`) }); }

  // --- run 2: "the user edited slides.md" -> recompile (warm) ---------------
  out.run2 = await run({ 'slides.md': ['# Quantum interference', '# Edited in the browser'] });
  await sleep(600);
  out.afterEdit_slide1 = await detail();
  // --- run 3: edit the Vue component ---------------------------------------
  out.run3 = await run({ 'components/QuantumInterference.vue': ['In phase · 0°', 'ZERO PHASE (edited)'] });
  await sleep(400);
  await press('ArrowRight'); await press('ArrowRight'); await press('ArrowRight'); await press('ArrowRight');
  out.afterComponentEdit = await deck()?.evaluate(() => [...document.querySelectorAll('button')].map(b => b.textContent.trim())).catch(e => String(e).slice(0, 100));
  out.console = uniq(consoleMsgs).slice(0, 20); out.pageErrors = uniq(pageErrors); out.external = uniq(external);
  out.compilerRequests = { count: requests.filter(u => u.includes('/compiler/')).length, files: uniq(requests.filter(u => u.includes('/compiler/')).map(u => u.split('/compiler/')[1])).slice(0, 40) };
} catch (e) { out.error = String(e.stack || e).slice(0, 600); }
finally { await browser.close(); server.kill(); }
await mkdir(resolve(here, '../results'), { recursive: true });
await writeFile(resolve(here, `../results/inbrowser-${deckName}.json`), JSON.stringify(out, null, 1));
const brief = r => r && ({ compileMs: Math.round(r.compileMs), bootMs: Math.round(r.bootMs), htmlBytes: r.htmlBytes, info: r.info, timings: Object.fromEntries(Object.entries(r.timings).map(([k, v]) => [k, Math.round(v)])), diagnostics: r.diagnostics, playerStates: r.playerStates, playerErrors: r.playerErrors });
console.log(JSON.stringify({ ...out, run1: brief(out.run1), run2: brief(out.run2), run3: brief(out.run3) }, null, 1));
