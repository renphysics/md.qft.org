// Bundle candidate entry points for the browser with esbuild and report sizes.
// Usage: node bundle-sizes.mjs <node_modules project dir> [filter]
import { build } from 'esbuild';
import { gzipSync, brotliCompressSync } from 'node:zlib';
import { mkdir, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const projectDir = resolve(process.argv[2]);
const filter = process.argv[3];
const outDir = resolve(import.meta.dirname, '../bundles');
await mkdir(outDir, { recursive: true });

// name -> entry source (virtual stdin module, resolved from projectDir)
const cases = {
  'slidev-parser-core': `export * from '@slidev/parser/core'`,
  'slidev-parser-index': `export * from '@slidev/parser'`,
  'slidev-parser-utils': `export * from '@slidev/parser/utils'`,
  'slidev-parser-fs': `export * from '@slidev/parser/fs'`,
  'slidev-types': `export * from '@slidev/types'`,
  'yaml': `export * from 'yaml'`,
  'markdown-exit': `export { default } from 'markdown-exit'`,
  'markdown-it': `export { default } from 'markdown-it'`,
  'comark-markdown-it': `export { default } from '@comark/markdown-it'`,
  'markdown-it-footnote': `export { default } from 'markdown-it-footnote'`,
  'markdown-it-github-alerts': `export { default } from 'markdown-it-github-alerts'`,
  'katex': `export { default } from 'katex'`,
  'lz-string': `export { default } from 'lz-string'`,
  'plantuml-encoder': `export * from 'plantuml-encoder'`,
  'shikijs-markdown-it-async': `export * from '@shikijs/markdown-it/async'`,
  'shiki-core+js-engine': `export * from 'shiki/core'; export * from 'shiki/engine/javascript'`,
  'shiki-core+js-engine+6langs+2themes': `
    export * from 'shiki/core'; export * from 'shiki/engine/javascript';
    export { default as md } from '@shikijs/langs/markdown'; export { default as vue } from '@shikijs/langs/vue';
    export { default as js } from '@shikijs/langs/javascript'; export { default as ts } from '@shikijs/langs/typescript';
    export { default as html } from '@shikijs/langs/html'; export { default as css } from '@shikijs/langs/css';
    export { default as vd } from '@shikijs/themes/vitesse-dark'; export { default as vl } from '@shikijs/themes/vitesse-light';`,
  'shiki-full-bundle(lazy langs)': `export * from 'shiki'`,
  'shikijs-magic-move-core': `export * from '@shikijs/magic-move/core'`,
  'vue-compiler-dom': `export * from '@vue/compiler-dom'`,
  'vue-compiler-sfc': `export * from '@vue/compiler-sfc'`,
  'vue-full(esm-bundler)': `export * from 'vue/dist/vue.esm-bundler.js'`,
  'vue-runtime-only': `export * from 'vue'`,
  'unocss-core+wind3+attributify+typography': `
    export { createGenerator } from '@unocss/core';
    export { presetWind3 } from '@unocss/preset-wind3'; export { presetAttributify } from '@unocss/preset-attributify';
    export { presetTypography } from '@unocss/preset-typography';
    export { default as transformerDirectives } from '@unocss/transformer-directives';
    export { default as transformerVariantGroup } from '@unocss/transformer-variant-group';`,
  'unocss-all(unocss pkg)': `export { createGenerator, presetWind3, presetAttributify, presetTypography, presetIcons, transformerDirectives, transformerVariantGroup } from 'unocss'`,
  'unocss-preset-icons(browser)': `export * from '@unocss/preset-icons/browser'`,
  'unocss-extractor-mdc': `export { default } from '@unocss/extractor-mdc'`,
  'iconify-json-carbon': `export { default } from '@iconify-json/carbon/icons.json'`,
  'iconify-json-ph': `export { default } from '@iconify-json/ph/icons.json'`,
  'unplugin-vue-markdown(core)': `export * from 'unplugin-vue-markdown'`,
  'mermaid': `export { default } from 'mermaid'`,
  'magic-string': `export { default } from 'magic-string'`,
  'magic-string-stack': `export { default } from 'magic-string-stack'`,
  'source-map-js': `export * from 'source-map-js'`,
  'typescript': `export * from 'typescript'`,
  'slidev-cli-index(node)': `export * from '@slidev/cli'`,
};

const rows = [];
for (const [name, contents] of Object.entries(cases)) {
  if (filter && !name.includes(filter)) continue;
  const row = { name };
  for (const minify of [false, true]) {
    try {
      const result = await build({
        stdin: { contents, resolveDir: projectDir, loader: 'js', sourcefile: name + '.entry.js' },
        bundle: true, write: false, format: 'esm', platform: 'browser', target: 'es2022',
        minify, logLevel: 'silent', metafile: true, legalComments: 'none',
        mainFields: ['browser', 'module', 'main'], conditions: ['browser', 'import', 'module', 'default', 'production'],
        define: { 'process.env.NODE_ENV': '"production"', '__VUE_OPTIONS_API__': 'true', '__VUE_PROD_DEVTOOLS__': 'false', '__VUE_PROD_HYDRATION_MISMATCH_DETAILS__': 'false' },
        loader: { '.json': 'json' },
      });
      const code = result.outputFiles[0].contents;
      if (minify) {
        row.min = code.length; row.gzip = gzipSync(code, { level: 9 }).length; row.brotli = brotliCompressSync(code).length;
        row.inputs = Object.keys(result.metafile.inputs).length;
        row.warnings = result.warnings.length;
        await writeFile(resolve(outDir, name.replace(/[^\w.+-]/g, '_') + '.min.js'), code);
        // Node-ish leftovers that survive bundling
        const text = Buffer.from(code).toString('utf8');
        row.nodeish = ['require(', 'process.', 'Buffer.', '__dirname', 'node:'].filter(k => text.includes(k)).join(' ');
      } else row.raw = code.length;
    } catch (error) {
      row.error = (error.errors ?? []).slice(0, 4).map(e => e.text).join(' | ') || String(error.message).slice(0, 300);
      row.errorCount = error.errors?.length;
      break;
    }
  }
  rows.push(row);
  console.log(JSON.stringify(row));
}
await writeFile(resolve(outDir, 'sizes.json'), JSON.stringify(rows, null, 2));
const kb = n => n == null ? '' : (n / 1024).toFixed(1);
console.log('\n| entry | raw KB | min KB | gzip KB | brotli KB | modules | note |');
console.log('|---|---:|---:|---:|---:|---:|---|');
for (const r of rows) console.log(`| ${r.name} | ${kb(r.raw)} | ${kb(r.min)} | ${kb(r.gzip)} | ${kb(r.brotli)} | ${r.inputs ?? ''} | ${r.error ? 'FAILS: ' + r.error.slice(0, 160) : (r.nodeish ? 'contains: ' + r.nodeish : 'ok')} |`);
