// Which client routes exist in a default static build?
import { spawn } from 'node:child_process';
import { resolve } from 'node:path';
import { chromium, sleep, uniq } from './deck-probe.mjs';
const [dist, port] = process.argv.slice(2);
const here = import.meta.dirname;
const server = spawn(process.execPath, [resolve(here, 'static-server.mjs'), port, JSON.stringify([{ prefix: '/', dir: resolve(dist), spa: true }])], { stdio: ['ignore', 'pipe', 'inherit'] });
await new Promise(r => server.stdout.once('data', r));
const browser = await chromium.launch();
try {
  const context = await browser.newContext({ viewport: { width: 1280, height: 720 } });
  await context.route(url => !/^(?:http:\/\/localhost|blob:|data:|about:)/.test(url.href), route => route.abort());
  for (const path of ['/', '/2', '/2?clicks=1', '/presenter', '/presenter/2', '/overview', '/notes', '/notes-edit', '/entry', '/export', '/print', '/presenter/print', '/nope', '/2?embedded=true', '/2?print']) {
    const page = await context.newPage();
    const errors = []; page.on('pageerror', e => errors.push(String(e.message).slice(0, 100)));
    await page.goto(`http://localhost:${port}${path}`, { waitUntil: 'load' }); await sleep(1300);
    const info = await page.evaluate(() => ({ url: location.pathname + location.search, title: document.title, pages: document.querySelectorAll('.slidev-page').length, presenter: !!document.querySelector('.slidev-presenter, [class*="presenter"]'), notes: !!document.querySelector('.slidev-note, [class*="note"]'), text: document.body.innerText.replace(/\s+/g, ' ').slice(0, 90), jsLoaded: performance.getEntriesByType('resource').filter(r => /\.js$/.test(r.name)).map(r => r.name.split('/').pop().replace(/-[\w-]{8}\.js$/, '')).filter(n => /presenter|overview|notes|entry|print|export|404|play/.test(n)) }));
    console.log(path.padEnd(18), '->', info.url.padEnd(16), 'pages=' + String(info.pages).padEnd(3), 'chunks=' + info.jsLoaded.join(','), '|', JSON.stringify(info.text.slice(0, 70)), errors.filter(e => !/Wake Lock/.test(e)).length ? 'ERR ' + errors[0] : '');
    await page.close();
  }
  // BroadcastChannel names used for sync in a serverless build
  const page = await context.newPage();
  await page.addInitScript(() => { const O = window.BroadcastChannel; window.__bc = []; window.BroadcastChannel = class extends O { constructor(n) { super(n); window.__bc.push(n); } }; const s = Storage.prototype.setItem; window.__ls = new Set(); Storage.prototype.setItem = function (k, v) { window.__ls.add(k); return s.call(this, k, v); }; });
  await page.goto(`http://localhost:${port}/presenter/1`, { waitUntil: 'load' }); await sleep(1500);
  await page.keyboard.press('ArrowRight'); await sleep(500);
  console.log('BroadcastChannel names:', await page.evaluate(() => window.__bc), '| localStorage keys written:', await page.evaluate(() => [...window.__ls]), '| localStorage keys present:', await page.evaluate(() => Object.keys(localStorage)));
} finally { await browser.close(); server.kill(); }
