// Compile a deck in the browser, then play the generated single-file HTML WITHOUT the kill-on-error
// player so that every slide can be visited and its errors attributed.
// Usage: node test-gaps.mjs <site dir> <port> <deck>
import { spawn } from 'node:child_process';
import { resolve } from 'node:path';
import { writeFile, mkdir } from 'node:fs/promises';
import { chromium, sleep, uniq } from './deck-probe.mjs';
const [site, port, deckName] = process.argv.slice(2);
const here = import.meta.dirname;
const server = spawn(process.execPath, [resolve(here, 'static-server.mjs'), port, JSON.stringify([{ prefix: '/', dir: resolve(site), spa: false }])], { stdio: ['ignore', 'pipe', 'inherit'] });
await new Promise(r => server.stdout.once('data', r));
const browser = await chromium.launch();
const out = { slides: [] };
try {
  const context = await browser.newContext({ viewport: { width: 1280, height: 720 } });
  const external = [];
  await context.route(url => !/^(?:http:\/\/localhost|blob:|data:|about:)/.test(url.href), route => { external.push(route.request().resourceType() + ' ' + route.request().url().slice(0, 110)); return route.abort(); });
  const page = await context.newPage();
  await page.goto(`http://localhost:${port}/index.html`, { waitUntil: 'load' });
  await page.waitForFunction(() => window.__app?.ready, null, { timeout: 30000 });
  const result = await page.evaluate(async deckName => window.__compileOnly(await window.__loadFiles(deckName)), deckName);
  out.compile = { compileMs: Math.round(result.compileMs), info: result.info, timings: Object.fromEntries(Object.entries(result.timings).map(([k, v]) => [k, Math.round(v)])), diagnostics: result.diagnostics, htmlBytes: result.html.length, scriptBytes: result.scriptBytes, cssBytes: result.cssBytes };
  await writeFile(resolve(here, `../results/gaps-${deckName}.html`), result.html);
  const play = await context.newPage();
  const logs = []; play.on('console', m => { if (m.type() === 'error' || m.type() === 'warning') logs.push(`[${m.type()}] ${m.text().slice(0, 260)}`); });
  play.on('pageerror', e => logs.push('[pageerror] ' + String(e.message).slice(0, 260)));
  await play.goto(`http://localhost:${port}/presentation-sandbox.html`); // any same-origin page without CSP for navigation purposes
  await play.setContent(result.html, { waitUntil: 'load' });
  await sleep(1500);
  out.bootLogs = uniq(logs.splice(0));
  for (let no = 1; no <= result.info.slides; no++) {
    await play.evaluate(no => window.__QFT_SLIDEV__.app.config.globalProperties.$router.push('/' + no), no).catch(e => logs.push('[nav] ' + String(e).slice(0, 120)));
    await sleep(900);
    const info = await play.evaluate(() => {
      const shown = [...document.querySelectorAll('#slideshow .slidev-page')].filter(p => { let e = p; while (e && e !== document.body) { if (getComputedStyle(e).display === 'none') return false; e = e.parentElement; } return true; });
      const cur = shown.at(-1); if (!cur) return { missing: true };
      const unresolved = [...cur.querySelectorAll('*')].map(e => e.localName).filter(n => n.includes('-') || n.includes(':')).filter(n => !customElements.get(n));
      return { page: (cur.className.match(/slidev-page-\d+/) || [])[0], layout: cur.querySelector('.slidev-layout')?.className?.slice(0, 60), title: cur.querySelector('h1,h2')?.textContent.trim().slice(0, 40), textLen: cur.innerText.length, unresolvedTags: [...new Set(unresolved)].slice(0, 12), errorLayout: !!cur.querySelector('.slidev-layout.error, [class*="error"]') };
    }).catch(e => ({ evalError: String(e).slice(0, 200) }));
    out.slides.push({ no, ...info, logs: uniq(logs.splice(0)).slice(0, 6) });
  }
  out.external = uniq(external);
} catch (e) { out.error = String(e.stack || e).slice(0, 600); }
finally { await browser.close(); server.kill(); }
await mkdir(resolve(here, '../results'), { recursive: true });
await writeFile(resolve(here, `../results/gaps-${deckName}.json`), JSON.stringify(out, null, 1));
console.log(JSON.stringify(out.compile, null, 1)); console.log('boot logs:', out.bootLogs);
for (const s of out.slides) console.log(String(s.no).padStart(2), JSON.stringify(s.title), '| layout:', s.layout, '| unresolved:', (s.unresolvedTags || []).join(','), s.evalError ? '| EVALERR ' + s.evalError : '', s.logs.length ? '\n      ' + s.logs.join('\n      ') : '');
console.log('external:', out.external); if (out.error) console.log('ERROR', out.error);
