// Compile a deck in the browser and play it in the md.qft.org sandbox replica (kill-on-error); walk all slides.
import { spawn } from 'node:child_process';
import { resolve } from 'node:path';
import { chromium, sleep, uniq } from './deck-probe.mjs';
const [site, port, ...decks] = process.argv.slice(2);
const here = import.meta.dirname;
const server = spawn(process.execPath, [resolve(here, 'static-server.mjs'), port, JSON.stringify([{ prefix: '/', dir: resolve(site), spa: false }])], { stdio: ['ignore', 'pipe', 'inherit'] });
await new Promise(r => server.stdout.once('data', r));
const browser = await chromium.launch();
try {
  for (const deckName of decks) {
    const context = await browser.newContext({ viewport: { width: 1280, height: 720 } });
    const external = []; await context.route(url => !/^(?:http:\/\/localhost|blob:|data:|about:)/.test(url.href), route => { external.push(route.request().url().slice(0, 100)); return route.abort(); });
    const page = await context.newPage();
    const logs = []; page.on('console', m => { if (m.type() === 'error') logs.push(m.text().slice(0, 220)); }); page.on('pageerror', e => logs.push('[pageerror] ' + String(e.message).slice(0, 200)));
    await page.goto(`http://localhost:${port}/index.html`, { waitUntil: 'load' });
    await page.waitForFunction(() => window.__app?.ready, null, { timeout: 30000 });
    const run = await page.evaluate(async deckName => window.__compileAndPlay(await window.__loadFiles(deckName)), deckName);
    await sleep(800);
    const deck = () => page.frames().find(f => f.url().startsWith('blob:'));
    const visited = [];
    for (let i = 0; i < run.info.slides * 4 && deck(); i++) {
      const cur = await deck().evaluate(() => { const shown = [...document.querySelectorAll('#slideshow .slidev-page')].filter(p => { let e = p; while (e && e !== document.body) { if (getComputedStyle(e).display === 'none') return false; e = e.parentElement; } return true; }); const c = shown.at(-1); return c ? (c.className.match(/slidev-page-(\d+)/) || [])[1] + ':' + (c.querySelector('h1')?.textContent.trim() ?? '') + ' imgs=' + [...c.querySelectorAll('img')].filter(i => i.complete && i.naturalWidth > 0).length + '/' + c.querySelectorAll('img').length : null; }).catch(() => null);
      if (cur && visited.at(-1) !== cur) visited.push(cur);
      await deck()?.locator('body').press('ArrowRight').catch(() => {}); await sleep(350);
    }
    const end = await page.evaluate(() => ({ states: window.__app.playerStates, errors: window.__app.playerErrors }));
    console.log(`\n## ${deckName}: compile ${Math.round(run.compileMs)} ms, boot ${Math.round(run.bootMs)} ms, html ${(run.htmlBytes / 1048576).toFixed(2)} MB, deck script ${(run.info.scriptBytes / 1024).toFixed(0)} KB`);
    console.log('   states:', end.states.join(' > '), '| player errors:', JSON.stringify(end.errors), '| unsupported:', JSON.stringify(run.info.unsupported), '| diagnostics:', run.diagnostics.length);
    console.log('   visited:', visited.join(' | ')); console.log('   console:', uniq(logs).slice(0, 5), '| external:', uniq(external));
    await context.close();
  }
} finally { await browser.close(); server.kill(); }
