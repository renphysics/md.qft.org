// Shared Playwright helpers for probing a Slidev deck (top-level page or a frame).
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
export const { chromium } = require('playwright');

/** Evaluate inside a page or frame: what does the deck look like right now? */
export async function probe(target) {
  return target.evaluate(() => {
    const visible = el => { const r = el.getBoundingClientRect(); const s = getComputedStyle(el); return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none' && Number(s.opacity) > 0; };
    const pages = [...document.querySelectorAll('.slidev-page')];
    const shown = pages.filter(p => { let e = p; while (e && e !== document.body) { const s = getComputedStyle(e); if (s.display === 'none') return false; e = e.parentElement; } return true; });
    let storage = 'ok';
    try { void window.localStorage.length; } catch (e) { storage = e.name + ': ' + e.message.slice(0, 90); }
    return {
      href: location.href, origin: window.origin, title: document.title,
      appChildren: document.querySelector('#app')?.childElementCount ?? -1,
      pageCount: pages.length,
      shownPages: shown.map(p => (p.className.match(/slidev-page-\d+/) || ['?'])[0]),
      h1: shown.flatMap(p => [...p.querySelectorAll('h1')]).filter(visible).map(e => e.textContent.trim()).slice(0, 4),
      katex: document.querySelectorAll('.katex').length,
      text404: /404|not found/i.test(document.body.innerText.slice(0, 400)),
      bodyText: document.body.innerText.replace(/\s+/g, ' ').slice(0, 160),
      storage,
    };
  }).catch(e => ({ evalError: String(e).slice(0, 200) }));
}

/** Attach collectors to a page. Returns a mutable record. */
export function collect(page) {
  const rec = { console: [], pageErrors: [], failed: [], badStatus: [], external: [] };
  page.on('console', m => { if (['error', 'warning'].includes(m.type())) rec.console.push(`[${m.type()}] ${m.text().slice(0, 300)}`); });
  page.on('pageerror', e => rec.pageErrors.push(String(e.message).slice(0, 300)));
  page.on('requestfailed', r => rec.failed.push(`${r.url().slice(0, 140)} :: ${r.failure()?.errorText}`));
  page.on('response', r => { if (r.status() >= 400) rec.badStatus.push(`${r.status()} ${r.url().slice(0, 140)}`); });
  return rec;
}

/** Block and record everything that is not localhost/file/blob/data. */
export async function blockExternal(context, rec) {
  await context.route(url => !/^(?:https?:\/\/(?:localhost|127\.0\.0\.1)(?::\d+)?\/|file:|blob:|data:|about:)/.test(url.href), route => {
    rec.push(route.request().resourceType() + ' ' + route.request().url().slice(0, 200));
    return route.abort('blockedbyclient');
  });
}

export const sleep = ms => new Promise(r => setTimeout(r, ms));
export const uniq = a => [...new Set(a)];
