// Per-slide DOM comparison (all clicks revealed) between a real build and the in-browser compile.
// Usage: node test-fidelity-slides.mjs <ref dist> <site dir> <deck name> <slide count>
import { spawn } from 'node:child_process';
import { resolve } from 'node:path';
import { writeFile, mkdir } from 'node:fs/promises';
import { chromium, sleep, uniq } from './deck-probe.mjs';
const [refDist, site, deckName, countArg] = process.argv.slice(2);
const here = import.meta.dirname;
const outDir = resolve(here, '../results/fidelity-' + deckName); await mkdir(outDir, { recursive: true });
const servers = [
  spawn(process.execPath, [resolve(here, 'static-server.mjs'), '4518', JSON.stringify([{ prefix: '/', dir: resolve(refDist), spa: true }])], { stdio: ['ignore', 'pipe', 'inherit'] }),
  spawn(process.execPath, [resolve(here, 'static-server.mjs'), '4519', JSON.stringify([{ prefix: '/', dir: resolve(site), spa: false }])], { stdio: ['ignore', 'pipe', 'inherit'] }),
];
await Promise.all(servers.map(s => new Promise(r => s.stdout.once('data', r))));
const browser = await chromium.launch();
const snapshot = target => target.evaluate(() => {
  const shown = [...document.querySelectorAll('#slideshow .slidev-page')].filter(p => { let e = p; while (e && e !== document.body) { if (getComputedStyle(e).display === 'none') return false; e = e.parentElement; } return true; });
  const cur = shown.at(-1); if (!cur) return null;
  const layout = cur.querySelector('.slidev-layout'); if (!layout) return { html: '(no layout)', tags: {}, unknown: [], text: cur.innerText };
  const unknown = [...layout.querySelectorAll('*')].filter(e => e instanceof HTMLUnknownElement || (e.localName.includes('-') && !customElements.get(e.localName))).map(e => e.localName);
  const clone = layout.cloneNode(true);
  const walk = el => { for (const a of [...el.attributes]) { if (/^data-v-[0-9a-f]+$/.test(a.name)) el.removeAttribute(a.name); } for (const c of el.children) walk(c); };
  walk(clone);
  const tags = {}; for (const e of clone.querySelectorAll('*')) tags[e.localName] = (tags[e.localName] || 0) + 1;
  const html = clone.outerHTML.replace(/<!--[\s\S]*?-->/g, '').replace(/\s+/g, ' ').replace(/> </g, '><').replace(/ id="[^"]*"/g, '').replace(/ for="[^"]*"/g, '').replace(/ style="[^"]*"/g, '').replace(/url\([^)]*\)/g, 'URL').replace(/ src="[^"]*"/g, ' src="ASSET"');
  return { page: (cur.className.match(/slidev-page-\d+/) || [])[0], html, tags, unknown: [...new Set(unknown)], text: layout.innerText.replace(/\s+/g, ' ').trim() };
});
const out = { slides: [] };
try {
  const context = await browser.newContext({ viewport: { width: 1280, height: 720 }, deviceScaleFactor: 1 });
  await context.route(url => !/^(?:http:\/\/localhost|blob:|data:|about:)/.test(url.href), route => route.abort());
  const ref = await context.newPage(); const dut = await context.newPage();
  const dutLogs = []; dut.on('console', m => { if (m.type() === 'error') dutLogs.push(m.text().slice(0, 200)); }); dut.on('pageerror', e => dutLogs.push('[pageerror] ' + String(e.message).slice(0, 200)));
  await dut.goto('http://localhost:4519/index.html', { waitUntil: 'load' });
  await dut.waitForFunction(() => window.__app?.ready, null, { timeout: 30000 });
  const result = await dut.evaluate(async deckName => window.__compileOnly(await window.__loadFiles(deckName)), deckName);
  out.compile = { compileMs: Math.round(result.compileMs), unsupported: result.info.unsupported, diagnostics: result.diagnostics };
  const play = await context.newPage();
  const logs = []; play.on('console', m => { if (m.type() === 'error') logs.push(m.text().slice(0, 200)); }); play.on('pageerror', e => logs.push('[pageerror] ' + String(e.message).slice(0, 200)));
  await play.goto('http://localhost:4519/blank.html').catch(() => {});
  await play.setContent(result.html, { waitUntil: 'load' }); await sleep(1500);
  for (let no = 1; no <= Number(countArg); no++) {
    await ref.goto(`http://localhost:4518/${no}?clicks=99`, { waitUntil: 'load' }); await sleep(1300);
    await play.evaluate(no => window.__QFT_SLIDEV__.app.config.globalProperties.$router.push({ path: '/' + no, query: { clicks: '99' } }), no).catch(e => logs.push('[nav] ' + String(e).slice(0, 100)));
    await sleep(1300);
    const a = await snapshot(ref); const b = await snapshot(play);
    await ref.screenshot({ path: resolve(outDir, `slide${no}-ref.png`) }); await play.screenshot({ path: resolve(outDir, `slide${no}-inbrowser.png`) });
    const same = a?.html === b?.html;
    let firstDiff = null;
    if (!same && a && b) { let k = 0; while (k < a.html.length && a.html[k] === b.html[k]) k++; firstDiff = { at: k, ref: a.html.slice(Math.max(0, k - 60), k + 140), inbrowser: b.html.slice(Math.max(0, k - 60), k + 140) }; }
    const tagDiff = {}; for (const t of new Set([...Object.keys(a?.tags ?? {}), ...Object.keys(b?.tags ?? {})])) { const d = (b?.tags?.[t] || 0) - (a?.tags?.[t] || 0); if (d) tagDiff[t] = d; }
    out.slides.push({ no, domIdentical: same, textIdentical: a?.text === b?.text, refLen: a?.html.length, inbrowserLen: b?.html.length, unknown: b?.unknown, tagDiff, firstDiff, logs: uniq(logs.splice(0)).slice(0, 4) });
  }
} catch (e) { out.error = String(e.stack || e).slice(0, 500); }
finally { await browser.close(); servers.forEach(s => s.kill()); }
await writeFile(resolve(outDir, 'slides-report.json'), JSON.stringify(out, null, 1));
console.log(JSON.stringify(out.compile)); if (out.error) console.log('ERROR', out.error);
for (const s of out.slides) { console.log(`slide ${String(s.no).padStart(2)} dom=${s.domIdentical ? 'IDENTICAL' : 'DIFF     '} text=${s.textIdentical ? 'same' : 'DIFF'} len ${s.refLen}/${s.inbrowserLen} unknown=[${(s.unknown || []).join(',')}] tagDiff=${JSON.stringify(s.tagDiff)}${s.logs.length ? ' logs=' + JSON.stringify(s.logs) : ''}`); if (s.firstDiff) { console.log('      ref      : ' + s.firstDiff.ref.replace(/\n/g, ' ')); console.log('      inbrowser: ' + s.firstDiff.inbrowser.replace(/\n/g, ' ')); } }
console.log('identical:', out.slides.filter(s => s.domIdentical).length, '/', out.slides.length);
