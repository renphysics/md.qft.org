// Minimal static server for the B2 experiments.
// Usage: node static-server.mjs <port> <mounts-json>
//   mounts-json: [{"prefix":"/","dir":"/abs/dist","spa":true,"cors":false,"headers":{}}]
// Longest prefix wins. spa=true falls back to <dir>/index.html (like Netlify _redirects / sirv --single).
// spa="404" serves <dir>/404.html with status 404 (GitHub Pages behaviour).
import http from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { extname, join, normalize, resolve } from 'node:path';

const port = Number(process.argv[2]);
const mounts = JSON.parse(process.argv[3]).sort((a, b) => b.prefix.length - a.prefix.length);
const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.png': 'image/png', '.svg': 'image/svg+xml', '.woff2': 'font/woff2', '.woff': 'font/woff', '.ttf': 'font/ttf', '.wasm': 'application/wasm', '.zip': 'application/zip', '.md': 'text/markdown; charset=utf-8', '.txt': 'text/plain; charset=utf-8', '.ico': 'image/x-icon', '.map': 'application/json' };
const log = [];
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  if (url.pathname === '/__log') { res.setHeader('content-type', 'application/json'); res.end(JSON.stringify(log)); return; }
  if (url.pathname === '/__clear') { log.length = 0; res.end('ok'); return; }
  const mount = mounts.find(m => url.pathname.startsWith(m.prefix));
  const entry = { method: req.method, path: url.pathname + url.search, origin: req.headers.origin ?? null, dest: req.headers['sec-fetch-dest'] ?? null, mode: req.headers['sec-fetch-mode'] ?? null };
  log.push(entry);
  if (!mount) { entry.status = 404; res.statusCode = 404; res.end('no mount'); return; }
  const rel = normalize(decodeURIComponent(url.pathname.slice(mount.prefix.length))).replace(/^(\.\.[/\\])+/, '');
  let file = resolve(mount.dir, rel);
  if (!file.startsWith(resolve(mount.dir))) { res.statusCode = 403; res.end(); return; }
  let status = 200;
  let info = await stat(file).catch(() => null);
  if (info?.isDirectory()) { file = join(file, 'index.html'); info = await stat(file).catch(() => null); }
  if (!info) {
    if (mount.spa === true) file = join(mount.dir, 'index.html');
    else if (mount.spa === '404') { file = join(mount.dir, '404.html'); status = 404; }
    else { entry.status = 404; res.statusCode = 404; res.setHeader('content-type', 'text/plain'); res.end('not found'); return; }
  }
  const body = await readFile(file).catch(() => null);
  if (!body) { entry.status = 404; res.statusCode = 404; res.end('not found'); return; }
  res.statusCode = entry.status = status;
  res.setHeader('content-type', types[extname(file).toLowerCase()] ?? 'application/octet-stream');
  res.setHeader('cache-control', 'no-store');
  if (mount.cors) res.setHeader('access-control-allow-origin', '*');
  for (const [k, v] of Object.entries(mount.headers ?? {})) res.setHeader(k, v);
  res.end(body);
});
server.listen(port, '127.0.0.1', () => console.log('listening', port));
