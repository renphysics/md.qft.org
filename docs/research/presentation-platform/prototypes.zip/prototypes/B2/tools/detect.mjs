// Upload classifier prototype (pure JS, no Node APIs in detectUpload itself).
//   files: Map<path, { size: number, text: () => string }>   (paths as stored in the ZIP)
// Returns what kind of presentation package this is and what the player has to cope with.
import { parseSync, resolveConfig, detectFeatures } from '@slidev/parser/core';

const HEADMATTER_KEYS = ['theme', 'addons', 'layout', 'transition', 'mdc', 'comark', 'drawings', 'fonts', 'routerMode', 'canvasWidth', 'aspectRatio', 'highlighter', 'lineNumbers', 'colorSchema', 'titleTemplate', 'themeConfig', 'monaco', 'twoslash', 'seoMeta', 'presenter', 'download', 'exportFilename', 'defaults', 'background', 'class', 'clicks', 'duration', 'info'];
const SLIDEV_SYNTAX = [/<v-clicks?\b/i, /\bv-click\b/, /\bv-motion\b/, /\bv-mark\b/, /\bv-drag\b/, /^::\s*[\w-]+\s*::\s*$/m, /```[\w-]*\s*\{monaco[\w-]*\}/, /```[\w-]+\s*(?:\[[^\]]*\]\s*)?\{[\d,|\-*a-l ]*\|[^}]*\}/, /^<<<\s+\S+/m, /\$slidev\b/, /<(?:Toc|Tweet|Youtube|SlidevVideo|Arrow|AutoFitText|LightOrDark|RenderWhen|Transform|VDragArrow|PoweredBySlidev|SlideCurrentNo|SlidesTotal)\b/, /````md\s+magic-move/, /^src:\s*\S+\.md/m];

const dirOf = p => p.includes('/') ? p.slice(0, p.lastIndexOf('/') + 1) : '';
const depth = p => p.split('/').length;

export function detectUpload(files) {
  const paths = [...files.keys()].filter(p => !p.startsWith('__MACOSX/') && !/(?:^|\/)\.DS_Store$/.test(p));
  const read = p => { try { return files.get(p).text(); } catch { return ''; } };
  const byDepth = list => list.sort((a, b) => depth(a) - depth(b) || a.length - b.length);
  const result = { kind: 'unknown', files: paths.length, bytes: paths.reduce((s, p) => s + files.get(p).size, 0) };

  // --- md.qft.org's own formats first ------------------------------------------------
  if (paths.some(p => /(?:^|\/)qft-presentation\.json$/.test(p))) return { ...result, kind: 'qft-portable-presentation' };
  if (paths.some(p => /(?:^|\/)qft\.json$/.test(p))) return { ...result, kind: 'qft-lesson-project' };

  // --- built Slidev app ----------------------------------------------------------------
  const htmls = byDepth(paths.filter(p => /(?:^|\/)index\.html?$/i.test(p) && !/node_modules\//.test(p)));
  for (const indexPath of htmls) {
    const html = read(indexPath);
    const version = html.match(/<meta\s+property=["']slidev:version["']\s+content=["']([^"']+)["']/i)?.[1] ?? null; // since v0.49.0
    const root = dirOf(indexPath);
    const looksSlidev = version || (/<div id="app"><\/div>/.test(html) && (/id="mermaid-rendering-container"/.test(html) || paths.some(p => p.startsWith(root + 'assets/slidev/'))));
    if (!looksSlidev) continue;
    const entry = html.match(/<script[^>]*type=["']module["'][^>]*\ssrc=["']([^"']+)["']/i)?.[1] ?? null;
    const base = entry ? entry.replace(/assets\/[^/]+$/, '') : null; // "/", "./", "/sub/path/"
    const inRoot = paths.filter(p => p.startsWith(root));
    const js = inRoot.filter(p => /\.m?js$/.test(p));
    const vueChunk = js.find(p => /assets\/modules\/vue-[\w-]+\.js$/.test(p));
    const vueCode = vueChunk ? read(vueChunk) : '';
    const smallJs = js.filter(p => files.get(p).size < 400_000 && /assets\/(?:slidev\/|index-)/.test(p)).map(read).join('\n');
    const routerMode = !vueCode ? 'unknown' : !/popstate/.test(vueCode) ? 'memory' : (/location\.host\b/.test(vueCode) || /[`"'](?:\.\/|\/)(?:[\w-]+\/)*#\/[`"']/.test(smallJs)) ? 'hash' : 'history';
    const external = [...html.matchAll(/<(link|script|img)\b[^>]*?\s(?:href|src)=["'](https?:\/\/[^"']+)["'][^>]*>/gi)].map(m => ({ tag: m[1].toLowerCase(), rel: m[0].match(/\srel=["']([^"']+)/i)?.[1] ?? null, url: m[2] }));
    return {
      ...result, kind: 'slidev-dist', root, slidevVersion: version, versionSource: version ? 'meta slidev:version' : 'structure only (built before v0.49.0?)',
      base, baseKind: base == null ? 'unknown' : base.startsWith('./') || base === '' ? 'relative' : base === '/' ? 'absolute-root' : 'absolute-subpath',
      routerMode, title: html.match(/<title>([^<]*)<\/title>/i)?.[1] ?? null,
      jsFiles: js.length, cssFiles: inRoot.filter(p => p.endsWith('.css')).length, distBytes: inRoot.reduce((s, p) => s + files.get(p).size, 0),
      features: {
        monaco: inRoot.some(p => /assets\/monaco\//.test(p)), webWorkers: inRoot.filter(p => /\.worker-[\w-]+\.js$/.test(p)).length,
        mermaid: inRoot.some(p => /(?:mermaid|flowDiagram|sequenceDiagram)[\w-]*\.js$/.test(p)), katexFonts: inRoot.filter(p => /KaTeX_.*\.woff2$/.test(p)).length,
        pwa: inRoot.some(p => /(?:^|\/)(?:sw\.js|manifest\.webmanifest)$/.test(p)), pdfDownload: inRoot.some(p => /\.pdf$/.test(p)),
        externalScripts: external.filter(e => e.tag === 'script').map(e => e.url), googleFonts: external.some(e => /fonts\.googleapis\.com/.test(e.url)), remotePreloads: external.filter(e => e.rel === 'preload').length,
      },
      hasSourceToo: paths.some(p => /(?:^|\/)slides\.md$/.test(p)),
    };
  }

  // --- Slidev source project ----------------------------------------------------------
  const pkgs = byDepth(paths.filter(p => /(?:^|\/)package\.json$/.test(p) && !/node_modules\//.test(p)));
  let pkgInfo = null;
  for (const p of pkgs) {
    let pkg; try { pkg = JSON.parse(read(p)); } catch { continue; }
    const deps = { ...pkg.devDependencies, ...pkg.dependencies };
    const scripts = Object.values(pkg.scripts ?? {}).join('\n');
    if (deps['@slidev/cli'] || /\bslidev\b/.test(scripts)) {
      pkgInfo = { path: p, root: dirOf(p), slidevRange: deps['@slidev/cli'] ?? null, themes: Object.keys(deps).filter(d => /^@slidev\/theme-|^slidev-theme-|\/slidev-theme-/.test(d)), addons: Object.keys(deps).filter(d => /slidev-addon-/.test(d)), otherDeps: Object.keys(deps).filter(d => !/^@slidev\/|slidev-(?:theme|addon)-|^vue$|^playwright-chromium$/.test(d)), entriesFromScripts: [...scripts.matchAll(/slidev(?:\s+(?:build|export|dev))?\s+([\w./-]+\.md)/g)].map(m => m[1]) };
      break;
    }
  }
  const mdCandidates = byDepth(paths.filter(p => /\.md$/i.test(p) && !/node_modules\/|(?:^|\/)README\.md$/i.test(p)));
  let best = null;
  for (const p of mdCandidates.slice(0, 12)) {
    const text = read(p); if (!text) continue;
    const head = text.match(/^﻿?---\r?\n([\s\S]*?)\r?\n---/)?.[1] ?? '';
    const keys = HEADMATTER_KEYS.filter(k => new RegExp(`^${k}:`, 'm').test(head));
    const syntax = SLIDEV_SYNTAX.filter(re => re.test(text)).length;
    const marp = /^marp:\s*true/m.test(head);
    const score = (pkgInfo && (pkgInfo.entriesFromScripts.includes(p.slice(pkgInfo.root.length)) || p === pkgInfo.root + 'slides.md') ? 5 : 0) + keys.length + 2 * syntax + (/(?:^|\/)slides\.md$/.test(p) ? 1 : 0) - (marp ? 10 : 0);
    if (!best || score > best.score) best = { path: p, score, keys, syntax, marp, text };
  }
  if (pkgInfo || (best && best.score >= 4)) {
    const root = pkgInfo?.root ?? dirOf(best.path);
    const info = { ...result, kind: 'slidev-source', root, confidence: pkgInfo?.slidevRange ? 'high (package.json depends on @slidev/cli)' : pkgInfo ? 'medium (slidev script)' : 'medium (markdown only: Slidev headmatter/syntax)', slidevRange: pkgInfo?.slidevRange ?? null, entry: best?.path ?? null, themesInstalled: pkgInfo?.themes ?? [], addonsInstalled: pkgInfo?.addons ?? [], otherNpmDeps: pkgInfo?.otherDeps ?? [], hasNodeModules: [...files.keys()].some(p => /(?:^|\/)node_modules\//.test(p)), hasLockfile: paths.some(p => /(?:package-lock\.json|pnpm-lock\.yaml|yarn\.lock|bun\.lockb?)$/.test(p)) };
    if (best) {
      const parsed = parseSync(best.text, best.path);
      const head = parsed.slides[0]?.frontmatter ?? {};
      const config = resolveConfig(head, {}, best.path);
      const inRoot = paths.filter(p => p.startsWith(root));
      Object.assign(info, {
        slides: parsed.slides.length, title: head.title ?? parsed.slides[0]?.title ?? null, theme: config.theme, addons: config.addons, routerMode: config.routerMode,
        features: detectFeatures(best.text), usesSrcImports: parsed.slides.some(s => s.frontmatter?.src),
        project: {
          components: inRoot.filter(p => /\/components\/.*\.vue$/.test('/' + p.slice(root.length))).length, layouts: inRoot.filter(p => /^layouts\/.*\.vue$/.test(p.slice(root.length))).length,
          setupFiles: inRoot.filter(p => /^setup\/.*\.[cm]?[jt]s$/.test(p.slice(root.length))).map(p => p.slice(root.length)), viteConfig: inRoot.some(p => /^vite\.config\.[cm]?[jt]s$/.test(p.slice(root.length))), unoConfig: inRoot.some(p => /^(?:uno|unocss)\.config\.[cm]?[jt]s$/.test(p.slice(root.length))),
          publicFiles: inRoot.filter(p => p.slice(root.length).startsWith('public/')).length, globalLayers: inRoot.filter(p => /^(?:global(?:-top|-bottom)?|slide-(?:top|bottom)|GlobalTop|GlobalBottom|SlideTop|SlideBottom)\.vue$/.test(p.slice(root.length))).length,
        },
      });
      const blockers = [];
      if (info.theme && !['default', 'none'].includes(info.theme)) blockers.push(`theme "${info.theme}"`);
      if (info.addons?.length) blockers.push('addons');
      if (info.features.monaco) blockers.push('monaco'); if (info.features.mermaid) blockers.push('mermaid'); if (info.features.tweet) blockers.push('tweet (remote script)');
      if (info.otherNpmDeps.length) blockers.push('npm deps: ' + info.otherNpmDeps.slice(0, 5).join(', '));
      if (info.project.viteConfig) blockers.push('vite.config'); if (info.project.setupFiles.length) blockers.push('setup/'); if (info.project.unoConfig) blockers.push('uno.config');
      info.inBrowserCompileBlockers = blockers;
    }
    return info;
  }

  // --- other things we should not mistake for Slidev -----------------------------------
  for (const p of byDepth(paths.filter(p => /\.html?$/i.test(p))).slice(0, 5)) {
    const html = read(p);
    if (/Reveal\.initialize\s*\(|class=["'][^"']*\breveal\b[^"']*["'][\s\S]{0,400}class=["'][^"']*\bslides\b/.test(html)) return { ...result, kind: 'revealjs', entry: p, usesCdn: /https?:\/\/[^"']*reveal(?:\.js)?[@/]/.test(html) };
  }
  if (best?.marp) return { ...result, kind: 'marp-markdown', entry: best.path };
  if (mdCandidates.length) return { ...result, kind: 'plain-markdown', entry: mdCandidates[0] };
  return result;
}
