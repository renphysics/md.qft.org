// Play single-file presentation HTML documents in a replica of the md.qft.org player
// (same runner page, same preparePresentationDocument, same CSP).
// Usage: node test-qft-player.mjs <qftplayer dir> <port> <file.html>...
import { spawn } from 'node:child_process';
import { resolve, basename } from 'node:path';
import { writeFile, mkdir } from 'node:fs/promises';
import { chromium, probe, collect, blockExternal, sleep, uniq } from './deck-probe.mjs';
const [dir, port, ...files] = process.argv.slice(2);
const here = import.meta.dirname;
const server = spawn(process.execPath, [resolve(here, 'static-server.mjs'), port, JSON.stringify([{ prefix: '/', dir: resolve(dir), spa: false }])], { stdio: ['ignore', 'pipe', 'inherit'] });
await new Promise(r => server.stdout.once('data', r));
const results = [];
try {
  for (const file of files) {
    const browser = await chromium.launch();
    const context = await browser.newContext({ viewport: { width: 1280, height: 720 } });
    const external = []; await blockExternal(context, external);
    const page = await context.newPage();
    const rec = collect(page);
    const result = { file };
    try {
      await page.goto(`http://localhost:${port}/player.html?src=${encodeURIComponent(file)}`, { waitUntil: 'load', timeout: 20000 });
      await page.waitForFunction(() => window.__player?.states.some(s => s === 'ready' || s === 'error'), null, { timeout: 25000 }).catch(() => {});
      await sleep(1200);
      result.player = await page.evaluate(() => ({ states: window.__player.states, errors: window.__player.errors, htmlBytes: window.__player.htmlBytes }));
      const deck = () => page.frames().find(f => f.url().startsWith('blob:'));
      result.frames = page.frames().map(f => f.url().slice(0, 60));
      if (deck()) {
        result.initial = await probe(deck());
        const press = async key => { await deck()?.locator('body').press(key).catch(() => {}); await sleep(450); };
        await press('ArrowRight');
        if (deck()) result.afterNext = await probe(deck());
        await press('ArrowRight'); await press('ArrowRight'); await press('ArrowRight');
        if (deck()) {
          result.atSlide3 = await probe(deck());
          result.interaction = await deck().evaluate(async () => {
            const btn = [...document.querySelectorAll('button')].find(b => /Opposite/.test(b.textContent));
            if (!btn) return 'no component button found';
            const read = () => document.querySelector('.intensity-value strong')?.textContent;
            const before = read(); btn.click(); await new Promise(r => setTimeout(r, 150));
            const styled = getComputedStyle(document.querySelector('.interference-demo')).borderRadius;
            return `intensity ${before} -> ${read()} | component scoped css border-radius=${styled}`;
          }).catch(e => 'eval error: ' + String(e).slice(0, 120));
          result.styles = await deck().evaluate(() => ({
            styleTags: document.querySelectorAll('style').length, linkTags: [...document.querySelectorAll('link')].map(l => l.rel + ' ' + (l.getAttribute('href') || '').slice(0, 60)),
            fontFamily: getComputedStyle(document.querySelector('.slidev-layout') || document.body).fontFamily.slice(0, 80),
            navControls: !!document.querySelector('.slidev-icon-btn'),
          }));
        }
        await sleep(600);
        result.playerEnd = await page.evaluate(() => ({ states: window.__player.states, errors: window.__player.errors }));
        await page.screenshot({ path: resolve(here, '../results', 'qft-' + basename(file) + '.png') }).catch(() => {});
      }
    } catch (e) { result.error = String(e.message).split('\n')[0].slice(0, 300); }
    result.console = uniq(rec.console).slice(0, 14);
    result.pageErrors = uniq(rec.pageErrors).slice(0, 8);
    result.external = uniq(external);
    results.push(result);
    console.log('\n###', file);
    console.log(JSON.stringify(result, null, 1).slice(0, 3500));
    await browser.close();
  }
} finally { server.kill(); }
await mkdir(resolve(here, '../results'), { recursive: true });
await writeFile(resolve(here, '../results/qft-player-' + Date.now() + '.json'), JSON.stringify(results, null, 2));
