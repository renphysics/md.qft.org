// E2: where can an ordinary `slidev build` output be opened from?
// Usage: node test-hosting.mjs <dir containing dist-* folders> [caseFilter]
import { spawn } from 'node:child_process';
import { writeFile, mkdir, copyFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { chromium, probe, collect, blockExternal, sleep, uniq } from './deck-probe.mjs';

const root = resolve(process.argv[2]);
const filter = process.argv[3];
const here = import.meta.dirname;
const outDir = resolve(here, '../results');
await mkdir(outDir, { recursive: true });
const D = name => resolve(root, name);

// --- servers -------------------------------------------------------------
const servers = [];
function serve(port, mounts) {
  const child = spawn(process.execPath, [resolve(here, 'static-server.mjs'), String(port), JSON.stringify(mounts)], { stdio: ['ignore', 'pipe', 'inherit'] });
  servers.push(child);
  return new Promise(r => child.stdout.once('data', r));
}
const hostDir = resolve(here, '../hostpages');
await mkdir(hostDir, { recursive: true });
await writeFile(resolve(hostDir, 'sandbox.html'), `<!doctype html><meta charset=utf-8><title>host</title><body style="margin:0">
<script>
const q = new URLSearchParams(location.search);
const f = document.createElement('iframe');
if (q.get('sandbox') !== null) f.setAttribute('sandbox', q.get('sandbox'));
f.style.cssText = 'position:fixed;inset:0;width:100%;height:100%;border:0';
f.id = 'deck';
if (q.get('mode') === 'blob') {
  fetch(q.get('src')).then(r => r.text()).then(t => { f.src = URL.createObjectURL(new Blob([t], { type: 'text/html' })); document.body.append(f); });
} else if (q.get('mode') === 'srcdoc') {
  fetch(q.get('src')).then(r => r.text()).then(t => { f.srcdoc = t; document.body.append(f); });
} else if (q.get('mode') === 'srcdoc-base') {
  fetch(q.get('src')).then(r => r.text()).then(t => { f.srcdoc = t.replace('<head>', '<head><base href="' + new URL(q.get('src'), location.href).href + '">'); document.body.append(f); });
} else if (q.get('mode') === 'srcdoc-base-shim') {
  Promise.all([fetch(q.get('src')).then(r => r.text()), fetch('shim-probe.js').then(r => r.text())]).then(([t, shim]) => {
    const s = document.createElement('script'); s.textContent = shim;
    f.srcdoc = t.replace('<head>', '<head><base href="' + new URL(q.get('src'), location.href).href + '">' + s.outerHTML);
    document.body.append(f);
  });
} else { f.src = q.get('src'); document.body.append(f); }
</script>`);
await copyFile(resolve(here, 'shim-probe.js'), resolve(hostDir, 'shim-probe.js'));
await writeFile(resolve(hostDir, 'blob-top.html'), `<!doctype html><meta charset=utf-8><title>blob opener</title><a id=go>open</a>
<script>fetch(new URLSearchParams(location.search).get('src')).then(r => r.text()).then(t => { document.getElementById('go').href = URL.createObjectURL(new Blob([t], { type: 'text/html' })); document.title = 'ready'; });</script>`);

await Promise.all([
  serve(4510, [{ prefix: '/', dir: D('dist-history-abs'), spa: true }]),
  serve(4511, [
    { prefix: '/abs-in-sub/', dir: D('dist-history-abs'), spa: true },
    { prefix: '/rel/', dir: D('dist-history-rel'), spa: true },
    { prefix: '/sub/deck/', dir: D('dist-history-sub'), spa: true },
    { prefix: '/sub-nospa/deck/', dir: D('dist-history-sub'), spa: false },
    { prefix: '/hash-abs/', dir: D('dist-hash-abs'), spa: false },
    { prefix: '/hash-rel/', dir: D('dist-hash-rel'), spa: false },
    { prefix: '/mem-rel/', dir: D('dist-memory-rel'), spa: false },
    { prefix: '/mem-abs/', dir: D('dist-memory-abs'), spa: false },
    { prefix: '/host/', dir: hostDir, spa: false },
  ]),
  serve(4512, [{ prefix: '/', dir: D('dist-history-rel'), spa: true }]),
  serve(4513, [{ prefix: '/', dir: D('dist-hash-abs'), spa: false }]),
  serve(4514, [{ prefix: '/', dir: D('dist-memory-abs'), spa: false }]),
  // 4515: same builds but with CORS headers (what GitHub Pages / most CDNs send)
  serve(4515, [
    { prefix: '/hash-rel/', dir: D('dist-hash-rel'), spa: false, cors: true },
    { prefix: '/mem-rel/', dir: D('dist-memory-rel'), spa: false, cors: true },
    { prefix: '/rel/', dir: D('dist-history-rel'), spa: true, cors: true },
    { prefix: '/host/', dir: hostDir, spa: false, cors: true },
  ]),
  serve(4516, [{ prefix: '/', dir: D('dist-history-sub'), spa: '404' }]),
]);

// --- cases ---------------------------------------------------------------
// frame: true => the deck is in iframe#deck of the host page.
const cases = [
  // 1. canonical hosting
  { id: 'http-root history abs', url: 'http://localhost:4510/' },
  { id: 'http-root history abs deep-link /3', url: 'http://localhost:4510/3' },
  { id: 'http-root history rel', url: 'http://localhost:4512/' },
  { id: 'http-root history rel deep-link /3', url: 'http://localhost:4512/3' },
  { id: 'http-root hash abs', url: 'http://localhost:4513/' },
  { id: 'http-root hash abs deep-link #/3', url: 'http://localhost:4513/#/3' },
  { id: 'http-root memory abs', url: 'http://localhost:4514/' },
  // 2. sub-path hosting
  { id: 'sub-path: history abs("/") build copied into /abs-in-sub/', url: 'http://localhost:4511/abs-in-sub/' },
  { id: 'sub-path: history rel("./") build at /rel/', url: 'http://localhost:4511/rel/' },
  { id: 'sub-path: history rel("./") build at /rel/index.html', url: 'http://localhost:4511/rel/index.html' },
  { id: 'sub-path: history base=/sub/deck/ build at /sub/deck/', url: 'http://localhost:4511/sub/deck/' },
  { id: 'sub-path: history base=/sub/deck/ deep-link /sub/deck/3 (SPA fallback on)', url: 'http://localhost:4511/sub/deck/3' },
  { id: 'sub-path: history base=/sub/deck/ deep-link /sub-nospa/deck/3 (no fallback)', url: 'http://localhost:4511/sub-nospa/deck/3' },
  { id: 'history base=/sub/deck/ build served at ROOT with 404.html fallback (wrong place)', url: 'http://localhost:4516/' },
  { id: 'sub-path: hash abs("/") build at /hash-abs/', url: 'http://localhost:4511/hash-abs/' },
  { id: 'sub-path: hash rel("./") build at /hash-rel/', url: 'http://localhost:4511/hash-rel/' },
  { id: 'sub-path: hash rel deep-link /hash-rel/#/3', url: 'http://localhost:4511/hash-rel/#/3' },
  { id: 'sub-path: hash rel at /hash-rel/index.html', url: 'http://localhost:4511/hash-rel/index.html' },
  { id: 'sub-path: memory rel("./") build at /mem-rel/', url: 'http://localhost:4511/mem-rel/' },
  { id: 'sub-path: memory abs("/") build at /mem-abs/', url: 'http://localhost:4511/mem-abs/' },
  // 3. file://
  { id: 'file:// history abs', url: pathToFileURL(D('dist-history-abs/index.html')).href },
  { id: 'file:// history rel', url: pathToFileURL(D('dist-history-rel/index.html')).href },
  { id: 'file:// hash rel', url: pathToFileURL(D('dist-hash-rel/index.html')).href },
  { id: 'file:// memory rel', url: pathToFileURL(D('dist-memory-rel/index.html')).href },
  { id: 'file:// memory rel + --allow-file-access-from-files', url: pathToFileURL(D('dist-memory-rel/index.html')).href, launchArgs: ['--allow-file-access-from-files'] },
  { id: 'file:// hash rel + --allow-file-access-from-files', url: pathToFileURL(D('dist-hash-rel/index.html')).href, launchArgs: ['--allow-file-access-from-files'] },
  // 4. blob: URL document (same origin as the creating page)
  { id: 'blob: iframe (unsandboxed) of hash-rel index.html', url: 'http://localhost:4511/host/sandbox.html?mode=blob&src=/hash-rel/index.html', frame: true },
  { id: 'blob: iframe (unsandboxed) of hash-abs index.html (host has no /assets)', url: 'http://localhost:4511/host/sandbox.html?mode=blob&src=/hash-abs/index.html', frame: true },
  { id: 'blob: top-level navigation of memory-rel index.html', url: 'http://localhost:4511/host/blob-top.html?src=/mem-rel/index.html', blobTop: true },
  { id: 'srcdoc iframe (unsandboxed) of hash-rel index.html, no <base>', url: 'http://localhost:4511/host/sandbox.html?mode=srcdoc&src=/hash-rel/index.html', frame: true },
  { id: 'srcdoc iframe (unsandboxed) of hash-rel index.html + <base href>', url: 'http://localhost:4511/host/sandbox.html?mode=srcdoc-base&src=/hash-rel/index.html', frame: true },
  { id: 'srcdoc iframe (unsandboxed) of memory-rel index.html + <base href>', url: 'http://localhost:4511/host/sandbox.html?mode=srcdoc-base&src=/mem-rel/index.html', frame: true },
  // 5. opaque-origin sandbox, deck still fetched over HTTP
  { id: 'sandbox=allow-scripts iframe src=/hash-rel/ (same host, NO CORS headers)', url: 'http://localhost:4511/host/sandbox.html?sandbox=allow-scripts&src=/hash-rel/', frame: true },
  { id: 'sandbox=allow-scripts iframe src=/hash-rel/ (CORS: ACAO *)', url: 'http://localhost:4515/host/sandbox.html?sandbox=allow-scripts&src=/hash-rel/', frame: true },
  { id: 'sandbox=allow-scripts iframe src=/mem-rel/ (CORS: ACAO *)', url: 'http://localhost:4515/host/sandbox.html?sandbox=allow-scripts&src=/mem-rel/', frame: true },
  { id: 'sandbox=allow-scripts iframe src=/rel/ history (CORS: ACAO *)', url: 'http://localhost:4515/host/sandbox.html?sandbox=allow-scripts&src=/rel/', frame: true },
  { id: 'sandbox="allow-scripts allow-same-origin" iframe src=/hash-rel/', url: 'http://localhost:4511/host/sandbox.html?sandbox=allow-scripts%20allow-same-origin&src=/hash-rel/', frame: true },
  { id: 'sandbox=allow-scripts srcdoc+<base> of memory-rel (CORS: ACAO *)', url: 'http://localhost:4515/host/sandbox.html?sandbox=allow-scripts&mode=srcdoc-base&src=/mem-rel/index.html', frame: true },
  { id: 'shim: sandbox=allow-scripts srcdoc+<base>+storage-shim of memory-rel (CORS)', url: 'http://localhost:4515/host/sandbox.html?sandbox=allow-scripts&mode=srcdoc-base-shim&src=/mem-rel/index.html', frame: true, probeExtra: true },
  { id: 'shim: sandbox=allow-scripts srcdoc+<base>+storage-shim of hash-rel (CORS)', url: 'http://localhost:4515/host/sandbox.html?sandbox=allow-scripts&mode=srcdoc-base-shim&src=/hash-rel/index.html', frame: true, probeExtra: true },
  { id: 'shim: sandbox=allow-scripts srcdoc+<base>+storage-shim of history-rel (CORS)', url: 'http://localhost:4515/host/sandbox.html?sandbox=allow-scripts&mode=srcdoc-base-shim&src=/rel/index.html', frame: true, probeExtra: true },
  { id: 'sandbox=allow-scripts blob: of memory-rel (CORS: ACAO *)', url: 'http://localhost:4515/host/sandbox.html?sandbox=allow-scripts&mode=blob&src=/mem-rel/index.html', frame: true },
];

const results = [];
try {
  for (const c of cases) {
    if (filter && !c.id.includes(filter)) continue;
    const browser = await chromium.launch({ args: c.launchArgs ?? [] });
    const context = await browser.newContext({ viewport: { width: 1280, height: 720 } });
    const external = [];
    await blockExternal(context, external);
    const page = await context.newPage();
    const rec = collect(page);
    const result = { id: c.id, url: c.url };
    try {
      await page.goto(c.url, { waitUntil: 'load', timeout: 20000 });
      if (c.blobTop) {
        await page.waitForFunction(() => document.title === 'ready', null, { timeout: 5000 });
        const href = await page.getAttribute('#go', 'href');
        await page.goto(href, { waitUntil: 'load', timeout: 20000 }).catch(e => { result.gotoError = String(e.message).split('\n')[0]; });
      }
      await sleep(1800);
      const getTarget = async () => c.frame ? (await (await page.waitForSelector('#deck', { timeout: 5000 })).contentFrame()) : page;
      let target = await getTarget();
      result.initial = await probe(target);
      if (c.probeExtra) result.extra = await target.evaluate(() => window.__probe).catch(e => String(e).slice(0, 100));
      // navigate: next slide x1 (to slide 2), then clicks, then slide 3 and use the component
      if (result.initial.pageCount > 0) {
        if (c.frame) await (await page.$('#deck')).focus();
        const press = async key => { if (c.frame) await target.locator('body').press(key).catch(() => {}); else await page.keyboard.press(key); await sleep(450); };
        await press('ArrowRight');
        result.afterNext = await probe(await getTarget());
        await press('ArrowRight'); await press('ArrowRight'); await press('ArrowRight');
        target = await getTarget();
        result.atSlide3 = await probe(target);
        // interact with the Vue component
        result.interaction = await target.evaluate(async () => {
          const btn = [...document.querySelectorAll('button')].find(b => /Opposite/.test(b.textContent));
          if (!btn) return 'no component button found';
          const read = () => document.querySelector('.intensity-value strong')?.textContent;
          const before = read(); btn.click(); await new Promise(r => setTimeout(r, 150));
          return `intensity ${before} -> ${read()}`;
        }).catch(e => 'eval error: ' + String(e).slice(0, 120));
        // reload at current URL (deep link) for top-level cases
        if (!c.frame && !c.blobTop) {
          await page.reload({ waitUntil: 'load', timeout: 20000 }).catch(e => { result.reloadError = String(e.message).split('\n')[0]; });
          await sleep(1500);
          result.afterReload = await probe(page);
        }
      }
    } catch (e) { result.error = String(e.message).split('\n')[0].slice(0, 300); }
    result.console = uniq(rec.console).slice(0, 12);
    result.pageErrors = uniq(rec.pageErrors).slice(0, 8);
    result.failed = uniq(rec.failed).slice(0, 12);
    result.badStatus = uniq(rec.badStatus).slice(0, 12);
    result.external = uniq(external);
    results.push(result);
    const deep = /deep-link/.test(c.id);
    const ok = (deep ? result.initial?.h1?.includes('Try it') : result.atSlide3?.h1?.includes('Try it')) && /-> 0\.00/.test(result.interaction ?? '');
    result.pass = !!ok;
    const s = v => v ? `${v.href?.replace(/^file:\/\/.*\/(dist-[^/]+)/, 'file://…/$1')} pages=${v.pageCount} shown=${v.shownPages} h1=${JSON.stringify(v.h1)}${v.text404 ? ' [404-text]' : ''}${v.storage && v.storage !== 'ok' ? ' storage=' + v.storage : ''}${v.evalError ? ' EVALERR ' + v.evalError : ''}` : '-';
    console.log(`\n### ${ok ? 'PASS' : 'FAIL'} :: ${c.id}`);
    console.log('  initial   :', s(result.initial));
    if (result.afterNext) console.log('  afterNext :', s(result.afterNext));
    if (result.atSlide3) console.log('  atSlide3  :', s(result.atSlide3), '|', result.interaction);
    if (result.afterReload) console.log('  afterReload:', s(result.afterReload));
    for (const k of ['error', 'gotoError', 'reloadError']) if (result[k]) console.log(`  ${k}:`, result[k]);
    for (const k of ['pageErrors', 'console', 'failed', 'badStatus']) if (result[k].length) console.log(`  ${k}:`, JSON.stringify(result[k].slice(0, 5), null, 0).slice(0, 900));
    await browser.close();
  }
} finally {
  for (const s of servers) s.kill();
}
await writeFile(resolve(outDir, 'hosting' + (filter ? '-' + filter.replace(/\W+/g, '_') : '') + '.json'), JSON.stringify(results, null, 2));
console.log('\nexternal requests seen across cases:', uniq(results.flatMap(r => r.external)));
