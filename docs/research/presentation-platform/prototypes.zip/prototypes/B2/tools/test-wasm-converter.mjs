// In-browser conversion of ordinary Slidev builds (esbuild-wasm inside a Worker, under the site's CSP),
// then playback in the md.qft.org sandbox replica.
import { spawn } from 'node:child_process';
import { resolve } from 'node:path';
import { writeFile } from 'node:fs/promises';
import { chromium, probe, sleep, uniq } from './deck-probe.mjs';
const [site, port, ...names] = process.argv.slice(2);
const here = import.meta.dirname;
const server = spawn(process.execPath, [resolve(here, 'static-server.mjs'), port, JSON.stringify([{ prefix: '/', dir: resolve(site), spa: false }])], { stdio: ['ignore', 'pipe', 'inherit'] });
await new Promise(r => server.stdout.once('data', r));
const browser = await chromium.launch();
const all = [];
try {
  const context = await browser.newContext({ viewport: { width: 1280, height: 720 } });
  const external = []; await context.route(url => !/^(?:http:\/\/localhost|blob:|data:|about:)/.test(url.href), route => { external.push(route.request().url().slice(0, 100)); return route.abort(); });
  const page = await context.newPage();
  const logs = []; page.on('console', m => { if (m.type() === 'error') logs.push(m.text().slice(0, 260)); }); page.on('pageerror', e => logs.push('[pageerror] ' + String(e.message).slice(0, 200)));
  const t0 = Date.now();
  await page.goto(`http://localhost:${port}/index.html`, { waitUntil: 'load' });
  await page.waitForFunction(() => window.__app?.ready, null, { timeout: 60000 });
  const init = await page.evaluate(() => window.__app.init);
  console.log('worker init:', JSON.stringify(init), 'page ready after', Date.now() - t0, 'ms');
  for (const name of names) {
    const run = await page.evaluate(name => window.__convertAndPlay(name).catch(e => ({ error: String(e.message) })), name);
    if (run.error) { console.log(`\n## ${name}: ERROR ${run.error}`); all.push({ name, ...run }); continue; }
    await sleep(700);
    const deck = () => page.frames().find(f => f.url().startsWith('blob:'));
    const result = { name, ...run };
    if (deck()) {
      result.initial = await probe(deck());
      for (let i = 0; i < 4; i++) { await deck()?.locator('body').press('ArrowRight').catch(() => {}); await sleep(400); }
      if (deck()) {
        result.atSlide3 = await probe(deck());
        result.interaction = await deck().evaluate(async () => { const btn = [...document.querySelectorAll('button')].find(b => /Opposite/.test(b.textContent)); if (!btn) return 'no button'; const read = () => document.querySelector('.intensity-value strong')?.textContent; const before = read(); btn.click(); await new Promise(r => setTimeout(r, 150)); return `intensity ${before} -> ${read()} | border-radius=${getComputedStyle(document.querySelector('.interference-demo')).borderRadius} | katexFont=${document.fonts ? [...document.fonts].filter(f => /KaTeX/.test(f.family) && f.status === 'loaded').length : '?'}`; }).catch(e => 'eval error ' + String(e).slice(0, 100));
      }
    }
    result.end = await page.evaluate(() => ({ states: window.__app.playerStates, errors: window.__app.playerErrors }));
    all.push(result);
    console.log(`\n## ${name}`);
    console.log('   report:', JSON.stringify({ ...run.report, bundleMs: Math.round(run.report.bundleMs), totalMs: Math.round(run.report.totalMs) }));
    console.log(`   load ${Math.round(run.loadMs)} ms, convert ${Math.round(run.report.totalMs)} ms (bundle ${Math.round(run.report.bundleMs)} ms), boot ${Math.round(run.bootMs)} ms, html ${(run.htmlBytes / 1048576).toFixed(2)} MB`);
    console.log('   player:', result.end.states.join(' > '), JSON.stringify(result.end.errors), '| initial h1:', JSON.stringify(result.initial?.h1), '| slide3 h1:', JSON.stringify(result.atSlide3?.h1), '|', result.interaction);
  }
  console.log('\nconsole errors:', uniq(logs).slice(0, 6), '| external:', uniq(external));
} finally { await browser.close(); server.kill(); }
await writeFile(resolve(here, '../results/wasm-converter.json'), JSON.stringify(all, null, 1));
