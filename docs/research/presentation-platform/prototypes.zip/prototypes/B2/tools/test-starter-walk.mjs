// Walk every slide of a built deck over HTTP and record external requests, workers, errors.
// Usage: node test-starter-walk.mjs <dist> <port> <slideCount> [--allow-external]
import { spawn } from 'node:child_process';
import { resolve } from 'node:path';
import { writeFile } from 'node:fs/promises';
import { chromium, sleep, uniq } from './deck-probe.mjs';
const [dist, port, countArg, flag] = process.argv.slice(2);
const here = import.meta.dirname;
const server = spawn(process.execPath, [resolve(here, 'static-server.mjs'), port, JSON.stringify([{ prefix: '/', dir: resolve(dist), spa: true }])], { stdio: ['ignore', 'pipe', 'inherit'] });
await new Promise(r => server.stdout.once('data', r));
const browser = await chromium.launch();
const out = { slides: [] };
try {
  const context = await browser.newContext({ viewport: { width: 1280, height: 720 } });
  const external = []; const local = [];
  await context.route('**/*', route => {
    const u = route.request().url();
    if (/^https?:\/\/localhost/.test(u)) { local.push(u); return route.continue(); }
    if (/^(?:blob:|data:)/.test(u)) return route.continue();
    external.push(route.request().resourceType() + ' ' + u.slice(0, 160));
    return flag === '--allow-external' ? route.continue() : route.abort('blockedbyclient');
  });
  const page = await context.newPage();
  const workers = []; page.on('worker', w => workers.push(w.url().slice(0, 120)));
  const errors = []; page.on('pageerror', e => errors.push(String(e.message).slice(0, 200)));
  const consoleErrors = []; page.on('console', m => { if (m.type() === 'error') consoleErrors.push(m.text().slice(0, 200)); });
  for (let no = 1; no <= Number(countArg); no++) {
    const e0 = external.length, w0 = workers.length, l0 = local.length, x0 = errors.length;
    await page.goto(`http://localhost:${port}/${no}`, { waitUntil: 'load', timeout: 30000 });
    await sleep(1500);
    const info = await page.evaluate(() => {
      const cur = [...document.querySelectorAll('.slidev-page')].find(p => { let e = p; while (e && e !== document.body) { if (getComputedStyle(e).display === 'none') return false; e = e.parentElement; } return true; });
      return { h1: cur?.querySelector('h1,h2')?.textContent.trim().slice(0, 50) ?? null, iframes: cur ? cur.querySelectorAll('iframe').length : 0, imgs: cur ? [...cur.querySelectorAll('img')].map(i => i.getAttribute('src')?.slice(0, 80)) : [], monaco: cur ? cur.querySelectorAll('.monaco-editor').length : 0, svg: cur ? cur.querySelectorAll('svg').length : 0 };
    });
    out.slides.push({ no, ...info, newExternal: uniq(external.slice(e0)), newWorkers: workers.slice(w0), localRequests: local.length - l0, errors: errors.slice(x0) });
  }
  out.allExternal = uniq(external); out.workers = uniq(workers); out.consoleErrors = uniq(consoleErrors).slice(0, 15);
  out.localFilesRequested = uniq(local).length;
  out.localBytesNote = 'see dist size';
} finally { await browser.close(); server.kill(); }
await writeFile(resolve(here, '../results/starter-walk.json'), JSON.stringify(out, null, 1));
for (const s of out.slides) console.log(String(s.no).padStart(2), JSON.stringify(s.h1), 'ext=' + s.newExternal.length, 'workers=' + s.newWorkers.length, 'monaco=' + s.monaco, 'iframes=' + s.iframes, s.errors.length ? 'ERR ' + JSON.stringify(s.errors) : '', s.newExternal.length ? '\n     ' + s.newExternal.join('\n     ') : '', s.newWorkers.length ? '\n     W: ' + s.newWorkers.join('\n     W: ') : '');
console.log('\nALL EXTERNAL:\n' + out.allExternal.join('\n')); console.log('\nWORKERS:', out.workers); console.log('local files requested:', out.localFilesRequested); console.log('console errors:', out.consoleErrors);
