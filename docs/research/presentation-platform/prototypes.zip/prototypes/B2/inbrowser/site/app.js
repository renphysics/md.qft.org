// Host page logic: load project files -> compile in the browser -> play in the md.qft.org sandbox replica.
import { createPresentationPlayer } from './presentation-runtime.js';
import { compileDeck, versions } from './compiler/compiler.js';

const state = window.__app = { versions, runs: [], player: null, playerStates: [], playerErrors: [], ready: false };
let clientHtml;

async function loadFiles(deck) {
  const manifest = await (await fetch(`decks/${deck}/manifest.json`)).json();
  const files = {};
  await Promise.all(manifest.map(async path => {
    const response = await fetch(`decks/${deck}/${path}`);
    files[path] = /\.(?:png|jpe?g|gif|webp|avif|woff2?)$/i.test(path) ? new Uint8Array(await response.arrayBuffer()) : await response.text();
  }));
  return files;
}

function buildPlayerHtml(result) {
  // Deck CSS and deck script go in front of the client's own inline scripts.
  const safe = result.script.replace(/<\/script/gi, '<\\/script');
  const css = result.css.replace(/<\/style/gi, '<\\/style');
  return clientHtml.replace('<body>', `<body><style data-qft-deck>${css}</style><script>${safe}</script>`);
}

window.__compileAndPlay = async function (files) {
  clientHtml ??= await (await fetch('generic-client.html')).text();
  const t0 = performance.now();
  const result = await compileDeck(files);
  const compileMs = performance.now() - t0;
  const html = buildPlayerHtml(result);
  state.playerStates = []; state.playerErrors = [];
  state.player?.destroy();
  const t1 = performance.now();
  await new Promise(resolve => {
    state.player = createPresentationPlayer(document.getElementById('host'), html, {
      title: result.info.title || 'deck', sandboxUrl: './presentation-sandbox.html',
      onState: s => { state.playerStates.push(s); if (s === 'ready' || s === 'error') resolve(); },
      onError: m => { state.playerErrors.push(m); },
    });
    state.player.start();
    setTimeout(resolve, 20000);
  });
  const run = { compileMs, bootMs: performance.now() - t1, htmlBytes: html.length, info: result.info, timings: result.timings, diagnostics: result.diagnostics, playerStates: [...state.playerStates], playerErrors: [...state.playerErrors] };
  state.runs.push(run);
  return run;
};

window.__compileOnly = async function (files) {
  clientHtml ??= await (await fetch('generic-client.html')).text();
  const t0 = performance.now();
  const result = await compileDeck(files);
  return { compileMs: performance.now() - t0, html: buildPlayerHtml(result), info: result.info, timings: result.timings, diagnostics: result.diagnostics, scriptBytes: result.script.length, cssBytes: result.css.length };
};
window.__loadFiles = loadFiles;
state.ready = true;
