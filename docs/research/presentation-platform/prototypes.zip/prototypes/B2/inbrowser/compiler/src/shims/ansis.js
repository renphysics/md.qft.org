const id = s => s
export const yellow = id, red = id, bold = id, gray = id, white = id, green = id, blue = id, cyan = id, dim = id
export default { yellow, red, bold, gray, white, green, blue, cyan, dim }
