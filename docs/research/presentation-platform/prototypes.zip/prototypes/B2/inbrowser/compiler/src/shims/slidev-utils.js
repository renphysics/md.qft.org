// Stand-in for packages/slidev/node/utils.ts (the real file pulls in jiti, node:crypto and the resolver).
import { relative, isAbsolute, resolve } from 'pathe'
export function isPathInsideRoots(filePath, roots) {
  return roots.some((root) => { const rel = relative(resolve(root), resolve(filePath)); return rel === '' || (!!rel && !rel.startsWith('..') && !isAbsolute(rel)) })
}
