// Bundle the browser compiler with esbuild. Usage: node build.mjs
import { createRequire } from 'node:module';
import { resolve } from 'node:path';
import { rm, readdir, stat, readFile, writeFile } from 'node:fs/promises';
import { gzipSync, brotliCompressSync } from 'node:zlib';
const here = import.meta.dirname;
const toolsRequire = createRequire(resolve(here, '../../tools/package.json'));
const { build } = toolsRequire('esbuild');
const upstream = resolve(here, '../../upstream-src/packages');
const deps = resolve(here, '../generic-client/node_modules');
const shim = name => resolve(here, 'src/shims', name);
const outdir = resolve(here, 'dist');
await rm(outdir, { recursive: true, force: true });
const version = JSON.parse(await readFile(resolve(deps, '@slidev/cli/package.json'), 'utf8')).version;

const aliasPlugin = {
  name: 'b2-alias',
  setup(b) {
    b.onResolve({ filter: /^@upstream\/slidev\// }, a => ({ path: resolve(upstream, 'slidev', a.path.slice('@upstream/slidev/'.length)) }));
    b.onResolve({ filter: /^node:fs(?:\/promises)?$|^fs$/ }, () => ({ path: shim('fs.js') }));
    b.onResolve({ filter: /^ansis$/ }, () => ({ path: shim('ansis.js') }));
    b.onResolve({ filter: /^unocss$/ }, () => ({ path: shim('unocss.js') }));
    b.onResolve({ filter: /^@shikijs\/vitepress-twoslash$/ }, () => ({ path: shim('twoslash.js') }));
    b.onResolve({ filter: /^markdown-it\/lib\/token\.js$/ }, () => ({ path: resolve(deps, 'markdown-it/lib/token.mjs') }));
    // Node-only neighbours of the syntax plugins
    b.onResolve({ filter: /^\.\.\/utils$/ }, a => a.importer.includes('/slidev/node/syntax') && !a.importer.includes('/codeblock/') ? { path: shim('slidev-utils.js') } : null);
    b.onResolve({ filter: /^\.\.\/vite\/monacoWrite$/ }, () => ({ path: shim('monaco-write.js') }));
  },
};
const result = await build({
  entryPoints: { compiler: resolve(here, 'src/index.js') },
  bundle: true, format: 'esm', platform: 'browser', target: 'es2022', splitting: true, outdir, minify: true, metafile: true,
  chunkNames: 'chunks/[name]-[hash]', legalComments: 'none', logLevel: 'warning',
  nodePaths: [deps, resolve(here, '../../tools/node_modules')],
  mainFields: ['browser', 'module', 'main'], conditions: ['browser', 'import', 'module', 'default', 'production'],
  define: { 'process.env.NODE_ENV': '"production"', __SLIDEV_VERSION__: JSON.stringify(version), 'process.env.DEBUG': 'undefined', global: 'globalThis' },
  plugins: [aliasPlugin],
});
// size report: entry + its static imports (always loaded) vs lazy chunks
const outputs = result.metafile.outputs;
const rel = p => p.slice(p.indexOf('dist/') + 5);
const entryKey = Object.keys(outputs).find(k => k.endsWith('dist/compiler.js'));
const eager = new Set();
(function walk(k) { if (eager.has(k)) return; eager.add(k); for (const i of outputs[k].imports) if (i.kind === 'import-statement') walk(i.path); })(entryKey);
let eagerBytes = 0, eagerGz = 0, eagerBr = 0, lazyBytes = 0, lazyCount = 0;
for (const k of Object.keys(outputs)) {
  const file = resolve(here, k.slice(k.indexOf('dist/')));
  const buf = await readFile(file);
  if (eager.has(k)) { eagerBytes += buf.length; eagerGz += gzipSync(buf, { level: 9 }).length; eagerBr += brotliCompressSync(buf).length; }
  else { lazyBytes += buf.length; lazyCount++; }
}
// contribution of each package to the eager part
const byPkg = {};
for (const k of eager) for (const [input, info] of Object.entries(outputs[k].inputs)) {
  const m = input.match(/node_modules\/((?:@[^/]+\/)?[^/]+)/); const name = m ? m[1] : input.includes('upstream-src') ? '(upstream @slidev/cli syntax sources)' : '(prototype glue + shims)';
  byPkg[name] = (byPkg[name] || 0) + info.bytesInOutput;
}
const report = { slidevVersion: version, eager: { files: eager.size, bytes: eagerBytes, gzip: eagerGz, brotli: eagerBr }, lazy: { files: lazyCount, bytes: lazyBytes }, byPackage: Object.fromEntries(Object.entries(byPkg).sort((a, b) => b[1] - a[1]).slice(0, 28)) };
await writeFile(resolve(outdir, 'size-report.json'), JSON.stringify(report, null, 1));
console.log(JSON.stringify(report, null, 1));
