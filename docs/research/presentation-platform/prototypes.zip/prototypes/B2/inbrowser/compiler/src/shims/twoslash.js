// TwoSlash needs the TypeScript language service (+ lib .d.ts files); not available in this prototype.
export function transformerTwoslash() { throw new Error('twoslash is not available in the browser compiler') }
