// Prototype: a Slidev-compatible deck compiler that runs in the browser (no Node, no eval, no WebAssembly).
//
//   files of an uploaded Slidev *source* project  ->  one classic <script> text + one CSS text
//
// The output is consumed by the prebuilt "generic client" (../generic-client), a real `slidev build`
// whose slide list is filled in at runtime (globalThis.__QFT_DECK__).
//
// Reused from upstream, unmodified:
//   @slidev/parser/fs                      (slides.md -> slides, incl. `src:` imports; node:fs aliased to a VFS)
//   @slidev/cli  node/syntax/**            (all Slidev markdown-it plugins; bundled from the v53.1.0 TS sources)
//   @slidev/client/uno.config.ts           (UnoCSS config)
// Re-implemented here (thin):
//   unplugin-vue-markdown's createMarkdown, Slidev's layoutWrapper/contextInjection/loaders,
//   @vitejs/plugin-vue (via @vue/compiler-sfc) + TypeScript stripping + module linking (sucrase -> CommonJS registry),
//   unplugin-vue-components (global registration by file name), UnoCSS build step (runtime generator).
import * as parser from '@slidev/parser/fs'
import { createMarkdownExit } from 'markdown-exit'
import { componentPlugin } from '@mdit-vue/plugin-component'
import { useMarkdownItPlugins } from '@upstream/slidev/node/syntax/index.ts'
import { createBundledHighlighter, createSingletonShorthands } from 'shiki/core'
import { createJavaScriptRegexEngine } from 'shiki/engine/javascript'
import { bundledLanguages, bundledThemes } from 'shiki'
import * as sfc from '@vue/compiler-sfc'
import { transform as sucrase } from 'sucrase'
import { createGenerator } from '@unocss/core'
import slidevUnoConfig from '@slidev/client/uno.config.ts'
import unoSafelist from '@slidev/client/.generated/unocss-tokens.ts'
import { dirname, resolve as resolvePath, extname } from 'pathe'
import { vfs } from './shims/fs.js'

export const versions = { slidev: __SLIDEV_VERSION__, vue: sfc.version }

const ROOT = '/deck'
const MATHML = new Set('annotation math menclose mfrac mglyph mi mlabeledtr mn mo mover mpadded mphantom mroot mrow mspace msqrt mstyle msub msubsup msup mtable mtd mtext mtr munder munderover semantics'.split(' '))
const hash = (s) => { let h = 0x811c9dc5; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193) } return (h >>> 0).toString(16).padStart(8, '0') }
const scriptSetupRE = /<\s*script([^>]*)\bsetup\b([^>]*)>([\s\S]*?)<\/script>/g
const styleBlockRE = /<style[^>]*>[^<]*<\/style>/gm

let highlighter
function setupShiki() {
  // Same construction as packages/slidev/node/setups/shiki.ts; grammars are lazy chunks.
  highlighter ??= createSingletonShorthands(createBundledHighlighter({ engine: createJavaScriptRegexEngine, langs: bundledLanguages, themes: bundledThemes }))
  return { shiki: highlighter, shikiOptions: { themes: { dark: 'vitesse-dark', light: 'vitesse-light' }, defaultColor: false } }
}

/** unplugin-vue-markdown's createMarkdown + Slidev's createMarkdownPlugin options. */
async function createSlideMarkdown(options) {
  const md = createMarkdownExit({ html: true, linkify: true, typographer: true, quotes: '""\'\'', xhtmlOut: true })
  md.use(componentPlugin, {})
  md.linkify.set({ fuzzyLink: true })
  await useMarkdownItPlugins(md, options, new Map(), [])
  return async (id, raw) => {
    let html = await md.renderAsync(raw.trimStart(), { id })
    html = `<div>${html}</div>`
    const scripts = []
    html = html.replace(scriptSetupRE, (_, a1, a2, code) => { scripts.push({ code, attr: `${a1} ${a2}`.trim() }); return '' })
    const styles = []
    html = html.replace(styleBlockRE, (code) => { styles.push(code); return '' })
    return { html, scripts, styles }
  }
}

/** Slidev's layoutWrapper: wrap the slide body in its layout and inject the slide context. */
function slideToSfc({ html, scripts, styles }, index, layoutName) {
  let body = html.trim()
  if (body.startsWith('<div>') && body.endsWith('</div>')) body = body.slice(5, -6)
  const attrs = [...new Set(scripts.map(s => s.attr))].join(' ').trim()
  return [
    `<template><InjectedLayout v-bind="_frontmatterToProps($frontmatter,${index})">\n${body}\n</InjectedLayout></template>`,
    `<script setup${attrs ? ' ' + attrs : ''}>`,
    `import InjectedLayout from ${JSON.stringify('#slidev-layout/' + layoutName)}`,
    `import { useSlideContext as _useSlideContext, frontmatterToProps as _frontmatterToProps } from "@slidev/client/context.ts"`,
    `const { $slidev, $nav, $clicksContext, $clicks, $page, $renderContext, $frontmatter } = _useSlideContext()`,
    `$clicksContext.setup()`,
    ...scripts.map(s => s.code),
    `</script>`,
    ...styles,
  ].join('\n')
}

/** Slidev's contextInjection for user .vue files that use <script setup>. */
function injectContext(code) {
  if (code.includes('useSlideContext()')) return code
  const m = /<script([^>]*)setup([^>]*)>/.exec(code)
  const inject = `\nimport { useSlideContext as _useSlideContext, frontmatterToProps as _frontmatterToProps } from "@slidev/client/context.ts"\nconst { $slidev, $nav, $clicksContext, $clicks, $page, $renderContext, $frontmatter } = _useSlideContext()\n`
  if (m) return code.slice(0, m.index + m[0].length) + inject + code.slice(m.index + m[0].length)
  if (!/<script/.test(code)) return `<script setup>${inject}</script>\n${code}`
  return code // options-API components: left alone in this prototype
}

/** @vitejs/plugin-vue equivalent: SFC -> CommonJS-style module body + CSS. */
function compileSfc(id, source, diagnostics) {
  const { descriptor, errors } = sfc.parse(source, { filename: id })
  for (const e of errors) diagnostics.push({ id, message: String(e.message || e) })
  const scopeHash = hash(id)
  const scoped = descriptor.styles.some(s => s.scoped)
  const compilerOptions = { isCustomElement: tag => MATHML.has(tag) }
  let code
  if (descriptor.script || descriptor.scriptSetup) {
    const script = sfc.compileScript(descriptor, { id: scopeHash, inlineTemplate: true, genDefaultAs: '__sfc__', templateOptions: { compilerOptions, transformAssetUrls: { includeAbsolute: true } } })
    code = script.content + `\n${scoped ? `__sfc__.__scopeId = "data-v-${scopeHash}"\n` : ''}__sfc__.__file = ${JSON.stringify(id)}\nexport default __sfc__\n`
  }
  else {
    const t = sfc.compileTemplate({ source: descriptor.template?.content ?? '', filename: id, id: scopeHash, scoped, compilerOptions })
    for (const e of t.errors) diagnostics.push({ id, message: String(e.message || e) })
    code = t.code + `\nexport default { render${scoped ? `, __scopeId: "data-v-${scopeHash}"` : ''} }\n`
  }
  let css = ''
  for (const style of descriptor.styles) {
    if (style.lang && style.lang !== 'css' && style.lang !== 'postcss') { diagnostics.push({ id, message: `<style lang="${style.lang}"> is not supported in the browser compiler` }); continue }
    const result = sfc.compileStyle({ source: style.content, filename: id, id: scopeHash, scoped: !!style.scoped })
    for (const e of result.errors) diagnostics.push({ id, message: String(e.message || e) })
    css += result.code + '\n'
  }
  return { code, css }
}

/** TypeScript + ESM -> a function body that runs in a classic inline <script>. */
function toModuleBody(id, code, diagnostics) {
  code = code.replace(/\bimport\.meta\.env\b/g, '({BASE_URL:"/",MODE:"production",DEV:false,PROD:true,SSR:false})').replace(/\bimport\.meta\.hot\b/g, 'undefined')
  try { return sucrase(code, { transforms: ['typescript', 'imports'], filePath: id, production: true }).code }
  catch (e) { diagnostics.push({ id, message: 'script transform failed: ' + e.message }); return `throw new Error(${JSON.stringify('compile error in ' + id + ': ' + e.message)})` }
}

const ASSET_MIME = { '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.svg': 'image/svg+xml', '.webp': 'image/webp', '.avif': 'image/avif', '.mp4': 'video/mp4', '.webm': 'video/webm', '.mp3': 'audio/mpeg' }
function toDataUri(path, mime) {
  const value = vfs.files.get(path)
  const bytes = typeof value === 'string' ? new TextEncoder().encode(value) : value
  let binary = ''
  for (let i = 0; i < bytes.length; i += 0x8000) binary += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000))
  return `data:${mime};base64,${btoa(binary)}`
}
const pascal = name => name.replace(/(^|[-_])(\w)/g, (_, __, c) => c.toUpperCase())

/**
 * @param {Record<string, string | Uint8Array>} files  project files, keys relative to the project root
 * @param {{ entry?: string }} [opts]
 */
export async function compileDeck(files, opts = {}) {
  const t0 = performance.now()
  const diagnostics = []
  const timings = {}
  vfs.reset(); vfs.mount(ROOT, files)
  const entry = `${ROOT}/${opts.entry ?? 'slides.md'}`

  // 1. parse (upstream parser, including `src:` imports)
  const data = await parser.load({ userRoot: ROOT, roots: [ROOT], allowedRoots: [ROOT] }, entry, undefined, 'build')
  const config = parser.resolveConfig(data.headmatter, {}, entry)
  for (const md of Object.values(data.markdownFiles)) for (const e of md.errors ?? []) diagnostics.push({ id: md.filepath, message: e.message })
  const unsupported = []
  if (config.twoslash) { config.twoslash = false; if (/\btwoslash\b/.test(data.entry.raw)) unsupported.push('twoslash') }
  if (data.features.monaco) unsupported.push('monaco')
  if (data.features.mermaid) unsupported.push('mermaid (needs the mermaid chunk in the client)')
  if (config.theme && !['default', 'none'].includes(config.theme)) unsupported.push(`theme "${config.theme}" (prototype ships the default theme only)`)
  if ((config.addons ?? []).length) unsupported.push('addons: ' + config.addons.join(', '))
  timings.parse = performance.now() - t0

  // 2. markdown -> html (upstream plugins) -> SFC text
  const t1 = performance.now()
  const options = { data: { ...data, config }, mode: 'build', userRoot: ROOT, userWorkspaceRoot: ROOT, roots: [ROOT], utils: { ...setupShiki(), katexOptions: { strict: false } } }
  const renderSlide = await createSlideMarkdown(options)
  const modules = {} // id -> function body
  let css = ''
  const allSources = [] // for UnoCSS extraction
  const slides = []
  const defaults = data.headmatter.defaults ?? {}
  for (let i = 0; i < data.slides.length; i++) {
    const slide = data.slides[i]
    const id = `${slide.source.filepath}__slidev_${i + 1}.md`
    try {
      const parts = await renderSlide(id, slide.content)
      const layoutName = (slide.frontmatter?.layout ?? defaults.layout) || (i === 0 ? 'cover' : 'default')
      const sfcText = slideToSfc(parts, i, layoutName)
      allSources.push(sfcText)
      const compiled = compileSfc(id, sfcText, diagnostics)
      modules[id] = toModuleBody(id, compiled.code, diagnostics)
      css += compiled.css
    }
    catch (e) {
      diagnostics.push({ id, message: 'slide failed to compile: ' + (e.message || e) })
      modules[id] = `throw new Error(${JSON.stringify(String(e.message || e))})`
    }
    slides.push({ id, frontmatter: slide.frontmatter ?? {}, info: { title: slide.title, level: slide.level, index: i, note: '', noteHTML: '', revision: slide.revision, images: slide.images } })
  }
  timings.slides = performance.now() - t1

  // 3. user modules: components/**/*.vue are auto-registered; other local modules are linked on demand
  const t2 = performance.now()
  const components = {}
  const assets = {}
  for (const path of vfs.list(ROOT)) {
    const ext = extname(path)
    if (path.includes('/node_modules/') || path.includes('/dist/')) continue
    if (ext === '.vue') {
      const source = injectContext(vfs.text(path))
      allSources.push(source)
      const compiled = compileSfc(path, source, diagnostics)
      modules[path] = toModuleBody(path, compiled.code, diagnostics)
      css += compiled.css
      if (path.startsWith(`${ROOT}/components/`)) components[pascal(path.split('/').pop().replace(/\.vue$/, ''))] = path
    }
    else if (/^\.(?:[cm]?[jt]s)$/.test(ext) && !/\.d\.ts$/.test(path) && !/(?:^|\/)(?:vite|uno|unocss)\.config\.|\/setup\//.test(path)) {
      modules[path] = toModuleBody(path, vfs.text(path), diagnostics)
    }
    else if (ext === '.json') modules[path] = `module.exports = ${vfs.text(path)}; module.exports.default = module.exports`
    else if (ext === '.css' && /\/styles?(?:\/index)?\.css$|\/style\.css$/.test(path)) css += vfs.text(path) + '\n'
    else if (ASSET_MIME[ext]) {
      // Vite would emit the file and export its URL; in a sandbox without network the URL is a data: URI.
      const url = toDataUri(path, ASSET_MIME[ext])
      assets[path] = url
      modules[path] = `module.exports = { __esModule: true, default: ${JSON.stringify(url)} }`
    }
  }
  // frontmatter URLs (background/image) are resolved at runtime by layouts: point them at the embedded data
  for (const slide of slides) {
    for (const key of ['image', 'backgroundImage', 'background']) {
      const value = slide.frontmatter[key]
      if (typeof value !== 'string' || !/^\.{0,2}\//.test(value)) continue
      const hit = assets[value.startsWith('/') ? `${ROOT}/public${value}` : resolvePath(ROOT, value)]
      if (hit) slide.frontmatter = { ...slide.frontmatter, [key]: hit }
    }
  }
  for (const path of ['vite.config.ts', 'vite.config.js', 'uno.config.ts', 'unocss.config.ts'].map(p => `${ROOT}/${p}`)) if (vfs.files.has(path)) unsupported.push(path.slice(ROOT.length + 1) + ' is ignored')
  if (vfs.list(`${ROOT}/setup`).length) unsupported.push('setup/*.ts files are ignored')
  if (vfs.list(`${ROOT}/layouts`).length) unsupported.push('layouts/*.vue (custom layouts) are not wired up in the prototype')
  timings.components = performance.now() - t2

  // 4. UnoCSS: generate the utilities used by the deck (the client CSS only contains its own)
  const t3 = performance.now()
  const uno = await createGenerator({ ...slidevUnoConfig, safelist: [] })
  const generated = await uno.generate(allSources.join('\n'), { preflights: false })
  timings.unocss = performance.now() - t3

  // 5. emit: one classic script, evaluated before the client boots
  const t4 = performance.now()
  const moduleTable = Object.entries(modules).map(([id, body]) => `${JSON.stringify(id)}: function (require, module, exports) {\n${body}\n}`).join(',\n')
  const script = `(function () {
"use strict";
var defs = {\n${moduleTable}\n};
var cache = Object.create(null);
var exts = ["", ".ts", ".js", ".mjs", ".vue", ".json", "/index.ts", "/index.js"];
function dirname(p) { return p.slice(0, p.lastIndexOf("/")) }
function join(base, rel) { var out = base.split("/"); rel.split("/").forEach(function (s) { if (s === "..") out.pop(); else if (s && s !== ".") out.push(s) }); return out.join("/") }
function load(host, id) {
  if (cache[id]) return cache[id].exports;
  var module = cache[id] = { exports: {} };
  defs[id](function (spec) { return req(host, id, spec) }, module, module.exports);
  return module.exports;
}
function req(host, from, spec) {
  if (host.modules[spec]) return host.modules[spec];
  if (spec.indexOf("#slidev-layout/") === 0) { var name = spec.slice(15); return { __esModule: true, default: host.layouts[name] || host.layouts["default"] } }
  if (spec[0] === "." || spec[0] === "/" || spec.indexOf("@/") === 0) {
    var base = spec[0] === "." ? join(dirname(from.replace(/__slidev_\\d+\\.md$/, "")), spec) : ${JSON.stringify(ROOT)} + "/" + spec.replace(/^@?\\//, "");
    for (var i = 0; i < exts.length; i++) if (defs[base + exts[i]]) return load(host, base + exts[i]);
    if (spec[0] === "/") { var pub = ${JSON.stringify(ROOT)} + "/public" + spec; if (defs[pub]) return load(host, pub); }
  }
  throw new Error("Cannot resolve module \\"" + spec + "\\" imported by " + from.replace(${JSON.stringify(ROOT + '/')}, "") + " (npm dependencies are not available in the browser player)");
}
var deck = ${JSON.stringify({ config: pickConfig(config), defaults, components })};
deck.slides = ${JSON.stringify(slides)}.map(function (s) { s.component = function (host) { return load(host, s.id)["default"] }; return s });
var host = globalThis.__QFT_SLIDEV__ = globalThis.__QFT_SLIDEV__ || {};
host.onAppReady = function (app) { Object.keys(deck.components).forEach(function (name) { app.component(name, load(host, deck.components[name])["default"]) }) };
globalThis.__QFT_DECK__ = deck;
})();`
  timings.emit = performance.now() - t4
  timings.total = performance.now() - t0
  return {
    script, css: css + '\n/* unocss (generated in the browser) */\n' + generated.css,
    info: { slides: slides.length, title: config.title, modules: Object.keys(modules).length, components: Object.keys(components), unoRules: generated.matched.size, unsupported, features: data.features, scriptBytes: script.length, cssBytes: css.length + generated.css.length },
    diagnostics, timings,
  }
}

/** Deck-level options the prebuilt client may take over at runtime (features baked in at client build time are not listed). */
function pickConfig(config) {
  const keys = ['title', 'titleTemplate', 'aspectRatio', 'canvasWidth', 'transition', 'clickAnimation', 'colorSchema', 'selectable', 'themeConfig', 'lineNumbers', 'codeCopy', 'magicMoveCopy', 'magicMoveDuration', 'info', 'author', 'duration', 'timer', 'htmlAttrs']
  const out = {}
  for (const k of keys) if (config[k] !== undefined) out[k] = config[k]
  out.slidesTitle = (config.titleTemplate || '%s').replace('%s', config.title || 'Slidev')
  return out
}
