// In-memory replacement for node:fs / node:fs/promises, backed by the files of the uploaded ZIP.
// Only what @slidev/parser/fs and @slidev/cli's snippet plugin call.
const files = new Map() // absolute posix path -> string | Uint8Array
const decoder = new TextDecoder()
const norm = p => { const out = []; for (const part of String(p).split('/')) { if (part === '..') out.pop(); else if (part && part !== '.') out.push(part) } return '/' + out.join('/') }
export const vfs = {
  files,
  reset() { files.clear() },
  mount(root, entries) { for (const [path, value] of Object.entries(entries)) files.set(norm(root + '/' + path), value) },
  text(path) { const v = files.get(norm(path)); return v == null ? undefined : typeof v === 'string' ? v : decoder.decode(v) },
  list(prefix) { const p = norm(prefix) + '/'; return [...files.keys()].filter(k => k.startsWith(p)) },
}
function missing(path) { const e = new Error(`ENOENT: no such file or directory, open '${path}'`); e.code = 'ENOENT'; return e }
export function existsSync(path) { const p = norm(path); return files.has(p) || [...files.keys()].some(k => k.startsWith(p + '/')) }
export function statSync(path) { const p = norm(path); if (files.has(p)) return { isFile: () => true, isDirectory: () => false }; if (existsSync(p)) return { isFile: () => false, isDirectory: () => true }; throw missing(path) }
export function readFileSync(path) { const t = vfs.text(path); if (t === undefined) throw missing(path); return t }
export function writeFileSync(path, data) { files.set(norm(path), data) }
export function mkdirSync() {}
export function realpathSync(path) { return norm(path) }
realpathSync.native = realpathSync
export async function readFile(path) { return readFileSync(path) }
export async function writeFile(path, data) { files.set(norm(path), data) }
export default { existsSync, statSync, readFileSync, writeFileSync, mkdirSync, realpathSync, readFile, writeFile, promises: { readFile, writeFile } }
