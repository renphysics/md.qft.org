// The 'unocss' umbrella package drags in Node-only code; re-export the browser-safe pieces.
export { createGenerator, mergeConfigs } from '@unocss/core'
export { presetWind3 } from '@unocss/preset-wind3'
export { presetAttributify } from '@unocss/preset-attributify'
export { presetTypography } from '@unocss/preset-typography'
export { default as transformerDirectives } from '@unocss/transformer-directives'
export { default as transformerVariantGroup } from '@unocss/transformer-variant-group'
export const defineConfig = config => config
