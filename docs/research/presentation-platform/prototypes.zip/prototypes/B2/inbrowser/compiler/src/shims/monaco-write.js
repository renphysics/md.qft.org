export const monacoWriterWhitelist = new Set()
