---
theme: default
title: QFT generic Slidev runtime
routerMode: memory
aspectRatio: 16/9
fonts:
  provider: none
  sans: system-ui
  serif: Georgia
  mono: ui-monospace, monospace
favicon: ''
monaco: false
download: false
record: false
presenter: false
wakeLock: false
browserExporter: false
contextMenu: false
drawings:
  enabled: false
remoteAssets: false
pwa: false
---

# Placeholder slide

This deck only exists so that `slidev build` emits the client. Real slides arrive at runtime. $x$
