// Does removing window.RTCPeerConnection in a bootstrap stop WebRTC STUN, given the player's CSP
// (frame-src 'none', worker-src 'none')? Test: a src-less child iframe yields a fresh realm.
const { chromium } = require('playwright');
const dgram = require('node:dgram');
const http = require('node:http');
(async () => {
  const udp = dgram.createSocket('udp4'); let datagrams = 0;
  udp.on('message', () => { datagrams += 1; });
  await new Promise(r => udp.bind(4791, '127.0.0.1', r));
  const deck = `<!doctype html><html><head><meta charset="utf-8">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; script-src-attr 'none'; style-src 'unsafe-inline'; img-src data: blob:; connect-src 'none'; frame-src 'none'; worker-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'">
<script>
// --- the proposed mitigation, run before any deck code ---
try { Object.defineProperty(window, 'RTCPeerConnection', { value: undefined, configurable: false, writable: false }); } catch (e) {}
try { Object.defineProperty(window, 'webkitRTCPeerConnection', { value: undefined, configurable: false, writable: false }); } catch (e) {}
</script></head><body><script>
(async () => {
  const out = { own: typeof window.RTCPeerConnection, violations: [] };
  document.addEventListener('securitypolicyviolation', e => out.violations.push(e.effectiveDirective + ' ' + e.blockedURI));
  try {
    const f = document.createElement('iframe');            // no src: initial about:blank, no navigation
    document.body.appendChild(f);
    out.childWindow = !!f.contentWindow;
    out.childCtor = typeof f.contentWindow.RTCPeerConnection;
    const PC = f.contentWindow.RTCPeerConnection;
    const pc = new PC({ iceServers: [{ urls: 'stun:127.0.0.1:4791' }] });
    pc.createDataChannel('x');
    await pc.setLocalDescription(await pc.createOffer());
    out.offer = 'created';
  } catch (e) { out.error = String(e); }
  await new Promise(r => setTimeout(r, 2500));
  parent.postMessage({ rtcProbe: out }, '*');
})();
</script></body></html>`;
  const host = `<!doctype html><meta charset="utf-8"><body><script>
    window.result = null; addEventListener('message', e => { if (e.data && e.data.rtcProbe) window.result = e.data.rtcProbe; });
    const f = document.createElement('iframe'); f.setAttribute('sandbox', 'allow-scripts'); f.srcdoc = ${JSON.stringify(deck).replace(/<\/script/gi, "<\\/script")}; document.body.appendChild(f);
  </script></body>`;
  const server = http.createServer((q, s) => { s.setHeader('content-type', 'text/html'); s.end(host); });
  await new Promise(r => server.listen(4790, '127.0.0.1', r));
  for (const channel of ['chromium', undefined]) {
    datagrams = 0;
    const browser = await chromium.launch(channel ? { channel } : {});
    const page = await browser.newPage();
    await page.goto('http://127.0.0.1:4790/');
    await page.waitForFunction(() => window.result !== null, null, { timeout: 15000 }).catch(() => {});
    const result = await page.evaluate(() => window.result);
    console.log(JSON.stringify({ browser: channel || 'headless-shell', version: browser.version(), result, stunDatagramsReceived: datagrams }));
    await browser.close();
  }
  server.close(); udp.close();
})();
