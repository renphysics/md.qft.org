// Variant: the deck gives a child frame its own script through srcdoc (fresh realm that the bootstrap never touched).
// CSP mirrors the player's prepared document: nonce-based script-src plus frame-src 'none' / worker-src 'none'.
const { chromium } = require('playwright');
const dgram = require('node:dgram');
const http = require('node:http');
(async () => {
  const udp = dgram.createSocket('udp4'); let datagrams = 0;
  udp.on('message', () => { datagrams += 1; });
  await new Promise(r => udp.bind(4791, '127.0.0.1', r));
  const N = 'abcdef0123456789abcdef';
  const csp = `default-src 'none'; script-src 'nonce-${N}'; script-src-attr 'none'; style-src 'unsafe-inline'; img-src data: blob:; connect-src 'none'; frame-src 'none'; worker-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'`;
  const mk = (variant) => `<!doctype html><html><head><meta charset="utf-8">
<meta http-equiv="Content-Security-Policy" content="${csp}">
<meta http-equiv="Content-Security-Policy" content="script-src 'unsafe-inline'; script-src-attr 'none'">
<script nonce="${N}">
try { Object.defineProperty(window, 'RTCPeerConnection', { value: undefined, configurable: false, writable: false }); } catch (e) {}
try { Object.defineProperty(window, 'webkitRTCPeerConnection', { value: undefined, configurable: false, writable: false }); } catch (e) {}
</script></head><body><script nonce="${N}">
(async () => {
  const out = { variant: ${JSON.stringify(variant)}, own: typeof window.RTCPeerConnection, violations: [] };
  document.addEventListener('securitypolicyviolation', e => out.violations.push(e.effectiveDirective + ' ' + e.blockedURI));
  addEventListener('message', e => { if (e.data && e.data.child) out.child = e.data.child; });
  const nonce = document.currentScript ? document.currentScript.nonce : '${N}';
  const childCode = "(async()=>{let r={ctor:typeof RTCPeerConnection};try{const pc=new RTCPeerConnection({iceServers:[{urls:'stun:127.0.0.1:4791'}]});pc.createDataChannel('x');await pc.setLocalDescription(await pc.createOffer());r.offer='created';}catch(e){r.error=String(e)}parent.postMessage({child:r},'*');})()";
  try {
    const f = document.createElement('iframe');
    if (${JSON.stringify(variant)} === 'srcdoc') f.srcdoc = '<script nonce="' + nonce + '">' + childCode + '<\\/script>';
    if (${JSON.stringify(variant)} === 'blob') f.src = URL.createObjectURL(new Blob(['<script nonce="' + nonce + '">' + childCode + '<\\/script>'], { type: 'text/html' }));
    if (${JSON.stringify(variant)} === 'data') f.src = 'data:text/html,' + encodeURIComponent('<script nonce="' + nonce + '">' + childCode + '<\\/script>');
    document.body.appendChild(f);
  } catch (e) { out.error = String(e); }
  await new Promise(r => setTimeout(r, 3000));
  parent.postMessage({ rtcProbe: out }, '*');
})();
</script></body></html>`;
  const hostFor = (variant) => `<!doctype html><meta charset="utf-8"><body><script>
    window.result = null; addEventListener('message', e => { if (e.data && e.data.rtcProbe) window.result = e.data.rtcProbe; });
    const f = document.createElement('iframe'); f.setAttribute('sandbox', 'allow-scripts'); f.srcdoc = ${JSON.stringify(mk(variant)).replace(/<\/script/gi, '<\\/script')}; document.body.appendChild(f);
  </script></body>`;
  const server = http.createServer((q, s) => { s.setHeader('content-type', 'text/html'); s.end(hostFor(new URL(q.url, 'http://x').searchParams.get('v') || 'srcdoc')); });
  await new Promise(r => server.listen(4790, '127.0.0.1', r));
  const browser = await chromium.launch({ channel: 'chromium' });
  for (const variant of ['srcdoc', 'blob', 'data']) {
    datagrams = 0;
    const page = await browser.newPage();
    await page.goto('http://127.0.0.1:4790/?v=' + variant);
    await page.waitForFunction(() => window.result !== null, null, { timeout: 15000 }).catch(() => {});
    const result = await page.evaluate(() => window.result);
    await page.waitForTimeout(500);
    console.log(JSON.stringify({ variant, result, stunDatagramsReceived: datagrams }));
    await page.close();
  }
  await browser.close(); server.close(); udp.close();
})();
