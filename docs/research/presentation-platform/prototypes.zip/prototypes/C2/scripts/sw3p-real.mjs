// Same as sw3p-block but WITH ThirdPartyStoragePartitioning enabled (Playwright disables it by default).
import fs from 'node:fs'; import { createRequire } from 'node:module';
const { chromium } = createRequire(import.meta.url)('playwright');
const PWDIS = '--disable-features=AvoidUnnecessaryBeforeUnloadCheckSync,DestroyProfileOnBrowserClose,DialMediaRouteProvider,GlobalMediaControls,HttpsUpgrades,LensOverlay,MediaRouter,PaintHolding,ThirdPartyStoragePartitioning,BlockOriginHeaderModificationOnRedirect,Translate,AutoDeElevate,OptimizationHints,msForceBrowserSignIn,msEdgeUpdateLaunchServicesPreferredVersion,WebUIOmniboxPopup,WebUIOmniboxAimPopup,WebUIReloadButton,AimEnabled,AutofillServerCommunication,NetworkTimeServiceQuerying,PreconnectToSearch,SessionRestoreInfobar';
const MYDIS = PWDIS.replace('ThirdPartyStoragePartitioning,', '');
const src = await import('./sw3p-server.mjs');
for (const block of [false, true]) {
  const ud = new URL('./ud3', import.meta.url).pathname; fs.rmSync(ud, { recursive: true, force: true }); fs.mkdirSync(ud + '/Default', { recursive: true });
  if (block) fs.writeFileSync(ud + '/Default/Preferences', JSON.stringify({ profile: { cookie_controls_mode: 1, block_third_party_cookies: true } }));
  const ctx = await chromium.launchPersistentContext(ud, { channel: 'chromium', ignoreDefaultArgs: [PWDIS], args: [MYDIS, '--ignore-certificate-errors', '--no-proxy-server', '--host-resolver-rules=MAP *.test 127.0.0.1'] });
  const top = await ctx.newPage(); await top.goto('https://renphysics.github-io.test:4653/child'); await top.evaluate(() => localStorage.setItem('a', 'top-level')); await top.close();
  const ptop = await ctx.newPage(); await ptop.goto('https://play.qft.test:4653/child'); await ptop.evaluate(() => localStorage.setItem('a', 'top-level')); await ptop.close();
  for (const [name, s, popup] of [['same-site subdomain iframe', 'https://play.qft.test:4653/child'], ['cross-site iframe', 'https://renphysics.github-io.test:4653/child'], ['cross-site popup', 'https://renphysics.github-io.test:4653/child', 1]]) {
    const page = await ctx.newPage(); await page.goto('https://md.qft.test:4653/?' + (popup ? 'popup=1&' : '') + 'src=' + encodeURIComponent(s));
    if (popup) await page.evaluate(() => go());
    const r = await Promise.race([page.evaluate(() => window.result), new Promise(x => setTimeout(() => x('timeout'), 8000))]);
    console.log((block ? '3PC blocked' : '3PC allowed').padEnd(12), name.padEnd(27), JSON.stringify(r)); await page.close();
  }
  await ctx.close(); fs.rmSync(ud, { recursive: true, force: true });
}
src.srv.close();
