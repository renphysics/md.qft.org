// Can a cross-site / same-site iframe register a service worker and use IndexedDB+Cache Storage? Full Chromium.
import https from 'node:https'; import fs from 'node:fs';
import { createRequire } from 'node:module';
const { chromium } = createRequire(import.meta.url)('playwright');
const PORT = 4652, dir = new URL('.', import.meta.url).pathname;
const child = `<script>
(async()=>{const r={};try{const reg=await navigator.serviceWorker.register('sw.js');await navigator.serviceWorker.ready;r.sw='registered '+reg.scope}catch(e){r.sw='ERR '+e.name+': '+e.message}
try{await new Promise((ok,no)=>{const q=indexedDB.open('t');q.onsuccess=ok;q.onerror=()=>no(q.error)});r.idb='ok'}catch(e){r.idb='ERR '+e}
try{const c=await caches.open('t');await c.put('/x',new Response('1'));r.cache='ok'}catch(e){r.cache='ERR '+e}
try{localStorage.setItem('a','1');r.ls='ok'}catch(e){r.ls='ERR '+e.name}
try{r.sa=typeof document.hasStorageAccess=='function'?await document.hasStorageAccess():'n/a'}catch(e){r.sa='ERR'}
parent.postMessage(r,'*')})()</script>`;
const srv = https.createServer({ key: fs.readFileSync(dir + 'key.pem'), cert: fs.readFileSync(dir + 'cert.pem') }, (req, res) => {
  const u = new URL(req.url, 'https://x');
  if (u.pathname === '/sw.js') { res.writeHead(200, { 'content-type': 'text/javascript' }); return res.end('self.addEventListener("fetch",()=>{})'); }
  if (u.pathname === '/child') { res.writeHead(200, { 'content-type': 'text/html' }); return res.end(child); }
  res.writeHead(200, { 'content-type': 'text/html' });
  res.end(`<script>window.result=new Promise(r=>addEventListener('message',e=>r(e.data)))</script><iframe src="${u.searchParams.get('src')}"></iframe>`);
}).listen(PORT);
for (const flags of [[], ['--test-third-party-cookie-phaseout']]) {
  const browser = await chromium.launch({ channel: 'chromium', args: ['--ignore-certificate-errors', '--no-proxy-server', '--host-resolver-rules=MAP *.test 127.0.0.1', ...flags] });
  for (const [name, src] of [['same-site subdomain', `https://play.qft.test:${PORT}/child`], ['cross-site', `https://renphysics.github-io.test:${PORT}/child`]]) {
    const ctx = await browser.newContext(); const page = await ctx.newPage();
    await page.goto(`https://md.qft.test:${PORT}/?src=${encodeURIComponent(src)}`);
    const r = await Promise.race([page.evaluate(() => window.result), new Promise(x => setTimeout(() => x('timeout'), 8000))]);
    console.log((flags.join(' ') || 'default').padEnd(36), name.padEnd(20), JSON.stringify(r));
    await ctx.close();
  }
  await browser.close();
}
srv.close();
