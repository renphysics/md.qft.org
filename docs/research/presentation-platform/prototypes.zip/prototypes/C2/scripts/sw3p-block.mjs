import fs from 'node:fs'; import { createRequire } from 'node:module';
const { chromium } = createRequire(import.meta.url)('playwright');
const ud = new URL('./ud', import.meta.url).pathname; fs.rmSync(ud, { recursive: true, force: true }); fs.mkdirSync(ud + '/Default', { recursive: true });
fs.writeFileSync(ud + '/Default/Preferences', JSON.stringify({ profile: { cookie_controls_mode: 1, block_third_party_cookies: true } }));
const src = await import('./sw3p-server.mjs');
const ctx = await chromium.launchPersistentContext(ud, { channel: 'chromium', args: ['--ignore-certificate-errors', '--no-proxy-server', '--host-resolver-rules=MAP *.test 127.0.0.1'] });
for (const [name, s] of [['same-site subdomain', 'https://play.qft.test:4653/child'], ['cross-site', 'https://renphysics.github-io.test:4653/child']]) {
  const page = await ctx.newPage(); await page.goto('https://md.qft.test:4653/?src=' + encodeURIComponent(s));
  const r = await Promise.race([page.evaluate(() => window.result), new Promise(x => setTimeout(() => x('timeout'), 8000))]);
  console.log('3PC blocked (prefs)'.padEnd(22), name.padEnd(20), JSON.stringify(r)); await page.close();
}
await ctx.close(); src.srv.close();
