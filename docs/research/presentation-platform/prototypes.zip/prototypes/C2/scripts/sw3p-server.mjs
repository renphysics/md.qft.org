// Can a cross-site / same-site iframe register a service worker and use IndexedDB+Cache Storage? Full Chromium.
import https from 'node:https'; import fs from 'node:fs';
import { createRequire } from 'node:module';

const PORT = 4653, dir = new URL('.', import.meta.url).pathname;
const child = `<script>
(async()=>{const r={};try{const reg=await navigator.serviceWorker.register('sw.js');await navigator.serviceWorker.ready;r.sw='registered '+reg.scope}catch(e){r.sw='ERR '+e.name+': '+e.message}
try{await new Promise((ok,no)=>{const q=indexedDB.open('t');q.onsuccess=ok;q.onerror=()=>no(q.error)});r.idb='ok'}catch(e){r.idb='ERR '+e}
try{const c=await caches.open('t');await c.put('/x',new Response('1'));r.cache='ok'}catch(e){r.cache='ERR '+e}
try{r.lsBefore=localStorage.getItem('a');localStorage.setItem('a','1');r.ls='ok'}catch(e){r.ls='ERR '+e.name}
try{r.sa=typeof document.hasStorageAccess=='function'?await document.hasStorageAccess():'n/a'}catch(e){r.sa='ERR'}
(opener||parent).postMessage(r,'*')})()</script>`;
export const srv = https.createServer({ key: fs.readFileSync(dir + 'key.pem'), cert: fs.readFileSync(dir + 'cert.pem') }, (req, res) => {
  const u = new URL(req.url, 'https://x');
  if (u.pathname === '/sw.js') { res.writeHead(200, { 'content-type': 'text/javascript' }); return res.end('self.addEventListener("fetch",()=>{})'); }
  if (u.pathname === '/child') { res.writeHead(200, { 'content-type': 'text/html' }); return res.end(child); }
  res.writeHead(200, { 'content-type': 'text/html' });
  res.end(u.searchParams.get("popup")?`<script>window.result=new Promise(r=>addEventListener("message",e=>r(e.data)));window.go=()=>open(${JSON.stringify("")}+u0,"_blank")</script>`.replace("u0",JSON.stringify(u.searchParams.get("src"))):`<script>window.result=new Promise(r=>addEventListener("message",e=>r(e.data)))</script><iframe src="${u.searchParams.get("src")}"></iframe>`);
}).listen(PORT);
