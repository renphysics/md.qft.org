// Does an infinite loop in an iframe freeze the embedding page? Full Chromium, site isolation on.
import https from 'node:https'; import fs from 'node:fs';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const PORT = 4651;
const loop = `<script>setTimeout(()=>{for(;;){}},300)</script>busy`;
const srv = https.createServer({key:fs.readFileSync('key.pem'),cert:fs.readFileSync('cert.pem')},(req, res) => {
  const u = new URL(req.url, 'https://x');
  const h = { 'content-type': 'text/html' };
  if (u.searchParams.get('oac')) h['origin-agent-cluster'] = '?1';
  if (u.pathname === '/busy') { res.writeHead(200, h); return res.end(loop); }
  const src = u.searchParams.get('src');
  const sandbox = u.searchParams.get('sandbox');
  res.writeHead(200, h);
  res.end(`<script>window.ticks=0;setInterval(()=>ticks++,50)</script>` +
    (sandbox ? `<iframe sandbox="allow-scripts" srcdoc="${loop.replace(/"/g,'&quot;')}"></iframe>` : `<iframe src="${src}"></iframe>`));
}).listen(PORT);
const browser = await chromium.launch({ channel: 'chromium', args: ['--ignore-certificate-errors','--no-proxy-server',`--host-resolver-rules=MAP *.test 127.0.0.1`] });
const cases = [
  ['same-origin', `https://md.qft.test:${PORT}/?src=/busy`],
  ['same-site subdomain', `https://md.qft.test:${PORT}/?src=https://play.qft.test:${PORT}/busy`],
  ['same-site subdomain + OAC ?1 header', `https://md.qft.test:${PORT}/?src=https://play.qft.test:${PORT}/busy%3Foac=1`],
  ['same-site subdomain, parent also OAC', `https://md.qft.test:${PORT}/?oac=1&src=https://play.qft.test:${PORT}/busy%3Foac=1`],
  ['cross-site', `https://md.qft.test:${PORT}/?src=https://renphysics.github-io.test:${PORT}/busy`],
  ['opaque sandbox srcdoc (allow-scripts only)', `https://md.qft.test:${PORT}/?sandbox=1`],
];
console.log('chromium', browser.version());
for (const [name, url] of cases) {
  const ctx = await browser.newContext(); const page = await ctx.newPage();
  await page.goto(url); await page.waitForTimeout(400);
  const t0 = await Promise.race([page.evaluate(() => ticks), new Promise(r => setTimeout(() => r('timeout'), 3000))]);
  await page.waitForTimeout(1500);
  const t1 = await Promise.race([page.evaluate(() => ticks), new Promise(r => setTimeout(() => r('timeout'), 3000))]);
  console.log(name.padEnd(45), 'ticks', t0, '->', t1, (t1 === 'timeout' || t1 === t0) ? 'PARENT FROZEN' : 'parent responsive');
  await ctx.close().catch(()=>{});
}
await browser.close(); srv.close();
