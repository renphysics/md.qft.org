import { startServers, launch, newApp, frameByName, sleep } from './lib.mjs';
const stop = await startServers(); const browser = await launch();
try {
  const { context, page } = await newApp(browser);
  const L = await page.evaluate(() => window.load({ zip: 'zips/esm6.zip' }));
  await page.evaluate((u) => window.frameOpen('A', u), `/d/${L.id}/index.html`); await sleep(2000);
  const st = () => frameByName(page, 'A').evaluate(() => { const R = window.Reveal || window.__deck; return JSON.stringify(R.getIndices()) + ' frag=' + document.querySelectorAll('.slides section.present .fragment').length + ' active=' + document.activeElement.tagName; });
  console.log('esm6 before', await st());
  const b = await (await page.$('iframe[name="A"]')).boundingBox(); await page.mouse.click(b.x + 640, b.y + 600);
  for (let i = 0; i < 3; i++) { await page.keyboard.press('ArrowRight'); await sleep(400); console.log('after right', i + 1, await st()); }
  const L2 = await page.evaluate(() => window.load({ zip: 'zips/classic6.zip' }));
  await page.evaluate((u) => window.frameOpen('B', u), `/d/${L2.id}/index.html#/2`); await sleep(1500);
  console.log('classic6 #/2', await frameByName(page, 'B').evaluate(() => { const R = window.Reveal; const s = document.querySelector('.slides section.present:not(.stack)') || document.querySelector('.slides section.present'); return JSON.stringify(R.getIndices()) + ' ' + JSON.stringify(s.innerText.slice(0, 60)) + ' ' + location.hash; }));
  await context.close();
} finally { await browser.close(); stop(); }
