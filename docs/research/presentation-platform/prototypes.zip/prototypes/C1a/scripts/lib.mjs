// Shared helpers: servers on 4600 (app) / 4602 (player), full Chromium, Slidev probes.
import { createRequire } from 'node:module'; import { spawn } from 'node:child_process'; import { resolve } from 'node:path';
const require = createRequire(import.meta.url);
export const { chromium } = require('playwright');
const C = resolve(import.meta.dirname, '..');
export const APP = 'http://127.0.0.1:4600', PLAYER = 'http://127.0.0.1:4602';
export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
export async function startServers() {
  const ps = [[C + '/www', 4600], [C + '/player', 4602]].map(([d, p]) => spawn(process.execPath, [C + '/scripts/static-server.mjs', d, String(p)], { stdio: ['ignore', 'pipe', 'inherit'] }));
  await Promise.all(ps.map((p) => new Promise((r) => p.stdout.once('data', r))));
  return () => ps.forEach((p) => p.kill());
}
export async function launch() { return chromium.launch({ channel: 'chromium' }); }
export async function newApp(browser, { blockExternal = true } = {}) {
  const context = await browser.newContext({ viewport: { width: 1400, height: 1500 } });
  const rec = { errors: [], external: [], bad: [] };
  await context.route((u) => !/^(https?:\/\/(127\.0\.0\.1|localhost):46\d\d\/|blob:|data:|about:)/.test(u.href), (route) => { rec.external.push(route.request().resourceType() + ' ' + route.request().url().slice(0, 100)); return blockExternal ? route.abort('blockedbyclient') : route.continue(); });
  context.on('weberror', (e) => rec.errors.push(String(e.error().message).slice(0, 160)));
  context.on('console', (m) => { if (m.type() === 'error') rec.errors.push('[console] ' + m.text().slice(0, 160)); });
  context.on('response', (r) => { if (r.status() >= 400) rec.bad.push(r.status() + ' ' + r.url().slice(0, 110)); });
  const page = await context.newPage();
  await page.goto((process.env.APPURL || APP) + "/app.html"); await page.waitForFunction(() => typeof window.load === 'function');
  return { context, page, rec };
}
export const frameByName = (page, name) => page.frames().find((f) => f.name() === name);
// What the Slidev deck shows now (run inside the deck frame)
export function slidevState(target) {
  return target.evaluate(() => {
    const vis = (el) => { let e = el; while (e && e !== document.body) { const s = getComputedStyle(e); if (s.display === 'none' || s.visibility === 'hidden') return false; e = e.parentElement; } return true; };
    const pages = [...document.querySelectorAll('.slidev-page')].filter(vis);
    const cur = pages[0];
    return { href: location.pathname + location.search + location.hash, pages: pages.length, h1: cur ? (cur.querySelector('h1') || {}).textContent : null,
      hidden: cur ? cur.querySelectorAll('.slidev-vclick-hidden').length : -1, intensity: (document.querySelector('.slidev-page .intensity-value strong') || {}).textContent || null,
      katex: cur ? cur.querySelectorAll('.katex').length : 0, presenter: !!document.querySelector('.slidev-presenter, [class*="presenter"]'), body: document.body.innerText.replace(/\s+/g, ' ').slice(0, 80) };
  }).catch((e) => ({ evalError: String(e.message).slice(0, 120) }));
}
export async function waitH1(page, name, h1, ms = 8000) {
  const t0 = Date.now(); let s;
  while (Date.now() - t0 < ms) { const f = frameByName(page, name); if (f) { s = await slidevState(f); if (s.h1 && s.h1.includes(h1)) return { ok: true, ms: Date.now() - t0, ...s }; } await sleep(50); }
  return { ok: false, ...s };
}
// Render + keyboard navigation + click animation + Vue component control on the 5-slide test deck
export async function slidevInteract(page, name) {
  const r = { };
  const first = await waitH1(page, name, 'Quantum interference'); r.render = first.ok; r.firstMs = first.ms; r.url0 = first.href;
  if (!first.ok) { r.state = first; return r; }
  const el = await page.$(`iframe[name="${name}"]`); const box = await el.boundingBox();
  await page.mouse.click(box.x + box.width / 2, box.y + box.height * 0.8);
  await page.keyboard.press('ArrowRight'); const s2 = await waitH1(page, name, 'Amplitudes', 4000); r.keyNav = s2.ok; r.hidden0 = s2.hidden; r.katex = s2.katex; r.url2 = s2.href;
  await page.keyboard.press('ArrowRight'); await sleep(300); r.hidden1 = (await slidevState(frameByName(page, name))).hidden;
  r.clickAnim = r.hidden0 === 2 && r.hidden1 === 1;
  await page.keyboard.press('ArrowRight'); await sleep(200); await page.keyboard.press('ArrowRight');
  const s3 = await waitH1(page, name, 'Try it', 4000); r.url3 = s3.href;
  try { await frameByName(page, name).getByRole('button', { name: /Opposite/ }).click({ timeout: 3000 }); await sleep(150); r.vue = (await slidevState(frameByName(page, name))).intensity; } catch (e) { r.vue = 'ERR ' + e.message.split('\n')[0].slice(0, 80); }
  r.ok = r.render && r.keyNav && r.clickAnim && r.vue === '0.00';
  return r;
}
// Full Chromium WITH third-party storage partitioning (Playwright disables the feature by default, chromiumSwitches.ts).
export async function launchPartitioned() {
  const probe = await chromium.launch({ channel: 'chromium' });
  const s = await probe.newBrowserCDPSession(); const { processInfo } = await s.send('SystemInfo.getProcessInfo');
  const { readFileSync } = await import('node:fs');
  const bp = processInfo.find((p) => p.type === 'browser');
  const argv = readFileSync(`/proc/${bp.id}/cmdline`, 'utf8').split('\0');
  await probe.close();
  const dis = argv.find((a) => a.startsWith('--disable-features='));
  const kept = dis.slice('--disable-features='.length).split(',').filter((f) => f !== 'ThirdPartyStoragePartitioning');
  return chromium.launch({ channel: 'chromium', ignoreDefaultArgs: [dis], args: ['--disable-features=' + kept.join(','), '--enable-features=ThirdPartyStoragePartitioning'] });
}
