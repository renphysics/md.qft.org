// Q1a/b + Q2 mounts: every Slidev build x mount strategy (prefix /d/, root-at-own-base, rewrite /r/). Output out/q1-matrix.json
import { writeFileSync } from 'node:fs';
import { startServers, launch, newApp, slidevInteract, sleep } from './lib.mjs';
const stop = await startServers(); const browser = await launch(); const rows = [];
const builds = ['ordinary', 'ordinary-rel', 'history-abs', 'history-rel', 'hash-abs', 'hash-rel', 'memory-abs', 'memory-rel', 'history-sub'];
try {
  for (const b of builds) for (const mount of ['prefix', 'root', 'rewrite']) {
    if (mount === 'rewrite' && !/abs|ordinary$/.test(b)) continue;
    const { context, page, rec } = await newApp(browser);
    const L = await page.evaluate((z) => window.load({ zip: 'zips/' + z + '.zip' }), b);
    const base = L.sw.base || '/';
    const url = mount === 'prefix' ? `/d/${L.id}/` : mount === 'rewrite' ? `/r/${L.id}/` : `${base}?__deck=${L.id}`;
    const open = await page.evaluate(([u]) => window.frameOpen('A', u), [url]);
    const r = await slidevInteract(page, 'A');
    const st = await page.evaluate(() => window.stats());
    rows.push({ build: b, mount, url: url.replace(L.id, '<id>'), base, ...r, loadMs: open.loadMs, unzipMs: L.unzipMs, storeMs: L.storeMs, resolvers: st.byResolver, misses: st.misses.slice(0, 3).map((m) => m.replace(L.id, '<id>')), errors: [...new Set(rec.errors)].slice(0, 4), bad: [...new Set(rec.bad)].slice(0, 3).map((m) => m.replace(L.id, '<id>')), external: [...new Set(rec.external)].slice(0, 3) });
    const x = rows.at(-1); console.log(JSON.stringify({ build: b, mount, ok: x.ok, render: x.render, keyNav: x.keyNav, clickAnim: x.clickAnim, vue: x.vue, url0: x.url0 && x.url0.replace(L.id, '<id>'), url3: x.url3 && x.url3.replace(L.id, '<id>'), firstMs: x.firstMs, misses: x.misses, errors: x.errors.slice(0, 2), bad: x.bad }));
    await context.close();
  }
} finally { await browser.close(); stop(); }
writeFileSync(new URL('../out/q1-matrix.json', import.meta.url), JSON.stringify(rows, null, 1));
