// Q4 Reveal spot check, Q5 edit loop timings, Q6 worker restart per store, plus cross-deck BroadcastChannel coupling. Output out/q4q5q6.json
import { writeFileSync } from 'node:fs';
import { startServers, launch, newApp, slidevState, waitH1, frameByName, sleep } from './lib.mjs';
const stop = await startServers(); const browser = await launch(); const out = { q4: [], q5: {}, q6: [], coupling: null };
const median = (a) => { const s = [...a].sort((x, y) => x - y); return s[Math.floor(s.length / 2)]; };
const revealState = (f) => f.evaluate(() => { const R = window.Reveal || window.__deck; const q = (s) => document.querySelector(s); return { ready: !!(R && R.isReady && R.isReady()), v: R && R.VERSION, total: R && R.getTotalSlides && R.getTotalSlides(), idx: R && R.getIndices && R.getIndices().h, cur: (q('.slides section.present:not(.stack)') || q('.slides section.present') || {}).innerText?.split('\n')[0].slice(0, 30), md: !!q('.slides h2, .slides h1'), menuBtn: !!q('.slide-menu-button'), chalk: !!q('.chalkboard-button, #chalkboard, [class*="chalkboard"]'), hljs: !!q('code.hljs') }; }).catch((e) => ({ evalError: e.message.slice(0, 80) }));
const press = async (page, name, key, n = 1) => { const b = await (await page.$(`iframe[name="${name}"]`)).boundingBox(); await page.mouse.click(b.x + b.width / 2, b.y + b.height * 0.85); for (let i = 0; i < n; i++) { await page.keyboard.press(key); await sleep(300); } };
try {
  // Q4
  for (const [zip, entry] of [['extmd6', 'index.html'], ['esm6', 'index.html'], ['plugins6', 'menu.html'], ['plugins6', 'chalkboard.html']]) for (const mount of ['prefix', 'root']) {
    const { context, page, rec } = await newApp(browser); const L = await page.evaluate((z) => window.load({ zip: 'zips/' + z + '.zip' }), zip);
    await page.evaluate((u) => window.frameOpen('A', u), mount === 'prefix' ? `/d/${L.id}/${entry}` : `/${entry}?__deck=${L.id}`); await sleep(2000);
    const s0 = await revealState(frameByName(page, 'A')); await press(page, 'A', 'ArrowRight', 1); await sleep(600); const s1 = await revealState(frameByName(page, 'A'));
    out.q4.push({ deck: zip + '/' + entry, mount, ready: s0.ready, version: s0.v, total: s0.total, md: s0.md, menuBtn: s0.menuBtn, chalk: s0.chalk, hljs: s0.hljs, idx0: s0.idx, idxAfterRight: s1.idx, errors: [...new Set(rec.errors)].slice(0, 3), bad: [...new Set(rec.bad)].slice(0, 3) });
    console.log(JSON.stringify(out.q4.at(-1))); await context.close();
  }
  // Q5 edit loop: Reveal classic6 (prefix mount), edit the "Code" slide title in index.html, reload restoring #/2
  { const { context, page } = await newApp(browser); const L = await page.evaluate(() => window.load({ zip: 'zips/classic6.zip' }));
    const orig = await page.evaluate((id) => new TextDecoder().decode(window.__files[id]['index.html']), L.id);
    await page.evaluate((u) => window.frameOpen('A', u), `/d/${L.id}/index.html#/2`); await sleep(1500);
    const runs = [];
    for (let n = 1; n <= 9; n++) {
      const t0 = Date.now();
      const p = await page.evaluate(([id, text]) => window.patch(id, 'index.html', text), [L.id, orig.replace('<h2>Code<', `<h2>Code v${n}<`)]);
      const tPatch = Date.now() - t0;
      await page.evaluate((u) => { window.frameNav('A', u); }, `/d/${L.id}/index.html?v=${n}#/2`);
      let s; while (Date.now() - t0 < 8000) { const f = frameByName(page, 'A'); s = f && await revealState(f); if (s && s.ready && s.idx === 2 && s.cur === `Code v${n}`) break; await sleep(10); }
      runs.push({ n, patchMs: tPatch, swMs: p.ms, totalMs: Date.now() - t0, ok: s && s.cur === `Code v${n}` });
    }
    out.q5.reveal = { runs, medianTotalMs: median(runs.map((r) => r.totalMs)), medianPatchMs: median(runs.map((r) => r.patchMs)), allOk: runs.every((r) => r.ok) };
    console.log(JSON.stringify(out.q5.reveal)); await context.close(); }
  // Q5b: Slidev default build, reload of the frame restoring /3 (what an edit loop would cost after a recompile)
  { const { context, page } = await newApp(browser); const L = await page.evaluate(() => window.load({ zip: 'zips/ordinary.zip' }));
    await page.evaluate((u) => window.frameOpen('A', u), `/3?__deck=${L.id}`); await waitH1(page, 'A', 'Try it');
    const runs = [];
    for (let n = 1; n <= 9; n++) { const t0 = Date.now(); await page.evaluate((u) => { window.frameNav('A', u); }, `/3?__deck=${L.id}&v=${n}`); await sleep(30); const r = await waitH1(page, 'A', 'Try it'); runs.push({ n, ok: r.ok, totalMs: Date.now() - t0 }); }
    out.q5.slidevReload = { medianTotalMs: median(runs.map((r) => r.totalMs)), allOk: runs.every((r) => r.ok), runs: runs.map((r) => r.totalMs) };
    console.log(JSON.stringify(out.q5.slidevReload)); await context.close(); }
  // Q6 restart of the worker (CDP ServiceWorker.stopAllWorkers) for each store
  for (const store of ['memory', 'cache', 'ondemand']) {
    const { context, page, rec } = await newApp(browser); const L = await page.evaluate((s) => window.load({ zip: 'zips/ordinary.zip', store: s }), store);
    await page.evaluate((u) => window.frameOpen('A', u), `/1?__deck=${L.id}`); const r0 = await waitH1(page, 'A', 'Quantum');
    const boot0 = (await page.evaluate(() => window.stats())).boot;
    const cdp = await context.newCDPSession(page); await cdp.send('ServiceWorker.enable'); await sleep(300); await cdp.send('ServiceWorker.stopAllWorkers'); await sleep(800);
    const entry = await frameByName(page, 'A').evaluate(() => document.querySelector('script[type=module]').getAttribute('src'));
    const fetchAfter = await frameByName(page, 'A').evaluate(async (u) => { try { const r = await fetch(u + '?x=1'); return r.status + ' ' + (r.headers.get('x-c1a-resolved') || ''); } catch (e) { return 'ERR ' + e.message; } }, entry);
    const lazyNav = await (async () => { await press(page, 'A', 'ArrowRight', 4); return (await slidevState(frameByName(page, 'A'))).h1; })();
    await frameByName(page, 'A').evaluate(() => location.reload()); const rReload = await waitH1(page, 'A', 'Try it', 6000);
    await page.evaluate((u) => window.frameOpen('B', u), `/1?__deck=${L.id}`); const rNew = await waitH1(page, 'B', 'Quantum', 6000);
    const st = await page.evaluate(() => window.stats());
    out.q6.push({ store, renderedBefore: r0.ok, restarted: st.boot !== boot0, fetchAfterRestart: fetchAfter.replace(/boot=\d+/, 'boot=new'), slideAfterRestartKeyNav: lazyNav, reloadAfterRestart: rReload.ok ? 'ok ' + rReload.href.replace(L.id, '<id>') : 'FAIL ' + (rReload.body || '').slice(0, 50), newFrameAfterRestart: rNew.ok ? 'ok' : 'FAIL ' + (rNew.body || '').slice(0, 50), needsServedByApp: await page.evaluate(() => window.__needs), resolversAfterRestart: st.byResolver, missesAfterRestart: st.misses.slice(0, 3).map((m) => m.replace(L.id, '<id>')) });
    console.log(JSON.stringify(out.q6.at(-1))); await context.close();
  }
  // Cross-deck coupling: deck DA viewer, a DIFFERENT deck DB (same title) as presenter; does DA follow DB's presenter?
  { const { context, page } = await newApp(browser);
    await page.evaluate(() => window.load({ zip: 'zips/ordinary.zip', id: 'DA' })); await page.evaluate(() => window.load({ zip: 'zips/history-abs.zip', id: 'DB' }));
    await page.evaluate(() => Promise.all([window.frameOpen('A', '/1?__deck=DA'), window.frameOpen('B', '/presenter/1?__deck=DB')]));
    await waitH1(page, 'A', 'Quantum'); await sleep(1000); await press(page, 'B', 'ArrowRight', 5); await sleep(800);
    out.coupling = { viewerOfDeckA: (await slidevState(frameByName(page, 'A'))).href, presenterOfDeckB: (await slidevState(frameByName(page, 'B'))).href };
    console.log(JSON.stringify(out.coupling)); await context.close(); }
} finally { await browser.close(); stop(); }
writeFileSync(new URL('../out/q4q5q6.json', import.meta.url), JSON.stringify(out, null, 1));
