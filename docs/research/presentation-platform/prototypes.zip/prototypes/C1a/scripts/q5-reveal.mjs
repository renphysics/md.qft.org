// Q5 edit loop on a Reveal deck (classic6, prefix mount and root mount): patch index.html in the worker store, reload frame restoring the slide.
import { writeFileSync } from 'node:fs';
import { startServers, launch, newApp, frameByName, sleep } from './lib.mjs';
const stop = await startServers(); const browser = await launch(); const out = {};
const median = (a) => { const s = [...a].sort((x, y) => x - y); return s[Math.floor(s.length / 2)]; };
try {
  for (const mount of ['prefix', 'root']) for (const store of ['cache', 'memory']) {
    const { context, page } = await newApp(browser); const L = await page.evaluate((s) => window.load({ zip: 'zips/classic6.zip', store: s }), store);
    const orig = await page.evaluate((id) => new TextDecoder().decode(window.__files[id]['index.html']), L.id);
    const base = mount === 'prefix' ? `/d/${L.id}/index.html` : `/index.html`; const tok = mount === 'prefix' ? '' : `__deck=${L.id}&`;
    await page.evaluate((u) => window.frameOpen('A', u), `${base}?${tok}v=0`); await sleep(1500);
    const idx = await frameByName(page, 'A').evaluate(() => [...document.querySelectorAll('.slides > section')].findIndex((s) => [...s.querySelectorAll('h2')].some((h) => h.textContent === 'Code')));
    const runs = [];
    for (let n = 1; n <= 9; n++) {
      const t0 = Date.now();
      const p = await page.evaluate(([id, text]) => window.patch(id, 'index.html', text), [L.id, orig.replace('<h2>Code<', `<h2>Code v${n}<`)]);
      const tPatch = Date.now() - t0;
      const nav = page.evaluate((u) => window.frameNav('A', u), `${base}?${tok}v=${n}#/${idx}`);
      let s; while (Date.now() - t0 < 8000) { const f = frameByName(page, 'A'); s = f && await f.evaluate((n) => { const R = window.Reveal; const sec = document.querySelector('.slides > section.present'); return !!(R && R.isReady() && sec && [...sec.querySelectorAll('h2')].some((h) => h.textContent === 'Code v' + n)); }, n).catch(() => false); if (s) break; await sleep(5); }
      const frameLoadMs = (await nav).loadMs;
      runs.push({ patchMs: tPatch, swMs: p.ms, frameLoadMs, totalMs: Date.now() - t0, ok: s });
    }
    out[mount + '/' + store] = { slideIndex: idx, medianTotalMs: median(runs.map((r) => r.totalMs)), medianFrameLoadMs: median(runs.map((r) => r.frameLoadMs)), medianPatchMs: median(runs.map((r) => r.patchMs)), allOk: runs.every((r) => r.ok), totals: runs.map((r) => r.totalMs) };
    console.log(mount, store, JSON.stringify(out[mount + '/' + store])); await context.close();
  }
} finally { await browser.close(); stop(); }
writeFileSync(new URL('../out/q5-reveal.json', import.meta.url), JSON.stringify(out, null, 1));
