// App on http://localhost:4600 (a different SITE from the player http://127.0.0.1:4602): storage partitioning applies to the frame.
import { startServers, launch, launchPartitioned, newApp, slidevInteract, slidevState, waitH1, frameByName, sleep } from './lib.mjs';
process.env.APPURL = 'http://localhost:4600';
const stop = await startServers(); const browser = process.env.PART ? await launchPartitioned() : await launch(); const out = { partitioned: !!process.env.PART };
try {
  const { context, page, rec } = await newApp(browser);
  const L = await page.evaluate(() => window.load({ zip: 'zips/ordinary.zip', id: 'XS' }));
  await page.evaluate(() => window.frameOpen('A', '/1?__deck=XS')); out.interact = await slidevInteract(page, 'A');
  out.frameStorage = await frameByName(page, 'A').evaluate(async () => ({ controlled: !!navigator.serviceWorker.controller, caches: (await caches.keys()).length }));
  // popup presenter, like Slidev's own link
  const popP = context.waitForEvent('page', { timeout: 6000 }).catch(() => null);
  await frameByName(page, 'A').evaluate(() => { const a = document.createElement('a'); a.href = '/presenter/1?__deck=XS'; a.target = '_blank'; document.body.append(a); a.click(); });
  const pop = await popP;
  if (pop) { await pop.waitForLoadState('load').catch(() => {}); await sleep(2500);
    out.popup = { body: await pop.evaluate(() => document.body.innerText.replace(/\s+/g, ' ').slice(0, 80)).catch((e) => 'ERR ' + e.message.slice(0, 60)), controlled: await pop.evaluate(() => !!navigator.serviceWorker.controller).catch(() => null), cacheKeys: await pop.evaluate(async () => (await caches.keys()).join(',')).catch(() => null) };
    await pop.mouse.click(300, 650); await pop.keyboard.press('ArrowRight'); await pop.keyboard.press('ArrowRight'); await sleep(1000); await page.bringToFront();
    out.audienceAfterPopupKeys = (await slidevState(frameByName(page, 'A'))).href; }
  // same-site comparison is in q2q3-cd.json; here: two frames in the same partition still sync?
  await page.evaluate(() => window.frameOpen('P', '/presenter/1?__deck=XS')); await sleep(1500);
  const b = await (await page.$('iframe[name="P"]')).boundingBox(); await page.mouse.click(b.x + 640, b.y + 610);
  for (let i = 0; i < 2; i++) { await page.keyboard.press('ArrowRight'); await sleep(300); } await sleep(600);
  out.audienceAfterFramePresenter = (await slidevState(frameByName(page, 'A'))).href;
  out.errors = [...new Set(rec.errors.filter((e) => !/violates/.test(e)))].slice(0, 5); out.bad = [...new Set(rec.bad)].slice(0, 5);
  await context.close();
} finally { await browser.close(); stop(); }
console.log(JSON.stringify(out, null, 1));
