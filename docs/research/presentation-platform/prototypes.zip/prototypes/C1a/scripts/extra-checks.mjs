// Extra: kitchen-sink slide 12 (Mermaid) with longer wait + clicks; print routes of the small deck.
import { startServers, launch, newApp, frameByName, sleep } from './lib.mjs';
const stop = await startServers(); const browser = await launch();
try {
  const { context, page, rec } = await newApp(browser);
  await page.evaluate(() => window.load({ zip: 'zips/starter.zip', id: 'KS' }));
  await page.evaluate(() => window.frameOpen('A', '/12?__deck=KS')); await sleep(6000);
  const f = () => frameByName(page, 'A');
  const m = () => f().evaluate(() => { const cur = [...document.querySelectorAll('.slidev-page')].find((p) => getComputedStyle(p.closest('.slidev-slide-container') || p).display !== 'none'); return { svgs: document.querySelectorAll('.slidev-page svg').length, mermaidEls: document.querySelectorAll('.mermaid, [class*="mermaid"]').length, mermaidSvgs: document.querySelectorAll('svg[id^="mermaid"], .mermaid svg, svg[aria-roledescription]').length, hidden: document.querySelectorAll('.slidev-vclick-hidden').length, plantuml: [...document.querySelectorAll('img')].filter((i) => /plantuml/.test(i.src)).map((i) => i.naturalWidth) }; });
  console.log('slide12 after 6s', JSON.stringify(await m()));
  const b = await (await page.$('iframe[name="A"]')).boundingBox(); await page.mouse.click(b.x + 640, b.y + 700);
  for (let i = 0; i < 4; i++) { await page.keyboard.press('ArrowRight'); await sleep(1200); console.log('click', i + 1, (await f().evaluate(() => location.pathname + location.search)), JSON.stringify(await m())); }
  console.log('errors', JSON.stringify([...new Set(rec.errors.filter((e) => !/violates/.test(e)))].slice(0, 5)));
  await page.evaluate(() => window.load({ zip: 'zips/ordinary.zip', id: 'OR' }));
  for (const u of ['/print?__deck=OR', '/1?print&__deck=OR', '/?__deck=OR&print']) { await page.evaluate((x) => window.frameOpen('B', x), u); await sleep(2500); console.log(u, JSON.stringify(await frameByName(page, 'B').evaluate(() => ({ href: location.pathname + location.search, pages: document.querySelectorAll('.slidev-page').length, printClass: !!document.querySelector('.print, #page-root.print, [class*="print"]'), body: document.body.innerText.replace(/\s+/g, ' ').slice(0, 70) })))); }
  await context.close();
} finally { await browser.close(); stop(); }
