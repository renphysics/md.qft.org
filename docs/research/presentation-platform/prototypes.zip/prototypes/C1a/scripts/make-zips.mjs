// Zip deck build folders for the app page. Usage: node make-zips.mjs <outDir> name=dir ...
import { createRequire } from 'node:module'; import { readdirSync, readFileSync, statSync, writeFileSync } from 'node:fs'; import { join, relative } from 'node:path';
const fflate = createRequire(import.meta.url)('/home/user/md.qft.org/node_modules/fflate');
const [out, ...pairs] = process.argv.slice(2);
const walk = (d) => readdirSync(d).flatMap((n) => { const p = join(d, n); return statSync(p).isDirectory() ? walk(p) : [p]; });
for (const pair of pairs) { const [name, dir] = pair.split('='); const files = {}; for (const f of walk(dir)) files[relative(dir, f)] = readFileSync(f);
  const z = fflate.zipSync(files, { level: 6 }); writeFileSync(join(out, name + '.zip'), z); console.log(name, Object.keys(files).length, 'files', z.length, 'bytes'); }
