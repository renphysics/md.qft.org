// Q2 deep links / reload / two decks at once (root mount) and Q3 presenter sync. Output out/q2q3.json
import { writeFileSync } from 'node:fs';
import { startServers, launch, newApp, slidevState, slidevInteract, waitH1, frameByName, sleep } from './lib.mjs';
const stop = await startServers(); const browser = await launch(); const out = {};
const clean = (o) => o;
const press = async (page, name, key, n = 1) => { const b = await (await page.$(`iframe[name="${name}"]`)).boundingBox(); await page.mouse.click(b.x + b.width / 2, b.y + b.height * 0.85); for (let i = 0; i < n; i++) { await page.keyboard.press(key); await sleep(250); } };
try {
  // a. deep links into a default build (base "/", history router) mounted at the player root
  if (!process.env.SKIP_A) { const { context, page, rec } = await newApp(browser); const L = await page.evaluate(() => window.load({ zip: "zips/ordinary.zip", id: "A1" }));
    out.deep = {};
    for (const r of ['/2', '/presenter/1', '/overview', '/notes', '/entry', '/3?clicks=1', '/5', '/presenter/2']) {
      const q = r.includes('?') ? r + '&__deck=A1' : r + '?__deck=A1';
      await page.evaluate((u) => window.frameOpen('A', u), q); await sleep(1500);
      const s = await slidevState(frameByName(page, 'A'));
      const extra = await frameByName(page, 'A').evaluate(() => ({ iframesInPage: document.querySelectorAll('iframe').length, slideContainers: document.querySelectorAll('.slidev-slide-container, .slidev-slides-container').length, noteText: (document.querySelector('.slidev-note, [class*="note"]') || {}).textContent?.slice(0, 40) || null, h1s: [...document.querySelectorAll('h1')].map((h) => h.textContent).slice(0, 6) }));
      out.deep[r] = { href: s.href, h1: s.h1, pages: s.pages, hidden: s.hidden, body: s.body, ...extra };
    }
    // b. reload of the frame: with the token kept in the URL, and after the deck dropped it (history.replaceState)
    await page.evaluate(() => window.frameOpen('A', '/1?__deck=A1')); await waitH1(page, 'A', 'Quantum'); await press(page, 'A', 'ArrowRight', 4);
    const before = await slidevState(frameByName(page, 'A'));
    await frameByName(page, 'A').evaluate(() => location.reload()); await sleep(1500);
    const afterReload = await slidevState(frameByName(page, 'A'));
    await frameByName(page, 'A').evaluate(() => history.replaceState(null, '', '/3')); await frameByName(page, 'A').evaluate(() => location.reload()); await sleep(1500);
    const afterTokenlessReload = await slidevState(frameByName(page, 'A'));
    out.reload = { before: before.href + ' ' + before.h1, afterReload: afterReload.href + ' ' + afterReload.h1, afterTokenlessReload: afterTokenlessReload.href + ' ' + (afterTokenlessReload.h1 || afterTokenlessReload.body), stats: (await page.evaluate(() => window.stats())).byResolver, misses: (await page.evaluate(() => window.stats())).misses };
    out.deepErrors = [...new Set(rec.errors.filter((e) => !/violates/.test(e)))].slice(0, 6);
    await context.close(); }
  // c. two different decks at the same time, both at "/" of the player origin
  { const { context, page, rec } = await newApp(browser);
    await page.evaluate(() => window.load({ zip: 'zips/ordinary.zip', id: 'DA' })); await page.evaluate(() => window.load({ zip: 'zips/hash-abs.zip', id: 'DB' }));
    await page.evaluate(() => Promise.all([window.frameOpen('A', '/?__deck=DA'), window.frameOpen('B', '/?__deck=DB')]));
    const a0 = await waitH1(page, 'A', 'Quantum'), b0 = await waitH1(page, 'B', 'Quantum');
    await press(page, 'A', 'ArrowRight', 4); await sleep(800);
    const a1 = await slidevState(frameByName(page, 'A')), b1 = await slidevState(frameByName(page, 'B'));
    const ls = await frameByName(page, 'B').evaluate(() => Object.keys(localStorage).filter((k) => /slidev/.test(k)).length);
    const ib = await slidevInteract(page, 'B'); // full interaction on B as well
    out.twoDecks = { A0: a0.href, B0: b0.href, afterNavA: { A: a1.href + ' ' + a1.h1, B: b1.href + ' ' + b1.h1 }, sharedSlidevLocalStorageKeysSeenByB: ls, interactB: { ok: ib.ok, url3: ib.url3 } };
    // same deck title, different decks: does Slidev's BroadcastChannel ("<title> - Slidev - shared") couple them?
    await press(page, 'B', 'ArrowLeft', 1); await sleep(800);
    out.twoDecks.afterBLeft = { A: (await slidevState(frameByName(page, 'A'))).href, B: (await slidevState(frameByName(page, 'B'))).href };
    out.twoDecksErrors = [...new Set(rec.errors.filter((e) => !/violates/.test(e)))].slice(0, 6);
    await context.close(); }
  // d. Q3 presenter + audience in two frames, and presenter in a popup window opened without the token
  { const { context, page, rec } = await newApp(browser); await page.evaluate(() => window.load({ zip: 'zips/ordinary.zip', id: 'PA' }));
    await page.evaluate(() => Promise.all([window.frameOpen('V', '/1?__deck=PA'), window.frameOpen('P', '/presenter/1?__deck=PA')]));
    await waitH1(page, 'V', 'Quantum'); await sleep(1000);
    await press(page, 'P', 'ArrowRight', 2); await sleep(600);
    const v1 = await slidevState(frameByName(page, 'V'));
    await press(page, 'P', 'ArrowRight', 3); await sleep(600);
    const v2 = await slidevState(frameByName(page, 'V')), p2 = await slidevState(frameByName(page, 'P'));
    // popup: like Slidev's own "presenter" link (an <a target=_blank href="/presenter/N"> without our token)
    const popP = context.waitForEvent('page', { timeout: 6000 }).catch(() => null);
    await frameByName(page, 'V').evaluate(() => { const a = document.createElement('a'); a.href = '/presenter/3'; a.target = '_blank'; document.body.append(a); a.click(); });
    const pop = await popP; let popup = null;
    if (pop) { await pop.waitForLoadState('load'); await sleep(2000); const s = await slidevState(pop); await pop.bringToFront(); await pop.mouse.click(300, 650); await pop.keyboard.press('ArrowRight'); await sleep(900); await page.bringToFront();
      popup = { url: pop.url().replace(/^https?:\/\/[^/]+/, ''), h1s: await pop.evaluate(() => [...document.querySelectorAll('h1')].map((h) => h.textContent).slice(0, 4)).catch(() => null), state: s.body, audienceAfterPopupRight: (await slidevState(frameByName(page, 'V'))).href }; }
    const st = await page.evaluate(() => window.stats());
    out.presenter = { audienceAfter2: v1.href + ' hidden=' + v1.hidden, audienceAfter5: v2.href + ' ' + v2.h1, presenterAfter5: p2.href, popup, resolvers: st.byResolver, misses: st.misses.slice(0, 4), errors: [...new Set(rec.errors.filter((e) => !/violates/.test(e)))].slice(0, 6) };
    await context.close(); }
} finally { await browser.close(); stop(); }
const o = clean(out, ['A1', 'DA', 'DB', 'PA']); writeFileSync(new URL(process.env.SKIP_A ? '../out/q2q3-cd.json' : '../out/q2q3.json', import.meta.url), JSON.stringify(o, null, 1)); console.log(JSON.stringify(o, null, 1));
