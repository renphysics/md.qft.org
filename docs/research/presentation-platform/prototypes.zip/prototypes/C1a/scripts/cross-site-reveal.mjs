// Reveal speaker view (popup) when app and player are different SITES, with and without storage partitioning.
import { startServers, launch, launchPartitioned, newApp, frameByName, sleep } from './lib.mjs';
const stop = await startServers(); const res = {};
try {
  for (const [label, appUrl, part] of [['same-site', 'http://127.0.0.1:4600', true], ['cross-site', 'http://localhost:4600', true]]) {
    process.env.APPURL = appUrl; const browser = part ? await launchPartitioned() : await launch();
    const { context, page } = await newApp(browser);
    const L = await page.evaluate(() => window.load({ zip: 'zips/classic6.zip' }));
    await page.evaluate((u) => window.frameOpen('A', u), `/d/${L.id}/index.html`); await sleep(1500);
    const b = await (await page.$('iframe[name="A"]')).boundingBox(); await page.mouse.click(b.x + 640, b.y + 360);
    const popP = context.waitForEvent('page', { timeout: 6000 }).catch(() => null); await page.keyboard.press('s'); const pop = await popP; await sleep(5000);
    res[label + (part ? ' partitioned' : '')] = pop ? await pop.evaluate(() => ({ path: location.pathname.replace(/\/d\/[^/]+/, '/d/<id>'), controlled: !!navigator.serviceWorker.controller, iframes: [...document.querySelectorAll('iframe')].map((f) => { try { return f.contentWindow.location.pathname.replace(/\/d\/[^/]+/, '') + ' ready=' + f.contentWindow.Reveal.isReady(); } catch (e) { return 'ERR ' + e.name; } }), body: document.body.innerText.replace(/\s+/g, ' ').slice(0, 60) })).catch((e) => 'ERR ' + e.message.slice(0, 80)) : 'no popup';
    await browser.close();
  }
} finally { stop(); }
console.log(JSON.stringify(res, null, 1));
