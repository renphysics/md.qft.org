// Q1c + Q5 first-open: the 37 MB official template build (314 files) served unmodified at the player root.
// Usage: node q1c-starter.mjs block|allow   Output out/q1c-<mode>.json
import { writeFileSync, readFileSync } from 'node:fs';
import { startServers, launch, newApp, slidevState, waitH1, frameByName, sleep } from './lib.mjs';
const mode = process.argv[2] || 'block';
const stop = await startServers(); const browser = await launch(); const out = { mode };
async function rss() { // sum of VmRSS over all processes of this browser
  const s = await browser.newBrowserCDPSession(); const { processInfo } = await s.send('SystemInfo.getProcessInfo'); await s.detach();
  let kb = 0; for (const p of processInfo) { try { kb += Number(/VmRSS:\s+(\d+)/.exec(readFileSync(`/proc/${p.id}/status`, 'utf8'))[1]); } catch {} }
  return { mb: Math.round(kb / 1024), processes: processInfo.length };
}
try {
  const { context, page, rec } = await newApp(browser, { blockExternal: mode === 'block' });
  const workers = []; page.on('worker', (w) => workers.push(w.url().replace(/^https?:\/\/[^/]+/, '').slice(0, 80)));
  await sleep(500); out.rssAppOnly = await rss();
  const t0 = Date.now();
  const L = await page.evaluate((net) => window.load({ zip: 'zips/starter.zip', id: 'KS', store: 'cache', net }), mode); out.load = { ...L, sw: { ms: L.sw.ms, base: L.sw.base, relayMs: L.sw.relayMs } };
  out.rssAfterStore = await rss();
  await page.evaluate(() => window.frameOpen('A', '/1?__deck=KS'));
  const first = await waitH1(page, 'A', 'Welcome', 20000); out.firstRender = { ok: first.ok, msAfterStore: Date.now() - t0 - L.fetchMs - L.unzipMs - L.storeMs, totalMsFromClick: Date.now() - t0 };
  await sleep(1500); out.rssAfterFirstRender = await rss();
  out.slides = [];
  for (let n = 1; n <= 16; n++) {
    const w0 = workers.length, e0 = rec.errors.length, x0 = rec.external.length;
    await page.evaluate((u) => window.frameNav('A', u), `/${n}?__deck=KS`); await sleep(1800);
    const f = frameByName(page, 'A');
    const info = await f.evaluate(() => {
      const cur = [...document.querySelectorAll('.slidev-page')].find((p) => { let e = p; while (e && e !== document.body) { if (getComputedStyle(e).display === 'none') return false; e = e.parentElement; } return true; });
      const imgs = cur ? [...cur.querySelectorAll('img')] : [];
      return { h1: cur?.querySelector('h1,h2')?.textContent.trim().slice(0, 30) ?? null, monaco: cur ? cur.querySelectorAll('.monaco-editor').length : 0, imgs: imgs.length, imgsLoaded: imgs.filter((i) => i.naturalWidth > 0).length, iframes: cur ? cur.querySelectorAll('iframe').length : 0, svg: cur ? cur.querySelectorAll('svg').length : 0, mermaid: cur ? cur.querySelectorAll('.mermaid svg, svg[id^="mermaid"]').length : 0, bg: cur ? getComputedStyle(cur.querySelector('.slidev-layout') || cur).backgroundImage.slice(0, 40) : null };
    }).catch((e) => ({ evalError: e.message.slice(0, 80) }));
    out.slides.push({ n, ...info, newWorkers: workers.slice(w0), errors: [...new Set(rec.errors.slice(e0).map((e) => e.replace(/violates the following.*$/, 'violates CSP')))].slice(0, 3), external: [...new Set(rec.external.slice(x0))].slice(0, 4) });
    if (n === 15 && info.monaco) { // Monaco: type, then ask the TS worker for diagnostics via hover-free check: wait for squiggles
      try { await f.locator('.monaco-editor').first().click(); await page.keyboard.type('\nconst x: number = "s"\n'); await sleep(3500);
        out.monaco = await f.evaluate(() => ({ lines: document.querySelector('.monaco-editor .view-lines')?.innerText.split('\n').length, squiggles: document.querySelectorAll('.monaco-editor .squiggly-error').length, text: document.querySelector('.monaco-editor .view-lines')?.innerText.slice(-40) }));
      } catch (e) { out.monaco = 'ERR ' + e.message.split('\n')[0].slice(0, 100); }
    }
  }
  out.rssAfterWalk = await rss();
  out.allWorkers = [...new Set(workers)]; out.allExternal = [...new Set(rec.external)].slice(0, 30); out.bad = [...new Set(rec.bad)].slice(0, 10);
  out.errors = [...new Set(rec.errors.map((e) => e.replace(/violates the following.*$/, 'violates CSP')))].slice(0, 25);
  out.stats = await page.evaluate(() => window.stats()); delete out.stats.meta;
  await context.close();
} finally { await browser.close(); stop(); }
writeFileSync(new URL(`../out/q1c-${mode}.json`, import.meta.url), JSON.stringify(out, null, 1));
const { slides, ...rest } = out; console.log(JSON.stringify(rest, null, 1)); for (const s of slides) console.log(JSON.stringify(s));
