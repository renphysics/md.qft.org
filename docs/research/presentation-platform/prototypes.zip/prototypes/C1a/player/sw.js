// C1a player-origin service worker. Research prototype, extends B1's sw.js.
// Serves unzipped deck files. Mounts: (i) prefix /d/<id>/..., (iii) prefix /r/<id>/... with base rewriting,
// (ii) "root mount": the deck is served at its own build base on the origin root; which deck a request belongs to
// is resolved from ?__deck=<id> on the navigation, then FetchEvent.clientId / resultingClientId, then Referer, then client URL.
// Stores: 'memory' (Map in the worker), 'cache' (Cache Storage), 'ondemand' (asks the host page, which asks the app via a MessagePort).
const CSP_BLOCK = "default-src 'self' 'unsafe-inline' 'unsafe-eval' data: blob:; connect-src 'self' data: blob:; form-action 'none'; base-uri 'self'";
const TYPES = { html: 'text/html; charset=utf-8', htm: 'text/html; charset=utf-8', js: 'text/javascript; charset=utf-8', mjs: 'text/javascript; charset=utf-8', css: 'text/css; charset=utf-8', json: 'application/json', md: 'text/markdown; charset=utf-8', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', svg: 'image/svg+xml', webp: 'image/webp', woff: 'font/woff', woff2: 'font/woff2', ttf: 'font/ttf', mp4: 'video/mp4', webm: 'video/webm', mp3: 'audio/mpeg', txt: 'text/plain; charset=utf-8', map: 'application/json', wasm: 'application/wasm', ico: 'image/x-icon' };
const typeOf = (p) => TYPES[p.split('.').pop().toLowerCase()] || 'application/octet-stream';
const BOOT = Date.now();
const mem = new Map();        // id -> Map(path -> ArrayBuffer)       (store 'memory')
const meta = new Map();       // id -> { store, net, base }           (persisted to cache 'vfs-meta' unless store 'memory')
const clientDeck = new Map(); // clientId -> id
const stats = { boot: BOOT, served: 0, byResolver: {}, misses: [], needs: 0 };
self.addEventListener('install', (e) => e.waitUntil(self.skipWaiting()));
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));

const metaReq = (k) => new Request(self.location.origin + '/__meta/' + k);
async function metaPut(k, v) { const c = await caches.open('vfs-meta'); await c.put(metaReq(k), new Response(JSON.stringify(v))); }
async function metaGet(k) { const c = await caches.open('vfs-meta'); const r = await c.match(metaReq(k)); return r ? r.json() : null; }
async function getMeta(id) { if (!meta.has(id)) { const m = await metaGet('deck/' + id); if (m) meta.set(id, m); } return meta.get(id); }
async function mapClient(clientId, id) { if (!clientId || clientDeck.get(clientId) === id) return; clientDeck.set(clientId, id); const m = meta.get(id); if (m && m.store !== 'memory') await metaPut('client/' + clientId, id); }
async function lookupClient(clientId) { if (!clientId) return null; if (clientDeck.has(clientId)) return clientDeck.get(clientId); const id = await metaGet('client/' + clientId); if (id) clientDeck.set(clientId, id); return id; }
const fileKey = (id, path) => new Request(self.location.origin + '/__vfs/' + id + '/' + path.split('/').map(encodeURIComponent).join('/'));

function detectBase(html) { // base of a Vite build = directory of the entry module script, if absolute
  const m = /<script[^>]+type="module"[^>]*src="(\/[^"]*?)assets\/[^"]+\.js"/.exec(html) || /<script[^>]+src="(\/[^"]*?)assets\/[^"]+\.js"[^>]*type="module"/.exec(html);
  return m ? m[1] : null;
}

self.addEventListener('message', (e) => {
  const m = e.data, port = e.ports[0]; if (!m || !port) return;
  (async () => {
    const t0 = performance.now();
    if (m.op === 'put' || m.op === 'patch') {
      let d = m.op === 'put' ? { store: m.store || 'cache', net: m.net || 'block', base: null } : await getMeta(m.id);
      if (!d) throw new Error('unknown deck ' + m.id);
      if (m.op === 'put') { mem.delete(m.id); await caches.delete('vfs-' + m.id); }
      if (d.store === 'memory') { const map = mem.get(m.id) || new Map(); for (const f of m.files) map.set(f.path, f.bytes); mem.set(m.id, map); }
      else if (d.store === 'cache') { const c = await caches.open('vfs-' + m.id); await Promise.all(m.files.map((f) => c.put(fileKey(m.id, f.path), new Response(f.bytes, { headers: { 'content-type': typeOf(f.path) } })))); }
      const idx = m.files.find((f) => f.path === 'index.html');
      if (idx) d.base = detectBase(new TextDecoder().decode(idx.bytes)) || null;
      meta.set(m.id, d); if (d.store !== 'memory') await metaPut('deck/' + m.id, d);
      port.postMessage({ ok: true, id: m.id, base: d.base, ms: Math.round(performance.now() - t0) });
    } else if (m.op === 'stats') {
      port.postMessage({ ok: true, ...stats, clients: clientDeck.size, decksInMemory: mem.size, meta: Object.fromEntries(meta) });
    } else if (m.op === 'forget') { meta.delete(m.id); mem.delete(m.id); await caches.delete('vfs-' + m.id); port.postMessage({ ok: true }); }
  })().catch((err) => port.postMessage({ ok: false, error: String(err) }));
});

async function askHost(id, path) { // store 'ondemand': SW -> host page (player origin) -> app page, reply comes back on the port
  stats.needs++;
  const all = await self.clients.matchAll({ includeUncontrolled: true, type: 'window' });
  const host = all.find((c) => new URL(c.url).pathname === '/__host.html');
  if (!host) return null;
  const ch = new MessageChannel();
  const reply = new Promise((resolve) => { ch.port1.onmessage = (ev) => resolve(ev.data); setTimeout(() => resolve(null), 5000); });
  host.postMessage({ op: 'need', id, path }, [ch.port2]);
  const r = await reply; return r && r.bytes ? r.bytes : null;
}

async function readFile(id, d, path) {
  if (d.store === 'memory') { const map = mem.get(id); return map && map.has(path) ? map.get(path) : null; }
  if (d.store === 'cache') { const c = await caches.open('vfs-' + id); const r = await c.match(fileKey(id, path)); return r ? r.arrayBuffer() : null; }
  return askHost(id, path);
}

function rewrite(text, type, prefix) { // strategy (iii): retarget an absolute-base ("/") Vite/Slidev build to /r/<id>/
  if (type.startsWith('text/html')) return text.replace(/(\s(?:src|href)=")\/(?!\/)/g, '$1' + prefix);
  if (type.startsWith('text/javascript')) return text
    .replace(/([`"'])\/assets\//g, '$1' + prefix + 'assets/')
    .replace(/history:(\w+)\(`\/`\)/g, 'history:$1(`' + prefix + '`)')
    .replace(/`\/`\+(\w)\b/g, '`' + prefix + '`+$1');
  if (type.startsWith('text/css')) return text.replace(/url\(\/(?!\/)/g, 'url(' + prefix);
  return text;
}

const tokenOf = (u) => { try { return new URL(u).searchParams.get('__deck'); } catch { return null; } };

self.addEventListener('fetch', (event) => {
  const req = event.request; const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;              // cross-origin: browser default (CSP decides)
  if (url.pathname === '/sw.js' || url.pathname === '/__host.html') return;
  event.respondWith((async () => {
    let id, rel, how, mount;
    const seg = url.pathname.split('/');
    if ((seg[1] === 'd' || seg[1] === 'r') && seg[2] && (await getMeta(seg[2]))) { mount = seg[1]; id = seg[2]; rel = seg.slice(3).join('/'); how = 'prefix'; }
    else {
      mount = 'root';
      if (req.mode === 'navigate' || req.destination === 'iframe') {
        id = tokenOf(req.url); how = 'token';
        if (!id) { id = tokenOf(req.referrer); how = 'referrer-token'; }
        if (!id && req.referrer) { // referrer is a same-origin deck page without token: find the client with that URL
          const cs = await self.clients.matchAll({ type: 'window' }); const hit = [];
          for (const c of cs) if (c.url === req.referrer) { const x = await lookupClient(c.id); if (x) hit.push(x); }
          if (new Set(hit).size === 1) { id = hit[0]; how = 'referrer-client'; }
        }
        if (!id && event.clientId) { id = await lookupClient(event.clientId); how = 'nav-clientId'; }
        if (id) await mapClient(event.resultingClientId, id);
      } else {
        id = await lookupClient(event.clientId); how = 'clientId';
        if (!id && event.clientId) { const c = await self.clients.get(event.clientId); if (c) { id = tokenOf(c.url); how = 'client-url'; if (id) await mapClient(event.clientId, id); } }
        if (id && event.resultingClientId) await mapClient(event.resultingClientId, id); // dedicated/shared worker scripts
      }
      if (!id) { stats.misses.push(url.pathname + ' mode=' + req.mode + ' dest=' + req.destination + ' cid=' + (event.clientId ? 'y' : 'n') + ' ref=' + req.referrer.slice(0, 60)); return new Response('No deck for this request', { status: 404 }); }
      const d0 = await getMeta(id); if (!d0) return new Response('Unknown deck', { status: 404 });
      rel = url.pathname.slice(1);
      if (d0.base && d0.base !== '/' && url.pathname.startsWith(d0.base)) rel = url.pathname.slice(d0.base.length);
    }
    const d = await getMeta(id); if (!d) return new Response('Unknown deck', { status: 404 });
    stats.byResolver[how] = (stats.byResolver[how] || 0) + 1;
    let path = decodeURIComponent(rel); if (path === '' || path.endsWith('/')) path += 'index.html';
    let body = await readFile(id, d, path);
    if (!body && !/\.[a-z0-9]+$/i.test(path)) { body = await readFile(id, d, path + '/index.html') || await readFile(id, d, path + '.html'); if (body) path = path + '/index.html'; }
    if (!body && req.mode === 'navigate') { body = await readFile(id, d, 'index.html'); path = 'index.html'; } // SPA fallback (like 404.html on Pages)
    if (!body) { stats.misses.push('404 ' + id + ':' + path); return new Response('Not in package: ' + path, { status: 404, headers: { 'content-type': 'text/plain' } }); }
    const type = typeOf(path);
    if (mount === 'r' && /^text\/(html|javascript|css)/.test(type)) body = rewrite(new TextDecoder().decode(body), type, '/r/' + id + '/');
    const headers = new Headers({ 'content-type': type, 'cache-control': 'no-store', 'x-content-type-options': 'nosniff', 'x-c1a-resolved': how + ' boot=' + BOOT });
    if (d.net === 'block') headers.set('content-security-policy', CSP_BLOCK);
    stats.served++;
    return new Response(body, { status: 200, headers });
  })());
});
