# Research prototypes

Snapshots of the prototypes, test scripts and logs behind `docs/research/presentation-platform/README.md`.
They prove feasibility and record how each claim was tested. They are not production code and are not maintained.

- Written by research agents in a temporary container. Absolute paths were replaced by `SCRATCH`; scripts need their
  paths, ports and dependencies adjusted before they run again.
- Removed to keep the archive small and clean: `node_modules`, build outputs, downloaded npm packages, third-party
  decks, vendored library copies, screenshots, and logs larger than 64 KB.
- `.ts` and `.vue` files carry an extra `.txt` suffix.
- Several folders contain hostile test pages (sandbox-escape probes aimed at local listeners). They exist to test
  this site's own sandbox.

## Most reusable files

| File | What it is |
| --- | --- |
| `B7/scripts/inline-deck.mjs` | Reveal.js adapter: inlines a deck, maps reveal.js/KaTeX CDN URLs to bundled copies, math shim, History guard |
| `A2/scripts/wrap-reveal.mjs` | Simpler five-rewrite wrapper; converts inline event handlers |
| `B1/www/reveal-compat-shim.js` | 2.2 KB shim: tolerant History, fullscreen forward, inert window.open |
| `B1/www/detect-reveal.js` | Reveal.js deck detector (entry file, version, problems) |
| `B1/www/live-agent.js` | In-deck agent for reload and in-place slide swap |
| `B2/packer/convert-dist.mjs` | Converts an ordinary Slidev build into one HTML (six patches plus bundling) |
| `B2/wasmtest/site/worker.js` | The same conversion in a same-origin Worker with esbuild-wasm |
| `B2/tools/detect.mjs` | Slidev upload classifier |
| `B2/inbrowser/compiler/src/` | In-browser Slidev compiler glue; `B2/inbrowser/generic-client/` is the client configuration |
| `B6/reveal-lab/slide-map.mjs` | Static slide-to-source mapper |
| `B6/patch-lab/patch-apply.mjs` | Paste-in importer for AI answers (see V2 for its failure cases) |
| `B6/live-lab/bridge-reveal.js`, `bridge-slidev.js` | Host bridges for slide sync |
| `B7/artefacts/` | Short AI prompts, skill outline, check-report schema, well-known index example |
| `C1a/player/sw.js` | Served mode: root-mount worker that played 9/9 Slidev builds |
| `C1b/player2/sw.js`, `C1b/player2/boot.html` | Served mode: hardened design |
| `B1/sandbox-origin/sw.js` | First served-mode prototype. Unsafe as written; see `findings/C1b.txt` |
| `A1/hostile-battery.html`, `C1b/hostile/battery.js`, `V1/*.cjs` | Security probes |
| `M1/rtc-bypass2.cjs` | Shows that removing RTCPeerConnection is bypassed from a srcdoc child frame |

`../test-decks/` holds the two decks written by AI assistants for the study.
