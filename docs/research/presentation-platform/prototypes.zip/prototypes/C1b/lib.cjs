// C1b shared helpers: static servers, attacker listeners. Ports 4620-4649 only.
const http = require('node:http'); const net = require('node:net'); const dgram = require('node:dgram'); const fs = require('node:fs'); const path = require('node:path');
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.zip': 'application/zip', '.png': 'image/png', '.txt': 'text/plain' };
function startStatic(port, dir, extraHeaders = {}) {
  const log = [];
  const server = http.createServer((req, res) => {
    const url = new URL(req.url, 'http://x'); log.push({ method: req.method, url: req.url, dest: req.headers['sec-fetch-dest'], sw: req.headers['service-worker'] });
    if (url.pathname === '/csd') { res.writeHead(200, { 'content-type': 'text/plain', 'Clear-Site-Data': '"storage"' }); return res.end('cleared'); }
    let file = path.join(dir, decodeURIComponent(url.pathname)); if (!file.startsWith(dir)) { res.writeHead(403); return res.end(); }
    if (fs.existsSync(file) && fs.statSync(file).isDirectory()) file = path.join(file, 'index.html');
    if (!fs.existsSync(file)) { res.writeHead(404, { 'content-type': 'text/plain' }); return res.end('static 404 ' + url.pathname); }
    res.writeHead(200, { 'content-type': MIME[path.extname(file)] || 'application/octet-stream', 'cache-control': 'no-store', ...extraHeaders }); fs.createReadStream(file).pipe(res);
  });
  return new Promise((r) => server.listen(port, '0.0.0.0', () => r({ log, close: () => new Promise((d) => { server.closeAllConnections(); server.close(() => d()); }) })));
}
function startEvil(port) {
  const log = [];
  const server = http.createServer((req, res) => {
    let body = ''; req.on('data', (c) => { body += c; }); req.on('end', () => {
      const u = new URL(req.url, 'http://x');
      log.push({ method: req.method, url: req.url, c: u.searchParams.get('c'), run: u.searchParams.get('run'), referer: req.headers.referer, origin: req.headers.origin, dest: req.headers['sec-fetch-dest'], site: req.headers['sec-fetch-site'], purpose: req.headers['sec-purpose'], body: body.slice(0, 80) });
      const p = u.pathname; const type = p.endsWith('.js') ? 'text/javascript' : p.endsWith('.css') ? 'text/css' : p.endsWith('.html') || p === '/page' ? 'text/html' : p.endsWith('.png') ? 'image/png' : 'text/plain';
      res.writeHead(200, { 'content-type': type, 'access-control-allow-origin': '*', 'cache-control': 'no-store' });
      res.end(type === 'text/javascript' ? 'self.__evilScriptRan=true;' : type === 'text/css' ? 'body{outline:1px solid red}' : type === 'text/html' ? '<!doctype html><title>evil</title>evil page' : 'ok');
    });
  });
  server.on('upgrade', (req, socket) => { const u = new URL(req.url, 'http://x'); log.push({ method: 'UPGRADE', url: req.url, c: u.searchParams.get('c'), run: u.searchParams.get('run') }); socket.destroy(); });
  return new Promise((r) => server.listen(port, '0.0.0.0', () => r({ log, close: () => new Promise((d) => { server.closeAllConnections(); server.close(() => d()); }) })));
}
function startUdp(port) { const log = []; const s = dgram.createSocket('udp4'); s.on('message', (m, ri) => log.push({ t: Date.now(), len: m.length, hex: m.subarray(0, 8).toString('hex'), from: ri.address })); return new Promise((r) => s.bind(port, '0.0.0.0', () => r({ log, close: () => new Promise((d) => s.close(d)) }))); }
function startTcp(port) { const log = []; const server = net.createServer((sock) => { const e = { t: Date.now(), first: '' }; log.push(e); sock.on('data', (c) => { e.first += c.toString('latin1').slice(0, 80); }); sock.on('error', () => {}); setTimeout(() => sock.destroy(), 1000); }); return new Promise((r) => server.listen(port, '0.0.0.0', () => r({ log, close: () => new Promise((d) => server.close(d)) }))); }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const withTimeout = (p, ms) => Promise.race([p.then((value) => ({ ok: true, value })), sleep(ms).then(() => ({ ok: false, value: `no answer within ${ms} ms` }))]);
async function targets(browser) { const s = await browser.newBrowserCDPSession(); const { targetInfos } = await s.send('Target.getTargets'); let procs = null; try { procs = (await s.send('SystemInfo.getProcessInfo')).processInfo.map((p) => p.type); } catch {} await s.detach(); return { targets: targetInfos.map((t) => `${t.type} ${t.url.slice(0, 70)}`), renderers: procs ? procs.filter((p) => p === 'renderer').length : null }; }
module.exports = { startStatic, startEvil, startUdp, startTcp, sleep, withTimeout, targets, DIR: __dirname };
// Playwright disables ThirdPartyStoragePartitioning (and adds --disable-background-networking). realLaunch() restores Chrome's shipping default.
async function realLaunch(extra = [], { background = false } = {}) {
  const { chromium } = require('playwright');
  const b0 = await chromium.launchServer({ channel: 'chromium' }); const args = fs.readFileSync('/proc/' + b0.process().pid + '/cmdline', 'utf8').split('\0'); await b0.close();
  const df = args.find((a) => a.startsWith('--disable-features=')); const kept = df.slice('--disable-features='.length).split(',').filter((f) => f !== 'ThirdPartyStoragePartitioning');
  const ignore = [df]; if (background) ignore.push('--disable-background-networking');
  const browser = await chromium.launch({ channel: 'chromium', ignoreDefaultArgs: ignore, args: ['--disable-features=' + kept.join(','), ...extra] });
  browser.__note = 'ThirdPartyStoragePartitioning re-enabled' + (background ? ', background networking enabled' : ''); return browser;
}
module.exports.realLaunch = realLaunch;
