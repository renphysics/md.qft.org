// Q4: are worker-delivered headers enforced, and which egress channels stay open? node q4.cjs [same|cross]
const L = require('./lib.cjs'); const fs = require('node:fs'); const H = require('./hostile/battery.js');
const mode = process.argv[2] || 'cross'; const APP = (mode === 'same' ? 'http://127.0.0.1' : 'http://localhost') + ':4620'; const PLAYER = 'http://127.0.0.1:4622';
const EVIL = 'http://127.0.0.2:4630'; const cfgBase = { evil: EVIL, stun: 'stun:127.0.0.2:4631', tcp: 'http://127.0.0.2:4632', wt: 'https://127.0.0.2:4633' };
(async () => {
  const app = await L.startStatic(4620, L.DIR + '/app'); const player = await L.startStatic(4622, L.DIR + '/player2'); const evil = await L.startEvil(4630); const udp = await L.startUdp(4631); const tcp = await L.startTcp(4632);
  const browser = await L.realLaunch([], { background: true }); const out = { mode, version: browser.version(), launch: browser.__note, runs: {} };
  const open = async (opts) => { const context = await browser.newContext(); const page = await context.newPage(); const dialogs = []; page.on('dialog', (d) => { dialogs.push(d.type() + ': ' + d.message()); d.dismiss().catch(() => {}); });
    await page.goto(`${APP}/app.html?player=${encodeURIComponent(PLAYER)}`); const o = await page.evaluate((x) => window.openV2(x), { files: H.files, ...opts }); const frame = page.frames().find((f) => f.url().includes('/vfs/')); return { context, page, frame, o, dialogs }; };
  const batteryRun = async (run, opts) => {
    const { context, frame, o } = await open(opts); const u0 = udp.log.length, t0 = tcp.log.length, s0 = player.log.length; let results;
    try { results = await frame.evaluate(H.battery, { ...cfgBase, run }); } catch (e) { results = { error: e.message.split('\n')[0] }; }
    await L.sleep(3000); const hits = evil.log.filter((l) => l.run === run);
    out.runs[run] = { opts: { ...opts, files: undefined }, boot: o.bootInfo && { controlled: o.bootInfo.controlled, report: o.bootInfo.report }, ack: o.ack && o.ack.type, reachedAttacker: [...new Set(hits.map((l) => l.c))], hitDetails: hits.map((l) => `${l.c}: ${l.method} dest=${l.dest} site=${l.site} referer=${l.referer} origin=${l.origin}${l.purpose ? ' sec-purpose=' + l.purpose : ''}`).slice(0, 60), stunPackets: udp.log.length - u0, tcpConnections: tcp.log.slice(t0).map((x) => x.first.slice(0, 30)), staticHostSaw: player.log.slice(s0).map((l) => l.url.slice(0, 60) + (l.sw ? ' [Service-Worker: script]' : '')), results };
    await context.close();
  };
  try {
    await batteryRun('A-control-no-policy', { headers: { 'Cache-Control': 'no-store' } });
    await batteryRun('B-offline-policy-all-responses', { policy: 'offline' });
    await batteryRun('C-offline-policy-html-only', { policy: 'offline', htmlOnly: true });
    // D: CSP sandbox directive delivered by the worker
    for (const [name, sb] of [['D1-csp-sandbox-allow-scripts', 'sandbox allow-scripts'], ['D2-csp-sandbox-allow-scripts-allow-same-origin', 'sandbox allow-scripts allow-same-origin']]) {
      const s0 = player.log.length; const { context, frame, o } = await open({ headers: { 'Content-Security-Policy': `default-src 'self' 'unsafe-inline' 'unsafe-eval' data: blob:; ${sb}` } });
      const r = frame ? await frame.evaluate(async () => ({ origin: self.origin, controller: (() => { try { return !!navigator.serviceWorker.controller; } catch (e) { return 'ERR ' + e.name; } })(), localStorage: (() => { try { localStorage.x = 1; return 'ok'; } catch (e) { return 'ERR ' + e.name; } })(), img: await new Promise((res) => { const i = new Image(); i.onload = () => res('load'); i.onerror = () => res('error'); i.src = 'plain.txt'; }), fetchSub: await fetch('sub.html').then((x) => 'status ' + x.status, (e) => 'ERR ' + e.message) })).catch((e) => 'ERR ' + e.message.split('\n')[0]) : 'no frame';
      out.runs[name] = { result: r, staticHostSaw: player.log.slice(s0).map((l) => l.url.slice(0, 70)) }; await context.close();
    }
    { // P: Permissions-Policy header from the worker, frame has allow="fullscreen"
      const a = await open({ headers: { 'Permissions-Policy': 'fullscreen=()' }, allow: 'fullscreen' }); const withHeader = await a.frame.evaluate(() => document.featurePolicy.allowsFeature('fullscreen')); await a.context.close();
      const b = await open({ headers: { 'Cache-Control': 'no-store' }, allow: 'fullscreen' }); const without = await b.frame.evaluate(() => document.featurePolicy.allowsFeature('fullscreen')); await b.context.close();
      out.runs['P-permissions-policy'] = { 'fullscreen allowed with worker header fullscreen=()': withHeader, 'fullscreen allowed without header': without };
    }
    { // G: Clear-Site-Data on a worker-synthesised response versus on a network response
      const g = await open({ headers: { 'Clear-Site-Data': '"storage"' } });
      out.runs['G-clear-site-data'] = await g.frame.evaluate(async () => { const state = async () => ({ ls: localStorage.getItem('k'), caches: await caches.keys(), regs: (await navigator.serviceWorker.getRegistrations()).length });
        localStorage.setItem('k', 'v'); await caches.open('c1'); const before = await state(); const r1 = await fetch('sub.html'); const hdr = r1.headers.get('clear-site-data'); await new Promise((r) => setTimeout(r, 800)); const afterWorkerResponse = await state();
        const r2 = await fetch('/csd').then((x) => x.status + ' ' + x.headers.get('clear-site-data'), (e) => 'ERR ' + e.message); await new Promise((r) => setTimeout(r, 1500)); const afterNetworkResponse = await state(); return { before, workerResponseHeader: hdr, afterWorkerResponse, networkResponse: r2, afterNetworkResponse }; }).catch((e) => 'ERR ' + e.message.split('\n')[0]);
      await g.context.close();
    }
  } catch (e) { out.error = String(e.stack).slice(0, 500); }
  finally { await Promise.race([browser.close(), L.sleep(5000)]); for (const s of [app, player, evil, udp, tcp]) await s.close(); }
  fs.writeFileSync(`${L.DIR}/out/q4-${mode}.json`, JSON.stringify(out, null, 1));
  for (const [k, v] of Object.entries(out.runs)) { console.log('=== ' + k); if (v.reachedAttacker) { console.log(' reached attacker HTTP:', v.reachedAttacker.join(', ')); console.log(' STUN packets:', v.stunPackets, '| TCP 4632 connections:', v.tcpConnections.length, '| static host saw:', JSON.stringify(v.staticHostSaw)); } else console.log(JSON.stringify(v)); }
  if (out.error) console.log(out.error);
})();
