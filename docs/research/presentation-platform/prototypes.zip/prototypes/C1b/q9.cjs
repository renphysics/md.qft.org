// Sanity: do real Reveal.js packages still play under the hardened flow (single sandboxed frame, memory-only worker, path-restricted fixed policy)?
const L = require('./lib.cjs'); const fs = require('node:fs'); const { unzipSync } = require('/home/user/md.qft.org/node_modules/fflate');
const Z = L.DIR + '/../B1/zips/'; const APP = 'http://localhost:4620'; const PLAYER = 'http://127.0.0.1:4622';
const cases = [['classic6.zip', 'index.html'], ['classic4.zip', 'index.html'], ['extmd6.zip', 'index.html'], ['esm6.zip', 'index.html'], ['plugins6.zip', 'menu.html'], ['plugins6.zip', 'chalkboard.html'], ['plugins6.zip', 'copycode.html'], ['plugins6.zip', 'mermaid.html'], ['corpus-n1.zip', 'index.html']];
(async () => {
  const app = await L.startStatic(4620, L.DIR + '/app'); const player = await L.startStatic(4622, L.DIR + '/player2'); const browser = await L.realLaunch(); const rows = [];
  try { for (const [zip, entry] of cases) {
    const files = {}; for (const [p, d] of Object.entries(unzipSync(new Uint8Array(fs.readFileSync(Z + zip))))) if (!p.endsWith('/')) files[p] = { b64: Buffer.from(d).toString('base64') };
    const context = await browser.newContext({ viewport: { width: 1200, height: 800 } }); const page = await context.newPage(); const csp = [], bad = []; page.on('console', (m) => { if (/Content Security Policy/i.test(m.text())) csp.push(m.text().slice(0, 150)); }); context.on('response', (r) => { if (r.status() >= 400) bad.push(r.status() + ' ' + r.url().replace(/^.*\/vfs\/[^/]+\//, '').slice(0, 50)); });
    await page.goto(`${APP}/app.html?player=${encodeURIComponent(PLAYER)}&fsrc=1`); const t0 = Date.now(); const o = await page.evaluate((x) => window.openV2(x), { files, entry, allow: 'fullscreen' }); await page.waitForTimeout(2500);
    const frame = page.frames().find((f) => f.url().includes('/vfs/')); const st = frame ? await frame.evaluate(() => { const R = window.Reveal || window.__deck; return { version: R && R.VERSION, ready: !!(R && R.isReady && R.isReady()), slides: R && R.getTotalSlides && R.getTotalSlides(), katex: document.querySelectorAll('.katex').length, menu: !!document.querySelector('.slide-menu-button'), mermaid: !!document.querySelector('.mermaid svg'), hljs: !!document.querySelector('code.hljs') }; }).catch((e) => 'ERR ' + e.message.split('\n')[0]) : 'no frame';
    rows.push({ zip, entry, files: Object.keys(files).length, ack: o.ack && o.ack.type, openMs: Date.now() - t0 - 2500, state: st, cspViolations: [...new Set(csp)].slice(0, 3), bad: [...new Set(bad)].slice(0, 4) }); console.log(JSON.stringify(rows[rows.length - 1])); await context.close(); } }
  catch (e) { console.log(String(e.stack).slice(0, 400)); }
  finally { await Promise.race([browser.close(), L.sleep(5000)]); await app.close(); await player.close(); }
  fs.writeFileSync(L.DIR + '/out/q9.json', JSON.stringify(rows, null, 1));
})();
