// Q1 + Q2: registration/control, storage partitioning, process model, freeze. node q1q2.cjs <same|cross> [extra chromium flag ...]
const { chromium } = require('playwright'); const L = require('./lib.cjs'); const fs = require('node:fs');
const mode = process.argv[2]; const flags = process.argv.slice(3);
const APP = (mode === 'same' ? 'http://127.0.0.1' : 'http://localhost') + ':4620'; const PLAYER = 'http://127.0.0.1:4621';
const deck = `<!doctype html><title>deck</title><body><h1>deck</h1><script>
localStorage.setItem('deck-ls','DECK-LS'); indexedDB.open('deck-db');
addEventListener('message', (e) => { if (e.data === 'loop') { for(;;){} } });
</script>`;
const rafStats = (page) => L.withTimeout(page.evaluate(() => new Promise((res) => { window.__raf.length = 0; setTimeout(() => { const a = window.__raf.slice(); res({ frames: a.length, maxGapMs: Math.max(0, ...a) }); }, 1500); })), 5000);
(async () => {
  const app = await L.startStatic(4620, L.DIR + '/app'); const player = await L.startStatic(4621, L.DIR + '/player1');
  const out = { mode, flags, APP, PLAYER };
  const real = flags.includes('real'); const browser = real ? await L.realLaunch(flags.filter((f) => f !== 'real')) : await chromium.launch({ channel: 'chromium', args: flags });
  try {
    out.version = browser.version(); const context = await browser.newContext(); const page = await context.newPage();
    await page.goto(`${APP}/app.html?player=${encodeURIComponent(PLAYER)}`);
    const o = await page.evaluate((deck) => window.openV1({ files: { 'index.html': deck } }), deck); out.boot = o.info && { controlled: o.info.controlled, files: o.info.files };
    const frame = page.frames().find((f) => f.url().includes('/vfs/'));
    out.deck = frame ? await frame.evaluate(async () => ({ origin: self.origin, controlled: !!navigator.serviceWorker.controller, regs: (await navigator.serviceWorker.getRegistrations()).length, caches: await caches.keys(), ls: localStorage.getItem('deck-ls'), idb: (await indexedDB.databases()).map((d) => d.name), hasStorageAccess: await document.hasStorageAccess(), cookieEnabled: navigator.cookieEnabled, persisted: await navigator.storage.persisted(), quotaMB: Math.round((await navigator.storage.estimate()).quota / 1e6) })).catch((e) => 'ERR ' + e.message.split('\n')[0]) : 'no deck frame (' + page.frames().map((f) => f.url()).join(' | ') + ')';
    out.processesWhilePlaying = await L.targets(browser);
    // top-level visit to the player origin in the same profile
    const top = await context.newPage(); await top.goto(PLAYER + '/sw-host.html'); await top.waitForTimeout(800);
    out.topLevelVisit = await top.evaluate(async (id) => ({ regsBeforeItsOwnRegister: 'n/a (page registers itself)', caches: await caches.keys(), ls: localStorage.getItem('deck-ls'), idb: (await indexedDB.databases()).map((d) => d.name), fetchDeck: await fetch('/vfs/' + id + '/index.html').then(async (r) => r.status + ' ' + (await r.text()).slice(0, 30)) }), o.id);
    const top2 = await context.newPage(); const resp = await top2.goto(PLAYER + '/vfs/' + o.id + '/index.html'); out.topLevelNavigateToDeckUrl = resp.status() + ' ' + (await top2.title()); await top2.close(); await top.close();
    // freeze
    out.rafBaseline = (await rafStats(page)).value;
    await page.evaluate(() => window.__frame.contentWindow.postMessage('loop', '*')); await L.sleep(600);
    const r = await rafStats(page); out.rafDuringDeckLoop = r.value;
    const t0 = Date.now(); const click = await L.withTimeout(page.locator('#stop').click({ timeout: 5000 }).then(() => 'clicked', (e) => 'CLICK FAILED: ' + e.message.split('\n')[0]), 6000); out.stopClick = click.ok ? `${click.value} after ${Date.now() - t0} ms` : click.value;
    const st = await L.withTimeout(page.evaluate(() => ({ handled: window.__stopHandled !== null, frames: document.querySelectorAll('#stage iframe').length })), 3000); out.afterStop = st.value;
    if (!st.ok) { out.note = 'app page frozen by the deck loop; opaque comparison run in a fresh page'; }
    // comparison: opaque sandbox (same-origin URL, sandbox="allow-scripts"), fresh page
    const page2 = await context.newPage(); await page2.goto(`${APP}/app.html?player=${encodeURIComponent(PLAYER)}`);
    await page2.evaluate(() => new Promise((res) => { const f = document.createElement('iframe'); f.setAttribute('sandbox', 'allow-scripts'); addEventListener('message', (e) => { if (e.data && e.data.type === 'opaque-loaded') res(); }); f.src = 'opaque.html'; document.getElementById('stage').replaceChildren(f); window.__frame = f; }));
    out.opaque = { processes: await L.targets(browser) };
    await page2.evaluate(() => window.__frame.contentWindow.postMessage('loop', '*')); await L.sleep(600);
    out.opaque.rafDuringLoop = (await rafStats(page2)).value;
    const t1 = Date.now(); const c2 = await L.withTimeout(page2.locator('#stop').click({ timeout: 5000 }).then(() => 'clicked', (e) => 'CLICK FAILED: ' + e.message.split('\n')[0]), 6000); out.opaque.stopClick = c2.ok ? `${c2.value} after ${Date.now() - t1} ms` : c2.value;
    await Promise.race([context.close().catch(() => {}), L.sleep(3000)]);
    // speaker view with the unmodified prototype page and classic6.zip
    const ctx2 = await browser.newContext({ viewport: { width: 1400, height: 800 } }); const p = await ctx2.newPage(); const bad = [];
    ctx2.on('response', (r) => { if (r.status() >= 400) bad.push(r.status() + ' ' + r.url().replace(/^.*\/vfs\/[^/]+\//, '').slice(0, 60)); });
    await p.goto(`${APP}/vfs-site.html?player=${encodeURIComponent(PLAYER)}`); await p.waitForFunction(() => typeof window.openZip === 'function');
    await p.evaluate(() => window.openZip({ zip: 'zips/classic6.zip' })); await p.waitForTimeout(2000);
    const df = p.frames().find((f) => f.url().includes('/vfs/')); out.reveal = df ? await df.evaluate(() => ({ ready: !!(window.Reveal && Reveal.isReady()), controlled: !!navigator.serviceWorker.controller })).catch((e) => 'ERR ' + e.message.split('\n')[0]) : 'no frame';
    await p.mouse.click(640, 360); const pp = ctx2.waitForEvent('page', { timeout: 5000 }).catch(() => null); await p.keyboard.press('s'); const popup = await pp; await p.waitForTimeout(5000);
    out.speaker = popup ? await popup.evaluate(() => ({ url: location.href.slice(0, 60), origin: self.origin, iframes: [...document.querySelectorAll('iframe')].map((f) => { try { return f.contentWindow.location.pathname.replace(/^\/vfs\/[^/]+/, '') + ' ready=' + !!(f.contentWindow.Reveal && f.contentWindow.Reveal.isReady()) + ' title=' + f.contentDocument.title + ' body=' + f.contentDocument.body.innerText.slice(0, 30); } catch (e) { return 'blocked ' + e.name; } }) })).catch((e) => 'eval failed ' + e.message.slice(0, 80)) : 'no popup';
    out.speakerBadResponses = [...new Set(bad)].slice(0, 6);
    await ctx2.close();
  } catch (e) { out.error = String(e.stack).slice(0, 400); }
  finally { await Promise.race([browser.close(), L.sleep(5000)]); await app.close(); await player.close(); }
  out.playerStaticLog = player.log.filter((l) => l.url.startsWith('/vfs/')).slice(0, 5);
  fs.writeFileSync(`${L.DIR}/out/q1q2-${mode}${flags.length ? '-' + flags.join('').replace(/[^a-z]/gi, '').slice(0, 30) : ''}.json`, JSON.stringify(out, null, 1)); console.log(JSON.stringify(out, null, 1));
})();
