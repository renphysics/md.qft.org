// Real host names (resolver-mapped to 127.0.0.1): same-site subdomain vs different registrable domain vs *.github.io. Process model, freeze, partitioning.
const L = require('./lib.cjs'); const fs = require('node:fs'); const H = require('./hostile/battery.js');
const APP = 'http://md.qft.test:4620'; const PLAYERS = { 'same-site subdomain (player.qft.test)': 'http://player.qft.test:4622', 'other registrable domain (player.example-player.test)': 'http://player.example-player.test:4622', 'github.io project host (qft-player.github.io)': 'http://qft-player.github.io:4622' };
(async () => {
  const app = await L.startStatic(4620, L.DIR + '/app'); const player = await L.startStatic(4622, L.DIR + '/player2'); const out = {};
  const browser = await L.realLaunch(['--host-resolver-rules=MAP *.test 127.0.0.1, MAP *.github.io 127.0.0.1', '--unsafely-treat-insecure-origin-as-secure=' + [APP, ...Object.values(PLAYERS)].join(',')]);
  try {
    for (const [name, PLAYER] of Object.entries(PLAYERS)) {
      const context = await browser.newContext(); const page = await context.newPage(); await page.goto(`${APP}/app.html?player=${encodeURIComponent(PLAYER)}&fsrc=1`); const o = await page.evaluate((x) => window.openV2(x), { files: H.files, headers: { 'Cache-Control': 'no-store' } });
      const frame = page.frames().find((f) => f.url().includes('/vfs/')); const r = { appSecure: await page.evaluate(() => isSecureContext), ack: o.ack && o.ack.type, bootErr: o.bootInfo && o.bootInfo.report && o.bootInfo.report.swErr };
      if (frame) { r.deck = await frame.evaluate(() => { localStorage.setItem('deck-ls', 'DECK-LS'); return { origin: self.origin, controlled: !!navigator.serviceWorker.controller }; }); r.targets = (await L.targets(browser)).targets.filter((t) => !t.startsWith('service_worker')).map((t) => t.replace(/\?.*/, '').replace(/vfs\/[0-9a-f]+/, 'vfs/T'));
        const top = await context.newPage(); await top.goto(PLAYER + '/boot.html'); r.topLevelVisitSeesDeckStorage = await top.evaluate(async () => ({ ls: localStorage.getItem('deck-ls'), regs: (await navigator.serviceWorker.getRegistrations()).length })); const nav = await top.goto(frame.url()); r.topLevelDeckUrl = nav.status() + ' ' + (await top.title()); await top.close();
        await frame.evaluate(() => { setTimeout(() => { for (;;) {} }, 200); }); await L.sleep(700); const raf = await L.withTimeout(page.evaluate(() => new Promise((res) => { window.__raf.length = 0; setTimeout(() => res(window.__raf.length), 1000); })), 4000); r.appFramesIn1sDuringDeckLoop = raf.value;
        const t0 = Date.now(); const c = await L.withTimeout(page.locator('#stop').click({ timeout: 3000 }).then(() => 'clicked', () => 'click timed out'), 4000); r.stop = c.value + ' after ' + (Date.now() - t0) + ' ms'; }
      out[name] = r; await Promise.race([context.close(), L.sleep(3000)]);
    }
  } catch (e) { out.error = String(e.stack).slice(0, 400); }
  finally { await Promise.race([browser.close(), L.sleep(5000)]); for (const s of [app, player]) await s.close(); }
  fs.writeFileSync(`${L.DIR}/out/q8.json`, JSON.stringify(out, null, 1)); console.log(JSON.stringify(out, null, 1));
})();
