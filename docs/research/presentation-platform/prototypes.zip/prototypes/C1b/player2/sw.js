// Hardened player worker (C1b). Files live only in memory; a session is addressed by an unguessable token; control only over the
// MessagePort that arrived with the session. TEST-ONLY: 'headers'/'htmlOnly' in the session message let experiments vary the policy.
const sessions = new Map(); const TOKEN = /^[0-9a-f]{32}$/; const BORN = Date.now();
const dir = (t) => self.location.origin + '/vfs/' + t + '/';
const POLICIES = {
  offline: (t) => ({ 'Content-Security-Policy': `default-src ${dir(t)} 'unsafe-inline' 'unsafe-eval' data: blob:; connect-src ${dir(t)} data: blob:; frame-src ${dir(t)} data: blob:; worker-src ${dir(t)} blob:; object-src 'none'; base-uri ${dir(t)}; form-action 'none'`,
    'Referrer-Policy': 'no-referrer', 'X-Content-Type-Options': 'nosniff', 'Cache-Control': 'no-store', 'Cross-Origin-Resource-Policy': 'same-origin',
    'Permissions-Policy': 'geolocation=(), camera=(), microphone=(), display-capture=(), usb=(), serial=(), hid=(), bluetooth=(), payment=(), midi=(), clipboard-read=(), publickey-credentials-get=(), idle-detection=(), window-management=(), local-fonts=(), browsing-topics=(), attribution-reporting=()' }),
  network: (t) => ({ ...POLICIES.offline(t), 'Content-Security-Policy': (() => { const cdn = 'https://cdn.jsdelivr.net https://cdnjs.cloudflare.com https://unpkg.com'; return `default-src ${dir(t)} 'unsafe-inline' 'unsafe-eval' data: blob:; script-src ${dir(t)} 'unsafe-inline' 'unsafe-eval' blob: ${cdn}; style-src ${dir(t)} 'unsafe-inline' ${cdn} https://fonts.googleapis.com; font-src ${dir(t)} data: ${cdn} https://fonts.gstatic.com; img-src ${dir(t)} data: blob:; connect-src ${dir(t)} data: blob:; frame-src ${dir(t)} data: blob:; worker-src ${dir(t)} blob:; object-src 'none'; base-uri ${dir(t)}; form-action 'none'`; })() }),
};
self.addEventListener('install', (e) => e.waitUntil(self.skipWaiting()));
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));
self.addEventListener('message', (e) => {
  const m = e.data; const port = e.ports && e.ports[0];
  if (m && m.type === 'list-attempt') { e.source.postMessage({ type: 'list-reply', note: 'no listing API', born: BORN }); return; }
  if (!m || m.type !== 'session' || !port || !TOKEN.test(m.token) || sessions.has(m.token)) { if (port) port.postMessage({ type: 'refused' }); return; }
  const files = new Map(m.files.map((f) => [f.path, { bytes: f.bytes, type: f.type }]));
  sessions.set(m.token, { files, headers: m.headers || (POLICIES[m.policy] || POLICIES.offline)(m.token), htmlOnly: !!m.htmlOnly, mediate: !!m.mediate });
  port.onmessage = (ev) => { const c = ev.data || {}; if (c.type === 'put') files.set(c.path, { bytes: c.bytes, type: c.type }); else if (c.type === 'close') sessions.delete(m.token); else if (c.type === 'ping') port.postMessage({ type: 'pong', sessions: sessions.size, born: BORN }); };
  port.postMessage({ type: 'ready', token: m.token, born: BORN });
});
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin) { // cross-origin request made by a controlled client
    const tokOf = async () => { const c = event.clientId ? await self.clients.get(event.clientId) : null; return c ? new URL(c.url).pathname.split('/')[2] : null; };
    event.respondWith((async () => { const s = sessions.get(await tokOf()); if (s && !s.mediate) return fetch(event.request); // legacy pass-through (experiments A-C)
      const f = s && s.files.get('ext:' + url.origin + url.pathname); // 'localised' copy fetched earlier by the APP, never by the deck
      if (!f) return new Response('blocked by player worker: not a localised dependency', { status: 404, headers: { 'content-type': 'text/plain' } });
      return new Response(f.bytes.slice(0), { status: 200, headers: { 'content-type': f.type, 'access-control-allow-origin': '*' } }); })()); return; }
  if (url.pathname === '/boot.html' || url.pathname === '/sw.js' || url.pathname === '/csd') return; // static files, from the network
  event.respondWith((async () => {
    const seg = url.pathname.split('/'); const s = seg[1] === 'vfs' ? sessions.get(seg[2]) : null;
    if (!s) return new Response('no such session', { status: 404, headers: { 'content-type': 'text/plain', 'x-player': 'no-session' } });
    let path; try { path = decodeURIComponent(seg.slice(3).join('/')); } catch { path = ''; } if (path === '' || path.endsWith('/')) path += 'index.html';
    const f = s.files.get(path); if (!f) return new Response('not in package', { status: 404, headers: { 'content-type': 'text/plain' } });
    const html = /^text\/html/.test(f.type); const headers = new Headers({ 'content-type': f.type }); if (!s.htmlOnly || html) for (const [k, v] of Object.entries(s.headers)) headers.set(k, v);
    return new Response(f.bytes.slice(0), { status: 200, headers });
  })());
});
