OPEN THIS PRESENTATION

Open this ZIP in https://md.qft.org/ and choose Present. Its files stay in your browser.

This is a compiled Slidev presentation. Browser-based interactions work without a CDN. Browser storage and slide synchronization are private, temporary, in-memory state; they reset when playback restarts.

EDIT THE SOURCE

The source/ folder contains the editable Slidev project. Run npm ci, revise slides.md or components, and run npm run package. Editing source alone does not update presentation.html. See source/README.md for the portable build requirements.

The player cannot read your documents. It blocks ordinary network requests, external scripts, workers, nested frames, forms and dynamic code evaluation, so presentations that require those features need adaptation.
